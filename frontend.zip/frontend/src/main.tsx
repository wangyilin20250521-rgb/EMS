import { createRoot } from "react-dom/client";
import App from "./app/App.tsx";
import "./styles/index.css";

const rootEl = document.getElementById("root")!;
const bootEl = document.getElementById("boot-loading");

// 加载动画最小展示时长（ms）：低带宽下资源加载时间 > 该值时自然延长；
// 本地/快速网络下保证动画完整呈现、不闪跳
const MIN_BOOT_MS = 1200;
const bootStart = performance.now();

createRoot(rootEl).render(<App />);

// React 首次渲染 commit 完成后：至少展示 MIN_BOOT_MS，再淡出移除 loading
const remain = Math.max(0, MIN_BOOT_MS - (performance.now() - bootStart));
setTimeout(() => {
  if (bootEl) {
    bootEl.style.transition = "opacity 350ms ease";
    bootEl.style.opacity = "0";
    setTimeout(() => bootEl.remove(), 400); // 过渡结束后移除节点
  }
}, remain);
