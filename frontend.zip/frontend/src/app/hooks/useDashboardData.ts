import { useCallback, useEffect, useMemo, useState } from "react";
import {
  getDashboardStats,
  getSampleDistribution,
  getReceptionTrend,
  getTatWarnings,
  getDashboardActivities,
  type DashboardDateRange,
} from "@/app/lib/api";
import type {
  ChartDatum,
  DashboardStatCard,
  DashboardActivity,
  TatWarning,
  BarDatum,
} from "@/app/lib/api";
import { fetchSiroDeviceList } from "@/app/lib/api/siro";
import config from "@/app/lib/constants/dashboard-config.json";
import type { StageStat, AlertSummary, HealthSummary } from "@/app/features/dashboard/types";

/** stageTiles 配置条目（dashboard-config.json） */
interface StageTileConfig {
  key: StageStat["key"];
  label: string;
  tone: StageStat["tone"];
  iconAsset: string;
  target: string;
}

const STAGE_TILE_CONFIG = (config.stageTiles as StageTileConfig[]) ?? [];

/** 每卡片独立错误态：单卡失败不阻断整页 */
export interface DashboardErrors {
  stats?: string;
  distribution?: string;
  warnings?: string;
  activities?: string;
  trendSeries?: string;
}

/**
 * 首页数据 Hook（新版卡片 UI 与日期范围筛选融合）：
 * 并行加载各指标（stats/distribution/trend 由 dateRange 驱动，api 层零改动）、
 * SIRO 设备合并、派生阶段瓷砖/预警汇总/健康汇总，暴露手动 refresh 与最后更新时间。
 *
 * @param dateRange  日期范围（缺省 = 今日，DashboardDateRange）
 * @param rangeLabel 范围文案（"今日收样" / "近7日收样" / …），驱动收样卡 label 动态化
 */
export function useDashboardData(dateRange?: DashboardDateRange, rangeLabel?: string) {
  const [stats, setStats] = useState<DashboardStatCard[]>([]);
  const [distribution, setDistribution] = useState<ChartDatum[]>([]);
  const [tatWarnings, setTatWarnings] = useState<TatWarning[]>([]);
  const [activities, setActivities] = useState<DashboardActivity[]>([]);
  const [trendBarData, setTrendBarData] = useState<BarDatum[]>([]);
  const [errors, setErrors] = useState<DashboardErrors>({});
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setErrors({});

    // 每卡片独立 try/catch：单卡失败仅该卡显示错误占位
    const [statsRes, distRes, trendRes, tatRes, actRes, siroDevs] = await Promise.all([
      getDashboardStats(dateRange).catch(e => e),
      getSampleDistribution(dateRange).catch(e => e),
      getReceptionTrend(dateRange).catch(e => e),
      getTatWarnings().catch(e => e),
      getDashboardActivities().catch(e => e),
      fetchSiroDeviceList().catch(() => []),
    ]);

    const nextErrors: DashboardErrors = {};

    // SIRO 设备合并（沿用现有逻辑）
    const siroOnline = siroDevs.filter((d: { status?: string }) => d.status === "ONLINE").length;
    const siroTotal = siroDevs.length;

    if (Array.isArray(statsRes)) {
      // 收样卡：label 随范围动态；范围模式副指标格式切换为日均（后端已返回 daily-avg）
      const withSiro = statsRes.map(stat => {
        if (stat.key === "devices-online")
          return {
            ...stat,
            value: stat.value + siroOnline,
            subMetrics: [{ label: "total-devices", value: (stat.subMetrics?.[0]?.value ?? 0) + siroTotal }],
          };
        if (stat.key === "running-tasks")
          return {
            ...stat,
            subMetrics: [{ label: "running-devices", value: (stat.subMetrics?.[0]?.value ?? 0) + siroOnline }],
          };
        return stat;
      });
      setStats(
        rangeLabel
          ? withSiro.map(stat =>
              stat.key === "today-received"
                ? { ...stat, label: rangeLabel, subFormat: rangeLabel === "今日收样" ? stat.subFormat : ("dailyAvg" as const) }
                : stat,
            )
          : withSiro,
      );
    } else {
      nextErrors.stats = statsRes?.message ?? "指标加载失败";
    }

    if (Array.isArray(distRes)) setDistribution(distRes);
    else nextErrors.distribution = distRes?.message ?? "分布数据加载失败";

    if (Array.isArray(trendRes)) setTrendBarData(trendRes);
    else nextErrors.trendSeries = trendRes?.message ?? "收样趋势数据加载失败";

    if (Array.isArray(tatRes)) setTatWarnings(tatRes);
    else nextErrors.warnings = tatRes?.message ?? "预警数据加载失败";

    if (Array.isArray(actRes)) setActivities(actRes);
    else nextErrors.activities = actRes?.message ?? "活动数据加载失败";

    setErrors(nextErrors);
    setLastUpdate(new Date().toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" }));
    setLoading(false);
  }, [dateRange, rangeLabel]);

  useEffect(() => {
    void load();
  }, [load]);

  /** 阶段瓷砖：completed 取状态分布"完成"数，其余沿用 statCards 键位（dashboard-config.json stageTiles）；
   * 收样瓷砖 label 随范围动态（今日收样/近7日收样/…），与图表标题口径一致，避免与状态分布类目"已收样"混淆 */
  const stageStats: StageStat[] = useMemo(() => {
    return STAGE_TILE_CONFIG.map(t => {
      const value =
        t.key === "completed"
          ? distribution.find(d => d.name === "完成")?.value ?? 0
          : stats.find(s => s.key === t.key)?.value ?? 0;
      return {
        key: t.key,
        label: t.key === "today-received" && rangeLabel ? rangeLabel : t.label,
        value,
        tone: t.tone,
        iconAsset: t.iconAsset,
        target: t.target as StageStat["target"],
      };
    });
  }, [stats, distribution, rangeLabel]);

  /** 预警汇总：getTatWarnings 按 isOverdue 分组 */
  const alertSummary: AlertSummary = useMemo(
    () => ({
      overdue: tatWarnings.filter(w => w.isOverdue).length,
      warning: tatWarnings.filter(w => !w.isOverdue).length,
    }),
    [tatWarnings],
  );

  /** 运行健康：devices-online（含 SIRO 合并）派生 */
  const healthSummary: HealthSummary | null = useMemo(() => {
    const card = stats.find(s => s.key === "devices-online");
    if (!card) return null;
    return { online: card.value, total: card.subMetrics?.[0]?.value ?? card.value };
  }, [stats]);

  return {
    stats,
    distribution,
    tatWarnings,
    activities,
    trendBarData,
    errors,
    loading,
    lastUpdate,
    stageStats,
    alertSummary,
    healthSummary,
    refresh: load,
  };
}

export type UseDashboardDataResult = ReturnType<typeof useDashboardData>;
