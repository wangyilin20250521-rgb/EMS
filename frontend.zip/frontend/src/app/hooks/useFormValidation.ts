import { useState } from 'react'
import type { z } from 'zod'
import type { FieldError, ValidationResult } from '../lib/validation'
import { zodIssuesToFieldErrors } from '../lib/validation'

export function useFormValidation<T>(schema: z.ZodType<T>) {
  const [errors, setErrors] = useState<FieldError[]>([])

  const validate = (input: unknown): ValidationResult<T> => {
    const result = schema.safeParse(input)

    if (result.success) {
      setErrors([])
      return { success: true, data: result.data }
    }

    const fieldErrors = zodIssuesToFieldErrors(result.error.issues)
    setErrors(fieldErrors)
    return { success: false, errors: fieldErrors }
  }

  const clearErrors = (field?: string) => {
    setErrors((current) => field ? current.filter((error) => error.field !== field) : [])
  }

  const getFieldError = (field: string) => errors.find((error) => error.field === field)

  return { validate, errors, clearErrors, getFieldError }
}
