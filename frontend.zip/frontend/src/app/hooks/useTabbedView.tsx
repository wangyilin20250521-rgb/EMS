import React, { useState } from "react";

export interface TabConfig {
  value: string;
  label: string;
  count?: number;
}

export interface TabBarProps {
  tabs: TabConfig[];
  active: string;
  onChange: (value: string) => void;
  showCounts?: boolean;
  trailing?: React.ReactNode;
}

/**
 * 页内标签切换状态
 * @example
 * const { activeTab, setActiveTab } = useTabbedView<TabType>(initialTab)
 */
export function useTabbedView<T extends string>(initialTab: T) {
  const [activeTab, setActiveTab] = useState<T>(initialTab);
  return { activeTab, setActiveTab };
}

/** 胶囊样式标签栏，可选数量徽章与右侧附加内容 */
export function TabBar({ tabs, active, onChange, showCounts = true, trailing }: TabBarProps) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="flex items-center gap-1 bg-muted/40 rounded-lg p-1">
        {tabs.map(t => {
          const isActive = t.value === active;
          return (
            <button
              key={t.value}
              onClick={() => onChange(t.value)}
              className={`flex items-center gap-1.5 px-4 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                isActive ? "bg-white shadow text-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.label}
              {showCounts && t.count !== undefined && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary font-semibold">
                  {t.count}
                </span>
              )}
            </button>
          );
        })}
      </div>
      {trailing && <div className="shrink-0">{trailing}</div>}
    </div>
  );
}
