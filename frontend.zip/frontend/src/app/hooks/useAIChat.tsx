import React, { createContext, useCallback, useContext, useEffect, useReducer, useRef, useState } from "react"
import { toast } from "sonner"
import { useAuth } from "./useAuth"
import { getConversations, getConversationById, getApiConfig, importSamplesFromExcel, type ConversationSummary } from "../lib/api"
import { getAuthToken } from "../lib/api/http"
import { streamChat, answerChatQuestion, submitFormChat, continueChat, type ActionProposal, type QuestionSpec, type FormRequestSpec, type FileRequestSpec } from "../lib/utils/sse"
import { buildStreamCallbacks } from "../lib/chat/stream-turn"
import { confirmAiAction, cancelAiAction, getSessionAiActions, uploadAttachment } from "../lib/api/ai"
import type { ComposerAttachment } from "@/app/components/shared/ChatComposer"
import { chatReducer, type AIMessage } from "../features/ai-assistant/state/chatReducer.js"
import { normalizeConversationMessages, attachProposals, attachQuestions } from "../features/ai-assistant/state/history.js"

// 类型与历史恢复纯函数已拆至 features/ai-assistant/state/（reducer + history）；
// 此处 re-export 维持旧导入路径兼容
export type { AIMessage, AIProcessItem } from "../features/ai-assistant/state/chatReducer.js"
export { normalizeConversationMessages, attachProposals, attachQuestions } from "../features/ai-assistant/state/history.js"

/** 参数表单（schema 驱动表单卡；request_form → form_request 事件进入） */
export interface ActiveForm {
  requestId: string;
  toolName: string;
  explanation?: string;
  fieldHints?: FormRequestSpec["fieldHints"];
  /** ready=待填写 / submitting=提交续流中 / submitted=已提交（AI 将 propose） */
  status: "ready" | "submitting" | "submitted";
  error?: string;
  /** 已提交收据摘要（历史恢复用：structured.forms 回填，人类可读无 JSON） */
  submittedSummary?: string;
}

/** 文件上传卡（request_file → file_request；对话内直传样本 Excel） */
export interface ActiveFileUpload {
  requestId: string;
  /** AI 写的上传用途说明（卡片顶部展示） */
  purpose: string;
  /** 接受的文件类型（如 ".xlsx,.xls,.csv"） */
  accept: string;
  /** ready=待上传 / uploading=上传中 / done=已上传（结果已注入续流） */
  status: "ready" | "uploading" | "done";
  /** 上传结果摘要（done 态展示） */
  result?: string;
  error?: string;
}

/** 向导卡步骤（分步向导：写操作参数逐项确认聚合为单卡多步） */
export interface WizardStep {
  questionId: string
  question: string
  field?: string
  options?: string[]
  /** 多选步骤（候选列表勾选；提交值「、」分隔） */
  multi?: boolean
  /** 用户已选值（answered 时有值） */
  answer?: string
  status: "pending" | "answered"
  ts: number
}

interface AIChatContextValue {
  messages: AIMessage[]
  streaming: boolean
  sessionId: string | null
  conversations: ConversationSummary[]
  activeConversationId: string | null
  sendMessage: (text: string) => void
  stopGeneration: () => void
  newConversation: () => void
  openConversation: (id: string) => void
  deleteConversation: (id: string) => void
  loadConversations: () => void
  /** 确认/取消 AI 写操作提议（调 agent-server /api/actions 端点） */
  confirmAction: (proposalId: string) => Promise<void>
  cancelAction: (proposalId: string) => Promise<void>
  /** 回答 AI 结构化提问（POST /api/chat/answer 续流）；field=问题归属的参数键（mustAsk gate 证据） */
  answerQuestion: (questionId: string, answer: string, field?: string) => void
  /** 分步向导：写操作参数确认的跨轮聚合步骤；null = 无向导 */
  wizardSteps: WizardStep[] | null
  /** 向导步选择提交：标记已答 + 走 /api/chat/answer 续流 */
  wizardAnswer: (questionId: string, answer: string, field?: string) => void
  /** 参数表单（schema 驱动表单卡）；null = 无表单 */
  activeForm: ActiveForm | null
  /** 提交表单：登记证据 + AI 续流 propose（POST /api/chat/form-submit） */
  submitForm: (toolName: string, values: Record<string, unknown>, optionsByField: Record<string, string[]>) => void
  /** 关闭参数表单卡 */
  dismissForm: () => void
  /** 文件上传卡（对话内直传样本 Excel）；null = 无 */
  activeFileUpload: ActiveFileUpload | null
  /**待发送的聊天附件（composer chips；随下一条消息发给 AI） */
  chatAttachments: ComposerAttachment[]
  addChatFiles: (files: File[]) => void
  removeChatAttachment: (id: string) => void
  /** 上传样本 Excel：调 web-server 导入 → 结果注入续流（AI 汇报排单） */
  uploadSamplesFile: (file: File, batchId?: string) => Promise<void>
  /** 关闭文件上传卡 */
  dismissFileUpload: () => void
  /** 对 pending 提议提交修改意见：静默取消旧提议 → AI 按意见重新生成建议卡 */
  reviseProposal: (proposalIds: string[], text: string) => Promise<void>
}

const AIChatContext = createContext<AIChatContextValue | null>(null)

const WELCOME: AIMessage = {
  role: "ai",
  text: "你好！我是 EMS 助手。你可以问我样本状态、设备情况、TAT超期等问题。",
}

function generateSessionId(): string {
  return `conv-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
}

export function AIChatProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth()
  const [messages, dispatch] = useReducer(chatReducer, [WELCOME])
  const [streaming, setStreaming] = useState(false)
  const [sessionId, setSessionId] = useState<string | null>(null)
  const [conversations, setConversations] = useState<ConversationSummary[]>([])
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null)
  /** 分步向导步骤：带 field 的 ask_user 跨轮聚合；普通消息/换会话清空 */
  const [wizardSteps, setWizardSteps] = useState<WizardStep[] | null>(null)
  /** 参数表单：request_form 进入；表单到达清空向导；提交/关闭后清空 */
  const [activeForm, setActiveForm] = useState<ActiveForm | null>(null)
  /** 文件上传卡：request_file 进入；上传完成结果注入续流 */
  const [activeFileUpload, setActiveFileUpload] = useState<ActiveFileUpload | null>(null)
  const [chatAttachments, setChatAttachments] = useState<ComposerAttachment[]>([])
  const abortRef = useRef<AbortController | null>(null)

  // 卸载清理:AI 流式回复/请求进行中切走页面时中断,避免旧实例回调竞态导致页面崩溃
  useEffect(() => {
    return () => {
      abortRef.current?.abort()
      abortRef.current = null
    }
  }, [])
  /** 进行中的确认请求（防重复点击） */
  const confirmingRef = useRef<Set<string>>(new Set())
  /** 确认执行后的自动续流触发器（buildTurnCallbacks 就绪后经 effect 赋值，避免声明顺序耦合） */
  const continuationRef = useRef<() => void>(() => {})
  /** 当前打开会话（openConversation 异步注入 pending 时防竞态：切会话后丢弃迟到恢复） */
  const activeConversationIdRef = useRef<string | null>(null)

  // Reset everything when user identity changes (login/logout/switch account)
  const usernameKey = user?.username ?? ""

  const loadConversations = useCallback(() => {
    getConversations()
      .then(setConversations)
      .catch(() => setConversations([]))
  }, [])

  useEffect(() => {
    dispatch({ type: "setMessages", messages: [WELCOME] })
    setSessionId(null)
    setActiveConversationId(null)
    activeConversationIdRef.current = null
    setConversations([])
    setWizardSteps(null)
    setActiveForm(null)
    setActiveFileUpload(null)
    loadConversations()
    // 不再全局恢复 pending 挂到新对话——恢复卡按会话归属注入
    // （openConversation 里拉取该会话自己的未决提议），新对话顶部不会出现无关确认卡
  }, [usernameKey, loadConversations])

  /** 更新某条提议在消息中的状态（确认/取消/失败后回填） */
  const updateProposalStatus = useCallback((proposalId: string, patch: Partial<ActionProposal>) => {
    dispatch({ type: "updateProposal", proposalId, patch })
  }, [])

  /** 确认并执行 AI 写操作提议（POST /api/actions/:id/confirm，携用户 JWT） */
  const confirmAction = useCallback(async (proposalId: string) => {
    if (confirmingRef.current.has(proposalId)) return
    confirmingRef.current.add(proposalId)
    try {
      const r = await confirmAiAction(proposalId)
      if (r.ok) {
        const result = r.result
        const summary = result && typeof result === "object"
          ? String((result as { message?: string }).message ?? "")
          : typeof result === "string" ? result : ""
        updateProposalStatus(proposalId, { status: "confirmed", result: summary || undefined })
        toast.success("操作已执行")
        // 自动续流：确认执行后叫醒 AI 继续后续流程（如下一步写操作提议）；
        // 无后续步骤时简短收尾。此前链路断点：确认后 AI 不会自己继续，用户要手动催
        continuationRef.current?.()
      } else {
        // 403"仅提议人本人或管理员"等后端文案原样展示
        updateProposalStatus(proposalId, { status: "failed", result: r.message })
        toast.error(r.message)
      }
    } catch {
      updateProposalStatus(proposalId, { status: "failed", result: "网络错误" })
      toast.error("网络错误，请重试")
    } finally {
      confirmingRef.current.delete(proposalId)
    }
  }, [updateProposalStatus])

  /** 取消 AI 写操作提议（POST /api/actions/:id/cancel） */
  const cancelAction = useCallback(async (proposalId: string) => {
    if (confirmingRef.current.has(proposalId)) return
    confirmingRef.current.add(proposalId)
    try {
      const r = await cancelAiAction(proposalId)
      if (r.ok) {
        updateProposalStatus(proposalId, { status: "cancelled" })
        toast.success("已取消")
      } else {
        toast.error(r.message)
      }
    } catch {
      toast.error("网络错误，请重试")
    } finally {
      confirmingRef.current.delete(proposalId)
    }
  }, [updateProposalStatus])

  const stopGeneration = useCallback(() => {
    if (abortRef.current) { abortRef.current.abort(); abortRef.current = null }
    setStreaming(false)
    dispatch({ type: "finishStreaming" })
  }, [])

  // 构建 SSE 回调集（sendMessage 与 answerQuestion 共用；逻辑收编
  // lib/chat/stream-turn 引擎——rAF 节流/tool_update 尾行/KB 溯源行等差异统一由引擎处理，
  // 页面只留消息列表形态的差异：applyStreamPatch=合入最后一条 streaming 消息、errorBubble=替换为错误气泡）
  // 参数表单请求：request_form → form_request → 打开表单卡（替代逐问向导）
  const handleFormRequest = useCallback((req: FormRequestSpec) => {
    setWizardSteps(null) // 表单 supersede 逐问收集
    setActiveForm(prev => ({ requestId: req.requestId, toolName: req.toolName, explanation: req.explanation, fieldHints: req.fieldHints, status: "ready" as const }))
  }, [])

  // 带 field 提问 → 向导步骤：同会话连续参数确认聚合为分步向导卡
  const handleFieldQuestion = useCallback((q: QuestionSpec) => {
    setWizardSteps(prev => {
      if (prev?.some(s => s.questionId === q.questionId)) return prev // 去重（同问题重发）
      const step: WizardStep = {
        questionId: q.questionId, question: q.question, field: q.field,
        options: q.options, multi: q.multi, status: "pending", ts: Date.now(),
      }
      return [...(prev ?? []), step]
    })
  }, [])

  // 文件上传请求：request_file → file_request → 打开对话内上传卡
  // （全链路演示"上传自己的 Excel"：用户留在 AI 页面直传，不再跳样本中心模块）
  const handleFileRequest = useCallback((req: FileRequestSpec) => {
    setWizardSteps(null)
    setActiveForm(null)
    setActiveFileUpload({ requestId: req.requestId, purpose: req.purpose, accept: req.accept, status: "ready" })
  }, [])

  // 工作任务完整状态由 agent-server 持久化；通知工作台立即刷新，无需等轮询周期。
  const handleTaskUpdate = useCallback(() => {
    window.dispatchEvent(new CustomEvent("mlims:ai-task-update"))
  }, [])

  const buildTurnCallbacks = useCallback((pendingId: string) => buildStreamCallbacks({
    idPrefix: pendingId,
    onFieldQuestion: handleFieldQuestion,
    onFormRequest: handleFormRequest,
    onFileRequest: handleFileRequest,
    onTaskUpdate: handleTaskUpdate,
    apply: (patch) => {
      dispatch({ type: "applyStreamPatch", patch })
    },
    onDone: () => {
      setStreaming(false)
      abortRef.current = null
      loadConversations()
      dispatch({ type: "finishStreaming" })
    },
    onError: (msg) => {
      abortRef.current = null
      setStreaming(false)
      loadConversations()
      dispatch({ type: "errorBubble", text: `连接失败：${msg}` })
    },
  }), [loadConversations, handleFieldQuestion, handleFormRequest, handleFileRequest, handleTaskUpdate])

  /** 确认执行后自动续流：触发 /api/chat/continue 让 AI 继续后续流程步骤；
   * 续流指令为系统通知语义（历史展示层隐藏），用户侧只看到 AI 的继续回复。 */
  const startContinuation = useCallback(() => {
    if (!sessionId || streaming) return
    if (abortRef.current) { abortRef.current.abort(); abortRef.current = null }
    setStreaming(true)
    const pendingId = `${sessionId}-continue-${Date.now()}`
    dispatch({ type: "append", message: { id: pendingId, role: "ai", text: "", process: [], streaming: true } })
    const controller = continueChat(sessionId, buildTurnCallbacks(pendingId))
    abortRef.current = controller
  }, [sessionId, streaming, buildTurnCallbacks])
  useEffect(() => { continuationRef.current = startContinuation }, [startContinuation])

  const sendMessage = useCallback((text: string) => {
    if (!text.trim() || streaming) return
    if (abortRef.current) { abortRef.current.abort(); abortRef.current = null }
    setWizardSteps(null) // 普通消息 = 向导收尾
    setActiveForm(null)
    setActiveFileUpload(null)

    // 待发送附件：上传中的不发（ChatComposer 已禁用发送），发完即清空 chips
    const atts = chatAttachments.filter(a => !a.uploading)
    setChatAttachments([])

    const currentSessionId = sessionId ?? generateSessionId()
    if (!sessionId) setSessionId(currentSessionId)

    const msgId = `${currentSessionId}-response-${Date.now()}`
    // 用户气泡追加附件名（附件正文由 AI 经 read_attachment 读取，不进消息）
    const attachmentLines = atts.map(a => `📎 ${a.name}`).join("\n")
    const displayText = atts.length > 0 ? `${text}\n${attachmentLines}` : text
    dispatch({ type: "append", message: { id: `${currentSessionId}-user-${Date.now()}`, role: "user", text: displayText } })
    setStreaming(true)
    dispatch({ type: "append", message: { id: msgId, role: "ai", text: "", process: [], streaming: true } })

    // SSE via shared streamChat utility + lib/chat 引擎
    const controller = streamChat(text, buildTurnCallbacks(msgId), {
      sessionId: currentSessionId,
      ...(atts.length > 0 ? { attachments: atts.map(a => ({ id: a.id, name: a.name, kind: a.kind })) } : {}),
    })
    abortRef.current = controller
  }, [sessionId, streaming, loadConversations, buildTurnCallbacks, chatAttachments])

  const newConversation = useCallback(() => {
    stopGeneration()
    dispatch({ type: "setMessages", messages: [WELCOME] })
    setSessionId(null)
    setActiveConversationId(null)
    setWizardSteps(null)
    setActiveForm(null)
    setActiveFileUpload(null)
    activeConversationIdRef.current = null
    loadConversations()
  }, [stopGeneration, loadConversations])

  const deleteConversation = useCallback(async (id: string) => {
    setConversations(prev => prev.filter(c => c.sessionId !== id))
    if (activeConversationId === id) {
      dispatch({ type: "setMessages", messages: [WELCOME] })
      setSessionId(null)
      setActiveConversationId(null)
      activeConversationIdRef.current = null
    }
    try {
      // agent-server 已要求 JWT 鉴权，删除接口带 Bearer
      const token = getAuthToken()
      const res = await fetch(`${getApiConfig().agentUrl}/api/conversations/${encodeURIComponent(id)}`, {
        method: "DELETE",
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      })
      if (res.ok) loadConversations()
    } catch (err) {
      console.error("Delete conversation failed:", err)
    }
  }, [activeConversationId, loadConversations])

  const openConversation = useCallback((id: string) => {
    stopGeneration()
    setActiveConversationId(id)
    setWizardSteps(null)
    setActiveForm(null)
    setActiveFileUpload(null)
    activeConversationIdRef.current = id
    // 并行拉取：会话文档 + 该会话全部提议（卡片恢复——含终态/过期归一，
    // 按 ts 挂回原 AI 消息，重开后确认卡/收据样式与当时一致；替代旧"仅 pending 追加末尾"）
    Promise.all([
      getConversationById(id).catch(() => null),
      getSessionAiActions(id).catch(() => [] as ActionProposal[]),
    ]).then(([conv, actions]) => {
      if (activeConversationIdRef.current !== id) return // 异步返回前用户切走/新开对话 → 丢弃迟到恢复
      if (conv) {
        const msgs = normalizeConversationMessages(conv.messages)
        attachProposals(msgs, actions)
        attachQuestions(msgs, conv.structured?.questions ?? [])
        dispatch({ type: "setMessages", messages: msgs })
        setSessionId(conv.id)
        // 提问卡结构化恢复——已答步骤/未答问题按原形态回填向导（否则退化为纯文本）
        setWizardSteps(
          conv.structured?.questions?.length
            ? conv.structured.questions.map(q => ({
                questionId: q.questionId, question: q.question, field: q.field,
                options: q.options, answer: q.answerText,
                status: q.answered ? ("answered" as const) : ("pending" as const),
                ts: q.ts,
              }))
            : null
        )
        // 参数表单收据恢复——最近一次提交回填"已提交"收据卡
        // （之前只落一行原始文本/JSON 摘要，切页/重开后无卡片形态）
        const lastForm = conv.structured?.forms?.length
          ? conv.structured.forms[conv.structured.forms.length - 1]
          : null
        setActiveForm(lastForm
          ? { requestId: `restored-form-${lastForm.ts}`, toolName: lastForm.toolName, status: "submitted" as const, submittedSummary: lastForm.summary }
          : null
        )
      } else if (actions.length > 0) {
        // 会话文档缺失但存在提议记录 → 至少恢复卡片（极端兜底）
        const msgs: AIMessage[] = []
        attachProposals(msgs, actions)
        dispatch({ type: "setMessages", messages: msgs })
      }
    }).catch(() => { /* 恢复失败静默，确认卡可稍后重试 */ })
  }, [stopGeneration])

  /** 回答 AI 结构化提问：标记卡片已答 → POST /api/chat/answer 续流 */
  const answerQuestion = useCallback((questionId: string, answer: string, field?: string, opts?: { onError?: (msg: string) => void }) => {
    // 流式期间点击静默忽略会让用户困惑"点了没反应/是不是又问了一遍" → 明确提示
    if (!sessionId || streaming) {
      if (streaming) toast.info("AI 正在回复中，请等待本轮完成后再操作")
      return
    }
    if (abortRef.current) { abortRef.current.abort(); abortRef.current = null }

    // 标记对应问题卡片已答（answered 为前端本地字段）
    dispatch({ type: "markQuestionAnswered", questionId })

    setStreaming(true)
    const pendingId = `${sessionId}-answer-${Date.now()}`
    dispatch({ type: "append", message: { id: pendingId, role: "ai", text: "", process: [], streaming: true } })

    // field 随回答提交（mustAsk gate：后端据此登记结构化确认证据）
    // 提交失败（Empty answer/网络等）时挂 onError 钩子（向导步据此回滚为待答，避免"参数确认完成"假象）
    const base = buildTurnCallbacks(pendingId)
    const cb = opts?.onError && base.onError
      ? { ...base, onError: (msg: string) => { opts.onError!(msg); base.onError?.(msg); } }
      : base
    const controller = answerChatQuestion(sessionId, questionId, answer, cb, field)
    abortRef.current = controller
  }, [sessionId, streaming, buildTurnCallbacks])

  /** 提交参数表单：POST /api/chat/form-submit → AI 续流 propose；失败回滚 ready */
  const submitForm = useCallback((toolName: string, values: Record<string, unknown>, optionsByField: Record<string, string[]>) => {
    if (!sessionId || streaming || !activeForm) return
    if (abortRef.current) { abortRef.current.abort(); abortRef.current = null }
    setActiveForm(prev => (prev ? { ...prev, status: "submitting", error: undefined } : prev))
    setStreaming(true)
    const pendingId = `${sessionId}-form-${Date.now()}`
    dispatch({ type: "append", message: { id: pendingId, role: "ai", text: "", process: [], streaming: true } })
    const base = buildTurnCallbacks(pendingId)
    const cb = {
      ...base,
      onDone: (count: number) => {
        setActiveForm(prev => (prev ? { ...prev, status: "submitted" as const } : prev))
        base.onDone?.(count)
      },
      onError: (msg: string) => {
        setActiveForm(prev => (prev ? { ...prev, status: "ready" as const, error: msg } : prev))
        base.onError?.(msg)
      },
    }
    const controller = submitFormChat(sessionId, toolName, values, optionsByField, cb)
    abortRef.current = controller
  }, [sessionId, streaming, activeForm, buildTurnCallbacks])

  /** 关闭参数表单卡（用户取消；不重置 AI 侧状态） */
  const dismissForm = useCallback(() => {
    setActiveForm(null)
  }, [])

  /** *上传样本 Excel（文件上传卡提交）：
   * 调 web-server /samples/excel-import（解析→校验→入库→自动排单）→ 结果经 answer 通道
   * 注入续流（AI 汇报排单/失败原因）。失败（模板校验 400 等）回滚 ready 态展示错误。
   */  const uploadSamplesFile = useCallback(async (file: File, batchId?: string) => {
    if (!sessionId || streaming || !activeFileUpload) return
    if (abortRef.current) { abortRef.current.abort(); abortRef.current = null }
    setActiveFileUpload(prev => (prev ? { ...prev, status: "uploading" as const, error: undefined } : prev))
    try {
      const r = await importSamplesFromExcel(file, "", batchId || "")
      const failNote = (r.errors?.length ?? 0) > 0
        ? `，失败 ${r.errors!.length} 行（${r.errors!.slice(0, 3).map(e => `第 ${e.row} 行：${e.message}`).join("；")}）`
        : ""
      const summary = `成功导入 ${r.imported} 行${failNote}`
      // 注入续流指令：数据已入库（自动排单已由 web-server 触发），AI 只需汇报与引导
      const inject = [
        "【用户回答】我已通过页面上传 Excel 完成样本导入。",
        `- 文件名：${file.name}`,
        `- 导入结果：${summary}`,
        `- 关联批次：${batchId || "未关联"}`,
        r.autoScheduledOrder
          ? `- 自动排单：已创建 ${r.autoScheduledOrder.orderId}（${r.autoScheduledOrder.sampleCount} 例 ${r.autoScheduledOrder.project}，设备 ${r.autoScheduledOrder.deviceType}）`
          : "- 自动排单：未触发（样本数未达阈值或项目未启用自动排单）",
        "请继续：已创建排单则给出排单编号并引导前往排单看板确认；未触发则简要说明原因。不要复述导入明细。",
      ].join("\n")
      setActiveFileUpload(prev => (prev ? { ...prev, status: "done" as const, result: summary } : prev))
      setStreaming(true)
      const pendingId = `${sessionId}-upload-${Date.now()}`
      dispatch({ type: "append", message: { id: pendingId, role: "ai", text: "", process: [], streaming: true } })
      const controller = answerChatQuestion(sessionId, activeFileUpload.requestId, inject, buildTurnCallbacks(pendingId))
      abortRef.current = controller
    } catch (e: unknown) {
      const msg = (e as { message?: string })?.message || "上传失败，请重试"
      setActiveFileUpload(prev => (prev ? { ...prev, status: "ready" as const, error: msg } : prev))
      toast.error(msg.slice(0, 120))
    }
  }, [sessionId, streaming, activeFileUpload, buildTurnCallbacks])

  /** 关闭文件上传卡（用户取消；不重置 AI 侧状态） */
  const dismissFileUpload = useCallback(() => {
    setActiveFileUpload(null)
  }, [])

  /**composer 附件：选择文件 → 乐观占位 chip → 逐个上传 → 成功替换/失败移除并 toast */
  const addChatFiles = useCallback((files: File[]) => {
    for (const file of files.slice(0, 5)) {
      const ext = file.name.slice(file.name.lastIndexOf(".")).toLowerCase()
      const kind = [".png", ".jpg", ".jpeg", ".webp", ".bmp"].includes(ext) ? "image"
        : [".xlsx", ".xls", ".csv"].includes(ext) ? "spreadsheet" : "text"
      const tmpId = `tmp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
      setChatAttachments(prev => [...prev, { id: tmpId, name: file.name, kind, uploading: true }])
      uploadAttachment(file)
        .then(meta => {
          setChatAttachments(prev => prev.map(a => (a.id === tmpId ? { id: meta.id, name: meta.name, kind: meta.kind } : a)))
        })
        .catch((err: unknown) => {
          setChatAttachments(prev => prev.filter(a => a.id !== tmpId))
          toast.error((err as { message?: string })?.message?.slice(0, 120) || "附件上传失败")
        })
    }
  }, [])

  const removeChatAttachment = useCallback((id: string) => {
    setChatAttachments(prev => prev.filter(a => a.id !== id))
  }, [])

  /** *对 pending 提议提交修改意见（确认卡修订）：
   * 静默取消旧提议（用户表达修改意向 = 原建议作废，不弹"已取消"噪音）→
   * 修改意见作为消息发送续流 → AI 重新 propose_action 生成新建议卡；用户满意再点确认执行。
   */  const reviseProposal = useCallback(async (proposalIds: string[], text: string) => {
    const t = text.trim()
    if (!t || streaming || proposalIds.length === 0) return
    for (const id of proposalIds) {
      if (confirmingRef.current.has(id)) continue
      confirmingRef.current.add(id)
      try {
        const r = await cancelAiAction(id)
        if (r.ok) updateProposalStatus(id, { status: "cancelled" })
      } catch { /* 旧提议已超时/已处理：不阻塞修改流程 */ }
      finally { confirmingRef.current.delete(id) }
    }
    sendMessage(`【修改操作建议】${t}（请据此调整参数后重新生成操作建议卡片）`)
  }, [streaming, sendMessage, updateProposalStatus])

  /** 向导步选择提交：标记步骤已答 → 走 answer 续流；下一 field 问题到达时引擎自动 append 步骤。
   *  提交失败（Empty answer/网络）→ onError 回滚该步骤为待答（避免"参数确认完成"假象）。 */
  const wizardAnswer = useCallback((questionId: string, answer: string, field?: string) => {
    if (!sessionId || streaming) return
    setWizardSteps(prev => (prev ?? []).map(s =>
      s.questionId === questionId ? { ...s, answer, status: "answered" as const } : s
    ))
    answerQuestion(questionId, answer, field, {
      onError: () => {
        setWizardSteps(prev => (prev ?? []).map(s =>
          s.questionId === questionId ? { ...s, answer: undefined, status: "pending" as const } : s
        ))
      },
    })
  }, [sessionId, streaming, answerQuestion])

  return React.createElement(AIChatContext.Provider, {
    value: {
      messages, streaming, sessionId, conversations, activeConversationId,
      sendMessage, stopGeneration, newConversation, openConversation, deleteConversation, loadConversations,
      confirmAction, cancelAction, answerQuestion,
      wizardSteps, wizardAnswer,
      activeForm, submitForm, dismissForm,
      activeFileUpload, uploadSamplesFile, dismissFileUpload,
      chatAttachments, addChatFiles, removeChatAttachment,
      reviseProposal
    }
  }, children)
}

export function useAIChat(): AIChatContextValue {
  const ctx = useContext(AIChatContext)
  if (!ctx) throw new Error("useAIChat must be used within AIChatProvider")
  return ctx
}
