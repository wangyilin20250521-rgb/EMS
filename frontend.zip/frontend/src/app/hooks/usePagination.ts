import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import type { PaginationParams } from "../lib/api/types";

export interface UsePaginationOptions<T, F extends object> {
  /** Async fetcher: receives pagination + filter params, returns items or a paginated response. */
  fetcher: (params: PaginationParams & F) => Promise<T[] | { items: T[]; total: number }>;
  /** Page size, default 20. */
  initialPageSize?: number;
  /** Initial filter values. */
  initialFilters?: F;
}

export interface UsePaginationResult<T, F extends object> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  loading: boolean;
  error: string | null;
  /** Jump to a specific page. */
  setPage: (p: number) => void;
  /** Change page size (auto-resets to page 1). */
  setPageSize: (n: number) => void;
  /** Change filters (auto-resets to page 1). */
  setFilters: (f: F) => void;
  /** Refresh current page without changing page number. */
  refresh: () => void;
  /** Locally update matching items on the current page. */
  updateItem: (predicate: (item: T) => boolean, updater: (item: T) => T) => void;
  /** Active filters. */
  filters: F;
}

export function usePagination<T, F extends object = object>(
  options: UsePaginationOptions<T, F>,
): UsePaginationResult<T, F> {
  const { fetcher, initialPageSize = 20, initialFilters = {} as F } = options;

  const [items, setItems] = useState<T[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPageRaw] = useState(1);
  const [pageSize, setPageSizeRaw] = useState(initialPageSize);
  const [filters, setFiltersRaw] = useState<F>(initialFilters);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // 防止并发请求导致数据错乱：只采纳最新一次请求的结果
  const requestIdRef = useRef(0);

  const fetchData = useCallback(async (p: number, ps: number, f: F) => {
    const reqId = ++requestIdRef.current;
    setLoading(true);
    setError(null);
    try {
      const result = await fetcher({ page: p, pageSize: ps, ...f });
      if (reqId !== requestIdRef.current) return; // 已被新请求覆盖
      if (Array.isArray(result)) {
        setItems(result);
        setTotal(result.length);
      } else {
        setItems(result.items);
        setTotal(result.total);
      }
    } catch (e: unknown) {
      if (reqId !== requestIdRef.current) return;
      // http.ts 抛出的是 { status, code, message } 普通对象，需兼容取值
      const msg = (e as { message?: string })?.message ?? (e instanceof Error ? e.message : String(e));
      setError(msg);
      setItems([]);
      setTotal(0);
      toast.error(`数据加载失败：${msg}`);
    } finally {
      if (reqId === requestIdRef.current) setLoading(false);
    }
  }, [fetcher]);

  // page / pageSize / filters 变化时自动请求
  useEffect(() => {
    void fetchData(page, pageSize, filters);
  }, [page, pageSize, filters, fetchData]);

  const setPage = useCallback((p: number) => setPageRaw(p), []);

  const setPageSize = useCallback((n: number) => {
    setPageSizeRaw(n);
    setPageRaw(1); // 改变每页条数时回到第1页
  }, []);

  const setFilters = useCallback((f: F) => {
    setFiltersRaw(f);
    setPageRaw(1); // 改变筛选时回到第1页
  }, []);

  const refresh = useCallback(() => {
    void fetchData(page, pageSize, filters);
  }, [page, pageSize, filters, fetchData]);

  const updateItem = useCallback((predicate: (item: T) => boolean, updater: (item: T) => T) => {
    setItems((currentItems) => currentItems.map((item) => (predicate(item) ? updater(item) : item)));
  }, []);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return {
    items,
    total,
    page,
    pageSize,
    totalPages,
    loading,
    error,
    setPage,
    setPageSize,
    setFilters,
    refresh,
    updateItem,
    filters,
  };
}
