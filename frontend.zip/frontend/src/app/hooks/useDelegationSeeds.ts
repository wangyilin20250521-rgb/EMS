import { useEffect, useState } from "react"
import { getDelegationReceipts, type DelegationModule } from "@/app/lib/api/ai"

/** *委派种子消息（总管家模式的"原汁原味"呈现）：
 * EMS 助手经 delegate 在子 agent 模块代答过的问答，以【普通 user/ai 消息对】
 * 合入模块面板自己的对话流——用户看到的就是当时问答的原样，与在该模块直接提问
 * 无差别。非持久化：面板会话本身内存态，种子只是展示层的合入，随面板刷新重取。
 * 后端数据源仍是 agent.delegation_logs（GET /api/delegations）。
 */
export interface DelegationSeed {
  id: string
  role: "user" | "ai"
  text: string
}

/**委派记录消息判定（渲染层据此加"EMS 助手代问"标注）：
 * 种子文本是主助手发给子 agent 的委派原文，不是用户本人的话——直接当普通用户气泡渲染
 * 会让人误以为"自己说过这句话"（历史记录里甚至有第三人称措辞）。 */
export function isDelegationSeedId(id: string | undefined): boolean {
  return !!id && id.startsWith("seed-")
}

export function useDelegationSeeds(
  module: DelegationModule,
  targetRef: string | null,
  /**最多合入最近几条回执（每条 = 一问一答两个消息） */
  limit = 5,
): { seeds: DelegationSeed[]; clearSeeds: () => void } {
  const [seeds, setSeeds] = useState<DelegationSeed[]>([])

  useEffect(() => {
    if (!targetRef) {
      setSeeds([])
      return
    }
    let alive = true
    getDelegationReceipts(module, targetRef, limit)
      .then(rows => {
        if (!alive) return
        const msgs: DelegationSeed[] = []
        // 接口最新在前 → 对话展示按时间正序
        for (const r of [...rows].reverse()) {
          msgs.push({ id: `seed-${r.id}-q`, role: "user", text: r.question })
          msgs.push({ id: `seed-${r.id}-a`, role: "ai", text: r.answer })
        }
        setSeeds(msgs)
      })
      .catch(() => {
        if (alive) setSeeds([])
      })
    return () => { alive = false }
  }, [module, targetRef, limit])

  const clearSeeds = () => setSeeds([])

  return { seeds, clearSeeds }
}
