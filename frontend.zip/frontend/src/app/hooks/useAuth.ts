import { createContext, createElement, useCallback, useContext, useEffect, useState, type PropsWithChildren } from 'react'
import type { AuthState, AuthUser, ChangePasswordRequest, LoginRequest } from '../lib/api/types'
import { login as apiLogin, logout as apiLogout, changePassword as apiChangePassword } from '../lib/api/auth'
import { setAuthToken, getAuthToken } from '../lib/api/http'
import { toast } from 'sonner'

const USER_KEY = 'ems-auth-user'

export interface AuthContextValue extends AuthState {
  /** code === "1" 表示账号已有用户在线（详情在 details，登录页据此弹顶下线确认） */
  login(credentials: LoginRequest): Promise<{ success: boolean; error?: string; code?: string; details?: unknown }>
  logout(): void
  changePassword(input: ChangePasswordRequest): Promise<{ success: boolean; error?: string }>
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: PropsWithChildren) {
  const [state, setState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
    loading: true,
  })

  // 从 sessionStorage 恢复登录态（刷新页面时不丢失）
  useEffect(() => {
    const token = getAuthToken()
    const storedUser = sessionStorage.getItem(USER_KEY)
    if (token && storedUser) {
      try {
        const user = JSON.parse(storedUser) as AuthUser
        setState({ isAuthenticated: true, user, loading: false })
        return
      } catch { /* corrupted data, fall through */ }
    }
    setState((prev) => ({ ...prev, loading: false }))
  }, [])

  // 全局 401（token 缺失/过期）→ 清登录态并跳回登录页（http.ts 广播 auth:unauthorized）
  useEffect(() => {
    const onUnauthorized = () => {
      setState({ isAuthenticated: false, user: null, loading: false })
      sessionStorage.removeItem(USER_KEY)
      toast.error('登录已过期，请重新登录')
      if (window.location.hash !== '#/login') {
        window.location.hash = '#/login'
      }
    }
    window.addEventListener('auth:unauthorized', onUnauthorized)
    return () => window.removeEventListener('auth:unauthorized', onUnauthorized)
  }, [])

  const login = useCallback(async (credentials: LoginRequest) => {
    try {
      const result = await apiLogin(credentials)
      if (result.ok) {
        const { user } = result.data
        // 关键：把 JWT 注入 HTTP 层，后续请求才能带 Authorization 头（否则 real 模式全部 401）
        setAuthToken(result.data.token)
        sessionStorage.setItem(USER_KEY, JSON.stringify(user))
        setState({ isAuthenticated: true, user, loading: false })
        return { success: true }
      }
      return { success: false, error: result.error.message, code: result.error.code, details: result.error.details }
    } catch (err) {
      const message = err instanceof Error ? err.message : '登录失败'
      return { success: false, error: message }
    }
  }, [])

  const logout = useCallback(() => {
    setState({ isAuthenticated: false, user: null, loading: false })
    sessionStorage.removeItem(USER_KEY)
    // 2026-08-31 修复：先发起后端 logout（此时 token 尚未清，请求带鉴权 → 后端清在线状态），
    // 再清本地 token —— 原顺序（先清 token 再调接口）导致请求 401，后端清理从未执行，
    // 30 分钟窗口内再次登录误报"该账号已有用户在线"
    void apiLogout()
    setAuthToken(null)
  }, [])

  const changePassword = useCallback(async (input: ChangePasswordRequest) => {
    const result = await apiChangePassword(input)
    if (result.ok) {
      return { success: true }
    }
    return { success: false, error: result.error.message }
  }, [state.user])

  const value: AuthContextValue = {
    ...state,
    login,
    logout,
    changePassword,
  }

  return createElement(AuthContext.Provider, { value }, children)
}

export function useAuth(): AuthContextValue {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
