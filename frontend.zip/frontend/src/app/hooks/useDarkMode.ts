import { useState, useEffect } from "react";
import { usePlatform } from "../lib/platform";

const THEME_KEY = "ems-theme";

/**
 * Dark mode toggle hook.
 * - Persists preference via the Platform StorageAdapter (no direct localStorage access).
 * - Toggles the `.dark` class on document.documentElement to activate theme.css dark-mode variables.
 */
export function useDarkMode() {
  const { storage } = usePlatform();
  const [dark, setDark] = useState<boolean>(storage.get(THEME_KEY) === "dark");

  useEffect(() => {
    const root = document.documentElement;
    dark ? root.classList.add("dark") : root.classList.remove("dark");
    storage.set(THEME_KEY, dark ? "dark" : "light");
  }, [dark, storage]);

  return { dark, toggle: () => setDark(d => !d) };
}
