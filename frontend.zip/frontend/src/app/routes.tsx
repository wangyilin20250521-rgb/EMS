import { useState } from "react";
import { createHashRouter, Outlet, useNavigate, useLocation, Navigate } from "react-router";
import { FlaskConical } from "lucide-react";
import { useAuth } from "./hooks/useAuth";

import { DashboardPage } from "@/app/features/dashboard/DashboardPage";
import { LoginPage } from "@/app/components/auth/LoginPage";
import { RequireAuth } from "@/app/components/auth/RequireAuth";
import { Sidebar } from "@/app/features/layout/Sidebar";
import { TopBar } from "@/app/features/layout/TopBar";
import type { ViewId } from "./lib/api";
import { GUARD_EXEMPT_VIEWS, isViewAllowed } from "./lib/view-permissions";

function Root() {
  // 侧边栏宽度持久化：localStorage（"full" 204px 两列展开 / "narrow" 88px 一列窄栏）
  const [collapsed, setCollapsed] = useState(
    () => localStorage.getItem("mlims_sidebar_mode") === "narrow"
  );
  // 两列展开状态下的阅读视图持久化："grid" 全量图标宫格 / "cards" 5 分组卡片
  const [cardView, setCardView] = useState(
    () => localStorage.getItem("mlims_sidebar_view") === "cards"
  );
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  const pathToViewId = (path: string): ViewId => {
    const p = path.slice(1) || "dashboard";
    return p as ViewId;
  };

  const currentView = pathToViewId(location.pathname);

  // 角色路由守卫：白名单之外的视图一律落到样本制备
  // （登录后默认进入样本制备；直接输 URL 访问隐藏模块也会被弹回；豁免视图如个人信息除外）
  if (!GUARD_EXEMPT_VIEWS.includes(currentView) && !isViewAllowed(user?.role, currentView)) {
    return <Navigate to="/sample-prep" replace />;
  }

  const handleNavigate = (v: ViewId) => {
    navigate(v === "dashboard" ? "/" : `/${v}`);
  };

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden text-foreground">
      <Sidebar
        active={currentView}
        onNavigate={handleNavigate}
        collapsed={collapsed}
        onToggle={() => setCollapsed(v => {
          const next = !v;
          localStorage.setItem("mlims_sidebar_mode", next ? "narrow" : "full");
          return next;
        })}
        cardView={cardView}
        onToggleView={() => setCardView(v => {
          const next = !v;
          localStorage.setItem("mlims_sidebar_view", next ? "cards" : "grid");
          return next;
        })}
      />
      <div data-popover-boundary className="flex-1 flex flex-col min-w-0">
        <TopBar active={currentView} onNavigate={handleNavigate} />
        <main className="flex-1 min-h-0 relative bg-background">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

function DashboardPageWrapper() {
  const navigate = useNavigate();
  return <DashboardPage onNavigate={(v) => navigate(v === "dashboard" ? "/" : `/${v}`)} />;
}

function PlaceholderPage({ title, icon: Icon, description }: { title: string; icon: any; description: string }) {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center gap-4 p-6">
      <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center">
        <Icon size={28} className="text-muted-foreground" />
      </div>
      <div>
        <h2 className="text-lg font-semibold text-foreground mb-1">{title}</h2>
        <p className="text-sm text-muted-foreground max-w-xs">{description}</p>
      </div>
      <span className="text-xs bg-amber-50 text-amber-700 px-3 py-1 rounded-full border border-amber-200">第二期开发</span>
    </div>
  );
}

function AuthenticatedRoot() {
  return (
    <RequireAuth>
      <Root />
    </RequireAuth>
  );
}

export const router = createHashRouter([
  {
    path: "/login",
    Component: LoginPage,
  },
  {
    path: "/",
    Component: AuthenticatedRoot,
    children: [
      { index: true, Component: DashboardPageWrapper },
      // 以下页面路由懒加载：首屏只加载核心壳 + 登录 + 仪表盘，
      // xlsx / react-markdown 等重库随对应页面按需拆分（写法与 user-info 一致）
      { path: "unpack-register", lazy: () => import("@/app/features/unpack-register/UnpackRegisterPage").then(m => ({ Component: m.UnpackRegisterPage })) },
      { path: "sample-center", lazy: () => import("@/app/features/samples/SampleCenterPage").then(m => ({ Component: m.SampleCenterPage })) },
      { path: "sample-prep", lazy: () => import("@/app/features/sample-prep/SamplePrepPage").then(m => ({ Component: m.SamplePrepPage })) },
      { path: "experiment-schedule", lazy: () => import("@/app/features/experiment-schedule/ExperimentSchedulePage").then(m => ({ Component: m.ExperimentSchedulePage })) },
      { path: "task-list", lazy: () => import("@/app/features/tasks/TaskListPage").then(m => ({ Component: m.TaskListPage })) },
      { path: "anomaly-center", lazy: () => import("@/app/features/anomalies/AnomalyCenterPage").then(m => ({ Component: m.AnomalyCenterPage })) },
      { path: "strategy-management", lazy: () => import("@/app/features/strategy-management/StrategyManagementPage").then(m => ({ Component: m.StrategyManagementPage })) },
      { path: "ai-assistant", lazy: () => import("@/app/features/ai-assistant/AIAssistantPage").then(m => ({ Component: m.AIAssistantRoute })) },
      { path: "alerts", lazy: () => import("@/app/features/alerts/AlertsPage").then(m => ({ Component: m.AlertsPage })) },
      { path: "product-management", lazy: () => import("@/app/features/products/ProductManagementPage").then(m => ({ Component: m.ProductManagementPage })) },
      { path: "sequencing-task", lazy: () => import("@/app/features/sequencing/SequencingTaskPage").then(m => ({ Component: m.SequencingTaskPage })) },
      { path: "devices", lazy: () => import("@/app/features/devices/DevicesPage").then(m => ({ Component: m.DevicesPage })) },
      { path: "reagents",  Component: () => <PlaceholderPage title="试剂管理" icon={FlaskConical} description="追踪实验室试剂库存及效期。" /> },
      { path: "documents", lazy: () => import("@/app/features/documents/DocumentsPage").then(m => ({ Component: m.DocumentsPage })) },
      { path: "settings", lazy: () => import("@/app/features/system-management/SystemManagementPage").then(m => ({ Component: m.SystemManagementPage })) },
      { path: "solutions", lazy: () => import("@/app/features/solutions/SolutionsPage").then(m => ({ Component: m.SolutionsPage })) },
      { path: "user-info", lazy: () => import("@/app/components/auth/UserInfoPage").then(m => ({ Component: m.UserInfoPage })) },
      { path: "*", Component: () => <div className="p-6">404 - Not Found</div> },
    ],
  },
]);
