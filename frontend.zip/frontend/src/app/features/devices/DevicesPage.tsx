import { useState, useEffect, Fragment } from "react";
import {
  Plus,
  Activity, Clock, X, Save, Pencil, FileText,
  Cpu, Dna, FlaskConical, Truck, Snowflake, LayoutGrid, Hand,
} from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { PanelSidebar } from "@/app/components/shared/PanelSidebar";
import { panelCardCls, panelIconCls } from "@/app/components/shared/panel-styles";

import { toast } from "sonner";
import { getLabDevices, getDeviceLogs, createLabDevice, updateLabDevice, getDictItems, SEQUENCER_MODELS, ISLAND_TYPES, type LabDevice, type DeviceLogEntry, type DeviceCreatePayload } from "@/app/lib/api";
import { fetchSiroDeviceList, type SiroDevice } from "@/app/lib/api/siro";
import { useExecutionMode } from "@/app/lib/execution-mode";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";

// ─── Types ──────────────────────────────────────────────────────────────────

type LabDeviceStatus = "在线" | "运行中" | "离线" | "错误";
type LabDeviceGroup = "SIRO" | "测序仪" | "功能岛" | "AGV" | "冰箱" | "虚拟设备";

/** 实验执行类设备（受执行模式注册矩阵约束）；测序仪/AGV/冰箱不受限 */
const EXPERIMENT_DEVICE_GROUPS: LabDeviceGroup[] = ["SIRO", "功能岛", "虚拟设备"];

function fmtTime(isoStr: string | undefined): string {
  if (!isoStr) return "-"
  const d = new Date(isoStr)
  const bj = new Date(d.getTime() + 8 * 60 * 60 * 1000)
  return bj.toISOString().replace("T", " ").replace(/\.\d{3}Z$/, "")
}

function siroStatusLabel(s: string): LabDeviceStatus {
  const map: Record<string, LabDeviceStatus> = { ONLINE: "在线", OFFLINE: "离线", ERROR: "错误" }
  return map[s] ?? "离线"
}

function mapSiroToLabDevice(s: SiroDevice): LabDevice & { _source: "siro" } {
  return {
    id: s.biz_host_id,
    type: "SIRO",
    deviceType: s.host_type || "",
    name: s.device_id || s.host_name || s.biz_host_id,
    model: s.host_type || "",
    sn: s.biz_host_id,
    ip: s.device_ip || "",
    port: String(s.device_port ?? ""),
    endpoint: "",
    status: siroStatusLabel(s.status),
    currentTask: s.current_task_count > 0 ? `负载 ${s.load_percent}%` : undefined,
    progress: s.load_percent ?? 0,
    lastHeartbeat: s.last_heartbeat || "",
    location: s.location || "",
    connectedAt: s.create_time || "",
    notes: s.notes || "",
    _source: "siro" as const,
  }
}

// ─── Device Cards ────────────────────────────────────────────────────────────

function LabDeviceCard({ device, dormant, onDetail, onLog }: { device: LabDevice; dormant?: boolean; onDetail: () => void; onLog: () => void }) {
  return (
    <Card className="p-4 border-2 border-border transition-all hover:shadow-md cursor-pointer" onClick={onDetail}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1 min-w-0">
          {/* SIRO 设备：备注优先作为大标题（用户自定义别名），无备注用注册信息 */}
          <p className="text-sm font-semibold truncate mb-0.5">
            {device._source === "siro" && device.notes?.trim() ? device.notes : device.name}
          </p>
          <p className="text-xs text-muted-foreground truncate">{device.model}</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {dormant && (
            <span className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300">休眠</span>
          )}
          <button
            onClick={(e) => { e.stopPropagation(); onLog(); }}
            className="p-1 text-muted-foreground hover:text-primary hover:bg-primary/5 rounded transition-colors cursor-pointer"
            title="查看日志"
          >
            <FileText size={14} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 text-xs">
        <div><span className="text-muted-foreground">SN:</span> <span className="font-mono ml-1">{device.sn}</span></div>
        <div><span className="text-muted-foreground">IP:</span> <span className="font-mono ml-1">{device.ip}</span></div>
        <div><span className="text-muted-foreground">端口:</span> <span className="font-mono ml-1">{device.port}</span></div>
        <div><span className="text-muted-foreground">接口:</span> <span className="font-mono ml-1">{device.endpoint}</span></div>
        <div><span className="text-muted-foreground">位置:</span> <span className="ml-1">{device.location}</span></div>
        <div className="flex items-center gap-1">
          <Clock size={10} className="text-muted-foreground" />
          <span className="text-muted-foreground">{fmtTime(device.lastHeartbeat)}</span>
        </div>
      </div>
    </Card>
  );
}

// ─── Device Detail Drawer ──────────────────────────────────────────────────────

const DEVICE_TYPE_OPTIONS: LabDeviceGroup[] = ["SIRO", "测序仪", "功能岛", "AGV", "冰箱", "虚拟设备"];

/** 中文类型标签 → 后端 device_type 英文枚举（sequencer / island / agv / fridge / manual） */
function deviceTypeEnum(label: string): string {
  return label === "测序仪" ? "sequencer" : label === "功能岛" ? "island" : label === "AGV" ? "agv" : label === "冰箱" ? "fridge" : label === "虚拟设备" ? "manual" : "";
}

/** 型号/类型下拉选项：字典数据（权威）+ 兼容存量自定义值（历史自由输入的数据仍可显示）；冰箱/AGV 型号自由输入 */
function modelOptionsFor(type: string, current: string, sequencerModels: string[], islandModels: string[]): string[] {
  const base = type === "功能岛" ? [...islandModels] : [...sequencerModels];
  if (current && !base.includes(current)) base.push(current);
  return base;
}

type EditableLabDeviceField = "type" | "name" | "model" | "sn" | "ip" | "port" | "endpoint" | "location" | "status" | "notes";

function draftFromLabDevice(device: LabDevice): Pick<LabDevice, EditableLabDeviceField> {
  return {
    type: device.type, name: device.name, model: device.model, sn: device.sn,
    ip: device.ip, port: device.port, endpoint: device.endpoint,
    location: device.location, status: device.status, notes: device.notes,
  };
}

function LabDeviceDetailDrawer({
  device,
  dormant,
  onClose,
  onSave,
  sequencerModels,
  islandModels,
}: {
  device: LabDevice;
  /**执行模式注册矩阵越界 → 休眠：只读展示，编辑被禁（后端同守卫） */
  dormant?: boolean;
  onClose: () => void;
  onSave: (patch: Pick<LabDevice, EditableLabDeviceField>) => void;
  sequencerModels: string[];
  islandModels: string[];
}) {
  const [editMode, setEditMode] = useState(false);
  const [draft, setDraft] = useState<Pick<LabDevice, EditableLabDeviceField>>(draftFromLabDevice(device));
  const isSiro = device._source === "siro";

  const beginEdit = () => {
    if (dormant) {
      toast.error("该设备在当前执行模式下已休眠：不可编辑；切换回对应方案后恢复");
      return;
    }
    setDraft(draftFromLabDevice(device));
    setEditMode(true);
  };

  const save = async () => {
    if (isSiro) {
      if (!draft.location.trim() && !draft.notes.trim()) return
      const { updateSiroDevice } = await import("@/app/lib/api/siro")
      await updateSiroDevice(device.id, { location: draft.location.trim(), notes: draft.notes.trim() })
    } else {
      if (!draft.name.trim() || !draft.model.trim() || !draft.location.trim()) return
    }
    onSave(draft)
    setEditMode(false)
  };

  return (
    <div className="fixed inset-y-0 right-0 w-96 bg-card shadow-2xl z-40 flex flex-col border-l border-border animate-in slide-in-from-right-4 duration-300">
      <div className="px-5 py-4 border-b border-border flex items-center justify-between bg-muted/20 shrink-0">
        <h2 className="text-sm font-semibold">设备详情</h2>
        <button onClick={onClose} className="p-1 hover:bg-muted rounded transition-colors text-muted-foreground cursor-pointer" aria-label="关闭设备详情"><X size={16} /></button>
      </div>

      <div className="flex-1 overflow-y-auto p-5 space-y-5 text-[13px]">
        <div className="space-y-3">
          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">系统信息（不可修改）</p>
          <div className="bg-muted/30 rounded-xl p-3 border border-border space-y-2">
            {isSiro && (
              <div className="flex justify-between"><span className="text-muted-foreground">设备名称</span><span className="font-mono text-xs">{device.name}</span></div>
            )}
            <div className="flex justify-between"><span className="text-muted-foreground">设备编号</span><span className="font-mono text-xs">{device.id}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">接入时间</span><span className="font-mono text-xs">{fmtTime(device.connectedAt)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">最后心跳</span><span className="text-xs">{fmtTime(device.lastHeartbeat)}</span></div>
            {isSiro && (
              <>
                <div className="flex justify-between"><span className="text-muted-foreground">设备 IP</span><span className="font-mono text-xs">{device.ip}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">端口</span><span className="font-mono text-xs">{device.port}</span></div>
              </>
            )}
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">可编辑信息</p>
            {!editMode && (
              <button onClick={beginEdit} className="p-1 text-muted-foreground hover:text-primary rounded transition-colors cursor-pointer" aria-label="编辑设备信息"><Pencil size={13} /></button>
            )}
            {isSiro && !editMode && (
              <span className="text-[10px] text-muted-foreground bg-muted px-2 py-0.5 rounded">SIRO 自动注册</span>
            )}
          </div>
          <div className="space-y-2">
            <div className="p-3 bg-card border border-border rounded-xl">
              <label className="block text-[10px] text-muted-foreground mb-1">设备类型</label>
              {editMode && !isSiro ? (
                <div className="flex gap-1 p-0.5 bg-muted rounded-lg w-fit">
                  {DEVICE_TYPE_OPTIONS.map((option) => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => setDraft((d) => ({ ...d, type: option }))}
                      className={`px-2.5 py-1 text-xs rounded-md transition-colors font-medium cursor-pointer ${draft.type === option ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              ) : <p className="font-medium">{device.type}</p>}
            </div>
            <div className="p-3 bg-card border border-border rounded-xl">
              <label className="block text-[10px] text-muted-foreground mb-1">设备名称</label>
              {editMode && !isSiro ? <input value={draft.name} onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))} className="w-full border border-border rounded px-2 py-1 text-xs" /> : <p className="font-medium">{device.name}</p>}
            </div>
            <div className="p-3 bg-card border border-border rounded-xl">
              <label className="block text-[10px] text-muted-foreground mb-1">{draft.type === "功能岛" ? "类型" : "型号"}</label>
              {editMode && !isSiro ? (
                draft.type === "AGV" || draft.type === "冰箱" || draft.type === "虚拟设备" ? (
                  <input value={draft.model} onChange={(e) => setDraft((d) => ({ ...d, model: e.target.value }))}
                    className="w-full border border-border rounded px-2 py-1 text-xs" />
                ) : (
                  <Select onValueChange={v => setDraft((d) => ({ ...d, model: v }))} value={draft.model}>
  <SelectTrigger className="w-full border border-border rounded px-2 py-1 text-xs bg-card"><SelectValue /></SelectTrigger>
  <SelectContent>

                    {modelOptionsFor(draft.type, draft.model, sequencerModels, islandModels).map((m) => (
                      <SelectItem key={m} value={m}>{m}</SelectItem>
                    ))}
                  
  </SelectContent>
</Select>
                )
              ) : <p className="font-medium">{device.model}</p>}
            </div>
            <div className="p-3 bg-card border border-border rounded-xl">
              <label className="block text-[10px] text-muted-foreground mb-1">SN</label>
              {editMode && !isSiro ? <input value={draft.sn} onChange={(e) => setDraft((d) => ({ ...d, sn: e.target.value }))} className="w-full border border-border rounded px-2 py-1 text-xs font-mono" /> : <p className="font-mono text-xs">{device.sn}</p>}
            </div>
            <div className="p-3 bg-card border border-border rounded-xl">
              <label className="block text-[10px] text-muted-foreground mb-1">IP 地址</label>
              {editMode && !isSiro ? <input value={draft.ip} onChange={(e) => setDraft((d) => ({ ...d, ip: e.target.value }))} className="w-full border border-border rounded px-2 py-1 text-xs font-mono" /> : <p className="font-mono text-xs">{device.ip}</p>}
            </div>
            <div className="p-3 bg-card border border-border rounded-xl">
              <label className="block text-[10px] text-muted-foreground mb-1">端口</label>
              {editMode && !isSiro ? <input value={draft.port} onChange={(e) => setDraft((d) => ({ ...d, port: e.target.value }))} className="w-full border border-border rounded px-2 py-1 text-xs font-mono" /> : <p className="font-mono text-xs">{device.port}</p>}
            </div>
            <div className="p-3 bg-card border border-border rounded-xl">
              <label className="block text-[10px] text-muted-foreground mb-1">接口</label>
              {editMode && !isSiro ? <input value={draft.endpoint} onChange={(e) => setDraft((d) => ({ ...d, endpoint: e.target.value }))} className="w-full border border-border rounded px-2 py-1 text-xs font-mono" /> : <p className="font-mono text-xs">{device.endpoint}</p>}
            </div>
            <div className="p-3 bg-card border border-border rounded-xl">
              <label className="block text-[10px] text-muted-foreground mb-1">位置</label>
              {editMode ? <input value={draft.location} onChange={(e) => setDraft((d) => ({ ...d, location: e.target.value }))} className="w-full border border-border rounded px-2 py-1 text-xs" /> : <p className="font-medium">{device.location}</p>}
            </div>
            <div className="p-3 bg-card border border-border rounded-xl">
              <label className="block text-[10px] text-muted-foreground mb-1">备注</label>
              {editMode ? <input value={draft.notes} onChange={(e) => setDraft((d) => ({ ...d, notes: e.target.value }))} placeholder="填写备注" className="w-full border border-border rounded px-2 py-1 text-xs" /> : <p className="text-xs text-foreground">{device.notes || "—"}</p>}
            </div>
          </div>
        </div>

      </div>

      <div className="shrink-0 p-5 pt-4 border-t border-border flex flex-col gap-2 bg-card">
        {editMode ? (
          <div className="flex gap-2">
            <Button variant="ghost" className="flex-1 text-xs h-9" onClick={() => setEditMode(false)}>取消</Button>
            <Button variant="default" className="flex-1 text-xs h-9" onClick={save}><Save className="w-3.5 h-3.5 mr-2" />保存</Button>
          </div>
        ) : null}
        {!editMode && (
          <Button variant="outline" className="w-full text-xs h-9" onClick={beginEdit}><Pencil className="w-3.5 h-3.5 mr-2" />编辑信息</Button>
        )}
      </div>
    </div>
  );
}

// ─── Add Device Modal ────────────────────────────────────────────────────────

function AddLabDeviceModal({
  defaultType,
  onClose,
  onCreate,
  onRegistered,
  sequencerModels,
  islandModels,
}: {
  /** 打开时预选的设备类型（= 左侧当前选中分类，2026-09-17 分类卡浏览） */
  defaultType?: LabDeviceGroup;
  onClose: () => void;
  onCreate: (device: LabDevice) => Promise<void>;
  onRegistered?: () => void;
  sequencerModels: string[];
  islandModels: string[];
}) {
  // 类型锁定为触发它的分类（左侧分类卡已选定），不再提供类型切换（2026-09-17 用户反馈）
  const [type] = useState<LabDeviceGroup>(defaultType ?? "测序仪");
  const [name, setName] = useState("");
  // 测序仪型号/功能岛类型为固定下拉；AGV/冰箱/虚拟设备型号自由输入（虚拟设备预填手工工位）
  const initialModelFor = (t: LabDeviceGroup) =>
    t === "测序仪" ? (sequencerModels[0] ?? SEQUENCER_MODELS[0]) : t === "功能岛" ? (islandModels[0] ?? ISLAND_TYPES[0]) : t === "虚拟设备" ? "手工工位" : "";
  const [model, setModel] = useState<string>(initialModelFor(type));

  const [sn, setSn] = useState("");
  const [ip, setIp] = useState("");
  const [port, setPort] = useState("");
  const [endpoint, setEndpoint] = useState("");
  const [location, setLocation] = useState("");
  const [error, setError] = useState("");

  // SIRO 由上位机自动注册，不提供手动创建表单；测序仪/功能岛/AGV 走完整配置
  const isAutoRegister = type === "SIRO";

  const handleSave = async () => {
    if (!name.trim() || !model.trim()) {
      setError("请填写设备名称和设备型号。");
      return;
    }
    setError("");
    try {
      await onCreate({
        id: `D${Date.now()}`,
        type,
        // 分组依据 deviceType（后端英文枚举）：sequencer / island / agv
        deviceType: deviceTypeEnum(type),
        name: name.trim(),
        model: model.trim(),
        sn: sn.trim(),
        ip: ip.trim(),
        port: port.trim(),
        endpoint: endpoint.trim(),
        // 未与真实设备对接前，登记设备默认离线、无心跳
        status: "离线",
        lastHeartbeat: "",
        location: location.trim(),
        connectedAt: new Date().toISOString().slice(0, 10),
        notes: "",
      });
    } catch {
      setError("保存失败，请确认后端服务可用后重试");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="bg-card rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="px-6 py-4 border-b border-border flex items-center justify-between">
          <h2 className="text-base font-semibold">新增{type}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground cursor-pointer" aria-label="关闭新增设备"><X size={16} /></button>
        </div>
        <div className="p-6 space-y-6">
          {!isAutoRegister ? (
            <>
              <div className="space-y-4">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">基本信息</p>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs font-medium mb-1 block">设备名称 *</label>
                    <input value={name} onChange={(e) => setName(e.target.value)} placeholder="例: DNBSEQ-T7" className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                  <div>
                    <label className="text-xs font-medium mb-1 block">{type === "功能岛" ? "功能岛类型" : "设备型号"} *</label>
                    {type === "AGV" || type === "冰箱" || type === "虚拟设备" ? (
                      <input value={model} onChange={(e) => setModel(e.target.value)} placeholder={type === "冰箱" ? "例: 海尔 4℃ 冰箱" : "例: 转运机器人-01"}
                        className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                    ) : (
                      <Select onValueChange={v => setModel(v)} value={model}>
  <SelectTrigger className="w-full border border-border rounded-md px-3 py-1.5 text-sm bg-card focus:outline-none focus:ring-2 focus:ring-ring"><SelectValue /></SelectTrigger>
  <SelectContent>

                        {(type === "功能岛" ? islandModels : sequencerModels).map((m) => (
                          <SelectItem key={m} value={m}>{m}</SelectItem>
                        ))}
                      
  </SelectContent>
</Select>
                    )}
                  </div>
                  <div>
                    <label className="text-xs font-medium mb-1 block">序列号</label>
                    <input value={sn} onChange={(e) => setSn(e.target.value)} placeholder="SN..." className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">网络配置</p>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs font-medium mb-1 block">IP地址</label>
                    <input value={ip} onChange={(e) => setIp(e.target.value)} placeholder="192.168.1.xxx" className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                  <div>
                    <label className="text-xs font-medium mb-1 block">端口</label>
                    <input value={port} onChange={(e) => setPort(e.target.value)} placeholder="例: 9090" className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-medium mb-1 block">接口（Endpoint）</label>
                  <input value={endpoint} onChange={(e) => setEndpoint(e.target.value)} placeholder="例: /api/dnbseq/v2" className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                </div>
              </div>

              <div className="space-y-4">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">位置信息</p>
                <div>
                  <label className="text-xs font-medium mb-1 block">位置</label>
                  <input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="例: 测序室A" className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
                </div>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
              <div className="w-12 h-12 rounded-full bg-blue-50 dark:bg-blue-950/30 flex items-center justify-center mb-4">
                <Activity size={24} className="text-blue-500" />
              </div>
              <p className="text-sm font-medium text-foreground mb-1">SIRO 由上位机自动注册</p>
              <p className="text-xs text-muted-foreground max-w-sm leading-relaxed">
                SIRO（前处理仪器）启动后会自动向 SIRO 中台服务注册，无需手动创建。请确保设备上位机已启动并连接到 SIRO 服务。
              </p>
            </div>
          )}

          {error && <p role="alert" className="text-xs text-destructive">{error}</p>}
        </div>
        <div className="px-6 py-4 border-t border-border flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>取消</Button>
          {!isAutoRegister && <Button variant="default" onClick={handleSave}><Save size={12} />保存</Button>}
        </div>
      </div>
    </div>
  );
}

// ─── Device Log Modal ────────────────────────────────────────────────────────

const LOG_LEVEL_COLORS: Record<string, string> = {
  INFO: "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40",
  WARN: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40",
  ERROR: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40",
};

export function DeviceLogModal({ device, onClose }: { device: LabDevice; onClose: () => void }) {
  const [logs, setLogs] = useState<DeviceLogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getDeviceLogs(device.id).then(setLogs).finally(() => setLoading(false));
  }, [device.id]);

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[80vh] flex flex-col overflow-hidden shadow-2xl py-0">
        <div className="p-4 border-b border-border flex items-center justify-between bg-muted/30">
          <div className="flex items-center gap-2">
            <FileText size={16} className="text-muted-foreground" />
            <div>
              <h3 className="font-semibold text-sm">设备日志</h3>
              <p className="text-xs text-muted-foreground">{device.name} · {device.sn}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1 cursor-pointer">
            <X size={16} />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">
          {loading ? (
            <div className="py-16 text-center text-sm text-muted-foreground">加载中...</div>
          ) : logs.length === 0 ? (
            <div className="py-16 text-center text-sm text-muted-foreground">暂无日志记录</div>
          ) : (
            <Table className="w-full text-sm">
              <TableHeader className="bg-muted/40 sticky top-0 z-10">
                <TableRow>
                  <TableHead className="text-left px-4 py-2.5 text-sm font-semibold text-foreground w-44">时间</TableHead>
                  <TableHead className="text-left px-4 py-2.5 text-sm font-semibold text-foreground w-20">级别</TableHead>
                  <TableHead className="text-left px-4 py-2.5 text-sm font-semibold text-foreground">内容</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody className="divide-y divide-border">
                {logs.map((log, i) => (
                  <TableRow key={i} className="hover:bg-muted/10">
                    <TableCell className="px-4 py-2.5 font-mono text-sm text-muted-foreground whitespace-nowrap">{log.time}</TableCell>
                    <TableCell className="px-4 py-2.5">
                      <span className={`inline-flex rounded px-1.5 py-0.5 text-[11px] font-medium ${LOG_LEVEL_COLORS[log.level] ?? ""}`}>
                        {log.level}
                      </span>
                    </TableCell>
                    <TableCell className="px-4 py-2.5 text-muted-foreground">{log.message}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
        <div className="p-4 border-t border-border bg-muted/10 flex justify-end">
          <Button variant="ghost" size="sm" onClick={onClose}>关闭</Button>
        </div>
      </Card>
    </div>
  );
}

// ─── Main Page ───────────────────────────────────────────────────────────────

/** 设备分类元数据：group 决定侧边栏分节（组切换处渲染分隔线）。 */
const DEVICE_GROUPS: Array<{ key: LabDeviceGroup; label: string; desc: string; icon: typeof Cpu; group: "实验" | "测序" | "转运" | "存储" }> = [
  { key: "SIRO",     label: "SIRO",     desc: "SIRO-16/48/96",                icon: Cpu,          group: "实验" },
  { key: "功能岛",   label: "功能岛",   desc: "试剂/裂解/提取/建库/qPCR",      icon: FlaskConical, group: "实验" },
  { key: "虚拟设备", label: "虚拟设备", desc: "手工模式",                      icon: Hand,         group: "实验" },
  { key: "测序仪",   label: "测序仪",   desc: "MGI-200/2000、DNB-G99/E25", icon: Dna,          group: "测序" },
  { key: "AGV",      label: "AGV",      desc: "自动转运小车",                   icon: Truck,        group: "转运" },
  { key: "冰箱",     label: "冰箱",     desc: "试剂与产物存储",                 icon: Snowflake,    group: "存储" },
];

/** 组分隔线（`── 实验 ──`）：非交互节标记，卡面流式分节，不引入新层级样式 */
function GroupDivider({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-2 pt-1.5" role="separator" aria-label={label}>
      <span className="h-px flex-1 bg-border/70" />
      <span className="text-[11px] text-muted-foreground/70 select-none">{label}</span>
      <span className="h-px flex-1 bg-border/70" />
    </div>
  );
}

/** 设备 → 分类（与列表过滤同口径；SIRO 为兜底：中台映射设备的 deviceType 是 host_type 而非英文枚举） */
function groupOfDevice(d: LabDevice): LabDeviceGroup {
  if (d.deviceType === "sequencer") return "测序仪";
  if (d.deviceType === "island") return "功能岛";
  if (d.deviceType === "agv") return "AGV";
  if (d.deviceType === "fridge") return "冰箱";
  if (d.deviceType === "manual") return "虚拟设备";
  return "SIRO";
}

// LabDevice.status 为 string（兼容 SIRO 状态映射与自由登记），故用 string[] 承接
const ONLINE_STATUSES: readonly string[] = ["在线", "运行中"];

export function DevicesPage() {
  const [devices, setLabDevices] = useState<LabDevice[]>([]);
  const [selectedLabDeviceId, setSelectedLabDeviceId] = useState<string | null>(null);
  // 新增弹窗为哪个分类而开（null=关闭）：主区按钮 = 当前分类，分类卡上的 + = 该卡类型（2026-09-17）
  const [addFor, setAddFor] = useState<LabDeviceGroup | null>(null);
  const [logDevice, setLogDevice] = useState<LabDevice | null>(null);
  // 分类卡浏览（2026-09-17）：左侧选分类，右侧只看该类设备；默认 SIRO
  const [activeGroup, setActiveGroup] = useState<LabDeviceGroup>("SIRO");
  // 执行模式单源：实验执行类设备按模式限制注册（SIRO 模式仅 SIRO；手工模式仅虚拟设备；混合 SIRO+功能岛）
  const { mode, allowedExperimentDeviceTypes: allowedTypes } = useExecutionMode();
  // 注册矩阵：实验执行类不在允许集 → 分类休眠（可见不可注册/编辑，切回对应方案恢复）
  const registrationAllowed = (key: LabDeviceGroup) =>
    !EXPERIMENT_DEVICE_GROUPS.includes(key) || allowedTypes.includes(key);
  // 型号/类型下拉选项：字典「设备型号」为权威源（按 code 前缀 SEQ_/ISL_ 分组），静态常量兜底
  const [dictModels, setDictModels] = useState<{ sequencer: string[]; island: string[] }>({
    sequencer: [...SEQUENCER_MODELS],
    island: [...ISLAND_TYPES],
  });

  useEffect(() => {
    getDictItems("设备型号").then(items => {
      if (!Array.isArray(items) || items.length === 0) return;
      // 仅取启用项；禁用（软删除）的型号不出现在下拉里
      const sequencer = items.filter(i => i.code.startsWith("SEQ_") && i.status !== "禁用").map(i => i.name).filter(Boolean);
      const island = items.filter(i => i.code.startsWith("ISL_") && i.status !== "禁用").map(i => i.name).filter(Boolean);
      setDictModels(prev => ({
        sequencer: sequencer.length ? sequencer : prev.sequencer,
        island: island.length ? island : prev.island,
      }));
    }).catch(() => { /* 字典不可用时保留静态兜底 */ });
  }, []);

  useEffect(() => {
    Promise.all([
      fetchSiroDeviceList(),
      getLabDevices(),
    ]).then(([siroDevs, emsDevs]) => {
      const siroMapped = siroDevs.map(mapSiroToLabDevice)
      // 2026-09-17 修复：此前只保留 sequencer/fridge，功能岛与 AGV 登记后刷新即丢——分类浏览要求各类全保留
      // 2026-09-23：manual（虚拟设备/手工工位）入册保留
      const emsDevices = emsDevs.filter((d: LabDevice) =>
        d.deviceType === "sequencer" || d.deviceType === "island" || d.deviceType === "agv" || d.deviceType === "fridge" || d.deviceType === "manual")
      setLabDevices([...siroMapped, ...emsDevices])
      // Auto-open device passed via sessionStorage
      const sn = sessionStorage.getItem('open_device_sn')
      if (sn) {
        sessionStorage.removeItem('open_device_sn')
        const target = [...siroMapped, ...emsDevices].find(d => d.sn === sn || d.id === sn)
        if (target) setActiveGroup(groupOfDevice(target))
        setSelectedLabDeviceId(sn)
      }
    }).catch(() => {
      getLabDevices().then(setLabDevices)
    })
  }, []);

  const selectedLabDevice = selectedLabDeviceId ? devices.find((d) => d.id === selectedLabDeviceId) ?? null : null;

  const saveLabDevice = async (patch: Pick<LabDevice, EditableLabDeviceField>) => {
    const device = devices.find((d) => d.id === selectedLabDeviceId);
    setLabDevices((current) => current.map((d) => {
      if (d.id !== selectedLabDeviceId) return d;
      const merged = { ...d, ...patch };
      // 类型变更时同步 deviceType（分组依据）；未变更则保留原值（如 SIRO host_type）
      if (patch.type !== d.type) {
        merged.deviceType = deviceTypeEnum(patch.type);
      }
      return merged;
    }));
    // SIRO 设备由 SIRO 中台维护（位置/备注已推送）；EMS 管理的测序仪/功能岛持久化到 web.devices
    if (device && (device as LabDevice & { _source?: string })._source !== "siro") {
      try {
        await updateLabDevice(device.id, {
          name: patch.name, model: patch.model, sn: patch.sn, ip: patch.ip,
          port: patch.port, endpoint: patch.endpoint, location: patch.location, notes: patch.notes,
        });
      } catch {
        toast.error("设备信息保存失败，请稍后重试");
      }
    }
  };

  const addLabDevice = async (device: LabDevice) => {
    try {
      const created = await createLabDevice({
        device_type: device.deviceType as DeviceCreatePayload["device_type"],
        name: device.name,
        model: device.model,
        sn: device.sn,
        ip: device.ip,
        port: device.port,
        endpoint: device.endpoint,
        location: device.location,
        notes: device.notes,
      });
      setLabDevices((current) => [...current, created]);
      setAddFor(null);
      setActiveGroup(groupOfDevice(created));
    } catch (e) {
      throw e; // 错误上抛，由弹窗展示
    }
  };

  // 后端设备类型为英文枚举（sequencer/prep/pcr/island/agv/fridge/manual）
  const isSequencerDevice = (d: LabDevice) => d.deviceType === "sequencer";
  const isIslandDevice = (d: LabDevice) => d.deviceType === "island";
  const isAgvDevice = (d: LabDevice) => d.deviceType === "agv";
  const isFridgeDevice = (d: LabDevice) => d.deviceType === "fridge";
  const isManualStation = (d: LabDevice) => d.deviceType === "manual";
  const siroLabDevices = devices.filter((d) => !isSequencerDevice(d) && !isIslandDevice(d) && !isAgvDevice(d) && !isFridgeDevice(d) && !isManualStation(d));
  const devicesByGroup: Record<LabDeviceGroup, LabDevice[]> = {
    SIRO: siroLabDevices,
    测序仪: devices.filter(isSequencerDevice),
    功能岛: devices.filter(isIslandDevice),
    AGV: devices.filter(isAgvDevice),
    冰箱: devices.filter(isFridgeDevice),
    虚拟设备: devices.filter(isManualStation),
  };

  const activeDevices = devicesByGroup[activeGroup];
  const activeMeta = DEVICE_GROUPS.find((g) => g.key === activeGroup)!;
  const activeOnline = activeDevices.filter((d) => ONLINE_STATUSES.includes(d.status)).length;

  return (
    <div className="h-full flex overflow-hidden">
      {/* 左侧分类卡（PanelSidebar 统一规格） */}
      <PanelSidebar icon={LayoutGrid} title="设备分类" count={`共 ${devices.length} 台`}>
        {DEVICE_GROUPS.map(({ key, label, desc, icon: GroupIcon, group }, i) => {
          const selected = key === activeGroup;
          const groupChanged = i === 0 || DEVICE_GROUPS[i - 1].group !== group;
          return (
            <Fragment key={key}>
              {groupChanged && <GroupDivider label={group} />}
              
              <button
                type="button"
                onClick={() => setActiveGroup(key)}
                aria-pressed={selected}
                className={panelCardCls({ active: selected })}
              >
                <span className={panelIconCls(selected)}>
                  <GroupIcon size={15} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[14px] font-medium text-foreground leading-snug">{label}</span>
                  <span className="block text-[12px] text-muted-foreground truncate">{desc}</span>
                </span>
              </button>
            </Fragment>
          );
        })}
      </PanelSidebar>

      {/* 右侧：选中分类的设备注册列表 */}
      <div className="flex-1 min-w-0 overflow-y-auto">
        <div className="px-6 pb-6 pt-2 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <h1 className="text-base font-semibold text-foreground flex items-center gap-2">
                {activeGroup}
                <span className="text-xs font-normal text-muted-foreground">
                  共 {activeDevices.length} 台{activeOnline > 0 ? ` · 在线 ${activeOnline}` : ""}
                </span>
                {!registrationAllowed(activeGroup) && (
                  <span className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300">
                    当前模式（{mode}）休眠
                  </span>
                )}
              </h1>
              <p className="text-xs text-muted-foreground truncate">
                {registrationAllowed(activeGroup) ? activeMeta.desc : `${activeMeta.desc} · 当前执行模式不允许注册该类设备，存量设备休眠`}
              </p>
            </div>
            {registrationAllowed(activeGroup) ? (
              <Button variant="default" className="shrink-0" onClick={() => setAddFor(activeGroup)}><Plus size={12} />新增{activeGroup === "SIRO" ? "设备" : activeGroup}</Button>
            ) : (
              <Button variant="outline" className="shrink-0" disabled title={`当前执行模式（${mode}）不允许注册${activeGroup}`}><Plus size={12} />新增</Button>
            )}
          </div>

          {activeDevices.length === 0 ? (
            <p className="text-xs text-muted-foreground py-16 text-center border border-dashed border-border rounded-xl">
              暂无{activeGroup}设备{activeGroup === "SIRO" ? "——由上位机启动后自动注册" : registrationAllowed(activeGroup) ? "，点击右上角登记" : ""}
            </p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {activeDevices.map(d => <LabDeviceCard key={d.id} device={d} dormant={!registrationAllowed(groupOfDevice(d))} onDetail={() => setSelectedLabDeviceId(d.id)} onLog={() => setLogDevice(d)} />)}
            </div>
          )}
        </div>
      </div>

      {/* Add device modal（默认类型 = 触发它的分类） */}
      {addFor && (
        <AddLabDeviceModal
          defaultType={addFor}
          onClose={() => setAddFor(null)}
          onCreate={addLabDevice}
          onRegistered={() => {
            fetchSiroDeviceList().then(siroDevs => {
              const siroMapped = siroDevs.map(mapSiroToLabDevice);
              setLabDevices(prev => [...siroMapped, ...prev.filter(d => d.deviceType === "sequencer" || d.deviceType === "island" || d.deviceType === "agv" || d.deviceType === "fridge")]);
            });
          }}
          sequencerModels={dictModels.sequencer}
          islandModels={dictModels.island}
        />
      )}

      {logDevice && <DeviceLogModal device={logDevice} onClose={() => setLogDevice(null)} />}

      {selectedLabDevice && (
        <LabDeviceDetailDrawer
          device={selectedLabDevice}
          dormant={!registrationAllowed(groupOfDevice(selectedLabDevice))}
          onClose={() => setSelectedLabDeviceId(null)}
          onSave={saveLabDevice}
          sequencerModels={dictModels.sequencer}
          islandModels={dictModels.island}
        />
      )}
    </div>
  );
}
