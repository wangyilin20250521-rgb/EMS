import { useState, useCallback } from "react";
import {
  Bell,
  Search,
  AlertTriangle,
  Circle,
  CheckCircle2,
  CheckCheck,
} from "lucide-react";
import {
  getAlertsList,
  acknowledgeAlert,
  resolveAlert,
  batchAcknowledgeAlerts,
  batchResolveAlerts,
} from "@/app/lib/api";
import type { Alert } from "@/app/lib/api";
import { usePagination } from "@/app/hooks/usePagination";
import { useTabbedView, TabBar } from "@/app/hooks/useTabbedView";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { Button } from "@/app/components/ui/button";

export function AlertsPage() {
  const { activeTab: tab, setActiveTab: setTab } = useTabbedView<"未确认" | "已确认" | "已解决" | "全部">("未确认");
  const [typeFilter, setTypeFilter] = useState("所有类型");
  const [search, setSearch] = useState("");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isBatchProcessing, setIsBatchProcessing] = useState(false);

  const typeOptions = ["所有类型", "TAT超期", "设备预警", "实验异常", "培养到期", "收样异常", "任务完成", "试剂预警"];

  const fetchAlerts = useCallback(async (params: { page?: number; pageSize?: number; status?: string; type?: string }) => {
    const result = await getAlertsList({
      page: params.page,
      pageSize: params.pageSize,
      status: params.status,
      type: params.type,
    });
    if (!result.ok) throw new Error(result.error.message);
    return result.data;
  }, []);

  const {
    items: alerts,
    total,
    page,
    pageSize,
    setPage,
    setPageSize,
    setFilters,
    refresh,
  } = usePagination<Alert, { status: string; type: string }>({
    fetcher: fetchAlerts,
    initialPageSize: 20,
    initialFilters: { status: "未确认", type: "" },
  });

  const handleTabChange = (t: "未确认" | "已确认" | "已解决" | "全部") => {
    setTab(t);
    setSelectedIds([]);
    setFilters({ status: t === "全部" ? "" : t, type: typeFilter === "所有类型" ? "" : typeFilter });
  };

  const handleTypeChange = (val: string) => {
    setTypeFilter(val);
    setSelectedIds([]);
    setFilters({ status: tab === "全部" ? "" : tab, type: val === "所有类型" ? "" : val });
  };

  // Client-side search on paginated results
  const displayed = search
    ? alerts.filter(a => a.title.includes(search) || a.type.includes(search))
    : alerts;

  const handleAcknowledge = async (id: string) => {
    await acknowledgeAlert(id);
    refresh();
  };
  const handleResolve = async (id: string) => {
    await resolveAlert(id);
    refresh();
  };

  const selectedAlerts = alerts.filter((alert) => selectedIds.includes(alert.id));
  const acknowledgeIds = selectedAlerts.filter((alert) => alert.status === "未确认").map((alert) => alert.id);
  const resolveIds = selectedAlerts.filter((alert) => alert.status !== "已解决").map((alert) => alert.id);
  const allDisplayedSelected = displayed.length > 0 && displayed.every((alert) => selectedIds.includes(alert.id));

  const toggleAlertSelection = (id: string) => {
    setSelectedIds((previous) => (
      previous.includes(id) ? previous.filter((selectedId) => selectedId !== id) : [...previous, id]
    ));
  };

  const toggleDisplayedSelection = () => {
    const displayedIds = displayed.map((alert) => alert.id);
    setSelectedIds((previous) => (
      allDisplayedSelected
        ? previous.filter((id) => !displayedIds.includes(id))
        : Array.from(new Set([...previous, ...displayedIds]))
    ));
  };

  const handleBatchAction = async (action: "acknowledge" | "resolve") => {
    const ids = action === "acknowledge" ? acknowledgeIds : resolveIds;
    if (ids.length === 0) return;

    setIsBatchProcessing(true);
    try {
      if (action === "acknowledge") await batchAcknowledgeAlerts(ids);
      if (action === "resolve") await batchResolveAlerts(ids);
      setSelectedIds([]);
      refresh();
    } finally {
      setIsBatchProcessing(false);
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Page header */}
      <div className="px-6 pt-2 pb-0 shrink-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-end mb-4 gap-4">
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              className="pl-8 pr-3 py-1.5 text-sm border border-border rounded-md bg-card focus:outline-none focus:ring-2 focus:ring-ring w-full sm:w-56"
              placeholder="搜索标题、类型..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
        </div>

        {/* Tabs + type filter */}
        <TabBar
          tabs={[
            { value: "未确认" as const, label: "未确认" },
            { value: "已确认" as const, label: "已确认" },
            { value: "已解决" as const, label: "已解决" },
            { value: "全部" as const, label: "全部" },
          ]}
          active={tab}
          onChange={(t) => handleTabChange(t as "未确认" | "已确认" | "已解决" | "全部")}
          showCounts={false}
          trailing={
            <Select onValueChange={v => handleTypeChange(v)} value={typeFilter}>
  <SelectTrigger className="border border-border rounded-md px-2.5 py-1 text-sm bg-card focus:outline-none focus:ring-2 focus:ring-ring text-foreground w-full md:w-auto"><SelectValue /></SelectTrigger>
  <SelectContent>

              {typeOptions.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
            
  </SelectContent>
</Select>
          }
        />
      </div>

      {/* Alert list */}
      <div className="flex-1 overflow-y-auto px-6 py-3">
        {displayed.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 py-2.5 border-b border-border">
            <label className="inline-flex items-center gap-2 text-xs text-muted-foreground cursor-pointer select-none">
              <input
                type="checkbox"
                className="rounded accent-primary"
                checked={allDisplayedSelected}
                onChange={toggleDisplayedSelection}
                aria-label="全选当前警报"
              />
              全选当前列表
            </label>
            {selectedIds.length > 0 && (
              <>
                <span className="text-xs text-muted-foreground">已选 {selectedIds.length} 条</span>
                <Button variant="outline"
                  onClick={() => void handleBatchAction("acknowledge")}
                  disabled={isBatchProcessing || acknowledgeIds.length === 0}
                  className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-primary border border-border hover:border-primary rounded px-2.5 py-1 transition-colors bg-card disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                >
                  <CheckCircle2 size={12} />批量确认
                </Button>
                <Button variant="default"
                  onClick={() => void handleBatchAction("resolve")}
                  disabled={isBatchProcessing || resolveIds.length === 0}
                  className="inline-flex items-center gap-1 text-xs font-medium text-white bg-primary hover:bg-blue-700 rounded px-2.5 py-1 transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                >
                  <CheckCheck size={12} />批量解决
                </Button>
              </>
            )}
          </div>
        )}
        {displayed.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground gap-3">
            <Bell size={32} className="opacity-30" />
            <p className="text-sm">暂无{tab !== "全部" ? tab : ""}警报</p>
          </div>
        )}
        <div className="space-y-0">
          {displayed.map((alert) => {
            const isWarning = alert.level === "警告";
            const isSolved = alert.status === "已解决";
            return (
              <div
                key={alert.id}
                className={`flex items-start gap-4 py-4 border-b border-border last:border-0 transition-opacity ${isSolved ? "opacity-60" : ""}`}
              >
                <input
                  type="checkbox"
                  className="mt-2 rounded accent-primary shrink-0"
                  checked={selectedIds.includes(alert.id)}
                  onChange={() => toggleAlertSelection(alert.id)}
                  aria-label={`选择警报：${alert.title}`}
                />
                {/* Icon */}
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                  isWarning ? "bg-amber-100 dark:bg-amber-950/40" : "bg-blue-50 dark:bg-blue-950/40"
                }`}>
                  {isWarning
                    ? <AlertTriangle size={15} className="text-amber-500 dark:text-amber-300" />
                    : <Circle size={15} className="text-blue-400 dark:text-blue-300 fill-blue-100 dark:fill-blue-950" />
                  }
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-1.5 py-0.5 rounded ${
                      isWarning ? "bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300" : "bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-300"
                    }`}>
                      {isWarning ? <AlertTriangle size={9} /> : <Bell size={9} />}
                      {alert.level}
                    </span>
                    <span className="inline-flex text-[11px] font-medium px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                      {alert.type}
                    </span>
                    {alert.status === "已确认" && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-medium px-1.5 py-0.5 rounded bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-300">
                        <CheckCircle2 size={9} />已确认
                      </span>
                    )}
                    {alert.status === "已解决" && (
                      <span className="inline-flex items-center gap-1 text-[11px] font-medium px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-300">
                        <CheckCheck size={9} />已解决
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-foreground leading-snug">{alert.title}</p>
                  <p className="text-xs text-muted-foreground mt-1">{alert.time}</p>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap items-center gap-2 shrink-0">
                  {alert.status === "未确认" && (
                    <Button variant="outline"
                      onClick={() => handleAcknowledge(alert.id)}
                      className="flex items-center gap-1 text-xs font-medium text-muted-foreground hover:text-primary border border-border hover:border-primary rounded px-2.5 py-1 transition-colors bg-card cursor-pointer"
                    >
                      <CheckCircle2 size={12} />确认
                    </Button>
                  )}
                  {alert.status !== "已解决" && (
                    <Button variant="default"
                      onClick={() => handleResolve(alert.id)}
                      className="flex items-center gap-1 text-xs font-medium text-white bg-primary hover:bg-blue-700 rounded px-2.5 py-1 transition-colors cursor-pointer"
                    >
                      <CheckCheck size={12} />解决
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Pagination */}
      <div className="px-6 pb-4">
        <PaginationBar page={page} pageSize={pageSize} total={total} onPageChange={setPage} onPageSizeChange={setPageSize} />
      </div>
    </div>
  );
}
