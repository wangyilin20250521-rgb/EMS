/** *会话历史恢复的纯函数 — 从落盘文档（/api/conversations/:id）与提议记录
 * （/api/actions/session）重建前端 AIMessage 列表。从 useAIChat 拆出，无副作用。
 */
import type { ActionProposal, QuestionSpec } from "@/app/lib/utils/sse"
import type { AIMessage, AIProcessItem } from "./chatReducer.js"

type ConversationMessage = {
  role: "user" | "ai" | "toolResult"
  text: unknown
  /** 落盘消息时间戳（毫秒；提议卡挂载匹配用） */
  timestamp?: number
}

function extractMessageText(raw: unknown): string {
  if (typeof raw === "string") {
    if (raw.trimStart().startsWith("[")) {
      try {
        const blocks = JSON.parse(raw)
        if (Array.isArray(blocks)) {
          return blocks
            .filter((block): block is { type?: unknown; text?: unknown } => typeof block === "object" && block !== null)
            .filter(block => block.type === "text")
            .map(block => typeof block.text === "string" ? block.text : "")
            .join("")
        }
      } catch { /* Keep non-JSON strings as-is. */ }
    }
    return raw
  }
  if (Array.isArray(raw)) {
    return raw
      .filter((block): block is { type?: unknown; text?: unknown } => typeof block === "object" && block !== null)
      .filter(block => block.type === "text")
      .map(block => typeof block.text === "string" ? block.text : "")
      .join("")
  }
  return String(raw ?? "")
}

export function normalizeConversationMessages(rawMessages: ConversationMessage[]): AIMessage[] {
  const messages: AIMessage[] = []
  let currentUser: (AIMessage & { hidden?: boolean }) | null = null
  let currentTurn: ConversationMessage[] = []

  const flushTurn = () => {
    if (!currentUser) return

    // hidden 回合（系统通知/续流指令等机械注入）：不作为用户消息展示，
    // 但其后的 AI 回复仍独立成条（用户侧不再看到带 JSON 的执行回执）
    if (!currentUser.hidden) messages.push(currentUser)
    const answerIndex = currentTurn.reduce((lastIndex, message, index) => (
      message.role === "ai" && extractMessageText(message.text).trim() ? index : lastIndex
    ), -1)
    const process = currentTurn.flatMap((message, index): AIProcessItem[] => {
      const text = extractMessageText(message.text).trim()
      if (!text || (message.role === "ai" && index === answerIndex)) return []
      return [{
        id: `${currentUser?.id ?? "unknown"}-process-${index}`,
        type: message.role === "toolResult" ? "tool" : "thinking",
        text,
      }]
    })

    const answer = answerIndex >= 0 ? extractMessageText(currentTurn[answerIndex].text).trim() : ""
    if (answer || process.length > 0) {
      messages.push({
        id: `${currentUser.id}-response`,
        role: "ai",
        text: answer,
        // 时间戳：答案消息的 ts（提议卡挂载匹配；缺省回落用户消息 ts）
        ts: (answerIndex >= 0 ? currentTurn[answerIndex].timestamp : undefined) ?? currentUser.ts,
        process,
        streaming: false,
      })
    }
  }

  rawMessages.forEach((message, index) => {
    if (message.role === "user") {
      const text = extractMessageText(message.text)
      flushTurn()
      if (text.startsWith("【系统通知】")) {
        // 系统通知（确认执行回执/自动续流指令）：隐藏但保留回合边界——
        // 其后的 AI 继续回复独立成条，不混入前一个用户回合
        currentUser = { id: `history-sys-${index}`, role: "user", text: "", ts: message.timestamp, hidden: true }
        currentTurn = []
        return
      }
      currentUser = { id: `history-${index}`, role: "user", text, ts: message.timestamp }
      currentTurn = []
    } else if (currentUser) {
      currentTurn.push(message)
    }
  })
  flushTurn()

  return messages
}

/** *把会话提议卡挂回历史消息（卡片恢复）：
 * 按 ts 找到"提议创建之前的最近一条 AI 消息"挂入 proposals[]——重开对话后
 * DecisionCard/收据卡样式与当时一致；无匹配消息时追加独立卡消息兜底。
 * 数据源 = /api/actions/session（audit.ai_actions 全量，含终态与过期归一）。
 */
export function attachProposals(messages: AIMessage[], actions: ActionProposal[]): void {
  if (actions.length === 0) return
  const sorted = [...actions].sort((a, b) => (a.ts ?? 0) - (b.ts ?? 0))
  for (const action of sorted) {
    const ts = action.ts
    let target = -1
    for (let i = 0; i < messages.length; i++) {
      const m = messages[i]
      if (m.role === "ai" && (ts === undefined || (m.ts ?? 0) <= ts)) target = i
    }
    if (target >= 0) {
      const m = messages[target]
      messages[target] = { ...m, proposals: [...(m.proposals ?? []), action] }
    } else {
      messages.push({ id: `restored-action-${action.proposalId}`, role: "ai", text: "", proposals: [action], streaming: false })
    }
  }
}

/** *把无 field 的普通问题卡挂回历史消息（卡片恢复延续）：
 * 带 field 的问题已由向导（wizardSteps）路径恢复，此处只处理普通问题卡——
 * 按 ts 挂到对应 AI 消息（渲染为决策卡内嵌的"已回答：xxx"/待答区），不再退化为纯文本。
 */
export function attachQuestions(
  messages: AIMessage[],
  questions: Array<{ questionId: string; question: string; field?: string; options?: string[]; multi?: boolean; answered?: boolean; answerText?: string; ts: number }>
): void {
  for (const q of [...questions].sort((a, b) => a.ts - b.ts)) {
    // 带 field 且未答 → 留给向导（wizardSteps）路径渲染，避免双渲染；
    // 已答的（含带 field）一律挂回消息——向导卡对全答场景不渲染，这里是唯一的可见形态
    if (q.field && !q.answered) continue
    const spec: QuestionSpec = {
      questionId: q.questionId,
      question: q.question,
      options: q.options,
      multi: q.multi,
      answered: q.answered === true,
      ...(q.answerText ? { answerText: q.answerText } : {}),
    }
    let target = -1
    for (let i = 0; i < messages.length; i++) {
      const m = messages[i]
      if (m.role === "ai" && (m.ts ?? 0) <= q.ts) target = i
    }
    if (target >= 0) {
      const m = messages[target]
      messages[target] = { ...m, questions: [...(m.questions ?? []), spec] }
    } else {
      messages.push({ id: `restored-question-${q.questionId}`, role: "ai", text: "", questions: [spec], streaming: false })
    }
  }
}
