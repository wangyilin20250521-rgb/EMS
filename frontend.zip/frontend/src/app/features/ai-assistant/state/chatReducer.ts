/** *AI 对话消息列表的纯 reducer — useAIChat 仅保留 SSE 连接/发送/abort 副作用，
 * 消息列表的全部状态迁移（追加、流式帧合入、完成/中止、错误气泡、卡片状态回填）
 * 收敛在此，行为与拆分前的 setMessages 内联实现一一对应。
 */
import type { ActionProposal, ChartSpec, QuestionSpec } from "@/app/lib/utils/sse"

export interface AIMessage {
  id?: string
  role: "user" | "ai"
  text: string
  /** 消息时间戳（毫秒；历史恢复时用于把提议卡挂回原消息） */
  ts?: number
  process?: AIProcessItem[]
  /** AI 通过 render_chart 生成的图表（chart_data 事件累积） */
  charts?: ChartSpec[]
  /** AI 写操作提议（action_proposal 事件累积，渲染金色确认卡） */
  proposals?: ActionProposal[]
  /** AI 结构化提问（question 事件累积，渲染问题卡片；answered 为前端本地标记） */
  questions?: QuestionSpec[]
  streaming?: boolean
}

export interface AIProcessItem {
  id: string
  type: "thinking" | "tool"
  text: string
  /** 结构化工具名（tool 项专有；工作记录按模块归组的数据源） */
  toolName?: string
  /** 工具是否失败（tool 项专有） */
  toolError?: boolean
  /** 工具项阶段：start / end（工作记录只按 end 计数） */
  toolPhase?: "start" | "end"
}

/**流式帧合入补丁（lib/chat/stream-turn 引擎产出） */
export interface StreamPatch {
  text: string
  process: AIProcessItem[]
  charts?: ChartSpec[]
  proposals: ActionProposal[]
  questions?: QuestionSpec[]
}

export type ChatAction =
  | { type: "append"; message: AIMessage }
  | { type: "applyStreamPatch"; patch: StreamPatch }
  | { type: "finishStreaming" }
  | { type: "errorBubble"; text: string }
  | { type: "markQuestionAnswered"; questionId: string }
  | { type: "updateProposal"; proposalId: string; patch: Partial<ActionProposal> }
  | { type: "setMessages"; messages: AIMessage[] }

export function chatReducer(state: AIMessage[], action: ChatAction): AIMessage[] {
  switch (action.type) {
    case "append":
      return [...state, action.message]

    case "setMessages":
      return action.messages

    case "applyStreamPatch": {
      const last = state[state.length - 1]
      if (!(last?.role === "ai" && last.streaming)) return state
      return [...state.slice(0, -1), {
        ...last,
        text: action.patch.text,
        process: action.patch.process,
        charts: action.patch.charts,
        // 按 proposalId 合并：保留已落定的非 pending 终态（confirmed/failed/cancelled），
        // 避免引擎的 pending 快照在流式后续帧把用户刚确认的卡冲回 pending（导致按钮"复活"、二次点击 409）
        proposals: action.patch.proposals.map(p => {
          const prevCard = last.proposals?.find(x => x.proposalId === p.proposalId)
          return prevCard && prevCard.status !== "pending"
            ? { ...p, status: prevCard.status, result: prevCard.result }
            : p
        }),
        questions: action.patch.questions,
        streaming: true,
      }]
    }

    case "finishStreaming": {
      const last = state[state.length - 1]
      if (!(last?.role === "ai" && last.streaming)) return state
      return [...state.slice(0, -1), { ...last, streaming: false }]
    }

    case "errorBubble": {
      const last = state[state.length - 1]
      if (last?.role === "ai" && last.streaming) {
        return [...state.slice(0, -1), { role: "ai" as const, text: action.text, streaming: false }]
      }
      return [...state, { role: "ai" as const, text: action.text, streaming: false }]
    }

    case "markQuestionAnswered":
      return state.map(m =>
        m.questions
          ? { ...m, questions: m.questions.map(q => q.questionId === action.questionId ? { ...q, answered: true } : q) }
          : m
      )

    case "updateProposal":
      return state.map(m => {
        if (!m.proposals?.length) return m
        return { ...m, proposals: m.proposals.map(p => p.proposalId === action.proposalId ? { ...p, ...action.patch } : p) }
      })
  }
}
