import { useState } from "react";
import { HelpCircle, Loader2, Send } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import type { QuestionSpec } from "@/app/lib/utils/sse";
import { ChoiceInput } from "./ChoiceInput";

/**
 * 结构化提问交互区（2026-09-10）— AI 确认一律选择题：
 * options 存在 → ChoiceInput（单选点选即答 / 多选勾选确认，多选提交值以「、」分隔）；
 * 无 options 仅在确属自由文本时兜底输入（AI 侧已约束尽量不触发）。answered 由父组件 prop 驱动。
 */
export function QuestionControls({
  question,
  onAnswer,
  disabled,
}: {
  question: QuestionSpec;
  onAnswer: (answer: string) => void;
  /** 全局流式期间禁答（2026-09-22）：pending 态不渲染可点控件，防流式中误点 */
  disabled?: boolean;
}) {
  const [submitted, setSubmitted] = useState(false);
  const [input, setInput] = useState("");
  const status = question.answered ? "answered" : submitted ? "answering" : "pending";

  const submitText = (text: string) => {
    if (disabled || status !== "pending") return;
    setSubmitted(true);
    onAnswer(text);
  };

  if (disabled && status === "pending") {
    return (
      <p className="text-[13px] text-muted-foreground">AI 正在回复，回复完成后即可选择答案。</p>
    );
  }

  if (status === "pending" && question.options && question.options.length > 0) {
    return (
      <ChoiceInput
        options={question.options}
        multi={question.multi}
        onSubmit={values => submitText(values.join("、"))}
      />
    );
  }

  if (status === "pending") {
    // 兜底：确属自由文本（姓名/备注等）——仍给出输入，AI 端约束尽量不走到这
    return (
      <div className="flex items-center gap-2 pt-0.5">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter") { const v = input.trim(); if (v) submitText(v); } }}
          placeholder="输入后回车提交…"
          className="flex-1 text-[14px] h-8 px-2.5 rounded-md border border-border bg-background outline-none focus:border-primary/60"
        />
        <Button size="sm" onClick={() => { const v = input.trim(); if (v) submitText(v); }} className="text-[14px] shrink-0">
          <Send size={12} />
          提交
        </Button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1.5 pt-0.5 text-[14px] text-muted-foreground">
      {status === "answering" ? (
        <>
          <Loader2 size={13} className="animate-spin" />
          已收到回答，正在继续…
        </>
      ) : (
        <>
          <Send size={13} className="text-chart-2" />
          <span className="text-chart-2">
            已回答{question.answerText ? `：${question.answerText}` : ""}
          </span>
        </>
      )}
    </div>
  );
}

/**
 * AI 结构化提问卡（Phase A）— 独立卡片形态（流式期间/历史消息使用；决策卡内嵌时用 QuestionControls）。
 */
export function QuestionCard({
  question,
  onAnswer,
}: {
  question: QuestionSpec;
  onAnswer: (answer: string) => void;
}) {
  return (
    <Card className="py-0 gap-0 overflow-hidden border-primary/40 shadow-[0_0_14px_var(--primary)/20]">
      <div className="flex items-center gap-2 px-3 py-2 bg-primary-light-5 border-b border-primary/20">
        <HelpCircle size={14} className="text-primary shrink-0" />
        <span className="text-[14px] font-semibold text-foreground">AI 需要确认</span>
        {question.multi && (
          <span className="text-[14px] px-1.5 py-0.5 rounded bg-primary/10 text-primary font-medium">可多选</span>
        )}
        {question.required === false && (
          <span className="text-[14px] px-1.5 py-0.5 rounded bg-primary/10 text-primary font-medium">可跳过</span>
        )}
      </div>

      <div className="px-3 py-2.5 space-y-2">
        <p className="text-[14px] text-foreground leading-snug">{question.question}</p>
        <QuestionControls question={question} onAnswer={onAnswer} />
      </div>
    </Card>
  );
}
