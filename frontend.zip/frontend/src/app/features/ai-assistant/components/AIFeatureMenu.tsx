import { useState } from "react";
import { LayoutGrid } from "lucide-react";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/app/components/ui/hover-card";
import { AI_TEMPLATE_GROUPS, AI_TEMPLATES, type AITemplateItem } from "@/app/lib/constants/ai-features";
import { TemplateIcon } from "./ai-template-icons";

/**
 * 功能化引导入口（2026-09）：输入框旁的功能键 —— **鼠标悬停即展开**分组场景模板面板
 * （少一次点击，演示更顺滑）；移入面板保持展开，点击模板 = 填入输入框（可编辑后发送）。
 *
 * 2026-09-16 起无入口引用：左栏「技能」功能卡（AIChatSidebar）已完全承接本组交互，
 * 输入框旁按钮按用户反馈移除。文件保留待用（如需回退/复用悬停面板）。
 */
export function AIFeatureMenu({
  disabled = false,
  onPick,
}: {
  disabled?: boolean;
  onPick: (item: AITemplateItem) => void;
}) {
  const [open, setOpen] = useState(false);

  const handlePick = (item: AITemplateItem) => {
    setOpen(false);
    onPick(item);
  };

  return (
    <HoverCard open={open} onOpenChange={setOpen} openDelay={120} closeDelay={80}>
      <HoverCardTrigger asChild>
        <button
          type="button"
          title="功能引导（鼠标悬停展开，少打字多点击）"
          aria-label="功能引导"
          disabled={disabled}
          className="w-10 h-10 shrink-0 rounded-xl border border-border bg-transparent text-muted-foreground flex items-center justify-center hover:text-primary hover:border-primary/40 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <LayoutGrid size={18} />
        </button>
      </HoverCardTrigger>
      <HoverCardContent
        align="end"
        side="top"
        sideOffset={6}
        className="w-[21rem] p-0 max-h-[min(60vh,26rem)] flex flex-col overflow-hidden"
      >
        <div className="px-3 py-2 border-b border-border text-[14px] font-semibold text-muted-foreground">
          功能引导 — 点选场景模板，填入后可编辑再发送
        </div>
        <div className="overflow-y-auto py-1">
          {AI_TEMPLATE_GROUPS.map((g) => (
            <div key={g.id}>
              <p className="px-3 pt-2 pb-1 text-[14px] font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-1.5">
                <TemplateIcon name={g.icon} size={11} />
                {g.label}
              </p>
              {AI_TEMPLATES.filter((t) => t.group === g.id).map((tpl) => (
                <button
                  key={tpl.id}
                  type="button"
                  onClick={() => handlePick(tpl)}
                  className="w-full flex items-start gap-2.5 px-3 py-2 text-left hover:bg-muted/50 transition-colors cursor-pointer"
                >
                  <span className="mt-0.5 w-6 h-6 shrink-0 rounded-md bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-300">
                    <TemplateIcon name={tpl.icon} size={13} />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-[14px] font-medium text-foreground leading-tight">{tpl.label}</span>
                    <span className="block text-[14px] text-muted-foreground truncate" title={tpl.description}>
                      {tpl.description}
                    </span>
                  </span>
                </button>
              ))}
            </div>
          ))}
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}
