import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/app/components/ui/tooltip";
import { AI_TEMPLATE_GROUPS, AI_TEMPLATES, type AITemplateItem } from "@/app/lib/constants/ai-features";
import { TemplateIcon } from "./ai-template-icons";

/**
 * 技能面板（原「提示词模板」，2026-09-17 方案 2；2026-09-21 更名对齐 WorkBuddy 叫法）
 * 原实现是 720px 宽的 HoverCard + 每组一个边框卡 + 每项两行文字（标题+副文案）：
 * 25 条模板 = 50 行文字、8 层边框，且 hover 承载滚动/搜索本就是错配。
 * 现改为方块格子面板：
 * - 方块（icon + 短标签，副文案进 tooltip）——文字密度降一半，视觉对齐侧栏入口卡的图标语言；
 * - 分组只留小号标题，不再套边框卡。
 * 2026-09-21：「最近使用」分组与顶部「搜索能力」框整块移除（用户反馈：顶部不必有这些）。
 * 2026-09-21：外壳（Popover + 触发卡）交回 SidebarCallout，本组件只负责浮层内容，
 * 四张入口卡因此共用同一套「悬浮/点击出现、移开消失」的交互。
 */

/** 策略规则组已独立成「调用入口」卡片，不在本面板展示（与重构前口径一致） */
const PANEL_GROUPS = AI_TEMPLATE_GROUPS.filter((g) => g.id !== "rules");

/** 单个能力方块：8×8 图标块 + 单/双行短标签（2026-09-21 起浮层内部去色：hover 只做中性灰底，
 *  图标块保持灰阶，不引入主色/状态色） */
function Tile({ template, onPick }: { template: AITemplateItem; onPick: (t: AITemplateItem) => void }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          onClick={() => onPick(template)}
          className="group flex w-[82px] flex-col items-center gap-1.5 rounded-xl border border-border bg-card px-1.5 py-2.5 transition-colors cursor-pointer hover:bg-muted/50"
        >
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-300">
            <TemplateIcon name={template.icon} size={16} />
          </span>
          <span className="line-clamp-2 text-center text-[11px] leading-tight text-foreground">{template.label}</span>
        </button>
      </TooltipTrigger>
      <TooltipContent side="right" className="max-w-[240px] text-[12px] leading-snug">
        {template.description}
      </TooltipContent>
    </Tooltip>
  );
}

export function PromptTemplatePanel({ onPick }: { onPick: (t: AITemplateItem) => void }) {
  return (
    <TooltipProvider delayDuration={250}>
      <div className="flex-1 overflow-y-auto px-3 py-3">
        {PANEL_GROUPS.map((group) => {
          const items = AI_TEMPLATES.filter((t) => t.group === group.id);
          if (items.length === 0) return null;
          return (
            <section key={group.id} className="mb-3 last:mb-0">
              <p className="mb-2 flex items-center gap-1.5 text-[12px] font-semibold text-muted-foreground">
                <TemplateIcon name={group.icon} size={12} />
                {group.label}
                <span className="ml-auto font-normal text-muted-foreground/60">{items.length}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {items.map((t) => (
                  <Tile key={t.id} template={t} onPick={onPick} />
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </TooltipProvider>
  );
}
