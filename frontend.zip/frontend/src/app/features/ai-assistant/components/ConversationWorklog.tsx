import { useEffect, useMemo, useState } from "react";
import { ChevronRight, History, Loader2 } from "lucide-react";

import { getAiWorkflowTasks, type AiWorkflowTask } from "@/app/lib/api/ai";
import { findAiTool } from "@/app/lib/api/ai-tools";
import { aiToolLabel } from "@/app/lib/constants/ai-tool-labels";
import type { AIMessage } from "@/app/features/ai-assistant/state/chatReducer";
import type { ActionProposal } from "@/app/lib/utils/sse";

/**
 * 对话内「工作记录」小插件（2026-09-17）——左栏「AI 工作任务」「状态看板」两张卡下线后，
 * 把"本次对话都干了什么"收敛到对话流顶部的一条摘要，对齐主流 Agent 软件形态：
 * - 收起态一行：方向数 + 操作数（如"3 个方向 · 8 项操作"），不占视觉权重；
 * - 展开态按「方向」分组（方向取自 ai-tools 目录的 module，如 收样中心/排单/策略规则），
 *   每组列出具体操作：读操作 = 工具名 × 次数（失败单列），写操作 = 提议摘要 + 状态；
 * - 若本会话存在进行中的 AI 工作任务（agent.ai_tasks，按 sessionId 过滤）→ 顶部显示步骤进度，
 *   这是原「AI 工作任务」卡的职责，现随对话呈现；
 * - 纯前端聚合（消息里的 process/proposals），历史会话恢复后依然可重建。
 */

/** *不计入工作记录的工具：纯编排/交互手段。
 * propose_action 是"写操作的载体"——写操作本身已按提议摘要单列，再把它当读操作计数是重复且噪音；
 * 任务工具是进度载体（单独展示步骤）；ask_user/request_form/request_file 是交互而非工作产出。 */
const EXCLUDED_TOOLS = new Set([
  "propose_action",
  "create_workflow_task",
  "update_workflow_task",
  "ask_user",
  "request_form",
  "request_file",
]);

/** agent-server 静态工具（不在 ai-tools 目录内）的中文方向名 */
const STATIC_TOOL_DIRECTION: Record<string, string> = {
  query_database: "数据查询",
  search_knowledge_base: "知识库检索",
  scan_operational_insights: "风险巡检",
  rule_guidance: "策略规则",
  read_file: "策略规则",
  show_rule_file: "策略规则",
  render_chart: "图表生成",
  delegate: "子助手委派",
  // 正则快路的合成工具名（chat-handler 直接下发展示名，非注册表工具）
  结构化查询: "数据查询",
  create_workflow_task: "工作任务",
  update_workflow_task: "工作任务",
};

interface Operation {
  /** 读操作的工具名；写操作为空 */
  toolName?: string;
  /** 写操作摘要 */
  summary?: string;
  status?: ActionProposal["status"];
  failed?: boolean;
}

interface Direction {
  name: string;
  reads: Map<string, { count: number; failed: number }>;
  writes: Operation[];
}

const WRITE_STATUS_LABEL: Record<string, string> = {
  pending: "待确认",
  confirmed: "已执行",
  cancelled: "已取消",
  failed: "失败",
  expired: "已过期",
};

/** 聚合本次对话的操作（导出供单测；纯函数、无副作用） */
export function buildWorklog(messages: AIMessage[]): Direction[] {
  const byDirection = new Map<string, Direction>();
  const directionOf = (name: string): string => {
    if (STATIC_TOOL_DIRECTION[name]) return STATIC_TOOL_DIRECTION[name];
    const module = moduleCache.get(name);
    return module ?? "其他操作";
  };
  const pick = (name: string): Direction => {
    const key = directionOf(name);
    let dir = byDirection.get(key);
    if (!dir) {
      dir = { name: key, reads: new Map(), writes: [] };
      byDirection.set(key, dir);
    }
    return dir;
  };

  for (const m of messages) {
    for (const item of m.process ?? []) {
      if (item.type !== "tool" || !item.toolName) continue;
      // 一次工具调用会产生"开始行 + 结果行"两条过程项，只按结果行计数
      if (item.toolPhase === "start") continue;
      if (EXCLUDED_TOOLS.has(item.toolName)) continue;
      const dir = pick(item.toolName);
      const stat = dir.reads.get(item.toolName) ?? { count: 0, failed: 0 };
      stat.count += 1;
      if (item.toolError) stat.failed += 1;
      dir.reads.set(item.toolName, stat);
    }
    for (const p of m.proposals ?? []) {
      const dir = pick(p.toolName);
      dir.writes.push({ summary: p.summary, status: p.status, failed: p.status === "failed" });
    }
  }

  // 方向排序：有写操作的方向优先，其次按操作总数降序
  return [...byDirection.values()].sort((a, b) => {
    const total = (d: Direction) => d.writes.length + [...d.reads.values()].reduce((n, s) => n + s.count, 0);
    if (a.writes.length !== b.writes.length) return b.writes.length - a.writes.length;
    return total(b) - total(a);
  });
}

/** 工具名 → 模块名缓存（ai-tools 目录自带 module，懒加载一次） */
const moduleCache = new Map<string, string>();
let moduleCachePrimed = false;

function useToolModules(toolNames: string[]): number {
  const [version, setVersion] = useState(0);
  const key = toolNames.join(",");
  useEffect(() => {
    if (!key) return;
    if (moduleCachePrimed && toolNames.every((n) => moduleCache.has(n) || STATIC_TOOL_DIRECTION[n])) return;
    let alive = true;
    void Promise.all(
      toolNames.map(async (name) => {
        const entry = await findAiTool(name);
        if (entry?.module) moduleCache.set(name, entry.module);
      })
    ).then(() => {
      moduleCachePrimed = true;
      if (alive) setVersion((v) => v + 1);
    });
    return () => { alive = false; };
  }, [key]);
  return version;
}

export function ConversationWorklog({
  messages,
  sessionId,
  streaming,
}: {
  messages: AIMessage[];
  sessionId: string | null;
  streaming: boolean;
}) {
  const toolNames = useMemo(() => {
    const names = new Set<string>();
    for (const m of messages) {
      for (const it of m.process ?? []) if (it.toolName && !EXCLUDED_TOOLS.has(it.toolName)) names.add(it.toolName);
      // 写操作名只出现在提议里（propose_action 的 toolName 参数），需一并解析模块归属
      for (const p of m.proposals ?? []) names.add(p.toolName);
    }
    return [...names];
  }, [messages]);
  const moduleVersion = useToolModules(toolNames);

  const directions = useMemo(() => buildWorklog(messages), [messages, toolNames, moduleVersion]);

  // 本会话的 AI 工作任务（进度随对话呈现）
  const [tasks, setTasks] = useState<AiWorkflowTask[]>([]);
  useEffect(() => {
    let alive = true;
    const load = () =>
      getAiWorkflowTasks()
        .then((list) => { if (alive) setTasks(list); })
        .catch(() => {});
    load();
    window.addEventListener("mlims:ai-task-update", load);
    return () => { alive = false; window.removeEventListener("mlims:ai-task-update", load); };
  }, []);
  const sessionTasks = useMemo(
    () => (sessionId ? tasks.filter((t) => t.sessionId === sessionId) : []),
    [tasks, sessionId]
  );

  const [open, setOpen] = useState(false);
  const opCount = directions.reduce((n, d) => n + d.writes.length + [...d.reads.values()].reduce((s, v) => s + v.count, 0), 0);
  const hasContent = directions.length > 0 || sessionTasks.length > 0;
  // 无操作记录时不占位（欢迎页/空会话）；流式期间也不显示（避免与过程行抢视觉）
  if (!hasContent || streaming) return null;

  return (
    <div className="w-full max-w-3xl rounded-lg border border-border bg-muted/20 text-[13px]">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="flex w-full items-center gap-1.5 px-3 py-2 text-left text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
      >
        <History size={13} className="shrink-0" />
        <span className="font-medium">本次对话工作记录</span>
        <span className="text-muted-foreground/80">
          {directions.length} 个方向 · {opCount} 项操作
        </span>
        <ChevronRight size={13} className={`ml-auto shrink-0 transition-transform ${open ? "rotate-90" : ""}`} />
      </button>

      {open && (
        <div className="border-t border-border px-3 py-2.5 space-y-3">
          {sessionTasks.map((task) => {
            const done = task.steps.filter((s) => s.status === "completed").length;
            return (
              <div key={task.id}>
                <div className="flex items-center gap-1.5 text-foreground font-medium">
                  {task.status === "active" && <Loader2 size={11} className="animate-spin shrink-0" />}
                  <span className="truncate">{task.title}</span>
                  <span className="ml-auto shrink-0 text-muted-foreground font-normal">{done}/{task.steps.length} 步</span>
                </div>
                <div className="mt-1 space-y-0.5 pl-4">
                  {task.steps.map((s) => (
                    <div key={s.seq} className="flex items-center gap-1.5 text-muted-foreground">
                      <span className={s.status === "completed" ? "text-emerald-600" : ""}>
                        {s.status === "completed" ? "✓" : s.status === "blocked" ? "!" : "·"}
                      </span>
                      <span className="truncate">{s.title}</span>
                    </div>
                  ))}
                </div>
                {task.nextAction && <p className="mt-1 pl-4 text-primary">下一步：{task.nextAction}</p>}
              </div>
            );
          })}

          {directions.map((dir) => (
            <div key={dir.name}>
              <p className="font-medium text-foreground">{dir.name}</p>
              <div className="mt-0.5 space-y-0.5 pl-4">
                {dir.writes.map((w, i) => (
                  <div key={`w-${i}`} className="flex items-center gap-1.5 text-muted-foreground">
                    <span className={w.failed ? "text-destructive" : w.status === "confirmed" ? "text-emerald-600" : ""}>
                      {w.failed ? "✗" : w.status === "confirmed" ? "✓" : "○"}
                    </span>
                    <span className="truncate">{w.summary ?? "写操作"}</span>
                    <span className="ml-auto shrink-0 text-muted-foreground/70">{w.status ? WRITE_STATUS_LABEL[w.status] : ""}</span>
                  </div>
                ))}
                {[...dir.reads.entries()].map(([name, stat]) => (
                  <div key={`r-${name}`} className="flex items-center gap-1.5 text-muted-foreground">
                    <span>·</span>
                    {/* 展示中文名；英文原名挂 title（口径见 ai-tool-labels.ts） */}
                    <span className="truncate" title={name}>{aiToolLabel(name)}</span>
                    <span className="ml-auto shrink-0 text-muted-foreground/70">
                      {stat.count} 次{stat.failed > 0 ? `（${stat.failed} 次失败）` : ""}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
