import { describe, expect, it } from "vitest";
import { buildWorklog } from "./ConversationWorklog";
import type { AIMessage } from "@/app/features/ai-assistant/state/chatReducer";

/** 对话内「工作记录」聚合逻辑（纯函数）——按方向归组读/写操作，供摘要行与展开列表共用。 */
const msg = (patch: Partial<AIMessage>): AIMessage => ({ role: "ai", text: "", ...patch });

describe("buildWorklog（本次对话工作记录聚合）", () => {
  it("读操作按工具名归组并计次；写操作保留摘要与状态", () => {
    const dirs = buildWorklog([
      msg({
        process: [
          { id: "1", type: "tool", text: "🔧 query_database", toolName: "query_database", toolPhase: "start" },
          { id: "2", type: "tool", text: "✅ query_database", toolName: "query_database", toolPhase: "end" },
          { id: "3", type: "tool", text: "🔧 search_knowledge_base", toolName: "search_knowledge_base", toolPhase: "start" },
          { id: "4", type: "tool", text: "✅ search_knowledge_base", toolName: "search_knowledge_base", toolPhase: "end" },
        ],
      }),
      msg({
        proposals: [
          {
            proposalId: "p1", toolName: "reception.register_batch", summary: "登记 16 例", args: {},
            status: "confirmed",
          },
        ],
      }),
    ]);
    const query = dirs.find((d) => d.name === "数据查询");
    expect(query?.reads.get("query_database")?.count).toBe(1);
    expect(dirs.find((d) => d.name === "知识库检索")?.reads.size).toBe(1);
    const reception = dirs.find((d) => d.name === "收样中心" || d.name === "其他操作");
    expect(reception?.writes[0]?.summary).toBe("登记 16 例");
    expect(reception?.writes[0]?.status).toBe("confirmed");
  });

  it("失败的工具调用单独计数（不混入成功次数）", () => {
    const dirs = buildWorklog([
      msg({
        process: [
          { id: "1", type: "tool", text: "✅ query_database", toolName: "query_database", toolPhase: "end" },
          { id: "2", type: "tool", text: "❌ query_database", toolName: "query_database", toolError: true, toolPhase: "end" },
        ],
      }),
    ]);
    const stat = dirs[0]?.reads.get("query_database");
    expect(stat?.count).toBe(2);
    expect(stat?.failed).toBe(1);
  });

  it("内部编排工具（create/update_workflow_task）不计入工作记录", () => {
    const dirs = buildWorklog([
      msg({
        process: [
          { id: "1", type: "tool", text: "✅ create_workflow_task", toolName: "create_workflow_task", toolPhase: "end" },
          { id: "2", type: "tool", text: "✅ update_workflow_task", toolName: "update_workflow_task", toolPhase: "end" },
        ],
      }),
    ]);
    expect(dirs.length).toBe(0);
  });

  it("thinking 项与无 toolName 的旧数据不产生方向", () => {
    const dirs = buildWorklog([
      msg({ process: [{ id: "1", type: "thinking", text: "在想" }, { id: "2", type: "tool", text: "🔧 旧格式" }] }),
    ]);
    expect(dirs.length).toBe(0);
  });

  it("同一次调用的开始行与结果行只计一次（2026-09-17 实测回归）", () => {
    const dirs = buildWorklog([
      msg({
        process: [
          { id: "1", type: "tool", text: "🔧 结构化查询", toolName: "结构化查询", toolPhase: "start" },
          { id: "2", type: "tool", text: "✅ 结构化查询", toolName: "结构化查询", toolPhase: "end" },
        ],
      }),
    ]);
    const stat = dirs[0]?.reads.get("结构化查询");
    expect(stat?.count).toBe(1);
    // 正则快路的合成工具名归入"数据查询"方向
    expect(dirs[0]?.name).toBe("数据查询");
  });

  it("propose_action 等编排/交互工具不计入（写操作已按提议摘要单列，避免重复计数）", () => {
    const dirs = buildWorklog([
      msg({
        process: [
          { id: "1", type: "tool", text: "✅ propose_action", toolName: "propose_action", toolPhase: "end" },
          { id: "2", type: "tool", text: "✅ propose_action", toolName: "propose_action", toolPhase: "end" },
          { id: "3", type: "tool", text: "✅ ask_user", toolName: "ask_user", toolPhase: "end" },
          { id: "4", type: "tool", text: "✅ request_form", toolName: "request_form", toolPhase: "end" },
        ],
        proposals: [
          { proposalId: "p1", toolName: "device.create", summary: "登记新设备", args: {}, status: "confirmed" },
        ],
      }),
    ]);
    expect(dirs.length).toBe(1);
    expect(dirs[0].writes.length).toBe(1);
    expect([...dirs[0].reads.keys()]).toEqual([]);
  });

  it("有写操作的方向排在前面", () => {
    const dirs = buildWorklog([
      msg({
        process: [
          { id: "1", type: "tool", text: "✅ query_database", toolName: "query_database", toolPhase: "end" },
          { id: "2", type: "tool", text: "✅ query_database", toolName: "query_database", toolPhase: "end" },
        ],
        proposals: [
          { proposalId: "p1", toolName: "sample.create", summary: "建样本", args: {}, status: "pending" },
        ],
      }),
    ]);
    expect(dirs[0].writes.length).toBeGreaterThan(0);
  });
});
