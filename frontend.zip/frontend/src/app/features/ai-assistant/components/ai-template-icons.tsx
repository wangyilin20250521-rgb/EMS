import {
  Activity, AlertTriangle, BarChart2, Bell, BookOpen, Boxes, CalendarDays, CalendarPlus, CalendarRange,
  CheckCircle2, ClipboardList, Clock, Dna, FileCog, FlaskConical, FolderOpen, Inbox, Layers, ListChecks,
  Microscope, PackageCheck, Pencil, PieChart, PlayCircle, Radar, Search, Settings2, ShieldAlert,
  ShieldCheck, SlidersHorizontal, TestTubes, Wrench, Zap,
} from "lucide-react";

// ─── AI 模板图标解析（icon 字符串 → lucide 组件；欢迎网格/侧栏/功能引导面板共用） ───

export const AI_TEMPLATE_ICON_MAP: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  Search, AlertTriangle, CalendarDays, Clock, Activity, BarChart2, PieChart,
  Inbox, PackageCheck, ShieldAlert,
  CalendarRange, CalendarPlus, ListChecks, CheckCircle2,
  BookOpen, SlidersHorizontal, FileCog, Settings2,
  // 2026-09-16 全功能覆盖扩展：样本与制备 / 实验与设备 / 质控处置 + 演示组 Zap 修复
  TestTubes, Microscope, ShieldCheck, Radar, Pencil, FolderOpen, ClipboardList,
  FlaskConical, PlayCircle, Dna, Boxes, Wrench, Bell, Zap,
  // 2026-09-18 解决方案入口卡
  Layers,
};

export function TemplateIcon({ name, size = 16, className }: { name: string; size?: number; className?: string }) {
  const Icon = AI_TEMPLATE_ICON_MAP[name] ?? Search;
  return <Icon size={size} className={className} />;
}
