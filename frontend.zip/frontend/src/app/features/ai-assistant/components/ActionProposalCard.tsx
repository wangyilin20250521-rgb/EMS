import { useState } from "react";
import { AlertTriangle, Check, ChevronDown, Loader2, Sparkles, X } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import type { ActionProposal } from "@/app/lib/utils/sse";

/**
 * AI 写操作确认卡（P2）— 金色边框标识"AI 提议"，用户确认后才真正执行。
 * 状态机: pending(确认/取消) → confirmed / cancelled / failed / expired
 */

export const TOOL_LABELS: Record<string, string> = {
  "reception.register_batch": "收样中心",
  "reception.batch_update": "修改批次样本",
  "reception.confirm_samples": "确认收样",
  "reception.report_anomaly": "收样异常上报",
  "schedule.create_pre_order": "创建排单",
  "schedule.confirm_pre_order": "确认排单",
  "siro.dispatch": "SIRO 投递",
  "siro.host_command": "设备控制",
  "siro.release_task": "释放任务",
  "anomaly.resolve": "处置异常",
  "alert.acknowledge": "确认预警",
  "alert.resolve": "处置预警",
  "strategy_rule.update_file": "保存规则文件",
  // 2026-09-24 补齐：此前未映射的工具直接暴露英文工具名，与已映射工具的中文标签不一致
  "sample.create": "新建样本",
  "sample.create_batch": "批量新建样本",
  "sample.update": "修改样本",
  "sample.update_status": "修改样本状态",
  "sample.delete": "删除样本",
  "task.create": "创建实验任务",
  "task.start": "启动任务",
  "task.terminate": "终止任务",
  "device.create": "新增设备",
  "device.update": "修改设备",
  "device.maintenance": "设备维护登记",
  "product.create": "登记产物",
  "product.update": "修改产物",
  "product.destroy": "销毁产物",
  "prep.create": "创建制备任务",
  "prep.submit_to_experiment": "提交实验",
  "sequencing.create": "创建测序任务",
  "sequencing.import_confirm": "确认导入测序任务",
  "user.create": "新建用户",
  "user.update": "修改用户",
  "user.toggle_status": "启用/停用用户",
};

export function ActionProposalCard({
  proposal,
  onConfirm,
  onCancel,
}: {
  proposal: ActionProposal;
  onConfirm: () => Promise<void>;
  onCancel: () => Promise<void>;
}) {
  const [showArgs, setShowArgs] = useState(false);
  const [busy, setBusy] = useState(false);
  const { status, toolName } = proposal;
  const label = TOOL_LABELS[toolName] ?? toolName;

  const handleConfirm = async () => {
    if (busy) return;
    setBusy(true);
    try { await onConfirm(); } finally { setBusy(false); }
  };
  const handleCancel = async () => {
    if (busy) return;
    setBusy(true);
    try { await onCancel(); } finally { setBusy(false); }
  };

  const destructive = proposal.destructive === true;

  return (
    // 2026-09-01 样式调整：去金色/淡黄配色改白底常规边框（用户要求），保留标题行标识"AI 提议"
    // 破坏性操作（2026-09-11）：红色边框 + 警示标题，确认按钮文案改"不可恢复"
    <Card className={`py-0 gap-0 overflow-hidden border-border ${destructive ? "border-destructive/50" : ""}`}>
      {/* 头部：白底标题行 + AI 提议标识 */}
      <div className={`flex items-center gap-2 px-3 py-2 border-b border-border ${destructive ? "bg-destructive/10" : ""}`}>
        {destructive ? <AlertTriangle size={14} className="text-destructive shrink-0" /> : <Sparkles size={14} className="text-primary shrink-0" />}
        <span className={`text-[14px] font-semibold ${destructive ? "text-destructive" : "text-foreground"}`}>
          {destructive ? "AI 操作建议（破坏性，请仔细核对）" : "AI 操作建议"}
        </span>
        <span className="text-[14px] px-1.5 py-0.5 rounded bg-primary-light-5 text-primary font-medium">{label}</span>
      </div>

      <div className="px-3 py-2.5 space-y-2">
        <p className="text-[14px] font-medium text-foreground leading-snug">{proposal.summary}</p>
        {proposal.rationale && (
          <p className="text-[14px] text-muted-foreground leading-snug">原因：{proposal.rationale}</p>
        )}

        {/* 参数折叠 */}
        <button
          type="button"
          onClick={() => setShowArgs(v => !v)}
          className="flex items-center gap-1 text-[14px] text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
        >
          <ChevronDown size={12} className={`shrink-0 transition-transform ${showArgs ? "rotate-180" : ""}`} />
          查看参数
        </button>
        {showArgs && (
          <pre className="max-h-40 overflow-auto whitespace-pre-wrap break-words rounded-md bg-muted/60 border border-border px-2 py-1.5 font-mono text-[14px] leading-5 text-muted-foreground">
            {JSON.stringify(proposal.args, null, 2)}
          </pre>
        )}

        {/* 状态区 */}
        {status === "pending" && (
          <div className="flex items-center gap-2 pt-1">
            <Button
              size="sm"
              onClick={() => void handleConfirm()}
              disabled={busy}
              className={`text-[14px] ${destructive ? "bg-destructive text-white hover:bg-destructive/90" : ""}`}
            >
              {busy ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />}
              {busy ? "执行中…" : destructive ? "确认执行（不可恢复）" : "确认执行"}
            </Button>
            <Button size="sm" variant="plain" onClick={() => void handleCancel()} disabled={busy} className="text-[14px]">
              <X size={12} />
              取消
            </Button>
          </div>
        )}
        {status === "confirmed" && (
          <div className="flex items-center gap-1.5 pt-1 text-[14px] text-chart-2">
            <Check size={13} />
            已执行
            {proposal.result && <span className="text-muted-foreground truncate">· {proposal.result}</span>}
          </div>
        )}
        {status === "cancelled" && (
          <div className="flex items-center gap-1.5 pt-1 text-[14px] text-muted-foreground">
            <X size={13} />
            已取消
          </div>
        )}
        {status === "failed" && (
          <div className="flex items-start gap-1.5 pt-1 text-[14px] text-destructive">
            <X size={13} className="shrink-0 mt-0.5" />
            <span>执行失败：{proposal.result ?? "请重试"}</span>
          </div>
        )}
        {status === "expired" && (
          <div className="flex items-center gap-1.5 pt-1 text-[14px] text-muted-foreground">
            <X size={13} />
            已过期
          </div>
        )}
      </div>
    </Card>
  );
}
