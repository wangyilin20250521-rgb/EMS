import { useState } from "react";

import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/app/components/ui/hover-card";
import { panelCardCls, panelIconCls } from "@/app/components/shared/panel-styles";

/**
 * 左栏「调用入口卡」的统一交互（2026-09-21 用户要求四卡一致）：
 * 鼠标悬浮「或」点击卡片 → 右侧浮层出现；鼠标离开「卡片 + 浮层」这一整块区域 → 浮层消失。
 *
 * 为什么受控：Popover 的打开只认点击（悬浮不出浮层），HoverCard 又不认点击，
 * 所以用 HoverCard 承载悬浮语义、open 自己接管——Radix 的悬浮进/出仍会回调 onOpenChange，
 * 点击卡片与选中条目后再显式开/关。
 * - closeDelay 要盖住「卡片 → 浮层」之间 8px 的间隙，鼠标横穿过去不会闪断；
 * - 不接管焦点（HoverCard 本身不抢焦点）：打开浮层不会把焦点从输入框挪走，
 *   也不会像 Popover 那样一聚焦首个条目就弹出它的 tooltip。
 */
export function SidebarCallout({
  label,
  icon,
  panelClassName = "w-[400px]",
  children,
}: {
  label: string;
  icon: React.ReactNode;
  /** 浮层宽度等尺寸（默认 400px；技能面板 480px 单独指定） */
  panelClassName?: string;
  /** 浮层内容；参数 close = 选中条目后主动收起浮层 */
  children: (close: () => void) => React.ReactNode;
}) {
  const [open, setOpen] = useState(false);

  return (
    <HoverCard open={open} onOpenChange={setOpen} openDelay={150} closeDelay={180}>
      <HoverCardTrigger asChild>
        <button type="button" onClick={() => setOpen(true)} className={panelCardCls()}>
          <div className={panelIconCls()}>{icon}</div>
          <p className="min-w-0 flex-1 text-[14px] font-medium text-foreground leading-snug">{label}</p>
        </button>
      </HoverCardTrigger>
      <HoverCardContent
        side="right"
        align="start"
        sideOffset={8}
        className={`p-0 flex flex-col overflow-hidden max-h-[min(85vh,950px)] ${panelClassName}`}
      >
        {children(() => setOpen(false))}
      </HoverCardContent>
    </HoverCard>
  );
}
