import { useEffect, useRef, useState } from "react";
import { FileSpreadsheet, Loader2, ShieldCheck, Upload, X } from "lucide-react";
import { Card } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import type { ActiveFileUpload } from "@/app/hooks/useAIChat";
import { getReceptionBatches, type UnpackRecord } from "@/app/lib/api";

/**
 * 文件上传卡（2026-09-15）— request_file → file_request 事件后渲染：
 * 对话内直传样本 Excel（选文件 + 可选关联批次）→ /samples/excel-import（解析/校验/入库/自动排单）
 * → 结果注入续流由 AI 汇报。状态：ready → uploading → done。用户不再跳样本中心模块上传。
 */
export function FileUploadCard({
  upload,
  streaming,
  onUpload,
  onDismiss,
}: {
  upload: ActiveFileUpload;
  streaming: boolean;
  onUpload: (file: File, batchId?: string) => void;
  onDismiss: () => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [batchId, setBatchId] = useState("");
  const [batches, setBatches] = useState<UnpackRecord[]>([]);

  // 最近批次候选（关联批次可选，默认"不关联"）；加载失败不阻塞上传
  useEffect(() => {
    if (upload.status !== "ready") return;
    let alive = true;
    getReceptionBatches()
      .then((r) => { if (alive) setBatches((r ?? []).slice(0, 20)); })
      .catch(() => { /* 批次候选加载失败 → 下拉仅"不关联" */ });
    return () => { alive = false; };
  }, [upload.status]);

  const done = upload.status === "done";
  const uploading = upload.status === "uploading";

  return (
    <Card className="w-full py-0 gap-0 overflow-hidden border-border bg-card">
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-border">
        <span className="flex h-6 w-6 items-center justify-center rounded-md bg-primary-light-5 text-primary shrink-0">
          <FileSpreadsheet size={13} />
        </span>
        <div className="flex-1 min-w-0">
          <p className="text-[14px] font-semibold text-foreground leading-tight">样本导入 · Excel 上传</p>
        </div>
        <span className={`text-[14px] px-1.5 py-0.5 rounded font-medium ${
          done ? "bg-chart-2/10 text-chart-2" : "bg-primary-light-5 text-primary"
        }`}>
          {done ? "已上传" : uploading ? "上传中" : "待上传"}
        </span>
        {!done && !uploading && (
          <button type="button" onClick={onDismiss} className="text-muted-foreground hover:text-foreground cursor-pointer" title="取消">
            <X size={14} />
          </button>
        )}
      </div>

      <div className="px-4 py-3 space-y-3">
        <p className="text-[14px] text-foreground leading-relaxed">{upload.purpose}</p>

        {uploading && (
          <div className="flex items-center gap-2 text-[14px] text-muted-foreground py-2">
            <Loader2 size={14} className="animate-spin text-primary" />
            正在上传并导入样本…
          </div>
        )}

        {done && (
          <div className="flex items-start gap-2 rounded-lg border border-border bg-muted/30 px-3 py-2.5">
            <ShieldCheck size={15} className="text-primary mt-0.5 shrink-0" />
            <div className="min-w-0 space-y-1">
              <p className="text-[14px] text-foreground leading-snug">{upload.result ?? "导入完成"}</p>
              <p className="text-[14px] text-muted-foreground leading-snug">
                {streaming ? "AI 正在汇报结果…" : "导入结果已注入对话（见上方 AI 回复）。"}
              </p>
            </div>
          </div>
        )}

        {upload.status === "ready" && (
          <>
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={streaming}
              className="flex flex-col items-center justify-center gap-1.5 w-full h-20 rounded-xl border-2 border-primary/60 bg-primary/5 hover:bg-primary/10 transition-all cursor-pointer disabled:opacity-60"
            >
              <Upload size={18} className="text-primary" />
              <span className="text-[14px] font-medium text-primary truncate max-w-full px-2">
                {file ? file.name : "选择 Excel 文件（点击上传）"}
              </span>
              <span className="text-[14px] text-muted-foreground">支持 {upload.accept}</span>
            </button>
            <input
              ref={fileRef}
              type="file"
              accept={upload.accept}
              className="hidden"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) setFile(f); }}
            />

            <div className="flex items-center gap-2">
              <label className="text-[14px] text-muted-foreground shrink-0">关联批次</label>
              <select
                value={batchId}
                onChange={(e) => setBatchId(e.target.value)}
                className="flex-1 border border-border rounded-md px-2 py-1.5 text-[14px] bg-card focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="">不关联批次</option>
                {batches.map((b) => (
                  <option key={b.id} value={b.id}>{b.id}（{b.hospital || "—"}，{b.status}）</option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-end gap-2">
              <Button
                onClick={() => file && onUpload(file, batchId || undefined)}
                disabled={!file || streaming}
                className={`text-[14px] ${!file || streaming ? "opacity-50 cursor-not-allowed" : ""}`}
              >
                {streaming ? "处理中…" : "上传并导入"}
              </Button>
            </div>
          </>
        )}

        {upload.error && (
          <div className="flex items-start gap-2 text-[14px] text-destructive leading-relaxed">
            <X size={13} className="mt-0.5 shrink-0" />
            <span className="min-w-0 break-words">导入失败：{upload.error}</span>
          </div>
        )}
      </div>
    </Card>
  );
}
