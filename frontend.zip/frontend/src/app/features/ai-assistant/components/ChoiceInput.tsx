import { useEffect, useState } from "react";
import { Check, Loader2 } from "lucide-react";
import { Button } from "@/app/components/ui/button";

/**
 * 选项交互（2026-09-10）— AI 确认一律选择题：
 * - 单选（multi=false）：radio 行，点选即答
 * - 多选（multi=true）：checkbox 行 + 全选 + 底部「确认选择(n)」；提交值以「、」分隔
 * 无 options 的兜底仅在确属自由文本时出现（AI 侧已约束尽量不触发）。
 */
export function ChoiceInput({
  options,
  multi,
  disabled,
  onSubmit,
}: {
  options: string[];
  multi?: boolean;
  disabled?: boolean;
  onSubmit: (values: string[]) => void;
}) {
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  useEffect(() => { setPicked(new Set()); setBusy(false); }, [options, multi]);

  const submit = () => {
    if (busy || disabled) return;
    setBusy(true);
    onSubmit([...picked]);
  };

  if (multi) {
    const allPicked = options.length > 0 && picked.size === options.length;
    return (
      <div className="space-y-2">
        <div className="space-y-1.5" role="group" aria-label="多选">
          {options.map(opt => {
            const active = picked.has(opt);
            return (
              <button
                key={opt}
                type="button"
                role="checkbox"
                aria-checked={active}
                disabled={disabled || busy}
                onClick={() => {
                  setPicked(prev => {
                    const next = new Set(prev);
                    if (next.has(opt)) next.delete(opt); else next.add(opt);
                    return next;
                  });
                }}
                className={`w-full flex items-center gap-2.5 rounded-lg border px-3 py-2 text-left text-[14px] transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 ${
                  active ? "border-primary bg-primary-light-5" : "border-border bg-background hover:border-primary/40 hover:bg-muted/40"
                }`}
              >
                <span className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${active ? "border-primary bg-primary" : "border-muted-foreground/40"}`}>
                  {active && <Check size={11} strokeWidth={3} className="text-white" />}
                </span>
                <span className="text-foreground">{opt}</span>
              </button>
            );
          })}
        </div>
        <div className="flex items-center gap-2 pt-0.5">
          <Button size="sm" disabled={disabled || busy || picked.size === 0} onClick={submit} className="text-[14px]">
            {busy ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />}
            确认选择{picked.size > 0 ? `（${picked.size}）` : ""}
          </Button>
          <button
            type="button"
            disabled={disabled || busy}
            onClick={() => { setPicked(allPicked ? new Set() : new Set(options)); }}
            className="text-[14px] text-muted-foreground hover:text-foreground cursor-pointer disabled:opacity-50"
          >
            {allPicked ? "取消全选" : "全选"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-1.5" role="radiogroup">
      {options.map(opt => {
        const active = picked.has(opt);
        return (
          <button
            key={opt}
            type="button"
            role="radio"
            aria-checked={active}
            disabled={disabled || busy}
            // 单选点选即答：直接提交该选项值（勿依赖 setPicked 后的 state——闭包旧值会导致提交空串 "Empty answer"）
            onClick={() => { setPicked(new Set([opt])); if (!busy && !disabled) { setBusy(true); onSubmit([opt]); setBusy(false); } }}
            className={`w-full flex items-center gap-2.5 rounded-lg border px-3 py-2 text-left text-[14px] transition-colors cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 ${
              active ? "border-primary bg-primary-light-5" : "border-border bg-background hover:border-primary/50 hover:bg-muted/40"
            }`}
          >
            <span className={`flex h-4 w-4 shrink-0 items-center justify-center rounded-full border ${active ? "border-primary" : "border-muted-foreground/40"}`}>
              {active && <span className="h-2 w-2 rounded-full bg-primary" />}
            </span>
            <span className="text-foreground">{opt}</span>
          </button>
        );
      })}
    </div>
  );
}
