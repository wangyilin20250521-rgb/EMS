import { useEffect, useState } from "react";
import { Check, Loader2, ShieldCheck, Sparkles, X } from "lucide-react";
import { Card } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import type { ActiveForm } from "@/app/hooks/useAIChat";
import { findAiTool, type AiToolCatalogEntry } from "@/app/lib/api/ai-tools";
import { SchemaForm } from "./schema-form/SchemaForm";

/**
 * 参数表单卡（2026-09-11 schema 驱动表单卡）— request_form → form_request 事件后渲染：
 * 从 AI 工具目录拉取该工具 schema + mustAsk → SchemaForm 一次收集 → 提交转 specimens 对象数组
 * → POST /api/chat/form-submit（登记证据 + AI 续流 propose）。状态：ready → submitting → submitted。
 */
export function FormCard({
  form,
  streaming,
  onSubmit,
  onDismiss,
}: {
  form: ActiveForm;
  streaming: boolean;
  onSubmit: (values: Record<string, unknown>, optionsByField: Record<string, string[]>) => void;
  onDismiss: () => void;
}) {
  const [entry, setEntry] = useState<AiToolCatalogEntry | null | undefined>(undefined); // undefined=加载中
  useEffect(() => {
    let alive = true;
    findAiTool(form.toolName).then((e) => { if (alive) setEntry(e ?? null); });
    return () => { alive = false; };
  }, [form.toolName]);

  if (entry === undefined) {
    return (
      <Card className="py-3 px-4 flex items-center gap-2 text-[14px] text-muted-foreground">
        <Loader2 size={13} className="animate-spin text-primary" />
        正在准备参数表单…
      </Card>
    );
  }

  if (entry === null) {
    return (
      <Card className="py-3 px-4 flex items-center justify-between text-[14px] text-muted-foreground">
        <span>该操作（{form.toolName}）暂不支持参数表单，请直接继续对话描述需求。</span>
        <Button size="sm" variant="plain" onClick={onDismiss} className="text-[14px]"><X size={12} />关闭</Button>
      </Card>
    );
  }

  const submitted = form.status === "submitted";

  return (
    <Card className="w-full py-0 gap-0 overflow-hidden border-border bg-card">
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-border">
        <span className="flex h-6 w-6 items-center justify-center rounded-md bg-primary-light-5 text-primary shrink-0">
          <Sparkles size={13} />
        </span>
        <div className="flex-1 min-w-0">
          <p className="text-[14px] font-semibold text-foreground leading-tight">
            {entry.module} · {form.toolName.replace(/^[a-z]+\./, "")}
          </p>
        </div>
        <span className={`text-[14px] px-1.5 py-0.5 rounded font-medium ${
          submitted ? "bg-chart-2/10 text-chart-2" : "bg-primary-light-5 text-primary"
        }`}>
          {submitted ? "已提交" : form.status === "submitting" ? "提交中" : "填写参数"}
        </span>
        {!submitted && (
          <button type="button" onClick={onDismiss} className="text-muted-foreground hover:text-foreground cursor-pointer" title="取消">
            <X size={14} />
          </button>
        )}
      </div>

      <div className="px-4 py-3">
        {form.explanation && !submitted && (
          <p className="text-[14px] text-foreground leading-relaxed mb-3">{form.explanation}</p>
        )}

        {form.status === "submitting" && (
          <div className="flex items-center gap-2 text-[14px] text-muted-foreground py-2">
            <Loader2 size={14} className="animate-spin text-primary" />
            参数已提交，AI 正在生成操作建议…
          </div>
        )}

        {submitted && (
          <div className="flex items-start gap-2 rounded-lg border border-border bg-muted/30 px-3 py-2.5">
            <ShieldCheck size={15} className="text-primary mt-0.5 shrink-0" />
            <div className="min-w-0 space-y-1">
              <p className="text-[14px] text-foreground leading-snug">
                参数已确认，等待 AI 生成操作建议（下方确认卡）。如需修改参数，请直接告诉 AI。
              </p>
              {form.submittedSummary && (
                <p className="text-[14px] text-muted-foreground leading-snug break-words">{form.submittedSummary}</p>
              )}
            </div>
          </div>
        )}

        {form.status === "ready" && (
          <SchemaForm
            entry={entry}
            hints={form.fieldHints}
            busy={streaming}
            onSubmit={(values, optionsByField) => {
              // specimens（样例 id[]）→ 对象数组形状（后端 schema: [{ specimenId }]），UI 值即内部 id
              const out: Record<string, unknown> = { ...values };
              if (Array.isArray(out.specimens) && typeof out.specimens[0] === "string") {
                out.specimens = (out.specimens as string[]).map((id) => ({ specimenId: id }));
              }
              onSubmit(out, optionsByField);
            }}
          />
        )}

        {form.error && (
          <div className="mt-2 flex items-center gap-2 text-[14px] text-destructive">
            提交失败：{form.error}
            <Button size="sm" variant="plain" onClick={onDismiss} className="text-[14px]"><Check size={12} />知道了</Button>
          </div>
        )}
      </div>
    </Card>
  );
}
