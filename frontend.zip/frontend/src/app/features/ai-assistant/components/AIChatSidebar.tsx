import { useEffect, useState } from "react";
import { ArrowRight, Bot, ChevronDown, FileCog, FileText, History, Layers, LayoutGrid, MessageSquarePlus, Trash2 } from "lucide-react";
import { PanelSidebar } from "@/app/components/shared/PanelSidebar";
import { panelCardCls, panelIconCls } from "@/app/components/shared/panel-styles";
import { getKbDocuments, getRulesMeta, getSolutionProfiles } from "@/app/lib/api";
import type { ConversationSummary, KbDocSummary, RuleMetaEntry, SolutionProfilesPayload, StrategyRule } from "@/app/lib/api";
import { apiGet } from "@/app/lib/api/http";
import type { AITemplateItem } from "@/app/lib/constants/ai-features";
import { AI_TEMPLATES } from "@/app/lib/constants/ai-features";
import { RULE_STATUS_META, RULE_STUDY } from "@/app/features/strategy-management/strategy-constants";
import { expandScheduleRules, mapRuleFilesToRules, scheduleProjectOf } from "@/app/features/strategy-management/strategy-model";
import { RuleDifficultyStars } from "@/app/features/strategy-management/shared";
import { mainAgentDiffPrompt } from "@/app/features/solutions/solution-model";
import { PromptTemplatePanel } from "./PromptTemplatePanel";
import { SidebarCallout } from "./SidebarCallout";
import { TemplateIcon } from "./ai-template-icons";
import { curateFeaturedDocs } from "@/app/features/documents/document-model";

/** 策略「常用操作」：rules 组 4 条模板的入口（2026-09-28）。
 * 技能面板按既定口径不展示 rules 组、策略调用卡此前只列规则清单（只读解释），
 * 导致「调整 TAT 天数 / 新增自动排单规则」等写操作模板无路可达——在此补齐，
 * 选中即把问句填入输入框，写操作仍走确认卡闭环。 */
const RULE_QUICK_ACTIONS: AITemplateItem[] = ["rules-tat-view", "rules-tat-edit", "rules-auto-schedule", "rules-overview"]
  .map((id) => AI_TEMPLATES.find((t) => t.id === id))
  .filter((t): t is AITemplateItem => !!t);

/**
 * AI 助手左侧功能入口卡栈（2026-09-16 重构）——左栏 = "全模块能力中枢"：
 * 头部（名称 + 新对话）+ 5 张入口卡（技能 / 策略管理 / 文档归档 / 解决方案 / 对话历史）。
 * 2026-09-18 起外壳与卡样式走共享规格 PanelSidebar（280px + 固定头部 + 独立滚动列表），
 * 与设备管理/文档归档/策略管理/解决方案四个内部侧边栏视觉完全一致。
 * - 主卡面只留「图标 + 标题」（8×8 图标块 + 14px 标题 + min-h-[84px]）；
 * - 技能 / 策略管理 / 文档归档 / 解决方案为「调用入口」卡：四卡同一套交互（2026-09-21 用户要求统一）——
 *   鼠标悬浮或点击卡片即出右侧浮层，鼠标离开「卡片 + 浮层」整块区域浮层消失（见 SidebarCallout）；
 *   浮层里直接点选使用（填入输入框），编辑与完整功能仍在各自模块页（那边是"函数定义"，这边是"调用"）；
 *   2026-09-21 起三个数据型浮层（策略/文档/方案）与各自模块页同源取数，展示的就是模块里的真实清单；
 * - 对话历史（2026-09-20 改内联折叠，AI Native 常见形态；2026-09-21 起默认展开）：
 *   卡固定在最后，点击卡片在卡下方展开/收起会话列表（打开 + 悬停删除），不再占用右侧悬停浮层——
 *   历史是"就地浏览"，不需要跳出去看；
 * - 其余调用面板浮层宽 400px（2026-09-21 用户反馈：明细两列不好看，统一改单列列表，
 *   宽度随之从 720px 收窄；仍是统一规格里的既定例外，不承载卡片元数据）；
 * - 浮层内部一律去色（2026-09-21 用户要求：数据与图标不带彩，简洁好看）——
 *   规则状态徽章 / SOP 图标块 / 「运行中」标记全部落回中性灰（bg-muted / slate），
 *   仅保留底部「前往…」链接的主色文字作为唯一行动指引。
 */

export function AIChatSidebar({
  conversations,
  activeConversationId,
  streaming,
  onPickTemplate,
  onOpenConversation,
  onDeleteConversation,
  onNew,
}: {
  conversations: ConversationSummary[];
  activeConversationId: string | null;
  streaming: boolean;
  onPickTemplate: (tpl: AITemplateItem) => void;
  onOpenConversation: (id: string) => void;
  onDeleteConversation: (id: string) => void;
  onNew: () => void;
}) {
  // 对话历史默认展开（2026-09-21 用户反馈：进来就该看到历史，不必先点一下）
  const [historyOpen, setHistoryOpen] = useState(true);

  // 策略管理调用入口：与策略管理页同源取数（规则文件 + 元数据 + 自动排单配置），
  // task-schedule-rules 按项目展开为「自动排单（NIFTY）」等虚拟卡——
  // 浮层展示的就是策略页左栏那一份真实清单（2026-09-21 用户反馈：不要只列规则类型）
  const [rules, setRules] = useState<StrategyRule[]>([]);
  useEffect(() => {
    let alive = true;
    Promise.all([
      apiGet<Array<{ name: string; size: number; updatedAt: string }>>("/strategy-rules/files"),
      getRulesMeta().catch(() => ({} as Record<string, RuleMetaEntry>)),
      apiGet<Record<string, unknown>>("/strategy-rules/schedule").catch(() => ({} as Record<string, unknown>)),
    ])
      .then(([files, savedMeta, scheduleCfg]) => {
        if (alive) setRules(expandScheduleRules(mapRuleFilesToRules(files, savedMeta), scheduleCfg as Record<string, any>));
      })
      .catch(() => {});
    return () => { alive = false; };
  }, []);

  // 文档归档调用入口：精选文档列表（与文档归档页同口径：全部 SOP + 经典测试报告）
  const [docs, setDocs] = useState<KbDocSummary[]>([]);
  useEffect(() => {
    let alive = true;
    getKbDocuments()
      .then((list) => { if (alive) setDocs(curateFeaturedDocs(list)); })
      .catch(() => {});
    return () => { alive = false; };
  }, []);

  // 解决方案调用入口：方案清单 + 运行态标记（管理员端点；非管理员 403 → 保持空态）
  const [profileData, setProfileData] = useState<SolutionProfilesPayload | null>(null);
  useEffect(() => {
    let alive = true;
    getSolutionProfiles()
      .then((data) => { if (alive) setProfileData(data); })
      .catch(() => {});
    return () => { alive = false; };
  }, []);

  /** 跳转主页面的完整功能（hash 路由） */
  const goTo = (view: string) => { window.location.hash = `#/${view}`; };

  return (
    <PanelSidebar
      icon={Bot}
      title="EMS 智能助手"
      action={
        /* 新对话（2026-09-17 起不占入口卡，收为头部图标按钮） */
        <button
          type="button"
          onClick={onNew}
          disabled={streaming}
          title="开启新对话"
          aria-label="开启新对话"
          className="p-1.5 rounded-lg border border-border text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
        >
          <MessageSquarePlus size={15} />
        </button>
      }
    >
      {/* 技能（调用入口卡）：浮层 = 方块格子能力面板（2026-09-17 方案 2；
          2026-09-21 更名：提示词模板 → 技能，对齐 WorkBuddy 叫法，方块=助手封装好的一次能力调用） */}
      <SidebarCallout label="技能" icon={<LayoutGrid size={15} />} panelClassName="w-[480px]">
        {(close) => <PromptTemplatePanel onPick={(t) => { close(); onPickTemplate(t); }} />}
      </SidebarCallout>

      {/* 策略管理（调用入口卡）：浮层直接选用策略管理页的真实规则清单（填入解释问句），
          编辑与完整功能在策略管理页；自动排单项目卡（task-schedule-rules#项目）沿用页面的难度/状态口径：
          难度恒为 3 档、状态"生效"（全字段已接线），不显示编辑删除 */}
      <SidebarCallout label="策略管理" icon={<FileCog size={15} />}>
        {(close) => (
          <>
            {/* 常用操作（rules 组 4 条模板，选中填入问句） */}
            <div className="shrink-0 p-2 pb-0 space-y-0.5">
              <p className="px-1 pb-1 text-[12px] font-semibold text-muted-foreground">常用操作</p>
              {RULE_QUICK_ACTIONS.map((tpl) => (
                <button
                  key={tpl.id}
                  type="button"
                  onClick={() => {
                    close();
                    onPickTemplate(tpl);
                  }}
                  className="w-full flex items-center gap-3 px-2.5 py-2 rounded-lg text-left hover:bg-muted/60 transition-colors cursor-pointer"
                >
                  <span className="w-8 h-8 shrink-0 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-300">
                    <TemplateIcon name={tpl.icon} size={15} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[14px] font-medium text-foreground leading-snug truncate">{tpl.label}</span>
                    <span className="block text-[14px] text-muted-foreground mt-0.5 truncate">{tpl.description}</span>
                  </span>
                </button>
              ))}
            </div>
            <div className="shrink-0 border-t border-border mt-2" />
            <div className="flex-1 min-h-0 overflow-y-auto p-2 space-y-0.5">
              {rules.length === 0 ? (
                <p className="text-[14px] text-muted-foreground text-center py-8">规则加载中…</p>
              ) : (
                rules.map((rule, i) => {
                  const project = scheduleProjectOf(rule.id);
                  const study = project ? { level: 3, status: "ok" as const } : RULE_STUDY[rule.id];
                  const statusMeta = study ? RULE_STATUS_META[study.status] : null;
                  return (
                    <button
                      key={rule.id}
                      type="button"
                      onClick={() => {
                        close();
                        onPickTemplate({
                          id: `strategy-rule-${rule.id}`,
                          group: "rules",
                          label: rule.name,
                          description: "",
                          icon: "FileCog",
                          prompt: `请解释一下「${rule.name}」这条${project ? "自动排单策略" : "规则"}的作用，并给出具体的使用示例。`,
                        });
                      }}
                      className="w-full flex items-center gap-3 px-2.5 py-2.5 rounded-lg text-left hover:bg-muted/60 transition-colors cursor-pointer"
                    >
                      <span className="w-8 h-8 shrink-0 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-300 text-[14px] font-mono font-bold">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-[14px] font-medium text-foreground leading-snug truncate">{rule.name}</span>
                        {study && (
                          <span className="flex items-center gap-2 mt-1">
                            {statusMeta && <span className="text-[14px] px-1.5 py-0.5 rounded font-medium bg-muted text-muted-foreground">{statusMeta.label}</span>}
                            <span className="text-[14px] text-muted-foreground"><RuleDifficultyStars level={study.level} /></span>
                          </span>
                        )}
                      </span>
                    </button>
                  );
                })
              )}
            </div>
            <button
              onClick={() => goTo("strategy-management")}
              className="w-full px-4 py-2.5 border-t border-border text-[14px] text-primary hover:bg-muted/40 transition-colors cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
            >
              前往策略管理<ArrowRight size={13} />
            </button>
          </>
        )}
      </SidebarCallout>

      {/* 文档归档（调用入口卡）：浮层直接选用精选文档（填入咨询问句），智能介绍与全文咨询在文档归档页 */}
      <SidebarCallout label="文档归档" icon={<FileText size={15} />}>
        {(close) => (
          <>
            <div className="overflow-y-auto p-2 space-y-0.5">
              {docs.length === 0 ? (
                <p className="text-[14px] text-muted-foreground text-center py-8">文档加载中…</p>
              ) : (
                docs.map((d) => (
                  <button
                    key={d.docId}
                    type="button"
                    onClick={() => {
                      close();
                      onPickTemplate({
                        id: `doc-consult-${d.docId}`,
                        group: "query",
                        label: d.title,
                        description: "",
                        icon: "BookOpen",
                        prompt: `请介绍《${d.title}》这份文档的核心内容与测试结论，并说明它适用于什么场景。`,
                      });
                    }}
                    className="w-full flex items-center gap-3 px-2.5 py-2.5 rounded-lg text-left hover:bg-muted/60 transition-colors cursor-pointer"
                  >
                    <span className="w-8 h-8 shrink-0 rounded-lg flex items-center justify-center bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-300">
                      <FileText size={15} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-[14px] font-medium text-foreground leading-snug line-clamp-2">{d.title}</span>
                      <span className="block text-[14px] text-muted-foreground mt-0.5 truncate">{[d.product, d.platform, d.docType].filter(Boolean).join(" · ")}</span>
                    </span>
                  </button>
                ))
              )}
            </div>
            <button
              onClick={() => goTo("documents")}
              className="w-full px-4 py-2.5 border-t border-border text-[14px] text-primary hover:bg-muted/40 transition-colors cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
            >
              前往文档归档<ArrowRight size={13} />
            </button>
          </>
        )}
      </SidebarCallout>

      {/* 解决方案（调用入口卡）：浮层直接选用方案（填入差异解读问句），配置编辑与页面内咨询在解决方案页 */}
      <SidebarCallout label="解决方案" icon={<Layers size={15} />}>
        {(close) => (
          <>
            <div className="overflow-y-auto p-2 space-y-0.5">
              {!profileData || profileData.profiles.length === 0 ? (
                <p className="text-[14px] text-muted-foreground text-center py-8">方案加载中…</p>
              ) : (
                profileData.profiles.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      close();
                      onPickTemplate({
                        id: `solution-consult-${p.id}`,
                        group: "query",
                        label: `差异解读：${p.label}`,
                        description: "",
                        icon: "Layers",
                        prompt: mainAgentDiffPrompt(p),
                      });
                    }}
                    className="w-full flex items-center gap-3 px-2.5 py-2.5 rounded-lg text-left hover:bg-muted/60 transition-colors cursor-pointer"
                  >
                    <span className="w-8 h-8 shrink-0 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300 flex items-center justify-center">
                      <Layers size={15} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-1.5">
                        <span className="text-[14px] font-medium text-foreground leading-snug truncate">{p.label}</span>
                        {profileData.applied?.id === p.id && (
                          <span className="shrink-0 rounded-full px-1.5 py-px text-[11px] font-medium bg-muted text-muted-foreground">运行中</span>
                        )}
                      </span>
                      <span className="block text-[14px] text-muted-foreground mt-0.5 truncate">{p.description || p.id}</span>
                    </span>
                  </button>
                ))
              )}
            </div>
            <button
              onClick={() => goTo("solutions")}
              className="w-full px-4 py-2.5 border-t border-border text-[14px] text-primary hover:bg-muted/40 transition-colors cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
            >
              前往解决方案<ArrowRight size={13} />
            </button>
          </>
        )}
      </SidebarCallout>

      {/* 对话历史（2026-09-20 改内联折叠面板，卡片固定在最后）：
          点击卡 → 在卡片正下方展开/收起会话列表；历史是"就地浏览"，不再走右侧悬停浮层。
          展开区无卡片包裹（2026-09-20 按"其他 AI 软件就是自然的几段历史"去掉外框），
          只有 max-h + 自身滚动，防止长历史把侧栏顶长。 */}
      <button
        type="button"
        onClick={() => setHistoryOpen(v => !v)}
        aria-expanded={historyOpen}
        className={panelCardCls()}
      >
        <div className={panelIconCls()}><History size={15} /></div>
        <p className="min-w-0 flex-1 text-[14px] font-medium text-foreground leading-snug">对话历史</p>
        {/* 折叠指示：功能性的唯一尾元素（展开态旋转 180°） */}
        <ChevronDown
          size={14}
          className={`shrink-0 text-muted-foreground transition-transform ${historyOpen ? "rotate-180" : ""}`}
        />
      </button>

      {historyOpen && (
        <div className="max-h-[280px] overflow-y-auto space-y-0.5">
          {conversations.length === 0 ? (
            <p className="py-6 text-center text-[13px] text-muted-foreground">暂无历史对话</p>
          ) : (
            conversations.map((conv) => {
              const convId = conv.sessionId;
              const isActive = activeConversationId === convId;
              return (
                <div key={convId} className="group relative">
                  <button
                    type="button"
                    onClick={() => onOpenConversation(convId)}
                    disabled={streaming}
                    className={`w-full px-2.5 py-1.5 pr-8 rounded-lg text-left transition-colors cursor-pointer disabled:opacity-50 ${
                      isActive ? "bg-primary/5" : "hover:bg-muted/60"
                    }`}
                  >
                    {/* 一行截断（主流 AI 形态）：标题即全部，详情进对话看 */}
                    <span className={`block truncate text-[13px] leading-6 ${isActive ? "text-primary font-medium" : "text-foreground"}`}>{conv.title}</span>
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); onDeleteConversation(convId); }}
                    className="absolute right-1 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 p-1 rounded-md hover:bg-red-100 dark:hover:bg-red-950/30 text-muted-foreground hover:text-red-600 transition-all cursor-pointer"
                    title="删除对话"
                    aria-label={`删除对话 ${conv.title}`}
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              );
            })
          )}
        </div>
      )}
    </PanelSidebar>
  );
}
