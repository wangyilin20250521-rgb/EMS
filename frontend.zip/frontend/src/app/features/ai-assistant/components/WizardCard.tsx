import { useEffect, useRef, useState } from "react";
import { Check, ChevronRight, CircleDashed, Loader2, Sparkles } from "lucide-react";
import { Card } from "@/app/components/ui/card";
import type { WizardStep } from "@/app/hooks/useAIChat";
import { ChoiceInput } from "./ChoiceInput";

/**
 * 分步向导卡（2026-09-15 职责收敛）— 只负责"答题过程"：
 * - ChatGPT Apps 规范：单视图内联卡、≤2 主操作、系统色为主、强调色只给主按钮
 * - 选项 = 结构化单选行（radio 语义，非文字按钮堆）
 * - 步骤进度 = 迷你 stepper（完成 ✓ / 当前高亮 / 未到灰）
 * - 【确认权已合并】完成态确认区（原"确认并执行操作"+确认/取消按钮）删除——
 *   全部答完后本卡由页面层卸载，唯一确认入口是消息流中的 DecisionCard（AI 操作建议），
 *   杜绝同一笔提议出现两个"确认执行"按钮。
 *
 * 底层仍是逐轮 ask_user + /api/chat/answer；本组件把跨轮问题聚合为一张卡。
 */

/** field → 中文标签（展示用；与 ask_user 的 field 键一致） */
const FIELD_LABELS: Record<string, string> = {
  deviceType: "检测仪器",
  project: "检测项目",
  processNo: "实验流程",
  type: "类型",
  status: "状态",
  content: "内容",
  gender: "性别",
  patient: "患者",
  name: "规则名",
  trigger: "触发点",
  ordering: "排序规则",
  autoScheduleCount: "排单数量",
  qc: "质控品",
};

function fieldLabel(field?: string): string {
  return field ? (FIELD_LABELS[field] ?? field) : "";
}

export function WizardCard({
  steps,
  streaming,
  onAnswer,
}: {
  steps: WizardStep[];
  streaming: boolean;
  onAnswer: (questionId: string, answer: string, field?: string) => void;
}) {
  const pendingIdx = steps.findIndex(s => s.status === "pending");
  const current = pendingIdx >= 0 ? steps[pendingIdx] : null;
  const allAnswered = steps.length > 0 && pendingIdx < 0;
  const [busy, setBusy] = useState(false);
  const bodyRef = useRef<HTMLDivElement>(null);

  // 新步骤出现时滚到向导卡（自动跟进下一步）
  useEffect(() => {
    bodyRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [pendingIdx]);

  const submit = (answer: string) => {
    if (!current || streaming || busy) return;
    setBusy(true);
    try { onAnswer(current.questionId, answer, current.field); } finally { setBusy(false); }
  };

  return (
    <Card className="w-full py-0 gap-0 overflow-hidden border-border bg-card">
      {/* ── 头部：意图标题 + 迷你 stepper ── */}
      <div className="flex items-center gap-2.5 px-4 py-2.5 border-b border-border">
        <span className="flex h-6 w-6 items-center justify-center rounded-md bg-primary-light-5 text-primary shrink-0">
          <Sparkles size={13} />
        </span>
        <div className="flex-1 min-w-0">
          <p className="text-[14px] font-semibold text-foreground leading-tight truncate">
            {allAnswered ? "参数确认完成" : "确认操作参数"}
          </p>
          <div className="flex items-center gap-1 mt-0.5">
            {steps.map((s, i) => (
              <span key={s.questionId} className="flex items-center gap-1">
                {i > 0 && <ChevronRight size={10} className="text-muted-foreground/40" />}
                {s.status === "answered" ? (
                  <span className="flex items-center gap-0.5 text-[14px] text-chart-2">
                    <Check size={10} strokeWidth={3} />
                    <span className="hidden sm:inline">{fieldLabel(s.field)}</span>
                  </span>
                ) : i === pendingIdx ? (
                  <span className="flex items-center gap-1 text-[14px] font-medium text-primary">
                    <CircleDashed size={10} className="animate-spin" />
                    {fieldLabel(s.field)}
                  </span>
                ) : (
                  <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/25" />
                )}
              </span>
            ))}
          </div>
        </div>
        <span className="text-[14px] text-muted-foreground shrink-0">
          {pendingIdx >= 0 ? `${pendingIdx + 1}/${steps.length}` : `${steps.length}/${steps.length}`}
        </span>
      </div>

      <div ref={bodyRef} className="px-4 py-3 space-y-3">
        {/* ── 当前步：选择题（单选点选即答 / 多选勾选确认） ── */}
        {current && (
          <div className="space-y-2">
            <p className="text-[14px] text-foreground leading-snug">{current.question}</p>
            {current.options && current.options.length > 0 ? (
              <ChoiceInput
                options={current.options}
                multi={current.multi}
                disabled={streaming}
                onSubmit={values => submit(values.join("、"))}
              />
            ) : (
              <p className="text-[14px] text-muted-foreground">
                该项需要你补充信息——请直接在下方输入框回复（AI 通常会给可选项，此情况较少出现）。
              </p>
            )}
            {streaming && (
              <div className="flex items-center gap-1.5 text-[14px] text-muted-foreground">
                <Loader2 size={12} className="animate-spin text-primary" />
                正在处理你的选择…
              </div>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}
