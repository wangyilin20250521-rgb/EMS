import { useState } from "react";
import { AlertTriangle, Check, ChevronDown, HelpCircle, Loader2, Send, Sparkles, X } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/app/components/ui/table";
import type { ActionProposal, QuestionSpec } from "@/app/lib/utils/sse";
import { MarkdownPre } from "@/app/components/shared/MarkdownPre";
import { TOOL_LABELS } from "./ActionProposalCard";
import { QuestionControls } from "./QuestionCard";

/**
 * 决策卡（2026-09-03）— AI 需要用户确认的整条回复渲染为一张大卡（Claude Code 式）：
 * 头部（提议标识 + 工具标签 + 状态）→ 顶部 AI 说明（原气泡文本）→ 中部结构化内容
 * （规则文件字段级 diff > 参数摘要 details > 原始参数折叠）→ 选项区（ask_user 内嵌）→ 底部确认。
 * 2026-09-15：唯一确认入口（向导完成态确认区已合并至此）；新增"修改意见"输入框——
 * 用户可用自然语言要求调整参数（如"把某样本编号改为…"），提交后旧提议静默取消、AI 重新生成。
 * 触发条件见 isDecisionMessage：!streaming 且含 proposals/questions。
 */

export function isDecisionMessage(m: {
  role?: string;
  streaming?: boolean;
  proposals?: unknown[];
  questions?: unknown[];
}): boolean {
  return m.role === "ai" && !m.streaming
    && ((m.proposals?.length ?? 0) > 0 || (m.questions?.length ?? 0) > 0);
}

/** diff 表格：字段 | 修改前 | 修改后（schema 模式中文 label；值删除线/加粗对比） */
function DiffTable({ diff }: { diff: NonNullable<ActionProposal["diff"]> }) {
  const { changed, added, removed } = diff;
  if (changed.length === 0 && added.length === 0 && removed.length === 0) return null;
  return (
    <div className="space-y-2 rounded-md border border-border bg-muted/30 px-3 py-2">
      <p className="text-[14px] font-semibold text-foreground">变更对比 · {diff.file}</p>
      {(added.length > 0 || removed.length > 0) && (
        <div className="flex flex-wrap gap-1.5">
          {added.map(p => <span key={`a-${p}`} className="text-[14px] px-1.5 py-0.5 rounded bg-chart-2/10 text-chart-2 font-medium">＋ 新增 {p}</span>)}
          {removed.map(p => <span key={`r-${p}`} className="text-[14px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground font-medium">－ 移除 {p}</span>)}
        </div>
      )}
      {changed.length > 0 && (
        <Table className="w-full text-left text-[14px]">
          <TableHeader>
            <TableRow className="border-border">
              <TableHead className="w-1/2 px-1 py-1 font-semibold text-foreground">字段</TableHead>
              <TableHead className="w-1/4 px-1 py-1 font-semibold text-muted-foreground">修改前</TableHead>
              <TableHead className="w-1/4 px-1 py-1 font-semibold text-foreground">修改后</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {changed.map(row => {
              // 路径段前缀只在"确实提供了额外层级信息"时展示：顶层键（path 无点）与同名 label 会渲染成 "NIFTY · NIFTY"
              const prefix = row.path.includes(".") ? row.path.split(".")[0] : ""
              return (
              <TableRow key={row.path} className="border-border">
                <TableCell className="px-1 py-1 align-top">
                  {prefix && prefix !== row.label && (
                    <span className="text-muted-foreground break-all">{prefix} · </span>
                  )}
                  <span className="font-medium">{row.label}</span>
                </TableCell>
                <TableCell className="px-1 py-1 align-top break-all text-muted-foreground line-through">
                  {row.old ?? "—"}
                </TableCell>
                <TableCell className="px-1 py-1 align-top break-all text-foreground font-medium">
                  {row.new ?? "—"}
                </TableCell>
              </TableRow>
              )
            })}
          </TableBody>
        </Table>
      )}
    </div>
  );
}

/** details 结构化摘要：label: value 键值列表 */
function DetailsList({ details }: { details: NonNullable<ActionProposal["details"]> }) {
  return (
    <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 rounded-md border border-border bg-muted/30 px-3 py-2 text-[14px]">
      {details.map(d => (
        <div key={d.label} className="contents">
          <span className="text-muted-foreground whitespace-nowrap">{d.label}</span>
          {/* whitespace-pre-wrap：样本编号等枚举列表逐条列全后的多行渲染 */}
          <span className="text-foreground break-all whitespace-pre-wrap">{d.value}</span>
        </div>
      ))}
    </div>
  );
}

/** 提议内容区：summary + rationale + diff/details/原始参数（按优先级） */
function ProposalBody({ proposal }: { proposal: ActionProposal }) {
  const [showArgs, setShowArgs] = useState(false);
  const diff = proposal.diff;
  const hasDiff = diff && (diff.changed.length > 0 || diff.added.length > 0 || diff.removed.length > 0);
  return (
    <div className="space-y-2">
      <div>
        <p className="text-[14px] font-medium text-foreground leading-snug">{proposal.summary}</p>
        {proposal.rationale && (
          <p className="text-[14px] text-muted-foreground leading-snug mt-0.5">原因：{proposal.rationale}</p>
        )}
      </div>
      {hasDiff ? (
        <DiffTable diff={diff!} />
      ) : proposal.details && proposal.details.length > 0 ? (
        <DetailsList details={proposal.details} />
      ) : (
        <button
          type="button"
          onClick={() => setShowArgs(v => !v)}
          className="flex items-center gap-1 text-[14px] text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
        >
          <ChevronDown size={12} className={`shrink-0 transition-transform ${showArgs ? "rotate-180" : ""}`} />
          查看参数
        </button>
      )}
      {showArgs && (
        <pre className="max-h-40 overflow-auto whitespace-pre-wrap break-words rounded-md bg-muted/60 border border-border px-2 py-1.5 font-mono text-[14px] leading-5 text-muted-foreground">
          {JSON.stringify(proposal.args, null, 2)}
        </pre>
      )}
    </div>
  );
}

/** 底部状态区：pending 确认/取消按钮 + 终态文本（语义与 ActionProposalCard 一致） */
function ProposalFooter({
  proposal,
  onConfirm,
  onCancel,
  disabled,
}: {
  proposal: ActionProposal;
  onConfirm: () => Promise<void>;
  onCancel: () => Promise<void>;
  /** 全局流式期间禁用（2026-09-22） */
  disabled?: boolean;
}) {
  const [busy, setBusy] = useState(false);
  const { status } = proposal;
  const handle = async (fn: () => Promise<void>) => {
    if (busy || disabled) return;
    setBusy(true);
    try { await fn(); } finally { setBusy(false); }
  };
  if (status === "pending") {
    return (
      <div className="flex items-center gap-2 border-t border-border pt-2.5 mt-1">
        <Button
          size="sm"
          onClick={() => void handle(onConfirm)}
          disabled={busy || disabled}
          // 破坏性操作确认按钮红色警示（2026-09-11）：确认前必须核对"系统核实"行
          className={`text-[14px] ${proposal.destructive ? "bg-destructive text-white hover:bg-destructive/90" : ""}`}
        >
          {busy ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />}
          {busy ? "执行中…" : proposal.destructive ? "确认执行（不可恢复）" : "确认执行"}
        </Button>
        <Button size="sm" variant="plain" onClick={() => void handle(onCancel)} disabled={busy || disabled} className="text-[14px]">
          <X size={12} />
          取消
        </Button>
      </div>
    );
  }
  return (
    <div className="border-t border-border pt-2.5 mt-1 text-[14px]">
      {status === "confirmed" && (
        <div className="flex items-center gap-1.5 text-chart-2">
          <Check size={13} />已执行
          {proposal.result && <span className="text-muted-foreground truncate">· {proposal.result}</span>}
        </div>
      )}
      {status === "cancelled" && <div className="flex items-center gap-1.5 text-muted-foreground"><X size={13} />已取消</div>}
      {status === "failed" && (
        <div className="flex items-start gap-1.5 text-destructive">
          <X size={13} className="shrink-0 mt-0.5" />
          <span>执行失败：{proposal.result ?? "请重试"}</span>
        </div>
      )}
      {status === "expired" && <div className="flex items-center gap-1.5 text-muted-foreground"><X size={13} />已过期</div>}
    </div>
  );
}

export function DecisionCard({
  text,
  proposals,
  questions,
  onConfirm,
  onCancel,
  onAnswer,
  onRevise,
  disabled,
}: {
  text: string;
  proposals: ActionProposal[];
  questions: QuestionSpec[];
  onConfirm: (proposalId: string) => Promise<void>;
  onCancel: (proposalId: string) => Promise<void>;
  /** answer 随 field 提交（2026-09-04 mustAsk gate：后端按 field 登记确认证据） */
  onAnswer: (questionId: string, field: string | undefined, answer: string) => void;
  /** 修改意见提交（2026-09-15）：ids=当前 pending 提议（全部静默取消）→ text 交 AI 重新生成 */
  onRevise?: (proposalIds: string[], text: string) => Promise<void> | void;
  /** 全局流式期间禁用（2026-09-22）：确认/取消/修改意见/内嵌提问一律不可点，防误操作与续流竞态 */
  disabled?: boolean;
}) {
  const hasAction = proposals.length > 0;
  const pendingCount = proposals.filter(p => p.status === "pending").length;
  // 破坏性操作（2026-09-11）：任一 pending 提议为 destructive → 卡片红色警示
  const destructivePending = pendingCount > 0 && proposals.some(p => p.status === "pending" && p.destructive);
  /** 修改意见（2026-09-15 Claude Code 式）：提交后旧提议作废、AI 重新生成操作建议 */
  const [revision, setRevision] = useState("");
  const [revising, setRevising] = useState(false);
  const submitRevision = async () => {
    const t = revision.trim();
    if (!t || revising || disabled || !onRevise) return;
    const ids = proposals.filter(p => p.status === "pending").map(p => p.proposalId);
    if (ids.length === 0) return;
    setRevising(true);
    try {
      await onRevise(ids, t);
      setRevision("");
    } finally {
      setRevising(false);
    }
  };
  return (
    <Card className={`w-full py-0 gap-0 overflow-hidden border-border bg-card ${destructivePending ? "border-destructive/50" : ""}`}>
      {/* 头部：标识 + 工具标签 + 待确认计数/状态 */}
      <div className={`flex flex-wrap items-center gap-2 px-3 py-2 border-b border-border ${destructivePending ? "bg-destructive/10" : ""}`}>
        {hasAction
          ? destructivePending
            ? <AlertTriangle size={14} className="text-destructive shrink-0" />
            : <Sparkles size={14} className="text-primary shrink-0" />
          : <HelpCircle size={14} className="text-primary shrink-0" />}
        <span className={`text-[14px] font-semibold ${destructivePending ? "text-destructive" : "text-foreground"}`}>
          {hasAction ? (destructivePending ? "AI 操作建议（破坏性，请仔细核对）" : "AI 操作建议") : "AI 需要确认"}
        </span>
        {proposals.map(p => (
          <span key={p.proposalId} className="text-[14px] px-1.5 py-0.5 rounded bg-primary-light-5 text-primary font-medium">
            {TOOL_LABELS[p.toolName] ?? p.toolName}
          </span>
        ))}
        {questions.length > 0 && (
          <span className="text-[14px] px-1.5 py-0.5 rounded bg-primary-light-5 text-primary font-medium">
            {questions.length} 个问题待回答
          </span>
        )}
        <span className="ml-auto text-[14px] text-muted-foreground">
          {pendingCount > 0 ? "待确认" : proposals.map(p => (
            <span key={p.proposalId}>
              {p.status === "confirmed" && "已执行"}
              {p.status === "cancelled" && "已取消"}
              {p.status === "failed" && "执行失败"}
              {p.status === "expired" && "已过期"}
            </span>
          ))}
        </span>
      </div>

      <div className="px-3 py-2.5 space-y-2.5">
        {/* 顶部：AI 说明（原气泡文本，紧凑 markdown；空则不渲染 → 只显示头部+内容） */}
        {text.trim() && (
          <div className="text-[14px] leading-relaxed text-foreground decision-card-markdown space-y-1.5">
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              components={{
                a: ({ children, ...props }) => <a {...props} target="_blank" rel="noreferrer" className="text-primary underline underline-offset-2" />,
                code: ({ node, className, children, ...props }) => <code {...props} className={`${className ?? ""} rounded bg-muted px-1 py-0.5 font-mono text-[0.8125em]`}>{children}</code>,
                pre: ({ children }) => <MarkdownPre className="my-1.5 max-h-48 overflow-auto rounded-lg bg-muted p-2.5 text-[14px] text-foreground border border-border">{children}</MarkdownPre>,
                table: ({ children }) => <div className="my-1.5 overflow-x-auto"><Table className="w-full border-collapse text-left text-[14px]">{children}</Table></div>,
                th: ({ children }) => <TableHead className="border border-border bg-muted px-2 py-1 font-semibold">{children}</TableHead>,
                td: ({ children }) => <TableCell className="border border-border px-2 py-1">{children}</TableCell>,
              }}
            >
              {text}
            </ReactMarkdown>
          </div>
        )}

        {/* 中部：提议内容（diff > details > 查看参数） */}
        {proposals.map(p => <ProposalBody key={p.proposalId} proposal={p} />)}

        {/* 中部：选项区（ask_user 内嵌，点击即答续流） */}
        {questions.map(q => (
          <div key={q.questionId} className="border-t border-border pt-2 space-y-2">
            <p className="text-[14px] text-foreground leading-snug">{q.question}</p>
            <QuestionControls question={q} onAnswer={answer => onAnswer(q.questionId, q.field, answer)} disabled={disabled} />
          </div>
        ))}

        {/* 底部：确认/取消（各 pending 提议一个按钮区） */}
        {proposals.filter(p => p.status === "pending").map(p => (
          <ProposalFooter
            key={p.proposalId}
            proposal={p}
            onConfirm={() => onConfirm(p.proposalId)}
            onCancel={() => onCancel(p.proposalId)}
            disabled={disabled}
          />
        ))}

        {/* 修改意见输入（2026-09-15 Claude Code 式）：pending 提议时可用——
            提交后旧提议静默取消、修改意见发给 AI 重新生成操作建议卡；满意再点"确认执行" */}
        {pendingCount > 0 && onRevise && (
          <div className="flex items-center gap-2 border-t border-border pt-2.5 mt-1">
            <input
              value={revision}
              onChange={e => setRevision(e.target.value)}
              onKeyDown={e => {
                if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void submitRevision(); }
              }}
              disabled={disabled}
              placeholder="有调整意见？告诉 AI（如：把 26S00000001 改为 26S00000099）"
              className="flex-1 min-w-0 border border-border rounded-lg px-3 py-1.5 text-[14px] bg-card focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-60 disabled:cursor-not-allowed"
            />
            <Button
              size="sm"
              variant="plain"
              disabled={disabled || !revision.trim() || revising}
              onClick={() => void submitRevision()}
              className={`text-[14px] shrink-0 ${disabled || !revision.trim() || revising ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              {revising ? <Loader2 size={12} className="animate-spin" /> : <Send size={12} />}
              让 AI 调整
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}
