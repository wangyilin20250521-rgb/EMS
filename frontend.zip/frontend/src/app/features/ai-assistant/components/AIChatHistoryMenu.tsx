import { useMemo, useState } from "react";
import { History, Plus, Search, Trash2 } from "lucide-react";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/app/components/ui/hover-card";
import type { ConversationSummary } from "@/app/lib/api";

/**
 * 对话历史入口（2026-09）：输入行左侧历史按钮 —— 鼠标悬停/点击展开历史面板
 * （搜索 + 会话列表 + 打开/删除 + 底部新对话）。替代原左侧侧栏的对话历史区。
 *
 * 2026-09-16 起无入口引用：左栏「对话历史」功能卡（AIChatSidebar）已重新承接本组交互
 * （搜索 + 列表 + 删除），输入框旁按钮按用户反馈移除。文件保留待用（如需回退/复用）。
 */
export function AIChatHistoryMenu({
  conversations,
  activeConversationId,
  disabled = false,
  onOpen,
  onDelete,
  onNew,
}: {
  conversations: ConversationSummary[];
  activeConversationId: string | null;
  disabled?: boolean;
  onOpen: (sessionId: string) => void;
  onDelete: (sessionId: string) => void;
  onNew: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const filtered = useMemo(
    () => conversations.filter((c) => !q || (c.title ?? "").includes(q) || (c.preview ?? "").includes(q)),
    [conversations, q]
  );

  const handleOpen = (id: string) => {
    setOpen(false);
    onOpen(id);
  };
  const handleDelete = (id: string) => {
    onDelete(id);
    if (filtered.length <= 1) setQ(""); // 删空后清搜索避免"空列表但有过滤词"
  };

  return (
    <HoverCard open={open} onOpenChange={setOpen} openDelay={120} closeDelay={120}>
      <HoverCardTrigger asChild>
        <button
          type="button"
          title="对话历史（鼠标悬停展开）"
          aria-label="对话历史"
          disabled={disabled}
          className="w-10 h-10 shrink-0 rounded-xl border border-border bg-transparent text-muted-foreground flex items-center justify-center hover:text-primary hover:border-primary/40 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <History size={18} />
        </button>
      </HoverCardTrigger>
      <HoverCardContent
        align="start"
        side="top"
        sideOffset={6}
        className="w-[20rem] p-0 max-h-[min(60vh,26rem)] flex flex-col overflow-hidden"
      >
        <div className="px-3 py-2 border-b border-border flex items-center justify-between gap-2">
          <span className="text-[14px] font-semibold text-muted-foreground">对话历史</span>
          <button
            type="button"
            onClick={() => { setOpen(false); onNew(); }}
            className="inline-flex items-center gap-1 text-[14px] text-primary hover:underline cursor-pointer"
          >
            <Plus size={11} />
            新对话
          </button>
        </div>
        <div className="px-3 py-2 border-b border-border">
          <div className="relative">
            <Search size={11} className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="搜索对话..."
              className="w-full pl-6 pr-2 py-1 text-[14px] border border-border rounded-md bg-muted/40 focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
        </div>
        <div className="overflow-y-auto py-1">
          {filtered.length === 0 ? (
            <p className="text-[14px] text-muted-foreground text-center py-4">{q ? "未找到匹配的对话" : "暂无历史对话"}</p>
          ) : (
            filtered.map((conv) => {
              const convId = conv.sessionId;
              return (
                <div key={convId} className="group relative px-1">
                  <button
                    type="button"
                    onClick={() => handleOpen(convId)}
                    disabled={disabled}
                    className={`w-full p-2.5 pr-8 rounded-lg text-left transition-colors cursor-pointer disabled:opacity-50 ${
                      activeConversationId === convId ? "bg-primary/5" : "hover:bg-muted/50"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-[14px] font-medium text-foreground">{conv.title}</span>
                      <span className="shrink-0 text-[14px] text-muted-foreground">{conv.updatedAt?.slice(0, 10)}</span>
                    </div>
                    <p className="mt-0.5 text-[14px] text-muted-foreground truncate">{conv.preview ?? ""}</p>
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleDelete(convId); }}
                    className="absolute right-1.5 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-red-100 dark:hover:bg-red-950/30 text-muted-foreground hover:text-red-600 transition-all cursor-pointer"
                    title="删除对话"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              );
            })
          )}
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}
