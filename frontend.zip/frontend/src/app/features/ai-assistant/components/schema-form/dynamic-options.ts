/**
 * 排单表单动态候选（2026-09-11 → 09-12 可用性版）：
 * - deviceType：无依赖"首载"动态源——表单打开即拉组合接口一次拿全（设备 × 各型号流程可用性），
 *   型号按"中台有无流程"灰显（用户拍板口径），并显示可用流程数；
 * - processNo ← deviceType：从同一份已拉取的 ctx 按所选设备本地过滤，无二次 HTTP；
 * - specimens ← project：保持按项目实时拉取（数据量大），批卡整选。
 * 新增 form 工具时在此注册动态源（无动态源的字段回退 fieldHints 静态候选）。
 */
import type { FormOption } from "@/app/lib/utils/sse";
import { getPreOrderFormOptions, type PreOrderFormOptions } from "@/app/lib/api/schedule";
import { getAvailableSpecimens } from "@/app/lib/api/samples";

/** ctx 模块级缓存：表单内多字段共享一次请求；失败置空允许重试重拉 */
let formCtxPromise: Promise<PreOrderFormOptions> | null = null;

export function loadFormContext(): Promise<PreOrderFormOptions> {
  formCtxPromise ??= getPreOrderFormOptions().catch((err) => {
    formCtxPromise = null; // 失败不缓存，下次调用重新请求
    throw err;
  });
  return formCtxPromise;
}

/**
 * deviceType 候选（表单打开首载，无 dependsOn）：
 * 三型号全展示；有流程 → 可选 + "N 个可用流程"；无流程 → 灰显禁选 + 原因文案。
 * SIRO 中台不可达（siroError）→ 全部灰显 + "连接失败请重试"原因（与"没流程"区分）。
 */
export async function loadDeviceTypeOptions(): Promise<FormOption[]> {
  const ctx = await loadFormContext();
  const unreachable = !!ctx.siroError;
  return ctx.devices.map((d) => ({
    value: d.deviceType,
    label: d.deviceType,
    sub: d.flowCount > 0 ? `${d.flowCount} 个可用流程` : undefined,
    disabled: d.flowCount === 0,
    reason: unreachable
      ? "SIRO 中台连接失败，流程列表无法加载，请点击重试"
      : "暂无可用流程（需在 SIRO 中台配置后生效）",
  }));
}

/** deviceType → processNo 候选（SIRO 流程；本地过滤已拉全的 ctx，选中设备即时有候选） */
export async function loadProcessOptions(deviceType: string): Promise<FormOption[]> {
  const ctx = await loadFormContext();
  const device = ctx.devices.find((d) => d.deviceType === deviceType);
  return (device?.processes ?? []).map((p) => ({
    value: p.process_no,
    label: p.process_name
      ? `${p.process_no}（${p.process_name}${p.estimated_duration_minutes ? ` ~${p.estimated_duration_minutes}min` : ""}）`
      : p.process_no,
  }));
}

/** project → 可排样例候选（含 待接收/待录入等池子；value=样例 id，label=编号+患者） */
export async function loadSpecimenOptions(project: string): Promise<FormOption[]> {
  const { samples, pendingSpecimens } = await getAvailableSpecimens(project);
  const pool = [...samples, ...pendingSpecimens];
  return pool.map((s) => {
    const label = [
      s.sampleNo || s.id,
      s.patient || "",
      s.status ? `（${s.status}）` : "",
    ].filter(Boolean).join(" ");
    return {
      value: s.id,
      label: label || s.id,
      // 分组键 = 收样日期（YYYY-MM-DD），表单按"批"（一天收样 = 一批）组织整组选择
      group: s.receivedAt?.slice(0, 10) || "未知日期",
      // 二级维度 = 收样批次号（同一天多批次时按批次整选；无批次信息不展示二级）
      batch: s.batchNo || undefined,
    };
  });
}

/** 动态源注册表：key = `${toolName}.${field}`；有 dependsOn 的随父值变化重载，无 dependsOn 的表单打开即首载 */
export const DYNAMIC_LOADERS: Record<string, (dep: string) => Promise<FormOption[]>> = {
  "schedule.create_pre_order.deviceType": loadDeviceTypeOptions,
  "schedule.create_pre_order.processNo": loadProcessOptions,
  "schedule.create_pre_order.specimens": loadSpecimenOptions,
};

/** 依赖声明：key = `${toolName}.${field}` → 父字段（父值变化时重载本字段候选并清空旧值） */
export const DYNAMIC_DEPENDS: Record<string, string> = {
  "schedule.create_pre_order.processNo": "deviceType",
  "schedule.create_pre_order.specimens": "project",
};
