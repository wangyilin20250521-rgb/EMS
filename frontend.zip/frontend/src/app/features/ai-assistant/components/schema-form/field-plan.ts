/**
 * schema → 表单字段计划（2026-09-11 参数表单卡）— 纯逻辑。
 * 输入：AI 工具目录条目（JSON Schema + mustAsk + form 标记）+ AI 提供的 fieldHints；
 * 输出：FieldPlan[]（中文标签/控件类型/静态或动态候选/必填），供 SchemaForm 渲染。
 * 控件推断（zod→JSON Schema 形态）：enum → radio(≤4)/select；integer/number → number；
 * array[{specimenId}] → specimen-multi（候选来自动态源/fieldHints）；string → text。
 */
import type { AiToolCatalogEntry } from "@/app/lib/api/ai-tools";
import type { FormOption, FormRequestSpec } from "@/app/lib/utils/sse";
import { DYNAMIC_DEPENDS, DYNAMIC_LOADERS } from "./dynamic-options";

export type ControlKind = "radio" | "select" | "text" | "number" | "specimen-multi" | "checkbox-multi";

export interface FieldPlan {
  key: string;
  label: string;
  required: boolean;
  control: ControlKind;
  /** 静态选项（mustAsk.options 或 enum）；radio/select 用 */
  options?: FormOption[];
  /** 依赖字段（变更后重载本字段候选；如 processNo 依赖 deviceType） */
  dependsOn?: string;
  /** 注册了动态源（2026-09-12）：候选来自 DYNAMIC_LOADERS，不走静态 options；无 dependsOn 的表单打开即首载 */
  dynamic?: boolean;
  /** 动态候选加载器（dependsOn 触发时调用）；null = 无动态源 */
  loadOptions?: (depValue: string) => Promise<FormOption[]>;
  /** 字段说明（hint，展示在控件下） */
  hint?: string;
}

/** 中文标签回退表（zod toJSONSchema 不带 description；优先级 mustAsk.label > 本表 > 原始键） */
const FIELD_LABELS: Record<string, string> = {
  deviceType: "检测仪器型号",
  project: "检测项目",
  processNo: "实验流程（SIRO 流程编号）",
  specimens: "样本样例",
  patient: "患者姓名",
  gender: "性别",
  age: "年龄",
  type: "样本类型",
  status: "状态",
  content: "内容",
  name: "名称",
};

function pickLabel(key: string, mustAsk?: AiToolCatalogEntry["mustAsk"], hints?: FormRequestSpec["fieldHints"]): string {
  return mustAsk?.find((m) => m.field === key)?.label
    ?? hints?.[key]?.label
    ?? FIELD_LABELS[key]
    ?? key;
}

function toOptions(raw?: string[]): FormOption[] | undefined {
  if (!raw?.length) return undefined;
  return raw.map((v) => ({ value: v }));
}

interface SchemaLike {
  type?: string;
  enum?: string[];
  items?: SchemaLike | SchemaLike[];
  minimum?: number;
  maximum?: number;
}

function propSchema(entry: AiToolCatalogEntry, key: string): SchemaLike | undefined {
  const props = (entry.parameters?.properties ?? {}) as Record<string, SchemaLike>;
  const p = props[key];
  return p ?? undefined;
}

/** 可见字段 = schema required ∪ mustAsk（有 form 标记的工具走表单） */
function visibleFields(entry: AiToolCatalogEntry): string[] {
  const props = (entry.parameters?.properties ?? {}) as Record<string, unknown>;
  const required = (entry.parameters?.required as string[] | undefined) ?? [];
  const must = (entry.mustAsk ?? []).map((m) => m.field);
  const keys = new Set([...required, ...must]);
  return [...keys].filter((k) => props[k] !== undefined);
}

/** 字段顺序（缺省 = schema 声明序；排单按业务引导序） */
const ORDER_OVERRIDE: Record<string, string[]> = {
  "schedule.create_pre_order": ["deviceType", "project", "processNo", "specimens"],
};

function inferControl(
  key: string,
  schema: SchemaLike | undefined,
  toolName: string,
  mustAsk?: AiToolCatalogEntry["mustAsk"]
): ControlKind {
  if (key === "specimens") return "specimen-multi"; // 排单样例（[{specimenId}]）特判
  if (DYNAMIC_DEPENDS[`${toolName}.${key}`]) return "select"; // 依赖字段（如流程←设备）：下拉，候选随父值动态加载
  if (schema?.enum || mustAsk?.find((m) => m.field === key)?.options) {
    return "radio"; // 有枚举/候选 → 选项行
  }
  if (schema?.type === "integer" || schema?.type === "number") return "number";
  if (schema?.type === "array") return "checkbox-multi";
  return "text";
}

/** 由目录条目 + fieldHints 构建字段计划 */
export function buildFieldPlans(entry: AiToolCatalogEntry, hints?: FormRequestSpec["fieldHints"]): FieldPlan[] {
  const required = new Set((entry.parameters?.required as string[] | undefined) ?? []);
  const order = ORDER_OVERRIDE[entry.name] ?? visibleFields(entry);
  const mustAsk = entry.mustAsk;
  return order.map((key) => {
    const schema = propSchema(entry, key);
    const control = inferControl(key, schema, entry.name, mustAsk);
    // 依赖父字段（候选随父值动态加载，如流程←设备、样例←项目）
    const dependsOn = DYNAMIC_DEPENDS[`${entry.name}.${key}`];
    // 注册了动态源（2026-09-12）：候选来自 DYNAMIC_LOADERS（无依赖的如设备型号 = 表单打开首载）
    const dynamic = !!DYNAMIC_LOADERS[`${entry.name}.${key}`];
    // 静态选项：mustAsk.options 优先，其次 enum；走动态源的字段一律不用静态 options
    const options = (key === "specimens" || dependsOn || dynamic)
      ? undefined
      : (toOptions(mustAsk?.find((m) => m.field === key)?.options) ?? toOptions(schema?.enum));
    const staticOpts = options;
    const plan: FieldPlan = {
      key,
      label: pickLabel(key, mustAsk, hints),
      required: required.has(key),
      control,
      ...(dependsOn ? { dependsOn } : {}),
      ...(dynamic ? { dynamic } : {}),
      ...(staticOpts ? { options: staticOpts } : {}),
      ...(key === "specimens" ? { hint: "候选随所选项目实时加载；按收样批次/日期整组选择（默认选中最近一批），可展开排除个别样例" } : {}),
      ...(key === "deviceType" ? { hint: "仅显示有可用流程的设备型号；灰显型号需先在 SIRO 中台配置流程" } : {}),
      ...(key === "processNo" ? { hint: "候选随所选设备实时加载" } : {}),
    };
    return plan;
  }).filter((p) => p.label && p.key); // 只渲染能取到属性的字段
}

/** 由 fieldHints 生成某字段静态候选（无动态源字段的兜底） */
export function staticOptionsFromHints(hints: FormRequestSpec["fieldHints"], key: string): FormOption[] | undefined {
  return hints?.[key]?.options;
}
