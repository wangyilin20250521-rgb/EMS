import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, Loader2, Plus, RefreshCw, Search, X } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/app/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import type { AiToolCatalogEntry } from "@/app/lib/api/ai-tools";
import type { FormOption, FormRequestSpec } from "@/app/lib/utils/sse";
import type { FieldPlan } from "./field-plan";
import { buildFieldPlans } from "./field-plan";
import { DYNAMIC_LOADERS } from "./dynamic-options";

/**
 * schema 驱动参数表单（2026-09-11）— 一次收集写操作全部关键参数：
 * - 单选控件：options ≤4 radio 行 / >4 select；必填星标
 * - 动态依赖：deviceType → processNo、project → specimens 实时加载（失败显示"加载失败可重试"，非空）
 * - 自定义输入：select 类带"自定义…"入口（值并入 optionsByField，保证 mustAsk 强校验）
 * - 提交：onSubmit(values 原始形状, optionsByField 实际展示选项 ∪ 自定义值)
 */
export function SchemaForm({
  entry,
  hints,
  onSubmit,
  busy,
}: {
  entry: AiToolCatalogEntry;
  hints?: FormRequestSpec["fieldHints"];
  onSubmit: (values: Record<string, unknown>, optionsByField: Record<string, string[]>) => void;
  busy?: boolean;
}) {
  const plans = useMemo(() => buildFieldPlans(entry, hints), [entry, hints]);
  /** 样例多选字段名（排单 specimens；表单内样例区共用） */
  const pickedSpecimenField = plans.find((p) => p.control === "specimen-multi")?.key ?? "specimens";
  const [values, setValues] = useState<Record<string, string | string[]>>({});
  const [customValue, setCustomValue] = useState<Record<string, string>>({});
  const [shown, setShown] = useState<Record<string, string[]>>({}); // 每个字段实际展示的选项值（强校验前提）
  const [options, setOptions] = useState<Record<string, FormOption[]>>({});
  const [loadState, setLoadState] = useState<Record<string, "loading" | "error" | "ready">>({});
  const [specSearch, setSpecSearch] = useState("");
  /** 用户是否已手动操作过样例（默认全选只作用于未触碰的新候选批；换项目/取消后不覆盖用户意图） */
  const specimensTouched = useRef(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState("");

  // 动态源：父字段（dependsOn）变化 → 加载子字段候选并清空旧值
  const loadFor = async (field: string, depValue: string) => {
    const loader = DYNAMIC_LOADERS[`${entry.name}.${field}`];
    if (!loader) return;
    setLoadState((p) => ({ ...p, [field]: "loading" }));
    try {
      const opts = await loader(depValue);
      setOptions((p) => ({ ...p, [field]: opts }));
      setShown((p) => ({ ...p, [field]: opts.map((o) => o.value) }));
      setLoadState((p) => ({ ...p, [field]: "ready" }));
      // 依赖值变化：清空子字段旧值
      setValues((p) => {
        if (p[field] !== undefined) { const n = { ...p }; delete n[field]; return n; }
        return p;
      });
    } catch {
      setLoadState((p) => ({ ...p, [field]: "error" }));
    }
  };

  // 父字段（dependsOn 指向它）变化：清空子字段值并重新加载其候选
  const setField = (key: string, v: string | string[]) => {
    setValues((p) => ({ ...p, [key]: v }));
    const dependents = plans.filter((x) => x.dependsOn === key);
    for (const dep of dependents) {
      setValues((p) => { const n = { ...p }; delete n[dep.key]; return n; });
      setOptions((p) => { const n = { ...p }; delete n[dep.key]; return n; });
      setShown((p) => { const n = { ...p }; delete n[dep.key]; return n; });
      if (typeof v === "string" && v) void loadFor(dep.key, v);
    }
  };

  // 静态选项 + hints 兜底初始化
  const staticOpts = (plan: FieldPlan): FormOption[] => plan.options ?? [];
  const currentOpts = (plan: FieldPlan): FormOption[] => {
    // 动态源（specimens/依赖字段/无依赖首载字段如设备型号）候选一律来自 options 状态
    if (plan.control === "specimen-multi" || plan.dynamic) return options[plan.key] ?? [];
    return staticOpts(plan);
  };

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    for (const p of plans) {
      const v = values[p.key];
      const empty = v === undefined || v === "" || (Array.isArray(v) && v.length === 0);
      if (p.required && empty) errs[p.key] = `请选择${p.label}`;
      if (p.dependsOn && !values[p.dependsOn]) errs[p.key] = `请先选择${plans.find((x) => x.key === p.dependsOn)?.label ?? p.dependsOn}`;
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  // 父字段变化时自动加载依赖子字段候选（processNo ← deviceType；specimens ← project）
  useEffect(() => {
    for (const p of plans) {
      if (!p.dependsOn) continue;
      const depValue = values[p.dependsOn];
      if (!depValue || Array.isArray(depValue)) continue;
      if (options[p.key] === undefined) void loadFor(p.key, String(depValue)); // 仅首载（切换父值由 setField 触发）
    }
    // 依赖有意收窄：仅父值变化时首载
  }, [values.deviceType, values.project]);

  // 动态源首载（2026-09-12）：无依赖的动态字段（设备型号可用性）表单打开即加载，
  // 失败显示"加载失败可重试"（loadFor 对无依赖字段透传空串 dep）
  useEffect(() => {
    for (const p of plans) {
      if (!p.dynamic || p.dependsOn) continue;
      if (options[p.key] !== undefined) continue;
      if (loadState[p.key]) continue; // 加载中/已失败不重复触发（重试由按钮显式调用）
      void loadFor(p.key, "");
    }
    // 依赖有意收窄：仅 plans 变化时加载
  }, [plans]);

  // 样例候选加载完成 → 默认选中【最近一批】（按收样日期组织：排单通常就是送最近收的那批；未触碰时生效，用户改过不覆盖）
  useEffect(() => {
    if (!pickedSpecimenField) return;
    const opts = options[pickedSpecimenField];
    if (!opts?.length) return;
    if (specimensTouched.current) return; // 用户已手动调整过：不覆盖
    // 日期最大（最近）组作为默认批；无日期（未知日期）不默认
    const byDate = new Map<string, string[]>();
    for (const o of opts) {
      const g = o.group && o.group !== "未知日期" ? o.group : "";
      if (!g) continue;
      byDate.set(g, [...(byDate.get(g) ?? []), o.value]);
    }
    const dates = [...byDate.keys()].sort().reverse(); // YYYY-MM-DD 字典序即时间序
    if (!dates.length) return;
    setValues((p) => (p[pickedSpecimenField] ? p : { ...p, [pickedSpecimenField]: byDate.get(dates[0])! }));
    // 依赖有意收窄：仅选项变化时预填默认批
  }, [options, pickedSpecimenField]);

  const handleSubmit = () => {
    if (busy || !validate()) return;
    // optionsByField：静态/动态展示选项 ∪ 自定义输入值（保证 gate 强校验 includes 恒真）
    const optionsByField: Record<string, string[]> = {};
    for (const p of plans) {
      const shownList = shown[p.key] ?? currentOpts(p).map((o) => o.value);
      const extra = customValue[p.key];
      optionsByField[p.key] = extra && !shownList.includes(extra) ? [...shownList, extra] : shownList;
    }
    onSubmit({ ...values }, optionsByField);
  };

  const pickedSpecimens = (values[pickedSpecimenField] as string[]) ?? [];

  const renderField = (p: FieldPlan) => {
    const opts = currentOpts(p);
    const err = errors[p.key];
    const load = loadState[p.key];
    const isCustom = (v: string | undefined) => v !== undefined && !opts.some((o) => o.value === v);

    if (p.control === "specimen-multi" || p.dynamic) {
      return (
        <div className="space-y-1.5">
          {load === "loading" && <div className="flex items-center gap-1.5 text-[14px] text-muted-foreground"><Loader2 size={12} className="animate-spin" />正在加载{p.label}候选…</div>}
          {load === "error" && (
            <div className="flex items-center gap-2 text-[14px] text-destructive">
              {p.label}候选加载失败
              <button type="button" onClick={() => loadFor(p.key, p.dependsOn ? String(values[p.dependsOn] ?? "") : "")} className="inline-flex items-center gap-1 text-primary hover:underline cursor-pointer">
                <RefreshCw size={11} />重试
              </button>
            </div>
          )}
          {load !== "loading" && load !== "error" && (
            <div className="space-y-1.5">
              {p.control === "specimen-multi" ? (
                // 样例：按收样批次分组的批卡（默认最近一批整选；dependsOn 只负责随项目加载候选，不走下拉）
                <SpecimenBatchPicker
                  options={opts}
                  picked={pickedSpecimens}
                  search={specSearch}
                  onSearch={setSpecSearch}
                  onChange={(next) => { specimensTouched.current = true; setField(pickedSpecimenField, next); }}
                />
              ) : p.control === "radio" ? (
                // 动态单选（设备型号可用性，2026-09-12）：无流程灰显 + 原因；可用行显示流程数
                <RadioGroup value={values[p.key] as string | undefined} onValueChange={(v) => setField(p.key, v)} className="space-y-1.5">
                  {opts.map((o) => {
                    const active = values[p.key] === o.value;
                    return (
                      <label key={o.value} className={`flex items-start gap-2 text-[14px] rounded-lg border px-3 py-1.5 transition-colors ${o.disabled ? "cursor-not-allowed border-border bg-muted/30 opacity-60" : `cursor-pointer ${active ? "border-primary/60 bg-primary-light-5/60" : "border-border hover:border-primary/50"}`}`}>
                        <RadioGroupItem value={o.value} id={`${p.key}-${o.value}`} disabled={o.disabled} />
                        <span className="flex-1 min-w-0">
                          <span className="flex items-center justify-between gap-2">
                            <span className={o.disabled ? "text-muted-foreground" : active ? "text-foreground font-medium" : "text-foreground"}>{o.label ?? o.value}</span>
                            {o.sub && !o.disabled && <span className="shrink-0 text-[14px] font-medium text-chart-2">{o.sub}</span>}
                          </span>
                          {o.disabled && o.reason && (
                            <span className="block text-[14px] text-muted-foreground leading-snug mt-0.5">{o.reason}</span>
                          )}
                        </span>
                      </label>
                    );
                  })}
                </RadioGroup>
              ) : (
                <>
                  <Select value={values[p.key] as string | undefined} onValueChange={(v) => setField(p.key, v)} disabled={opts.length === 0}>
                    <SelectTrigger className="h-8 text-[14px]"><SelectValue placeholder={p.dependsOn && !values[p.dependsOn] ? `先选择${plans.find((x) => x.key === p.dependsOn)?.label ?? ""}` : opts.length === 0 ? `无可用${p.label}` : `选择${p.label}`} /></SelectTrigger>
                    <SelectContent>{opts.map((o) => <SelectItem key={o.value} value={o.value} disabled={o.disabled}>{o.label ?? o.value}</SelectItem>)}</SelectContent>
                  </Select>
                  {/* 依赖设备无任何可用流程：明确空态提示，不再让人面对空下拉（2026-09-12） */}
                  {p.dependsOn && load === "ready" && opts.length === 0 && values[p.dependsOn] && (
                    <p className="text-[14px] text-amber-600 leading-snug">该设备型号暂无可用实验流程，无法排单——需先在 SIRO 中台配置该型号流程，再回来重试。</p>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      );
    }

    if (p.control === "radio" && opts.length > 0) {
      return (
        <RadioGroup value={values[p.key] as string | undefined} onValueChange={(v) => setField(p.key, v)} className="space-y-1.5">
          {opts.map((o) => (
            <label key={o.value} className="flex items-center gap-2 text-[14px] cursor-pointer rounded-lg border border-border px-3 py-1.5 hover:border-primary/50">
              <RadioGroupItem value={o.value} id={`${p.key}-${o.value}`} />
              <span className="flex-1">{o.label ?? o.value}</span>
            </label>
          ))}
        </RadioGroup>
      );
    }

    if ((p.control === "select" || p.control === "radio") && opts.length > 0) {
      // select 化（radio 超限在 buildFieldPlans 决策；此处 radio 带自定义入口）
      const v = values[p.key] as string | undefined;
      return (
        <div className="space-y-1.5">
          <Select value={isCustom(v) ? "__custom__" : v} onValueChange={(x) => x === "__custom__" ? null : setField(p.key, x)}>
            <SelectTrigger className="h-8 text-[14px]"><SelectValue placeholder={`选择${p.label}`} /></SelectTrigger>
            <SelectContent>
              {opts.map((o) => <SelectItem key={o.value} value={o.value}>{o.label ?? o.value}</SelectItem>)}
              <SelectItem value="__custom__">自定义…</SelectItem>
            </SelectContent>
          </Select>
          {isCustom(v) && (
            <Input autoFocus value={customValue[p.key] ?? ""} onChange={(e) => { setCustomValue((c) => ({ ...c, [p.key]: e.target.value })); setField(p.key, e.target.value); }} placeholder={`输入自定义${p.label}`} className="h-8 text-[14px]" />
          )}
        </div>
      );
    }

    if (p.control === "number") {
      return <Input type="number" value={values[p.key] as string ?? ""} onChange={(e) => setField(p.key, e.target.value)} className="h-8 text-[14px]" />;
    }
    return <Input value={values[p.key] as string ?? ""} onChange={(e) => setField(p.key, e.target.value)} className="h-8 text-[14px]" />;
  };

  return (
    <div className="space-y-3">
      {plans.map((p) => (
        <div key={p.key} className="space-y-1">
          <Label className="text-[14px] font-medium text-foreground">
            {p.label}
            {p.required && <span className="text-destructive ml-0.5">*</span>}
          </Label>
          {renderField(p)}
          {p.hint && <p className="text-[14px] text-muted-foreground">{p.hint}</p>}
          {errors[p.key] && <p className="text-[14px] text-destructive">{errors[p.key]}</p>}
        </div>
      ))}
      {submitError && <p className="text-[14px] text-destructive">{submitError}</p>}
      <div className="flex items-center gap-2 pt-1">
        <Button size="sm" disabled={busy} onClick={handleSubmit} className="text-[14px]">
          {busy ? <Loader2 size={12} className="animate-spin" /> : null}
          确认提交
        </Button>
        {busy && <span className="text-[14px] text-muted-foreground">参数已提交，AI 正在生成操作建议…</span>}
      </div>
    </div>
  );
}

/**
 * 样例"范围整选器"（2026-09-12 v2，替代逐管批卡）— 排单是批量业务，样例几十管起步，
 * 绝不逐个/单选：入选只发生在"组"粒度——一级组 = 收样日期，同日多批次时二级组 = 收样批次；
 * 单管只以"排除个别"的负向名单出现（折叠明细，默认空）。默认整选最近一批（见调用方 effect）。
 */
interface BatchBlock {
  key: string;
  label: string;
  members: FormOption[];
}
interface DateGroup {
  date: string;
  title: string;
  members: FormOption[];
  blocks: BatchBlock[];
}

function titleForDate(date: string): string {
  if (!date) return "未标注收样日期";
  const today = new Date();
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  return date === todayStr ? "今日收样" : `${date} 收样`;
}

function idsOf(list: FormOption[]): string[] {
  return list.map((o) => o.value);
}

function groupOptions(options: FormOption[]): DateGroup[] {
  const byDate = new Map<string, FormOption[]>();
  for (const o of options) {
    const g = o.group ?? "未知日期";
    byDate.set(g, [...(byDate.get(g) ?? []), o]);
  }
  const dates = [...byDate.keys()].sort((a, b) => {
    if (a === "未知日期") return 1;
    if (b === "未知日期") return -1;
    return a < b ? 1 : -1;
  });
  return dates.map((date) => {
    const members = byDate.get(date)!;
    const byBatch = new Map<string, FormOption[]>();
    for (const m of members) {
      const k = m.batch?.trim() || "";
      byBatch.set(k, [...(byBatch.get(k) ?? []), m]);
    }
    const batchKeys = [...byBatch.keys()].sort((a, b) => {
      if (!a) return 1;
      if (!b) return -1;
      return a < b ? -1 : a > b ? 1 : 0;
    });
    return {
      date,
      title: titleForDate(date),
      members,
      // 同组单批次时收起二级（组=块），多批次时逐批整选
      blocks: batchKeys.map((k) => ({ key: k, label: k || "未标注批次", members: byBatch.get(k)! })),
    };
  });
}

function SpecimenBatchPicker({
  options, picked, search, onSearch, onChange,
}: {
  options: FormOption[];
  picked: string[];
  search: string;
  onSearch: (v: string) => void;
  onChange: (next: string[]) => void;
}) {
  const [manageOpen, setManageOpen] = useState<string | null>(null);
  const groups = useMemo(() => groupOptions(options), [options]);
  const pickedSet = useMemo(() => new Set(picked), [picked]);

  /** 整组/整批入选开关：加 = 并入全部 ids；减 = 剔除全部 ids（负向排除同时清除） */
  const toggleBlock = (blockIds: string[], on: boolean) => {
    onChange(on ? [...new Set([...picked, ...blockIds])] : picked.filter((v) => !blockIds.includes(v)));
  };

  /** 排除/恢复单管（负向名单：仅在已选块内生效；块整选/整除时随块清空） */
  const flipOne = (id: string) => {
    onChange(pickedSet.has(id) ? picked.filter((v) => v !== id) : [...picked, id]);
  };

  // 搜索 = 按范围（收样日期/批次号）过滤，不按单管
  const q = search.trim().toLowerCase();
  const matchText = (s: string) => (s?.toLowerCase().includes(q) ?? false);
  const visibleGroups = groups.filter((g) =>
    !q || matchText(g.title) || g.blocks.some((b) => matchText(b.label))
  );
  // 搜索态：命中的组/批强制展开为"整选行"，隐藏单管明细
  const searching = q.length > 0;

  const totalSelected = picked.length;
  let excludedCount = 0;
  for (const g of groups) {
    for (const b of g.blocks) {
      const sel = b.members.filter((o) => pickedSet.has(o.value)).length;
      if (sel > 0 && sel < b.members.length) excludedCount += b.members.length - sel;
    }
  }

  return (
    <div className="space-y-1.5">
      <div className="relative">
        <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input value={search} onChange={(e) => onSearch(e.target.value)} placeholder="搜索收样日期 / 批次号…" className="h-8 pl-7 text-[14px]" />
      </div>

      {groups.length === 0 ? (
        <p className="text-[14px] text-muted-foreground py-1">该批次下无可排样例（或均已排单占用）</p>
      ) : visibleGroups.length === 0 ? (
        <p className="text-[14px] text-muted-foreground py-1">没有匹配的收样日期 / 批次</p>
      ) : (
        <div className="max-h-56 overflow-auto space-y-1 rounded-lg border border-border p-1.5">
          {visibleGroups.map((g) => {
            const groupIds = idsOf(g.members);
            const selInGroup = g.members.filter((o) => pickedSet.has(o.value)).length;
            const groupAll = selInGroup === g.members.length && g.members.length > 0;
            const groupSome = selInGroup > 0 && !groupAll;
            const isOpen = manageOpen === g.date;
            const searchMatchedBlocks = q ? g.blocks.filter((b) => matchText(b.label)) : g.blocks;
            const blockRows = q ? searchMatchedBlocks : g.blocks;

            return (
              <div key={g.date} className={`rounded-lg border ${groupSome ? "border-primary/30 bg-primary-light-5/60" : "border-border"}`}>
                {/* 组头：整组入选开关（默认最近一批已整选，见调用方 effect） */}
                <div className="flex items-center gap-2 px-2 py-1.5">
                  <input
                    type="checkbox"
                    className="accent-primary shrink-0"
                    checked={groupAll}
                    ref={(el) => { if (el) el.indeterminate = groupSome; }}
                    onChange={() => toggleBlock(groupIds, !groupAll)}
                  />
                  <button
                    type="button"
                    onClick={() => toggleBlock(groupIds, !groupAll)}
                    className="flex-1 flex items-center justify-between text-left cursor-pointer min-w-0"
                  >
                    <span className="text-[14px] font-medium text-foreground truncate">{g.title}</span>
                    <span className="shrink-0 text-[14px] text-muted-foreground ml-2">
                      {g.members.length} 管 · 已选 {selInGroup}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setManageOpen(isOpen ? null : g.date)}
                    title={isOpen ? "收起管理" : "管理（按批次/排除个别）"}
                    className="shrink-0 text-muted-foreground hover:text-foreground cursor-pointer"
                  >
                    <ChevronDown size={13} className={`transition-transform ${isOpen ? "rotate-180" : ""}`} />
                  </button>
                </div>

                {/* 搜索态：直接给出命中的整选行（组或批次），无明细 */}
                {searching ? (
                  <div className="px-2 pb-1.5 space-y-0.5 border-t border-border/60 pt-1">
                    {blockRows.length === 0 && (
                      <p className="text-[14px] text-muted-foreground py-0.5">该日无匹配的批次行</p>
                    )}
                    {blockRows.map((b) => {
                      const bIds = idsOf(b.members);
                      const selB = b.members.filter((o) => pickedSet.has(o.value)).length;
                      const bAll = selB === b.members.length && b.members.length > 0;
                      const bSome = selB > 0 && !bAll;
                      return (
                        <label key={b.key} className="flex items-center gap-2 rounded px-1.5 py-0.5 text-[14px] cursor-pointer hover:bg-muted/50">
                          <input type="checkbox" className="accent-primary" checked={bAll}
                            ref={(el) => { if (el) el.indeterminate = bSome; }}
                            onChange={() => toggleBlock(bIds, !bAll)} />
                          <span className="truncate flex-1">{g.blocks.length > 1 ? `${b.label} · ` : ""}{b.members.length} 管</span>
                          <span className="shrink-0 text-[14px] text-muted-foreground">已选 {selB}</span>
                        </label>
                      );
                    })}
                  </div>
                ) : isOpen ? (
                  <div className="px-2 pb-1.5 pt-1 border-t border-border/60 space-y-1">
                    {/* 二级：同日多批次时按批次整选 */}
                    {g.blocks.length > 1 && (
                      <div className="space-y-0.5">
                        <p className="text-[14px] text-muted-foreground px-1 pt-0.5">按批次整选</p>
                        {g.blocks.map((b) => {
                          const bIds = idsOf(b.members);
                          const selB = b.members.filter((o) => pickedSet.has(o.value)).length;
                          const bAll = selB === b.members.length && b.members.length > 0;
                          const bSome = selB > 0 && !bAll;
                          return (
                            <label key={b.key} className="flex items-center gap-2 rounded px-1.5 py-0.5 text-[14px] cursor-pointer hover:bg-muted/50">
                              <input type="checkbox" className="accent-primary" checked={bAll}
                                ref={(el) => { if (el) el.indeterminate = bSome; }}
                                onChange={() => toggleBlock(bIds, !bAll)} />
                              <span className="truncate flex-1">{b.label}</span>
                              <span className="shrink-0 text-[14px] text-muted-foreground">
                                {b.members.length} 管 · 已选 {selB}{bSome ? `（排除 ${b.members.length - selB}）` : ""}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    )}
                    {/* 排除个别（负向名单：默认全部入选，点"不排"剔除单管；不得正向单选） */}
                    <div className="pt-0.5">
                      <p className="text-[14px] text-muted-foreground px-1">排除个别（默认全部入选；点"不排"剔除该管）</p>
                      {selInGroup === 0 ? (
                        <p className="text-[14px] text-muted-foreground px-1 py-0.5">先整选该组后，再在此排除个别样例</p>
                      ) : (
                        <div className="space-y-0.5">
                          {g.members.map((o) => {
                            const active = pickedSet.has(o.value);
                            return (
                              <div key={o.value} className={`flex items-center gap-2 rounded px-1.5 py-0.5 text-[14px] ${active ? "text-foreground" : "text-muted-foreground bg-muted/40"}`}>
                                <span className="truncate flex-1">{o.label ?? o.value}</span>
                                {active ? (
                                  <button
                                    type="button"
                                    onClick={() => flipOne(o.value)}
                                    className="shrink-0 flex items-center gap-0.5 text-muted-foreground hover:text-destructive cursor-pointer"
                                  >
                                    <X size={10} />不排
                                  </button>
                                ) : (
                                  <button
                                    type="button"
                                    onClick={() => flipOne(o.value)}
                                    className="shrink-0 flex items-center gap-0.5 text-primary cursor-pointer"
                                  >
                                    <Plus size={10} />恢复
                                  </button>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      )}

      {groups.length > 0 && (
        <div className="flex items-center justify-between text-[14px] text-muted-foreground">
          <span>
            已选 {totalSelected} 管（默认选中最近一批，可改选其他批次）
            {excludedCount > 0 && <span className="text-destructive"> · 排除 {excludedCount} 管</span>}
          </span>
          {!searching && groups.length > 1 && (
            <button type="button" onClick={() => onChange([])} className="text-muted-foreground hover:text-foreground cursor-pointer">清空选择</button>
          )}
        </div>
      )}
    </div>
  );
}
