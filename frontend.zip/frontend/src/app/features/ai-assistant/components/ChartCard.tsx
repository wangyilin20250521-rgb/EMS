import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { ChartSpec } from "@/app/lib/utils/sse";

/** AI 图表卡片（P1）— 渲染 chat_data 事件携带的图表规范，样式对齐 Dashboard 图表（token 驱动）。 */

const TOOLTIP_STYLE: React.CSSProperties = {
  background: "var(--card)",
  border: "1px solid var(--border)",
  borderRadius: 8,
  fontSize: 12,
  color: "var(--foreground)",
};

const AXIS_TICK = { fontSize: 11, fill: "var(--muted-foreground)" };

// 色板取自 --chart-* token（亮/暗双套同值），饼图/多序列按序取色
const PALETTE = [
  "var(--chart-1)",
  "var(--chart-2)",
  "var(--chart-3)",
  "var(--chart-4)",
  "var(--chart-5)",
];

const colorOf = (i: number) => PALETTE[i % PALETTE.length];

export function ChartCard({ chart }: { chart: ChartSpec }) {
  const data = chart.data.map((d) => ({ name: d.label, value: d.value }));
  if (data.length === 0) return null;

  return (
    <div className="rounded-lg border border-border bg-card p-3">
      {chart.title && (
        <p className="mb-2 text-[14px] font-semibold text-foreground">{chart.title}</p>
      )}
      <div style={{ height: 200 }}>
        <ResponsiveContainer width="100%" height="100%">
          {chart.chartType === "pie" ? (
            <PieChart>
              <Pie
                data={data}
                dataKey="value"
                nameKey="name"
                innerRadius="50%"
                outerRadius="80%"
                paddingAngle={2}
                stroke="none"
              >
                {data.map((_, i) => (
                  <Cell key={i} fill={colorOf(i)} />
                ))}
              </Pie>
              <Tooltip contentStyle={TOOLTIP_STYLE} />
            </PieChart>
          ) : chart.chartType === "line" ? (
            <LineChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="name" tick={AXIS_TICK} axisLine={false} tickLine={false} />
              <YAxis tick={AXIS_TICK} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ stroke: "var(--muted)", strokeWidth: 1 }} />
              <Line
                type="monotone"
                dataKey="value"
                name="数值"
                stroke={colorOf(0)}
                strokeWidth={2}
                dot={{ r: 3, fill: colorOf(0), strokeWidth: 0 }}
                activeDot={{ r: 5 }}
              />
            </LineChart>
          ) : (
            <BarChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
              <defs>
                {data.map((_, i) => (
                  <linearGradient key={i} id={`ai-bar-grad-${i}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={colorOf(i)} stopOpacity={1} />
                    <stop offset="100%" stopColor={colorOf(i)} stopOpacity={0.6} />
                  </linearGradient>
                ))}
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="name" tick={AXIS_TICK} axisLine={false} tickLine={false} />
              <YAxis tick={AXIS_TICK} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: "var(--muted)", opacity: 0.4 }} />
              <Bar dataKey="value" name="数值" radius={[4, 4, 0, 0]} maxBarSize={28}>
                {data.map((_, i) => (
                  <Cell key={i} fill={`url(#ai-bar-grad-${i})`} />
                ))}
              </Bar>
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>
    </div>
  );
}
