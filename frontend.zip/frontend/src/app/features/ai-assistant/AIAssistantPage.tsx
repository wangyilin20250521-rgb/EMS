import { useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Bot,
  ChevronRight,
  ChevronUp,
  PanelLeftClose,
  PanelLeftOpen,
} from "lucide-react";

import { AIChatProvider, useAIChat } from "@/app/hooks/useAIChat";
import { WELCOME_STARTERS } from "@/app/lib/constants/ai-prompts";
import { Table, TableHead, TableCell } from "@/app/components/ui/table";
import { AIThinkingTrace } from "@/app/components/shared/AIThinkingTrace";
import { MarkdownPre } from "@/app/components/shared/MarkdownPre";
import { IconAsset } from "@/app/components/shared/IconAsset";
import { ChatComposer } from "@/app/components/shared/ChatComposer";
import { ConversationWorklog } from "./components/ConversationWorklog";
import { ChartCard } from "./components/ChartCard";
import { DecisionCard, isDecisionMessage } from "./components/DecisionCard";
import { WizardCard } from "./components/WizardCard";
import { FormCard } from "./components/FormCard";
import { FileUploadCard } from "./components/FileUploadCard";
import { StreamingIndicator } from "@/app/components/shared/StreamingIndicator";
import { AIChatSidebar } from "./components/AIChatSidebar";
import { TemplateIcon } from "./components/ai-template-icons";
import type { AITemplateItem } from "@/app/lib/constants/ai-features";

export function AIAssistantPage() {
  const {
    messages, streaming, conversations, activeConversationId, sessionId,
    sendMessage, stopGeneration, newConversation, openConversation, deleteConversation,
    confirmAction, cancelAction, answerQuestion,
    wizardSteps, wizardAnswer,
    activeForm, submitForm, dismissForm,
    activeFileUpload, uploadSamplesFile, dismissFileUpload,
    chatAttachments, addChatFiles, removeChatAttachment,
    reviseProposal,
  } = useAIChat();

  const [input, setInput] = useState("");
  const [showIntroduction, setShowIntroduction] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  /** 技能胶囊是否展开成多行（默认单行、溢出隐藏） */
  const [startersExpanded, setStartersExpanded] = useState(false);
  /** 单行放不下 → 显示右端「>」展开按钮 */
  const [startersOverflow, setStartersOverflow] = useState(false);
  const starterRowRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const [pinnedToBottom, setPinnedToBottom] = useState(true);

  // 用户上滚超过阈值时暂停自动滚动（避免查看历史时被拉回底部），回到底部附近自动恢复
  const handleChatScroll = () => {
    const el = chatContainerRef.current;
    if (!el) return;
    setPinnedToBottom(el.scrollHeight - el.scrollTop - el.clientHeight < 100);
  };

  useEffect(() => {
    if (pinnedToBottom) messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, pinnedToBottom]);

  const handleSend = (text: string) => {
    const t = text.trim();
    if (!t || streaming) return;
    setShowIntroduction(false);
    sendMessage(t);
    setInput("");
  };

  const handleTemplateSelect = (text: string) => setInput(text);
  // 功能引导（2026-09）：点场景模板 → 填入输入框（可编辑）→ 聚焦便于回车即发
  const chatInputRef = useRef<HTMLTextAreaElement>(null);
  const handleFeaturePick = (item: AITemplateItem) => {
    handleTemplateSelect(item.prompt);
    requestAnimationFrame(() => chatInputRef.current?.focus());
  };

  const handleNew = () => {
    newConversation();
    setShowIntroduction(true);
    setInput("");
    setStartersExpanded(false);
  };

  // 技能胶囊单行放不下时整颗隐藏、右端出「>」展开（对齐 WorkBuddy：单行左对齐 + 多余隐藏）。
  // 行内 flex-wrap + max-h-10：换行的胶囊整颗溢出被裁掉（不会切一半）。
  // 判定用「胶囊总宽 vs 可用宽」：可用宽取外层容器去掉内边距后的宽度，与展开按钮是否挂载无关；
  // 若按行自身宽度算，按钮出现→行变窄→判定仍溢出→按钮不消失，收起后按钮会赖着不走。
  // 展开态不测：多行撑高后胶囊已无溢出问题，收起按钮由 startersExpanded 保底显示。
  useEffect(() => {
    if (startersExpanded) return;
    const el = starterRowRef.current;
    if (!el) return;
    const check = () => {
      const chips = Array.from(el.querySelectorAll<HTMLElement>(":scope > button"));
      if (chips.length === 0) return;
      const gap = parseFloat(getComputedStyle(el).columnGap) || 0;
      const need = chips.reduce((sum, c) => sum + c.offsetWidth, 0) + gap * (chips.length - 1);
      const wrap = el.parentElement;
      const wrapStyle = wrap ? getComputedStyle(wrap) : null;
      const available = wrap && wrapStyle
        ? wrap.clientWidth - parseFloat(wrapStyle.paddingLeft) - parseFloat(wrapStyle.paddingRight)
        : el.clientWidth;
      setStartersOverflow(need > available + 1);
    };
    check();
    const ro = new ResizeObserver(check);
    ro.observe(el);
    return () => ro.disconnect();
  }, [startersExpanded, showIntroduction]);

  return (
    <div className="h-full flex flex-col bg-slate-50/30 dark:bg-slate-950/30">
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧可收敛侧栏（2026-09 恢复：快捷模板/系统摘要/对话历史） */}
        {!sidebarCollapsed && (
          <AIChatSidebar
            conversations={conversations}
            activeConversationId={activeConversationId}
            streaming={streaming}
            onPickTemplate={(item) => handleFeaturePick(item)}
            onOpenConversation={(id) => { setShowIntroduction(false); openConversation(id); }}
            onDeleteConversation={deleteConversation}
            onNew={handleNew}
          />
        )}
        {/* Chat Area */}
        <div className="flex-1 flex flex-col min-w-0">
          {showIntroduction ? (
            <div className="flex-1 min-h-0 flex flex-col bg-gradient-to-br from-primary/5 via-background to-muted/40 dark:from-primary/10 dark:via-background dark:to-muted/20 relative">
              {/* 左上角操作按钮：仅保留折叠（2026-09-17：新对话入口已收至侧栏品牌头，主区不再重复） */}
              <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5">
                <button type="button" onClick={() => setSidebarCollapsed((c) => !c)}
                  title={sidebarCollapsed ? "展开侧栏（快捷模板/摘要/对话历史）" : "折叠侧栏"}
                  aria-label="切换侧栏"
                  className="p-2 rounded-lg border border-border bg-card text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer shadow-sm">
                  {sidebarCollapsed ? <PanelLeftOpen size={15} /> : <PanelLeftClose size={15} />}
                </button>
              </div>
              <div className="flex-1 overflow-y-auto flex items-center justify-center p-6">
                <div className="max-w-2xl w-full text-center">
                  <h1 className="text-3xl font-semibold text-foreground">EMS 智能助手</h1>
                  {/* 技能胶囊（2026-09-21 用户设计，对齐 WorkBuddy）：单行、与输入框同左边缘，
                      放不下的收起隐藏、右端「>」展开成多行；其余技能在侧栏「技能」面板里。
                      pr 给右上角 3D 助手图标留列：展开按钮落在它左侧，胶囊也不会被图标压住。
                      mt-16 = 标题两行行高（WorkBuddy 同款：大标题与下方操作区留白开阔） */}
                  <div className="mt-16 flex items-center gap-1.5 pr-[92px]">
                    <div
                      ref={starterRowRef}
                      className={`flex-1 min-w-0 flex flex-wrap items-start gap-2 overflow-hidden ${startersExpanded ? "" : "max-h-10"}`}
                    >
                      {WELCOME_STARTERS.map((tpl) => (
                        <button key={tpl.id} type="button" title={tpl.text} onClick={() => handleSend(tpl.text)}
                          className="group shrink-0 h-10 inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 text-[13px] leading-none text-foreground transition-colors cursor-pointer hover:border-primary/40 hover:bg-primary/5 hover:text-primary">
                          <TemplateIcon name={tpl.icon} size={14} className="text-muted-foreground transition-colors group-hover:text-primary" />
                          {tpl.label}
                        </button>
                      ))}
                    </div>
                    {(startersOverflow || startersExpanded) && (
                      <button
                        type="button"
                        onClick={() => setStartersExpanded((v) => !v)}
                        title={startersExpanded ? "收起" : "展开全部技能"}
                        aria-expanded={startersExpanded}
                        className="shrink-0 w-7 h-7 rounded-full border border-border bg-card text-muted-foreground flex items-center justify-center hover:text-foreground hover:bg-muted transition-colors cursor-pointer"
                      >
                        {startersExpanded ? <ChevronUp size={14} /> : <ChevronRight size={14} />}
                      </button>
                    )}
                  </div>
                  {/* 输入框居中（2026-09-21 用户设计）：空态=主流 AI 应用形态，首问后随聊天态落到底部；
                      3D 助手图标趴在输入框右上角（下半截被框体遮住，WorkBuddy 同款） */}
                  <div className="relative mt-3">
                    <IconAsset
                      name="ai"
                      size={88}
                      className="absolute -top-[60px] right-3 z-0 pointer-events-none"
                    />
                    <div className="relative z-10">
                      <ChatComposer
                        inputRef={chatInputRef}
                        value={input}
                        onChange={setInput}
                        onSend={() => handleSend(input)}
                        placeholder="输入问题，开始一段新对话..."
                        attachments={chatAttachments}
                        onRemoveAttachment={removeChatAttachment}
                        onFilesSelected={addChatFiles}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <>
              <div className="p-4 border-b border-border bg-card shrink-0">
                <div className="flex items-center gap-4">
                  {/* 顶部操作按钮：仅保留折叠（2026-09-17：新对话入口已收至侧栏品牌头） */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button type="button" onClick={() => setSidebarCollapsed((c) => !c)}
                      title={sidebarCollapsed ? "展开侧栏（快捷模板/摘要/对话历史）" : "折叠侧栏"}
                      aria-label="切换侧栏"
                      className="p-2 rounded-lg border border-border text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer">
                      {sidebarCollapsed ? <PanelLeftOpen size={15} /> : <PanelLeftClose size={15} />}
                    </button>
                  </div>
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-white shadow-lg shadow-primary/20 shrink-0"><Bot size={20} /></div>
                    {/* 2026-09-17 移除"实时在线"绿点状态行：该状态为写死文案（非真实连接检测），
                        且与 AI Native 的极简头部风格不符 */}
                    <h2 className="text-[14px] font-semibold text-foreground">EMS 智能助手</h2>
                  </div>
                </div>
              </div>

              <div ref={chatContainerRef} onScroll={handleChatScroll} className="flex-1 overflow-y-auto p-5 space-y-7">
                {/* 本次对话工作记录（2026-09-17：原左栏「AI 工作任务」「状态看板」两卡收敛于此） */}
                <ConversationWorklog messages={messages} sessionId={sessionId} streaming={streaming} />
                {messages.map((m, i) => {
                  const messageId = m.id ?? `message-${i}`;
                  // 决策卡：AI 含提议/提问且流式结束 → 整条回复渲染为一张大卡（不再气泡+独立卡分离）
                  const decision = isDecisionMessage(m);
                  // 思考/工具轨迹：AI 消息且有 process 数据时渲染（平文形态的浅色行，完成后自动收起）
                  const hasTrace = m.role === "ai" && (m.process?.length ?? 0) > 0;
                  return (
                  <div key={messageId} className={`flex flex-col gap-2 ${m.role === "user" ? "items-end" : "items-start"}`}>
                    {decision ? (
                      <>
                        {hasTrace && <AIThinkingTrace items={m.process!} streaming={!!m.streaming} />}
                        {/* 决策卡：整条 AI 回复 = 一张大卡（说明入卡顶、diff/参数摘要中部、确认在卡底） */}
                        <DecisionCard
                          text={m.text ?? ""}
                          proposals={m.proposals ?? []}
                          questions={m.questions ?? []}
                          onConfirm={(id) => confirmAction(id)}
                          onCancel={(id) => cancelAction(id)}
                          onAnswer={(qid, field, answer) => answerQuestion(qid, answer, field)}
                          onRevise={(ids, txt) => reviseProposal(ids, txt)}
                          disabled={streaming}
                        />
                      </>
                    ) : m.role === "user" ? (
                      // 用户消息：右侧白底卡片（与 AI 平文形态形成主次对比）；字号与 AI 正文一致（2026-09-22）
                      <div className="max-w-[85%] p-4 rounded-2xl text-[15px] leading-7 shadow-sm bg-card border border-border text-foreground rounded-br-none whitespace-pre-wrap">
                        {m.text}
                      </div>
                    ) : (
                      <>
                        {hasTrace && <AIThinkingTrace items={m.process!} streaming={!!m.streaming} />}
                        {/* AI 正文：无卡片平文打字（2026-09-17 AI Native 形态），宽度放宽提升阅读性；
                            行距 1.95 + 段落/列表间距（2026-09-17 用户反馈：行距偏密） */}
                        <div className="w-full max-w-3xl text-[15px] leading-[1.95] space-y-4 text-foreground [&_li]:my-1.5">
                          {m.text && (m.streaming ? (
                            // 流式期间轻量纯文本渲染（ReactMarkdown 全量解析在每次 delta 时是 O(全文)，卡顿根源之一）；结束后再一次性 markdown
                            <p className="whitespace-pre-wrap text-[15px] leading-[1.95]">{m.text}</p>
                          ) : (
                            <ReactMarkdown
                              remarkPlugins={[remarkGfm]}
                              components={{
                                a: ({ children, ...props }) => <a {...props} target="_blank" rel="noreferrer" className="text-primary underline underline-offset-2" />,
                                code: ({ node, className, children, ...props }) => <code {...props} className={`${className ?? ""} rounded bg-muted px-1 py-0.5 font-mono text-[0.8125em]`}>{children}</code>,
                                pre: ({ children }) => <MarkdownPre className="my-2 overflow-x-auto rounded-lg bg-muted p-3 text-foreground border border-border">{children}</MarkdownPre>,
                                table: ({ children }) => <div className="my-2 overflow-x-auto"><Table className="w-full border-collapse text-left text-[14px]">{children}</Table></div>,
                                th: ({ children }) => <TableHead className="border border-border bg-muted px-3 py-1.5 font-semibold">{children}</TableHead>,
                                td: ({ children }) => <TableCell className="border border-border px-3 py-1.5">{children}</TableCell>,
                              }}
                            >
                              {m.text}
                            </ReactMarkdown>
                          ))}
                          {m.streaming && <StreamingIndicator text={m.text} process={m.process} />}
                        </div>
                      </>
                    )}
                    {/* AI 生成的图表（render_chart → chart_data 事件） */}
                    {m.role === "ai" && (m.charts?.length ?? 0) > 0 && (
                      <div className="mt-2 space-y-2 w-full max-w-3xl">
                        {m.charts?.map((chart, ci) => (
                          <ChartCard key={`${messageId}-chart-${ci}`} chart={chart} />
                        ))}
                      </div>
                    )}
                    {/* 写操作提议：仅由流结束后的 DecisionCard（大卡）统一渲染——
                        流式期间不再闪现小卡片（2026-09-15 修复"先小后大"闪烁：等本回合输出完成，
                        确认卡一次性完整呈现，避免用户在未完成内容上误点确认） */}
                    {/* AI 结构化提问同策略（2026-09-22）：流式期间不渲染可点的问题卡，
                        流结束后由 DecisionCard 内嵌选项区统一呈现 */}
                  </div>
                );
                })}
                {/* 分步向导卡（2026-09-15 职责收敛）：仅存在未答步骤时渲染（答题过程）；
                    全部答完后卸载——唯一确认入口是消息流中的 DecisionCard（AI 操作建议），杜绝双确认 */}
                {(wizardSteps?.some(s => s.status === "pending") ?? false) && (
                  <div className="pt-1">
                    <WizardCard
                      steps={wizardSteps!}
                      streaming={streaming}
                      onAnswer={(qid, answer, field) => wizardAnswer(qid, answer, field)}
                    />
                  </div>
                )}
                {/* 参数表单卡（2026-09-11 schema 驱动）：request_form 到达时渲染，替代逐问向导 */}
                {activeForm && (
                  <div className="pt-1">
                    <FormCard
                      form={activeForm}
                      streaming={streaming}
                      onSubmit={(values, optionsByField) => submitForm(activeForm.toolName, values, optionsByField)}
                      onDismiss={dismissForm}
                    />
                  </div>
                )}
                {/* 文件上传卡（2026-09-15）：request_file 到达时渲染，对话内直传样本 Excel */}
                {activeFileUpload && (
                  <div className="pt-1">
                    <FileUploadCard
                      upload={activeFileUpload}
                      streaming={streaming}
                      onUpload={(file, batchId) => { void uploadSamplesFile(file, batchId) }}
                      onDismiss={dismissFileUpload}
                    />
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              <div className="p-4 shrink-0">
                <ChatComposer
                  inputRef={chatInputRef}
                  value={input}
                  onChange={setInput}
                  onSend={() => handleSend(input)}
                  onStop={stopGeneration}
                  streaming={streaming}
                  placeholder={streaming ? "AI 正在回复中..." : "在此输入您的问题..."}
                  attachments={chatAttachments}
                  onRemoveAttachment={removeChatAttachment}
                  onFilesSelected={addChatFiles}
                />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// 路由入口包装：AIChatProvider 只服务本页面，随页面一起懒加载（见 routes.tsx ai-assistant 路由）
export function AIAssistantRoute() {
  return (
    <AIChatProvider>
      <AIAssistantPage />
    </AIChatProvider>
  );
}
