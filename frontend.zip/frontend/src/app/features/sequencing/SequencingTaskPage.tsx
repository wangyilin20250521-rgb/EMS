import React, { useRef, useState, useCallback } from "react";
import * as XLSX from "xlsx";
import {
  Plus, Search, X, CheckCircle2,
  Save, FileText, Eye, Upload, Download,
} from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card, CardTitle } from "@/app/components/ui/card";
import { TableCard, TableCardHeader, TableCardFooter } from "@/app/components/shared/table-card";

import type { ChipStatus } from "@/app/lib/api";
import { createSequencingTask, getSequencingTasks, exportSequencingTasks, getLabDevices } from "@/app/lib/api";
import type { CreateSequencingTaskPayload, SequencingTask } from "@/app/lib/api";
import { usePagination } from "@/app/hooks/usePagination";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { triggerFileDownload } from "@/app/lib/utils/download";
import { toast } from "sonner";
import { CreateSequencingTaskModal } from "./CreateSequencingTaskModal";
import { SequencingTaskDetailPage } from "./SequencingTaskDetailPage";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";

const STATUS_TABS = ["全部", "待测序", "测序中", "已完成", "异常"] as const;

// ─── Helpers ───────────────────────────────────────────────────────────────

function chipStatusConfig(s: ChipStatus) {
  return {
    "待测序": { color: "text-amber-700", bg: "bg-amber-50", border: "border-amber-200" },
    "测序中": { color: "text-blue-700",   bg: "bg-blue-50",   border: "border-blue-200" },
    "已完成": { color: "text-emerald-700", bg: "bg-emerald-50", border: "border-emerald-200" },
    "异常":   { color: "text-red-700",    bg: "bg-red-50",    border: "border-red-200" },
  }[s];
}

function downloadSequencingTaskTemplate() {
  const headers = ["测序仪ID", "芯片名称", "Lane编号", "样本ID列表"];
  const exampleRows = [
    ["SEQ-001", "芯片 1", "1", "POOL-001,POOL-002"],
    ["SEQ-001", "芯片 1", "2", "POOL-003"],
    ["SEQ-001", "芯片 2", "1", "POOL-004,POOL-005"],
  ];
  const taskSheet = XLSX.utils.aoa_to_sheet([headers, ...exampleRows]);
  taskSheet["!cols"] = [
    { wch: 16 },
    { wch: 16 },
    { wch: 12 },
    { wch: 32 },
  ];

  const instructionSheet = XLSX.utils.aoa_to_sheet([
    ["字段", "填写说明"],
    ["测序仪ID", "必填。填写测序仪唯一 ID，应与系统中的可用测序仪一致。"],
    ["芯片名称", "必填。同一测序仪下相同的芯片名称视为同一块芯片。"],
    ["Lane编号", "必填。填写从 1 开始的 Lane 序号，不能超过所选测序仪的 Lane 数。"],
    ["样本ID列表", "必填。填写样本池 ID，多个样本使用英文逗号分隔；同一个样本不能分配到多个 Lane。"],
  ]);
  instructionSheet["!cols"] = [{ wch: 16 }, { wch: 76 }];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, taskSheet, "测序任务导入");
  XLSX.utils.book_append_sheet(workbook, instructionSheet, "填写说明");
  XLSX.writeFile(workbook, "测序任务导入模板.xlsx");
}

interface ImportedLaneRow {
  sequencerId: string;
  chipName: string;
  laneIndex: number;
  sampleIds: string[];
}

async function parseImportedLanes(rows: unknown[][]): Promise<CreateSequencingTaskPayload[]> {
  const [headerRow, ...dataRows] = rows;
  const headers = (headerRow ?? []).map(value => String(value ?? "").trim());
  const expectedHeaders = ["测序仪ID", "芯片名称", "Lane编号", "样本ID列表"];
  if (expectedHeaders.some((header, index) => headers[index] !== header)) {
    throw new Error("模板列名必须为：测序仪ID、芯片名称、Lane编号、样本ID列表");
  }
  const sequencingDevices = (await getLabDevices()).filter(
    device => device.deviceType === "sequencer" || device.type === "测序仪",
  );

  const importedRows: ImportedLaneRow[] = dataRows
    .filter(row => row.some(value => String(value ?? "").trim()))
    .map((row, index) => {
      const rowNumber = index + 2;
      const sequencerId = String(row[0] ?? "").trim();
      const chipName = String(row[1] ?? "").trim();
      const laneIndex = Number(String(row[2] ?? "").trim());
      const sampleIds = String(row[3] ?? "").split(",").map(value => value.trim()).filter(Boolean);
      const sequencer = sequencingDevices.find(device => device.id === sequencerId);

      if (!sequencer) {
        const availableSequencerIds = sequencingDevices.map(device => device.id).join("、");
        throw new Error(`第 ${rowNumber} 行未找到测序仪：${sequencerId}。设备目录中的测序仪：${availableSequencerIds || "无"}`);
      }
      if (!chipName || !Number.isInteger(laneIndex) || laneIndex < 1) {
        throw new Error(`第 ${rowNumber} 行的芯片名称或 Lane 编号无效`);
      }
      if (sampleIds.length === 0) throw new Error(`第 ${rowNumber} 行至少需要一个样本 ID`);
      return { sequencerId, chipName, laneIndex, sampleIds };
    });

  if (importedRows.length === 0) throw new Error("模板中没有可导入的数据");
  const assignedSampleIds = new Set<string>();
  const assignedLanes = new Set<string>();
  for (const row of importedRows) {
    const laneKey = `${row.sequencerId}|${row.chipName}|${row.laneIndex}`;
    if (assignedLanes.has(laneKey)) throw new Error(`Lane 重复：${row.chipName} - Lane ${row.laneIndex}`);
    assignedLanes.add(laneKey);
    for (const sampleId of row.sampleIds) {
      if (assignedSampleIds.has(sampleId)) throw new Error(`样本不能重复分配：${sampleId}`);
      assignedSampleIds.add(sampleId);
    }
  }

  const rowsBySequencer = new Map<string, ImportedLaneRow[]>();
  for (const row of importedRows) {
    const rows = rowsBySequencer.get(row.sequencerId) ?? [];
    rows.push(row);
    rowsBySequencer.set(row.sequencerId, rows);
  }

  return Array.from(rowsBySequencer, ([sequencerId, lanes]) => {
    const rowsByChip = new Map<string, ImportedLaneRow[]>();
    for (const lane of lanes) {
      const rows = rowsByChip.get(lane.chipName) ?? [];
      rows.push(lane);
      rowsByChip.set(lane.chipName, rows);
    }
    const chips = Array.from(rowsByChip, ([name, chipLanes]) => ({
      name,
      lanes: Array.from({ length: Math.max(...chipLanes.map(lane => lane.laneIndex)) }, (_, index) => ({
        sampleIds: chipLanes.find(lane => lane.laneIndex === index + 1)?.sampleIds ?? [],
      })),
    }));
    return { sequencerId, chips };
  });
}

// ─── Chip Card ──────────────────────────────────────────────────────────────

// ─── Import Wizard ────────────────────────────────────────────────────────────

function ImportWizard({ onClose, onImported }: { onClose: () => void; onImported: () => void }) {
  const [importMode, setImportMode] = useState<"file" | "paste">("file");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileSelected, setFileSelected] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [pastedData, setPastedData] = useState("");
  const [previewData, setPreviewData] = useState<CreateSequencingTaskPayload[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [importing, setImporting] = useState(false);
  const [parseLoading, setParseLoading] = useState(false);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      e.target.value = "";
      setSelectedFile(file);
      setFileSelected(true);
      setParseLoading(true);
      try {
        const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        setPreviewData(await parseImportedLanes(XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" }) as unknown[][]));
        setShowPreview(true);
      } catch (error) {
        setShowPreview(false);
        toast.error(error instanceof Error ? error.message : '文件解析失败，请检查文件格式');
      } finally {
        setParseLoading(false);
      }
    }
  };

  const handlePaste = async () => {
    if (!pastedData.trim()) return;
    setParseLoading(true);
    try {
      const rows = pastedData.split(/\r?\n/).map(line => line.split("\t"));
      setPreviewData(await parseImportedLanes(rows));
      setShowPreview(true);
    } catch (error) {
      setShowPreview(false);
      toast.error(error instanceof Error ? error.message : '数据解析失败，请检查格式');
    } finally {
      setParseLoading(false);
    }
  };

  const handleConfirmImport = async () => {
    if (!showPreview || previewData.length === 0) return;
    setImporting(true);
    try {
      await Promise.all(previewData.map(createSequencingTask));
      const importedCount = previewData.length;
      await onImported();
      toast.success(`${importedCount} 个测序任务已导入`);
      onClose();
    } catch {
      toast.error('导入失败，请重试');
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="bg-card rounded-2xl shadow-2xl w-[680px] max-h-[80vh] overflow-hidden flex flex-col">
        <div className="px-6 py-4 border-b border-border flex items-center justify-between shrink-0">
          <h2 className="text-base font-semibold">导入测序任务单</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground cursor-pointer"><X size={16} /></button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* Mode selector */}
          <div className="flex gap-2 bg-muted/40 rounded-lg p-1">
            <button onClick={() => setImportMode("file")}
              className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer ${importMode === "file" ? "bg-card shadow text-primary" : "text-muted-foreground hover:text-foreground"}`}>
              <Upload size={14} className="inline mr-2" />
              上传文件
            </button>
            <button onClick={() => setImportMode("paste")}
              className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer ${importMode === "paste" ? "bg-card shadow text-primary" : "text-muted-foreground hover:text-foreground"}`}>
              <FileText size={14} className="inline mr-2" />
              粘贴数据
            </button>
          </div>

          {/* File upload */}
          {importMode === "file" && (
            <div className="space-y-3">
              <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                <Upload size={32} className="mx-auto mb-3 text-muted-foreground" />
                <p className="text-sm font-medium mb-1">点击上传或拖拽文件到此区域</p>
                <p className="text-xs text-muted-foreground mb-4">支持 Excel (.xlsx, .xls) 或 CSV 格式</p>
                <div className="flex justify-center gap-2">
                  <input ref={fileInputRef} type="file" accept=".xlsx,.xls,.csv" onChange={handleFileSelect} className="hidden" />
                  <Button variant="secondary" size="sm" onClick={() => fileInputRef.current?.click()}>选择文件</Button>
                  <Button variant="outline" size="sm" onClick={downloadSequencingTaskTemplate}><Download size={12} />下载模板</Button>
                </div>
                {fileSelected && (
                  <p className="text-xs text-emerald-600 mt-3 flex items-center justify-center gap-1">
                    <CheckCircle2 size={12} />
                    {parseLoading ? '解析中...' : `文件已选择：${selectedFile?.name ?? ''}`}
                  </p>
                )}
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-700">
                <p className="font-semibold mb-1">📄 文件格式要求</p>
                <ul className="list-disc list-inside space-y-0.5">
                  <li>必须包含列：测序仪ID、芯片名称、Lane编号、样本ID列表</li>
                  <li>同一芯片的每个 Lane 单独占一行，样本 ID 以英文逗号分隔</li>
                  <li>下载模板可查看示例和完整填写说明</li>
                </ul>
              </div>
            </div>
          )}

          {/* Paste data */}
          {importMode === "paste" && (
            <div className="space-y-3">
              <div>
                <label className="text-xs font-medium mb-1 block">粘贴 Excel 数据（包含表头）</label>
                <textarea value={pastedData} onChange={e => setPastedData(e.target.value)}
                  placeholder="从 Excel 复制后粘贴到此处&#10;测序仪ID	芯片名称	Lane编号	样本ID列表&#10;SEQ-001	芯片 1	1	POOL-001,POOL-002"
                  rows={8}
                  className="w-full border border-border rounded-md px-3 py-2 text-xs font-mono resize-none focus:outline-none focus:ring-2 focus:ring-ring" />
              </div>
              <Button variant="secondary" size="sm" onClick={() => { if (pastedData.trim()) handlePaste(); }} className={(!pastedData.trim() || parseLoading) ? "opacity-50 pointer-events-none" : ""}>
                <Eye size={12} />{parseLoading ? '解析中...' : '解析预览'}
              </Button>
            </div>
          )}

          {/* Preview */}
          {showPreview && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold">数据预览</p>
                <span className="text-xs text-muted-foreground">共 {previewData.reduce((count, task) => count + task.chips.length, 0)} 个芯片任务</span>
              </div>
              <Card className="overflow-hidden py-0">
        

                <div className="overflow-x-auto">
                  <Table className="w-full text-sm">
                    <TableHeader className="bg-muted/40 border-b border-border">
                      <TableRow>{["测序仪", "芯片", "Lane 分配", "样本数量"].map(h => (
                        <TableHead key={h} className="text-left px-4 py-2 text-sm font-semibold text-foreground">{h}</TableHead>
                      ))}</TableRow>
                    </TableHeader>
                    <TableBody className="divide-y divide-border">
                      {previewData.flatMap(task => task.chips.map(chip => (
                        <TableRow key={`${task.sequencerId}-${chip.name}`} className="hover:bg-muted/20">
                          <TableCell className="px-4 py-2.5 font-mono text-sm">{task.sequencerId}</TableCell>
                          <TableCell className="px-4 py-2.5 font-mono text-sm">{chip.name}</TableCell>
                          <TableCell className="px-4 py-2.5 text-sm">{chip.lanes.map((lane, index) => `L${index + 1}: ${lane.sampleIds.length}`).join("，")}</TableCell>
                          <TableCell className="px-4 py-2.5 text-center">{chip.lanes.reduce((count, lane) => count + lane.sampleIds.length, 0)}</TableCell>
                        </TableRow>
                      )))}
                    </TableBody>
                  </Table>
                </div>
              </Card>
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-border flex justify-end gap-2 shrink-0">
          <Button variant="ghost" onClick={onClose}>取消</Button>
          <Button variant="default" onClick={handleConfirmImport} className={(!showPreview || importing) ? "opacity-50 pointer-events-none" : ""}>
            <Save size={12} />{importing ? '导入中...' : '确认导入'}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ─── Main Page ───────────────────────────────────────────────────────────────

export function SequencingTaskPage() {
  const [statusFilter, setStatusFilter] = useState("全部");
  const [search, setSearch] = useState("");
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [exporting, setExporting] = useState(false);

  const handleExport = async () => {
    setExporting(true);
    try {
      const res = await exportSequencingTasks(statusFilter !== '全部' ? statusFilter : undefined);
      if (res.success) triggerFileDownload(res.downloadUrl, res.filename || `测序任务_${new Date().toISOString().slice(0, 10)}.xlsx`);
    } catch { toast.error('导出失败，请稍后重试'); } finally {
      setExporting(false);
    }
  };

  const fetchTasks = useCallback(async (params: { page?: number; pageSize?: number; status?: string }) => {
    return getSequencingTasks({ page: params.page, pageSize: params.pageSize, status: params.status });
  }, []);

  const {
    items: chips,
    total,
    page,
    pageSize,
    setPage,
    setPageSize,
    setFilters,
    refresh,
  } = usePagination<SequencingTask, { status: string }>({
    fetcher: fetchTasks,
    initialPageSize: 20,
    initialFilters: { status: "" },
  });

  const handleStatusChange = (status: string) => {
    setStatusFilter(status);
    setFilters({ status: status === "全部" ? "" : status });
  };

  // Client-side search on paginated results
  const filtered = search
    ? chips.filter(c => c.chipNo.includes(search) || c.taskNo.includes(search))
    : chips;

  if (selectedTaskId) {
    return <SequencingTaskDetailPage taskId={selectedTaskId} onBack={() => setSelectedTaskId(null)} />;
  }

  return (
    <div className="px-6 pb-6 pt-2 overflow-y-auto h-full">
      {showImport && <ImportWizard onClose={() => setShowImport(false)} onImported={refresh} />}

      <CreateSequencingTaskModal
        open={showCreate}
        onClose={() => setShowCreate(false)}
        onCreated={() => setShowCreate(false)}
      />

      <div className="flex items-center justify-end mb-4">
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => { if (!exporting) handleExport(); }} className={exporting ? "opacity-50 pointer-events-none" : ""}>{exporting ? "导出中..." : <><Download size={12} />导出</>}</Button>
          <Button variant="outline" onClick={() => setShowImport(true)}><Upload size={12} />导入</Button>
          <Button variant="default" onClick={() => setShowCreate(true)}><Plus size={12} />创建任务</Button>
        </div>
      </div>

      <TableCard>
        <TableCardHeader>
            <CardTitle className="text-base font-semibold whitespace-nowrap shrink-0">测序任务</CardTitle>
            <div className="flex items-center gap-2.5 shrink-0">
              <Select value={statusFilter} onValueChange={(v) => handleStatusChange(v as (typeof STATUS_TABS)[number])}>
                <SelectTrigger size="sm" className="w-auto h-8 px-2.5 text-xs border border-border rounded-md bg-card">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_TABS.map(status => <SelectItem key={status} value={status}>{status}</SelectItem>)}
                </SelectContent>
              </Select>
              <div className="relative">
                <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="搜索任务编号/芯片编号..."
                  className="w-48 pl-8 pr-3 h-8 text-xs border border-border rounded-md bg-card focus:outline-none focus:ring-2 focus:ring-ring" />
              </div>
            </div>
        </TableCardHeader>

        <div className="overflow-x-auto">
          <Table className="w-full text-sm">
            <TableHeader className="bg-muted/40 border-b border-border">
              <TableRow>{["任务编号", "芯片号", "样本数量", "测序状态", "测序开始时间", "测序结束时间", "操作"].map(h => (
                <TableHead key={h} className="text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
              ))}</TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-border">
              {filtered.map(c => {
                const cfg = chipStatusConfig(c.status);
                return (
                  <TableRow key={c.id} onClick={() => setSelectedTaskId(c.id)} className="hover:bg-muted/20 transition-colors cursor-pointer">
                    <TableCell className="px-4 py-3">
                      <span className="font-mono text-xs text-primary font-semibold">{c.taskNo}</span>
                    </TableCell>
                    <TableCell className="px-4 py-3 font-mono text-sm font-medium">{c.chipNo}</TableCell>
                    <TableCell className="px-4 py-3 text-center">
                      <span className="font-semibold">{c.sampleCount}</span>
                    </TableCell>
                    <TableCell className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${cfg.bg} ${cfg.color}`}>{c.status}</span>
                    </TableCell>
                    <TableCell className="px-4 py-3 font-mono text-sm text-muted-foreground">
                      {c.sequenceStartTime ?? "-"}
                    </TableCell>
                    <TableCell className="px-4 py-3 font-mono text-sm text-muted-foreground">
                      {c.sequenceEndTime ?? "-"}
                    </TableCell>
                    <TableCell className="px-4 py-3" onClick={e => e.stopPropagation()}>
                      <Button variant="ghost" size="sm" onClick={() => setSelectedTaskId(c.id)}><Eye size={11} />详情</Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
          <TableCardFooter>
            <PaginationBar page={page} pageSize={pageSize} total={total} onPageChange={setPage} onPageSizeChange={setPageSize} />
          </TableCardFooter>
      </TableCard>
    </div>
  );
}