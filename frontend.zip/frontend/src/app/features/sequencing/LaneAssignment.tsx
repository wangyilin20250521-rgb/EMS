import { useEffect, useState } from 'react'
import { X } from 'lucide-react'
import type { Chip } from "@/app/lib/api"
import { getPoolSamples, type PoolSample } from "@/app/lib/api"

interface LaneAssignmentProps {
  chips: Chip[]
  onChange: (chips: Chip[]) => void
}

export function LaneAssignment({ chips, onChange }: LaneAssignmentProps) {
  const [activeChipIdx, setActiveChipIdx] = useState(0)
  const [activeLaneIdx, setActiveLaneIdx] = useState(0)
  const [poolSamples, setPoolSamples] = useState<PoolSample[]>([])

  useEffect(() => {
    getPoolSamples().then(setPoolSamples)
  }, [])

  if (chips.length === 0) return null

  const activeChip = chips[activeChipIdx] ?? chips[0]
  const activeLane = activeChip?.lanes[activeLaneIdx]

  // Get all assigned sample IDs across all lanes
  const allAssigned = new Set(chips.flatMap(c => c.lanes.flatMap(l => l.sampleIds)))
  const availableSamples = poolSamples.filter(s => !allAssigned.has(s.id))

  const assignSample = (sampleId: string) => {
    if (!activeLane) return
    const updated = chips.map((chip, ci) => {
      if (ci !== activeChipIdx) return chip
      return {
        ...chip,
        lanes: chip.lanes.map((lane, li) => {
          if (li !== activeLaneIdx) return lane
          return { ...lane, sampleIds: [...lane.sampleIds, sampleId] }
        }),
      }
    })
    onChange(updated)
  }

  const removeSample = (sampleId: string) => {
    const updated = chips.map((chip, ci) => {
      if (ci !== activeChipIdx) return chip
      return {
        ...chip,
        lanes: chip.lanes.map((lane, li) => {
          if (li !== activeLaneIdx) return lane
          return { ...lane, sampleIds: lane.sampleIds.filter(id => id !== sampleId) }
        }),
      }
    })
    onChange(updated)
  }

  return (
    <div className="space-y-3">
      <p className="text-sm font-medium text-foreground">样本分配到 Lane</p>

      {/* Chip / Lane tabs */}
      <div className="flex gap-2 flex-wrap">
        {chips.map((chip, ci) => (
          <div key={chip.id} className="flex gap-0.5">
            {chip.lanes.map((lane, li) => (
              <button
                key={`${ci}-${li}`}
                type="button"
                onClick={() => { setActiveChipIdx(ci); setActiveLaneIdx(li) }}
                className={`px-2 py-1 text-xs rounded cursor-pointer transition-colors ${
                  ci === activeChipIdx && li === activeLaneIdx
                    ? 'bg-primary text-white'
                    : 'bg-muted text-muted-foreground hover:bg-muted/80'
                }`}
              >
                {chip.name}-L{li + 1}
                {lane.sampleIds.length > 0 && ` (${lane.sampleIds.length})`}
              </button>
            ))}
          </div>
        ))}
      </div>

      {/* Current lane assignments */}
      {activeLane && (
        <div className="border border-border rounded-md p-3 space-y-2">
          <p className="text-xs font-medium text-muted-foreground">
            {activeChip.name} — Lane {activeLaneIdx + 1}（已分配 {activeLane.sampleIds.length} 样本）
          </p>
          {activeLane.sampleIds.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {activeLane.sampleIds.map(id => {
                const sample = poolSamples.find(s => s.id === id)
                return (
                  <span key={id} className="inline-flex items-center gap-1 px-2 py-0.5 bg-primary/10 text-primary text-xs rounded">
                    {sample?.sampleNo ?? id}
                    <button type="button" onClick={() => removeSample(id)} className="hover:text-destructive cursor-pointer">
                      <X size={10} />
                    </button>
                  </span>
                )
              })}
            </div>
          )}
        </div>
      )}

      {/* Available pool */}
      <div className="space-y-1.5">
        <p className="text-xs text-muted-foreground">可用样本池（点击分配）</p>
        {poolSamples.length === 0 ? (
          <p className="text-xs text-muted-foreground italic">暂无可用样本，请先在样本中心登记样本</p>
        ) : availableSamples.length === 0 ? (
          <p className="text-xs text-muted-foreground italic">所有样本已分配完毕</p>
        ) : (
          <div className="grid grid-cols-2 gap-1.5 max-h-32 overflow-y-auto">
            {availableSamples.map(sample => (
              <button
                key={sample.id}
                type="button"
                onClick={() => assignSample(sample.id)}
                className="text-left px-2 py-1.5 text-xs border border-border rounded hover:bg-muted/50 transition-colors cursor-pointer"
              >
                <span className="font-mono text-primary">{sample.sampleNo}</span>
                <span className="text-muted-foreground ml-1">{sample.patientName}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
