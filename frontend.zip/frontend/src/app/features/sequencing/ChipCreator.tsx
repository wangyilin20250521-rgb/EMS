import { Plus, Trash2 } from 'lucide-react'
import { Button } from "@/app/components/ui/button"
import type { Chip } from "@/app/lib/api"

interface ChipCreatorProps {
  chips: Chip[]
  laneCount: number
  onChange: (chips: Chip[]) => void
  error?: string
}

export function ChipCreator({ chips, laneCount, onChange, error }: ChipCreatorProps) {
  const addChip = () => {
    const newChip: Chip = {
      id: `CHIP-${Date.now()}`,
      name: `芯片 ${chips.length + 1}`,
      sequencerId: '',
      lanes: Array.from({ length: laneCount }, (_, i) => ({ index: i, sampleIds: [] })),
    }
    onChange([...chips, newChip])
  }

  const removeChip = (chipId: string) => {
    onChange(chips.filter(c => c.id !== chipId))
  }

  const renameChip = (chipId: string, name: string) => {
    onChange(chips.map(c => c.id === chipId ? { ...c, name } : c))
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-foreground">芯片配置</p>
        <Button type="button" variant="outline" size="sm" onClick={addChip}>
          <Plus size={12} className="mr-1" />
          添加芯片
        </Button>
      </div>

      {chips.length === 0 && (
        <p className="text-xs text-muted-foreground bg-muted/50 px-3 py-3 rounded text-center">
          请点击"添加芯片"创建芯片，每个芯片包含 {laneCount} 个 Lane
        </p>
      )}

      {chips.map((chip, idx) => (
        <div key={chip.id} className="border border-border rounded-md p-3 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <input
              type="text"
              value={chip.name}
              onChange={(e) => renameChip(chip.id, e.target.value)}
              className="flex-1 text-xs font-medium px-2 py-1 border border-border rounded bg-background focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder={`芯片 ${idx + 1}`}
            />
            <Button type="button" variant="ghost" size="sm" onClick={() => removeChip(chip.id)} className="h-6 w-6 p-0 text-muted-foreground hover:text-destructive">
              <Trash2 size={12} />
            </Button>
          </div>
          <div className="grid gap-1">
            {chip.lanes.map((lane) => (
              <div key={lane.index} className="flex items-center gap-2 text-xs">
                <span className="w-14 text-muted-foreground">Lane {lane.index + 1}</span>
                <div className="flex-1 h-6 bg-muted/50 rounded flex items-center px-2">
                  <span className="text-muted-foreground">
                    {lane.sampleIds.length > 0
                      ? `${lane.sampleIds.length} 个样本已分配`
                      : '未分配样本'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  )
}
