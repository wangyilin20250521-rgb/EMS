import { Label } from "@/app/components/ui/label"
import { SEQUENCERS } from "@/app/lib/constants/tasks"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";

interface SequencerSelectorProps {
  value: string
  onChange: (id: string) => void
  error?: string
}

export function SequencerSelector({ value, onChange, error }: SequencerSelectorProps) {
  const selected = SEQUENCERS.find(s => s.id === value)

  if (SEQUENCERS.length === 0) {
    return (
      <div className="space-y-2">
        <Label>选择测序仪 *</Label>
        <p className="text-xs text-muted-foreground bg-muted/50 px-3 py-3 rounded text-center">暂无可用测序仪</p>
      </div>
    )
  }

  return (
    <div className="space-y-2">
      <Label>选择测序仪 *</Label>
      <Select onValueChange={v => onChange(v)} value={value}>
  <SelectTrigger className="w-full px-3 py-2 text-sm border border-border rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring"><SelectValue placeholder="请选择测序仪" /></SelectTrigger>
  <SelectContent>

        
        {SEQUENCERS.map((seq) => (
          <SelectItem key={seq.id} value={seq.id} disabled={seq.status !== '空闲'}>
            {seq.name}（{seq.model}，{seq.laneCount} Lane）{seq.status !== '空闲' ? ` — ${seq.status}` : ''}
          </SelectItem>
        ))}
      
  </SelectContent>
</Select>
      {error && <p className="text-xs text-destructive">{error}</p>}
      {selected && (
        <div className="text-xs text-muted-foreground bg-muted/50 px-3 py-2 rounded">
          型号：{selected.model} | Lane 数：{selected.laneCount}
        </div>
      )}
    </div>
  )
}
