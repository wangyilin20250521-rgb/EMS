import { useEffect, useState } from "react";
import { ArrowLeft, Cpu, Clock, User, Layers, Download, FileText, ChevronDown } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";

import type { ChipStatus, LaneStatus, SequencingTaskDetail } from "@/app/lib/api";
import { exportSequencingTask, getSequencingTaskDetail } from "@/app/lib/api";
import { triggerFileDownload } from "@/app/lib/utils/download";
import { toast } from "sonner";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";

function chipStatusConfig(s: ChipStatus) {
  return {
    "待测序": { color: "text-amber-700", bg: "bg-amber-50", border: "border-amber-200" },
    "测序中": { color: "text-blue-700", bg: "bg-blue-50", border: "border-blue-200" },
    "已完成": { color: "text-emerald-700", bg: "bg-emerald-50", border: "border-emerald-200" },
    "异常": { color: "text-red-700", bg: "bg-red-50", border: "border-red-200" },
  }[s];
}

function laneStatusColor(s: LaneStatus | ChipStatus) {
  // Omics 换肤（2026-08-27）：与 theme.css --chart-* 同色系
  return {
    "通过": "#25b865",
    "让步接收": "#ff7d00",
    "不合格": "#f53f3f",
    "待测序": "#ff7d00",
    "测序中": "#4ba1fd",
    "已完成": "#25b865",
    "异常": "#f53f3f",
  }[s] ?? "#94A3B8";
}

const STATUS_PROGRESS: Record<ChipStatus, number> = {
  "待测序": 0,
  "测序中": 60,
  "已完成": 100,
  "异常": 45,
};

export function SequencingTaskDetailPage({ taskId, onBack }: { taskId: string; onBack: () => void }) {
  const [task, setTask] = useState<SequencingTaskDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [expandedLane, setExpandedLane] = useState<string | null>(null);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setLoadError("");
    getSequencingTaskDetail(taskId)
      .then(detail => {
        if (!active) return;
        if (!detail) setLoadError("未找到该测序任务");
        else setTask(detail);
      })
      .catch(() => {
        if (active) setLoadError("加载测序任务详情失败");
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => { active = false; };
  }, [taskId]);

  if (loading) {
    return <div className="p-6 text-sm text-muted-foreground">正在加载测序任务详情...</div>;
  }

  if (!task) {
    return (
      <div className="p-6 space-y-3">
        <p className="text-sm text-destructive">{loadError}</p>
        <Button variant="outline" onClick={onBack}><ArrowLeft size={12} />返回列表</Button>
      </div>
    );
  }

  const cfg = chipStatusConfig(task.status);
  const device = task.device ?? "—";
  const progress = STATUS_PROGRESS[task.status];

  const handleExport = async () => {
    setExporting(true);
    try {
      const res = await exportSequencingTask(task.id);
      if (res.success) triggerFileDownload(res.downloadUrl, res.filename || `测序任务_${task.taskNo ?? task.id}.xlsx`);
    } catch { toast.error('导出失败，请稍后重试'); } finally {
      setExporting(false);
    }
  };

  return (
    <div className="p-6 overflow-y-auto h-full space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            title="返回上一页"
            className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer shrink-0"
          >
            <ArrowLeft size={16} />
          </button>
          <div>
            <h1 className="text-xl font-semibold font-mono mb-1">{task.taskNo}</h1>
            <p className="text-sm text-muted-foreground">芯片号: {task.chipNo}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline"><FileText size={12} />报告</Button>
          <Button variant="outline" onClick={() => { if (!exporting) handleExport(); }} className={exporting ? "opacity-50 pointer-events-none" : ""}>{exporting ? "导出中..." : <><Download size={12} />导出数据</>}</Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card className="p-4">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">基本信息</p>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between items-center"><span className="text-muted-foreground">状态</span><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${cfg.bg} ${cfg.color}`}>{task.status}</span></div>
            <div className="flex justify-between items-center"><span className="text-muted-foreground flex items-center gap-1"><Cpu size={11} />关联设备</span><span className="font-medium font-mono text-xs">{device}</span></div>
            <div className="flex justify-between items-center"><span className="text-muted-foreground flex items-center gap-1"><Clock size={11} />创建时间</span><span className="font-medium font-mono text-xs">{task.createdAt}</span></div>
            <div className="flex justify-between items-center"><span className="text-muted-foreground flex items-center gap-1"><User size={11} />创建人</span><span className="font-medium">{task.createdBy}</span></div>
          </div>
        </Card>
        <Card className="p-4">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">进度</p>
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-gray-200 rounded-full h-2 overflow-hidden"><div className="bg-blue-500 h-full transition-all" style={{ width: `${progress}%` }} /></div>
              <span className="text-xs font-semibold text-blue-600 tabular-nums">{progress}%</span>
            </div>
            <div className="text-xs text-muted-foreground space-y-1">
              <p>开始时间: <span className="font-mono">{task.sequenceStartTime ?? "—"}</span></p>
              <p>结束时间: <span className="font-mono">{task.sequenceEndTime ?? "—"}</span></p>
              <p>样本总数: <span className="font-semibold text-foreground">{task.sampleCount}</span></p>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-4">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5"><Layers size={12} />芯片 Lane 分布</p>
        <div className="space-y-4">
          {(task.chipLanes ?? []).map((chip) => (
            <div key={chip.name}>
              <p className="text-xs font-semibold mb-2">{chip.name}</p>
              <div className="grid grid-cols-4 gap-3">
                {chip.lanes.map((lane, laneIndex) => {
                  const laneName = `${chip.name}-L${laneIndex + 1}`;
                  const laneData = task.lanes.find(item => item.lane === laneName);
                  const status = laneData?.status ?? "待测序";
                  return (
                    <div key={laneName} className="flex flex-col items-center">
                      <div className="w-full h-16 rounded-md mb-1.5" style={{ backgroundColor: laneStatusColor(status) }} />
                      <p className="text-[10px] font-medium text-muted-foreground mb-0.5">Lane {laneIndex + 1}</p>
                      <p className="text-xs font-semibold">{lane.sampleIds.length} 样本</p>
                      <p className="text-[10px]" style={{ color: laneStatusColor(status) }}>{status}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-4">
        <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5"><Layers size={12} />Lane 样本明细</p>
        <div className="space-y-2">
          {task.lanes.map((lane) => {
            const isExpanded = expandedLane === lane.lane;
            // 明细以后端 laneSamples 为准；未同步时不伪造数据
            const samples = isExpanded ? (task.laneSamples?.[lane.lane] ?? []) : [];
            return (
              <div key={lane.lane} className="border border-border rounded-lg overflow-hidden">
                <button
                  onClick={() => setExpandedLane(isExpanded ? null : lane.lane)}
                  className="w-full px-3 py-2 bg-muted/40 flex items-center justify-between cursor-pointer hover:bg-muted/60 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: laneStatusColor(lane.status) }} />
                    <span className="text-xs font-semibold">{lane.lane}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium" style={{ backgroundColor: laneStatusColor(lane.status) + "20", color: laneStatusColor(lane.status) }}>{lane.status}</span>
                    <span className="text-[10px] text-muted-foreground">{lane.sampleCount} 样本</span>
                  </div>
                  <ChevronDown size={14} className={`text-muted-foreground transition-transform ${isExpanded ? "rotate-180" : ""}`} />
                </button>
                {isExpanded && (
                  samples.length === 0 ? (
                    <p className="px-3 py-4 text-xs text-muted-foreground text-center border-t border-border">暂无样本</p>
                  ) : (
                    <div className="overflow-x-auto max-h-48 overflow-y-auto border-t border-border">
                      <Table className="w-full text-xs">
                        <TableHeader className="bg-muted sticky top-0">
                          <TableRow>{["样例编号", "患者姓名", "浓度(ng/µL)", "体积(µL)"].map(h => (
                            <TableHead key={h} className="text-left px-3 py-1.5 font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                          ))}</TableRow>
                        </TableHeader>
                        <TableBody className="divide-y divide-border">
                          {samples.map((s) => (
                            <TableRow key={s.sampleNo} className="hover:bg-muted/20">
                              <TableCell className="px-3 py-1.5 font-mono text-primary">{s.sampleNo}</TableCell>
                              <TableCell className="px-3 py-1.5">{s.patientName}</TableCell>
                              <TableCell className="px-3 py-1.5 text-center tabular-nums">{s.concentration}</TableCell>
                              <TableCell className="px-3 py-1.5 text-center tabular-nums">{s.volume}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )
                )}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
