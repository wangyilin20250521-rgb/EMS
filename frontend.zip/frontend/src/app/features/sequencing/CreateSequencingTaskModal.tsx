import { useEffect, useState } from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/app/components/ui/dialog"
import { Button } from "@/app/components/ui/button"
import { SequencerSelector } from "./SequencerSelector"
import { ChipCreator } from "./ChipCreator"
import { LaneAssignment } from "./LaneAssignment"
import { SEQUENCERS } from "@/app/lib/constants/tasks"
import { createSequencingTask } from "@/app/lib/api"
import type { Chip } from "@/app/lib/api"

interface CreateSequencingTaskModalProps {
  open: boolean
  onClose: () => void
  onCreated: () => void
}

export function CreateSequencingTaskModal({ open, onClose, onCreated }: CreateSequencingTaskModalProps) {
  const [sequencerId, setSequencerId] = useState('')
  const [chips, setChips] = useState<Chip[]>([])
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [submitting, setSubmitting] = useState(false)

  const selectedSequencer = SEQUENCERS.find(s => s.id === sequencerId)
  const laneCount = selectedSequencer?.laneCount ?? 4

  // Preselect the first available sequencer so users skip the manual selection step.
  useEffect(() => {
    if (open && !sequencerId) {
      const defaultSequencer = SEQUENCERS.find(s => s.status === '空闲')
      if (defaultSequencer) setSequencerId(defaultSequencer.id)
    }
  }, [open])

  const resetForm = () => {
    setSequencerId('')
    setChips([])
    setErrors({})
  }

  const handleClose = () => {
    resetForm()
    onClose()
  }

  const handleSequencerChange = (id: string) => {
    setSequencerId(id)
    setChips([]) // Reset chips when sequencer changes (lane count may differ)
  }

  const handleSubmit = async () => {
    setErrors({})

    if (!sequencerId) {
      setErrors({ sequencerId: '请选择测序仪' })
      return
    }

    if (chips.length === 0) {
      setErrors({ chips: '至少需要创建一个芯片' })
      return
    }

    // Check that at least one lane has samples
    const hasSamples = chips.some(c => c.lanes.some(l => l.sampleIds.length > 0))
    if (!hasSamples) {
      setErrors({ chips: '请至少为一个 Lane 分配样本' })
      return
    }

    setSubmitting(true)
    const result = await createSequencingTask({ sequencerId, chips })
    setSubmitting(false)

    if (result.success) {
      handleClose()
      onCreated()
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !v && handleClose()}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>创建测序任务</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <SequencerSelector
            value={sequencerId}
            onChange={handleSequencerChange}
            error={errors.sequencerId}
          />

          {sequencerId && (
            <>
              <ChipCreator
                chips={chips}
                laneCount={laneCount}
                onChange={setChips}
                error={errors.chips}
              />

              <LaneAssignment
                chips={chips}
                onChange={setChips}
              />
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>取消</Button>
          <Button onClick={handleSubmit} disabled={submitting}>
            {submitting ? '创建中...' : '确认创建'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
