import { useEffect, useState } from "react";
import { ArrowLeft, CheckCheck, Circle, Save } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { SampleStatusBadge } from "@/app/components/shared/status-badges";

import { getSampleExtraInfo, getSampleTimeline, getSampleSpecimens, updateSample, SOURCE_OPTIONS, SAMPLE_TYPE_OPTIONS, type Sample } from "@/app/lib/api";
import type { SampleExtraInfo as ExtraInfo, SampleTimelineStep } from "@/app/lib/api";
import { toast } from "sonner";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";

const PRIORITY_OPTIONS = ["常规", "紧急", "加急"];
const GENDER_OPTIONS = ["女", "男"];

interface EditForm {
  patient: string;
  gender: string;
  age: string;
  gestWeek: string;
  type: string;
  project: string;
  source: string;
  sampleNo: string;
  priority: string;
  hospital: string;
  department: string;
}

export function SampleEditPage({
  sample,
  onBack,
  onSaved,
}: {
  sample: Sample;
  onBack: () => void;
  onSaved?: () => void;
}) {
  const [extraInfo, setExtraInfo] = useState<ExtraInfo | null>(null);
  const [timeline, setTimeline] = useState<SampleTimelineStep[]>([]);
  const [specimens, setSpecimens] = useState<Array<{ id: string; status: string; task: string; location: string }>>([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const [form, setForm] = useState<EditForm>({
    patient: sample.patient,
    gender: sample.gender || "女", // 空值兜底女（业务以女性用户为主）
    age: String(sample.age),
    gestWeek: sample.gestWeek != null ? String(sample.gestWeek) : "",
    type: sample.type,
    project: sample.project,
    source: (sample as any).source ?? "本院",
    sampleNo: sample.sampleNo ?? "",
    priority: "",
    hospital: "",
    department: "",
  });

  useEffect(() => {
    getSampleExtraInfo(sample.id).then((info) => {
      setExtraInfo(info);
      setForm((prev) => ({
        ...prev,
        priority: info.priority,
        hospital: info.hospital,
        department: info.department,
      }));
    });
    getSampleTimeline(sample.id).then(setTimeline);
    getSampleSpecimens(sample.id).then((res) => {
      if ("data" in res && res.data) {
        setSpecimens(res.data.map((s) => ({ id: s.id, status: s.status, task: s.task, location: s.location })));
      } else {
        setSpecimens([
          { id: `${sample.id.slice(-3)}-A`, status: "待实验", task: "—", location: "P20260629-A1" },
          { id: `${sample.id.slice(-3)}-B`, status: "已入库", task: "T20260624-001", location: "P20260624-B4" },
          { id: `${sample.id.slice(-3)}-C`, status: "已入库", task: "—", location: "P20260628-H12" },
        ]);
      }
    });
  }, [sample.id]);

  const setField = (key: keyof EditForm, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setSaved(false);
  };

  /** 样例存放位置：用户自行操作物理位置，可手动修改 */
  const setSpecimenLocation = (id: string, location: string) => {
    setSpecimens((prev) => prev.map((sp) => (sp.id === id ? { ...sp, location } : sp)));
    setSaved(false);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateSample(sample.id, {
        patient: form.patient,
        gender: form.gender,
        age: Number(form.age) || sample.age,
        gestWeek: form.gestWeek ? Number(form.gestWeek) : null,
        type: form.type,
        project: form.project,
        source: form.source,
        sampleNo: form.sampleNo || "",
        priority: form.priority || "",
        hospital: form.hospital || "",
        department: form.department || "",
        // 样例存放位置随保存一并提交
        specimens: specimens.map((sp) => ({ id: sp.id, location: sp.location })),
      });
      setSaved(true);
      toast.success("样本信息已保存");
      onSaved?.();
    } catch (e) {
      const m = (e as any)?.message ?? String(e);
      toast.error(`保存失败：${m}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 overflow-y-auto h-full space-y-5">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            title="返回上一页"
            className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer shrink-0"
          >
            <ArrowLeft size={16} />
          </button>
          <div>
            <p className="text-xs text-muted-foreground mb-0.5">样本管理 › 样本中心 › 编辑</p>
            <div className="flex items-center gap-3">
              {/* 内部编号仅系统内部使用，标题展示样本编号（无则兜底内部编号） */}
              <h1 className="text-xl font-semibold" style={{ fontFamily: "'DM Mono', monospace" }}>{(sample as any).sampleNo || sample.id}</h1>
              <SampleStatusBadge status={sample.status} />
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={onBack}>取消</Button>
          <Button variant="default" onClick={saving ? undefined : handleSave} className={saving ? "opacity-50 cursor-not-allowed" : ""}>
            <Save size={12} />
            {saving ? "保存中..." : saved ? "已保存" : "保存修改"}
          </Button>
        </div>
      </div>

      {/* Success banner */}
      {saved && (
        <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-lg px-4 py-2.5 text-sm text-emerald-700">
          <CheckCheck size={14} />
          <span>样本信息已成功保存</span>
        </div>
      )}

      {/* Editable info */}
      <Card className="p-5">
        <h3 className="text-sm font-semibold mb-1">基本信息</h3>
        <p className="text-[11px] text-muted-foreground mb-4">修改样本基本信息后点击保存即可生效</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
          {/* 患者姓名（可编辑） */}
          <div>
            <label className="text-muted-foreground text-xs block mb-1">患者姓名</label>
            <input
              value={form.patient}
              onChange={(e) => setField("patient", e.target.value)}
              className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring bg-card"
            />
          </div>

          {/* 性别（入库登记录入，可编辑） */}
          <div>
            <label className="text-muted-foreground text-xs block mb-1">性别</label>
            <Select onValueChange={v => setField("gender", v)} value={form.gender}>
  <SelectTrigger className="w-full border border-border rounded-md px-3 py-1.5 text-sm bg-card"><SelectValue /></SelectTrigger>
  <SelectContent>

              {GENDER_OPTIONS.map((g) => (
                <SelectItem key={g} value={g}>{g}</SelectItem>
              ))}

  </SelectContent>
</Select>
          </div>

          {/* 年龄（可编辑） */}
          <div>
            <label className="text-muted-foreground text-xs block mb-1">年龄</label>
            <input
              type="number"
              value={form.age}
              onChange={(e) => setField("age", e.target.value)}
              className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring bg-card"
            />
          </div>

          {/* 孕周（可编辑） */}
          <div>
            <label className="text-muted-foreground text-xs block mb-1">孕周</label>
            <input
              type="number"
              value={form.gestWeek}
              placeholder="无"
              onChange={(e) => setField("gestWeek", e.target.value)}
              className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring bg-card"
            />
          </div>

          {/* 样本类型（可编辑） */}
          <div>
            <label className="text-muted-foreground text-xs block mb-1">样本类型</label>
            <Select onValueChange={v => setField("type", v)} value={form.type}>
  <SelectTrigger className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring bg-card"><SelectValue /></SelectTrigger>
  <SelectContent>

              {SAMPLE_TYPE_OPTIONS.map((t) => (
                <SelectItem key={t} value={t}>{t}</SelectItem>
              ))}

  </SelectContent>
</Select>
          </div>

          {/* 检测项目（可编辑） */}
          <div>
            <label className="text-muted-foreground text-xs block mb-1">检测项目</label>
            <input
              value={form.project}
              onChange={(e) => setField("project", e.target.value)}
              className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring bg-card"
            />
          </div>

          {/* 来源（可编辑） */}
          <div>
            <label className="text-muted-foreground text-xs block mb-1">来源</label>
            <Select onValueChange={v => setField("source", v)} value={form.source}>
  <SelectTrigger className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring bg-card"><SelectValue /></SelectTrigger>
  <SelectContent>

              {SOURCE_OPTIONS.map((s) => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}

  </SelectContent>
</Select>
          </div>

          {/* 样本编号（可编辑） */}
          <div>
            <label className="text-muted-foreground text-xs block mb-1">样本编号</label>
            <input
              value={form.sampleNo}
              onChange={(e) => setField("sampleNo", e.target.value)}
              placeholder="对外样本编号"
              className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>

          {/* 优先级（可编辑） */}
          <div>
            <label className="text-muted-foreground text-xs block mb-1">优先级</label>
            <Select onValueChange={v => setField("priority", v)} value={form.priority}>
  <SelectTrigger className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring bg-card"><SelectValue /></SelectTrigger>
  <SelectContent>

              {PRIORITY_OPTIONS.map((p) => (
                <SelectItem key={p} value={p}>{p}</SelectItem>
              ))}
            
  </SelectContent>
</Select>
          </div>

          {/* 送检医院（可编辑） */}
          <div>
            <label className="text-muted-foreground text-xs block mb-1">送检医院</label>
            <input
              value={form.hospital}
              onChange={(e) => setField("hospital", e.target.value)}
              className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring bg-card"
            />
          </div>

          {/* 送检科室（可编辑） */}
          <div>
            <label className="text-muted-foreground text-xs block mb-1">送检科室</label>
            <input
              value={form.department}
              onChange={(e) => setField("department", e.target.value)}
              className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
        </div>

        {/* Read-only fields */}
        <div className="mt-5 pt-4 border-t border-border">
          <p className="text-xs font-semibold text-muted-foreground mb-3">只读信息</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3 text-sm">
            <div>
              <span className="text-muted-foreground text-xs">收样时间</span>
              <p className="text-foreground font-medium mt-0.5">{sample.receivedAt}</p>
            </div>
            <div>
              <span className="text-muted-foreground text-xs">收样批次</span>
              <p className="text-foreground font-medium mt-0.5">{sample.batchId}</p>
            </div>
            <div>
              <span className="text-muted-foreground text-xs">TAT截止</span>
              <p className="text-foreground font-medium mt-0.5">{extraInfo?.tatDeadline ?? "—"}</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Status timeline (read-only) */}
      <Card className="p-5 overflow-x-auto">
        <h3 className="text-sm font-semibold mb-4 whitespace-nowrap">状态时间线</h3>
        <div className="flex items-center gap-2 min-w-max">
          {timeline.map((step, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="flex flex-col items-center">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border-2 ${
                  step.done ? "bg-primary border-primary text-white" : "bg-card border-border text-muted-foreground"
                }`}>
                  {step.done ? <CheckCheck size={12} /> : <Circle size={10} />}
                </div>
                <p className={`text-xs mt-1 font-medium ${step.done ? "text-foreground" : "text-muted-foreground"}`}>{step.label}</p>
                <p className="text-[10px] text-muted-foreground">{step.time}</p>
                {step.operator !== "—" && <p className="text-[10px] text-muted-foreground">{step.operator}</p>}
              </div>
              {i < timeline.length - 1 && <div className={`w-12 h-0.5 mb-6 ${step.done ? "bg-primary" : "bg-border"}`} />}
            </div>
          ))}
        </div>
      </Card>

      {/* Specimens（存放位置可编辑：用户自行操作物理位置） */}
      <Card className="overflow-hidden py-0">
        <div className="px-5 py-3 border-b border-border">
          <h3 className="text-sm font-semibold">关联样例</h3>
        </div>
        <div className="overflow-x-auto">
          <Table className="w-full text-sm">
            <TableHeader className="bg-muted/40">
              <TableRow>
                {["样例编号", "状态", "关联实验", "存放位置"].map((h) => (
                  <TableHead key={h} className="text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-border">
              {specimens.map((sp) => (
                <TableRow key={sp.id} className="hover:bg-muted/20">
                  <TableCell className="px-4 py-2.5 font-mono text-sm text-primary">{sp.id}</TableCell>
                  <TableCell className="px-4 py-2.5"><SampleStatusBadge status={sp.status} /></TableCell>
                  <TableCell className="px-4 py-2.5 text-muted-foreground">{sp.task}</TableCell>
                  <TableCell className="px-4 py-2.5">
                    <input
                      className="w-32 px-1.5 py-1 border border-border rounded font-mono text-xs focus:outline-none focus:ring-1 focus:ring-primary bg-card"
                      value={sp.location}
                      placeholder="输入存放位置"
                      onChange={(e) => setSpecimenLocation(sp.id, e.target.value)}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
