import { useEffect, useState } from "react";
import { CheckCircle2, Circle, Lock, X } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { getDictCategories, getDictItems, PROJECT_OPTIONS, SAMPLE_TYPE_OPTIONS, PACKAGE_SUFFIXES, type OmicsSample } from "@/app/lib/api";
import { toast } from "sonner";
import type { ManualEntry, ProductOption, } from "./add-sample-types";
import { CUSTOM_FIELDS } from "./add-sample-types";
import { fieldInput, ReadonlyValue, FieldRow } from "./shared-ui";

/** *受检者保密别名（与种子数据同规则）：受检者 + 4 位字母数字，从样本编号确定性推导——
 * 同一样本每次生成一致；字符集剔除易混淆字符 I/L/O/0/1。
 * 与 backend/scripts/demo-seed/seed-demo.ts 的 pseudoPatient 逐字一致，改一处须同步另一处。
 */
function pseudoPatient(sampleNo: string): string {
  const chars = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"
  let h = 0
  for (const ch of sampleNo) h = (h * 31 + ch.charCodeAt(0)) >>> 0
  let code = ""
  for (let i = 0; i < 4; i++) {
    h = (h * 1103515245 + 12345) >>> 0
    code += chars[h % chars.length]
  }
  return `受检者${code}`
}

export function ManualInputStep({
  batchInfo,
  prefillRequest,
  onPrefillConsumed,
  onDirtyChange,
  onSubmit,
}: {
  batchInfo?: { source?: string; hospital?: string; time?: string; products?: ProductOption[] };
  /** OmicsOne 预填请求（主组件查询成功后传入，追加为预填行） */
  prefillRequest: OmicsSample[] | null;
  onPrefillConsumed: () => void;
  /** 关闭保护：有已录入未入库的内容时上报主组件（true），关闭弹窗时拦截提示 */
  onDirtyChange?: (dirty: boolean) => void;
  onSubmit: (entries: ManualEntry[]) => Promise<void> | void;
}) {
  // 关联批次时自动填充来源/医院/收样日期（来自收样登记），无批次时留空手填
  const emptyRow = () => ({
    sampleNo: "", patient: "", gender: "女", age: "", project: "", sampleType: "", // 性别默认女（产品以生育相关为主，约 90% 女性用户）
    source: batchInfo?.source ?? "", hospital: batchInfo?.hospital ?? "", receiveDate: (batchInfo?.time ?? "").slice(0, 10),
    package: "",
    custom: {} as Record<string, string>,
    locked: false, // OmicsOne 预填行锁定为只读，不允许编辑
  });
  const [rows, setRows] = useState<Array<ReturnType<typeof emptyRow>>>(() => [emptyRow()]);
  // 左栏索引当前选中样本（右栏分块详情编辑对象）
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  // 定制字段（外包员工）：注册表分类中系统已存在的 → 显示；对应字典项作为下拉选项
  const [customCats, setCustomCats] = useState<string[]>([]);
  const [customItems, setCustomItems] = useState<Record<string, Array<{ code: string; name: string }>>>({});

  useEffect(() => {
    getDictCategories().then(all => {
      const cats = CUSTOM_FIELDS.map(f => f.category).filter(c => c in all);
      setCustomCats(cats);
      if (cats.length === 0) return;
      Promise.all(cats.map(c =>
        getDictItems(c).then(items => ({ c, items })).catch(() => ({ c, items: [] as Array<{ code: string; name: string }> }))
      )).then(rows => {
        const map: Record<string, Array<{ code: string; name: string }>> = {};
        for (const r of rows) map[r.c] = r.items.map(it => ({ code: it.code, name: it.name }));
        setCustomItems(map);
      });
    }).catch(() => {});
  }, []);

  // 批次选择变更时：对未填写行刷新来源/医院/收样日期（原批次步骤先选后录，现选择器在录入页顶部，可能后选批次；切回无批次时清空，避免残留上一批次的值）
  useEffect(() => {
    setRows(prev => prev.map(r =>
      r.patient.trim() || r.sampleNo.trim() ? r
        : { ...r, source: batchInfo?.source ?? "", hospital: batchInfo?.hospital ?? "", receiveDate: batchInfo?.time ? batchInfo.time.slice(0, 10) : "" }
    ));
  }, [batchInfo?.source, batchInfo?.hospital, batchInfo?.time]);

  // 样本编号草稿（确认式设计）：输入时仅更新草稿不写 rows —— 左栏不同步、不触发重渲染链（修复输入丢光标）；
  // 失焦（含切换样本/新增/提交）时经 onBlur 确认写入该行
  const [draftNo, setDraftNo] = useState("");
  // 选中行变化时加载该行编号作为草稿
  useEffect(() => {
    const cur = rows[Math.min(selectedIdx, rows.length - 1)];
    setDraftNo(cur?.sampleNo ?? "");
  }, [selectedIdx]); // 依赖有意收窄：仅选中行变化时同步草稿
  // 草稿确认：写入当前选中行（无变化不触发重渲染）
  const commitDraft = () => {
    const idx = Math.min(selectedIdx, rows.length - 1);
    const v = draftNo.trim();
    if (v !== rows[idx]?.sampleNo) updateRow(idx, "sampleNo", v);
  };

  const updateRow = (idx: number, key: keyof ReturnType<typeof emptyRow>, value: string) =>
    setRows(prev => prev.map((r, i) => (i === idx ? { ...r, [key]: value } : r)));
  const updateCustom = (idx: number, cat: string, value: string) =>
    setRows(prev => prev.map((r, i) => (i === idx ? { ...r, custom: { ...r.custom, [cat]: value } } : r)));
  const addRow = () => {
    setRows(prev => [...prev, emptyRow()]);
    setSelectedIdx(rows.length); // 新增行自动选中
  };
  const removeRow = (idx: number) => {
    const newLen = rows.length - 1;
    setRows(prev => prev.filter((_, i) => i !== idx));
    setSelectedIdx(prev => {
      if (prev > idx) return prev - 1;          // 删的行在选中行之前 → 索引前移
      if (prev === idx) return Math.max(0, Math.min(idx, newLen - 1)); // 删的是选中行 → 选相邻（前一行优先）
      return prev;
    });
  };
  // 切换样本：上一个 / 下一个 / 点击索引（始终可编辑，无只读态）
  const selectSample = (idx: number) => {
    setSelectedIdx(idx);
  };

  // OmicsOne 预填请求消费：匹配样本追加为行（与已有编号去重，重复跳过并提示），自动选中新增行并进入编辑态供核对
  useEffect(() => {
    if (!prefillRequest || prefillRequest.length === 0) return;
    const existing = new Set(rows.map(r => r.sampleNo.trim()).filter(Boolean));
    const fresh = prefillRequest.filter(s => {
      const no = (s.sampleNo ?? "").trim();
      return no && !existing.has(no);
    });
    if (fresh.length < prefillRequest.length) {
      toast.warning(`有 ${prefillRequest.length - fresh.length} 个编号已在列表中，已跳过`);
    }
    if (fresh.length > 0) {
      setRows(prev => [...prev, ...fresh.map(s => ({
        sampleNo: s.sampleNo,
        patient: s.patient ?? "",
        gender: s.gender ?? "",
        age: s.age != null ? String(s.age) : "",
        project: s.project ?? "",
        sampleType: s.type ?? "",
        source: s.source ?? batchInfo?.source ?? "",
        hospital: s.hospital ?? batchInfo?.hospital ?? "",
        receiveDate: s.receivedAt?.slice(0, 10) ?? (batchInfo?.time ?? "").slice(0, 10),
        package: "",
        custom: {} as Record<string, string>,
        locked: true, // OmicsOne 预填数据锁定为只读
      }))]);
      setSelectedIdx(rows.length); // 新增行选中（rows 为本次渲染闭包，追加后选中最后一行）
    }
    onPrefillConsumed();
  }, [prefillRequest]); // 依赖有意收窄：仅预填请求变化时消费

  // 关闭保护上报：任一行的样本编号/患者姓名非空，或当前选中行有未确认的编号草稿，即视为"已录入未入库"
  useEffect(() => {
    onDirtyChange?.(rows.some(r => r.sampleNo.trim() || r.patient.trim()) || draftNo.trim() !== "");
  }, [rows, onDirtyChange, draftNo]);

  // 随机填充（测试辅助）：未填写的行自动生成患者信息
  // 患者姓名采用与种子数据一致的保密别名（受检者+4位字母数字，从样本编号确定性推导）——
  // 与 backend/scripts/demo-seed 的 pseudoPatient 同规则；性别按业务分布填「女」
  const fillRandom = () => {
    // 基于当前 rows 闭包计算填充结果（避免 updater 双调用导致随机值/草稿同步问题）
    const selIdx = Math.min(selectedIdx, rows.length - 1);
    const next = rows.map((r, i) => {
      if (r.patient.trim() !== "") return r;
      // 选中行的编号优先用草稿（用户已输入未确认的不被随机覆盖）
      // 编号规则：年份后两位前缀 + S + 8 位随机数字（如 26S12345678）
      const sampleNo = r.sampleNo || (i === selIdx ? draftNo : "")
        || `${String(new Date().getFullYear()).slice(-2)}S${String(Math.floor(Math.random() * 100000000)).padStart(8, "0")}`;
      return {
        ...r,
        patient: pseudoPatient(sampleNo),
        gender: "女", // 业务 90% 女性用户（生育相关），测试填充按此分布
        age: String(Math.floor(Math.random() * 50) + 20),
        sampleNo,
        project: r.project || "NIFTY",
        sampleType: r.sampleType || "血液",
        source: r.source || batchInfo?.source || "本院",
        hospital: r.hospital || batchInfo?.hospital || "",
        receiveDate: r.receiveDate || (batchInfo?.time ?? "").slice(0, 10),
      };
    });
    setRows(next);
    // 选中行本次被填充 → 草稿同步（编号输入框立即显示，无需切换样本）
    const selJustFilled = rows[selIdx] && rows[selIdx]!.patient.trim() === "" && next[selIdx]!.patient.trim() !== "";
    if (selJustFilled) setDraftNo(next[selIdx]!.sampleNo ?? "");
  };

  const handleSubmit = async () => {
    if (submitting) return;
    // 选中行的编号草稿可能尚未经 blur 写入（直接点确认入库），构建 payload 时兜底合并
    const selIdx = Math.min(selectedIdx, rows.length - 1);
    const submitRows = rows.map((r, i) => (i === selIdx ? { ...r, sampleNo: draftNo.trim() } : r));
    const payload: ManualEntry[] = submitRows
      .filter(r => r.patient.trim() !== "" || r.sampleNo.trim() !== "")
      .map(r => ({
        sampleNo: r.sampleNo.trim(),
        patient: r.patient.trim(),
        gender: r.gender,
        age: parseInt(r.age, 10) || 0,
        type: r.sampleType,
        project: r.project,
        source: r.source.trim(),
        hospital: r.hospital.trim(),
        receivedAt: r.receiveDate.trim(),
        package: r.package,
        customFields: Object.fromEntries(Object.entries(r.custom).filter(([, v]) => v && v.trim() !== "")),
        realSampleNo: r.sampleNo.trim(),
      }));
    if (payload.length === 0) { toast.warning("请先填写至少一份样本"); return; }
    const errs: string[] = [];
    for (let i = 0; i < payload.length; i++) {
      const r = payload[i];
      const label = `第 ${i + 1} 份`;
      // 患者姓名 / 年龄按业务逻辑为非必填（仅样本编号/样本类型/检测项目必填）
      if (!r.sampleNo) errs.push(`${label}: 样本编号不能为空`);
      if (!r.type) errs.push(`${label}: 请选择样本类型`);
      if (!r.project) errs.push(`${label}: 请选择检测项目`);
    }
    if (errs.length > 0) {
      toast.error(errs.slice(0, 3).join("；") + (errs.length > 3 ? `…等 ${errs.length} 条` : ""));
      return;
    }
    setSubmitting(true);
    await new Promise((r) => setTimeout(r, 300));
    // 主组件校验（如登记批次未选）失败时也要恢复按钮状态，允许用户更正配置后再次提交
    try {
      await onSubmit(payload);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col">
      {/* 双栏：左样本索引 / 右分块详情（参考 OmicsOne 编号索引 + 详情分块） */}
      <div className="flex flex-1 min-h-0">
        {/* 左栏：样本索引列表 */}
        <div className="w-52 shrink-0 border-r border-border flex flex-col bg-muted/10">
          <div className="flex-1 overflow-y-auto py-2 px-1.5 space-y-0.5">
            {rows.length === 0 ? (
              <p className="text-[11px] text-muted-foreground italic text-center px-2 py-8 leading-relaxed">暂无样本</p>
            ) : (
              rows.map((r, idx) => {
                const filled = r.patient.trim() !== "" || r.sampleNo.trim() !== "";
                const active = idx === selectedIdx;
                return (
                  <div
                    key={idx}
                    onClick={() => selectSample(idx)}
                    className={`group flex items-center gap-1.5 px-2 py-1.5 rounded-md cursor-pointer transition-colors ${
                      active ? "bg-primary/10 border-l-2 border-primary" : "border-l-2 border-transparent hover:bg-muted/60"
                    }`}
                  >
                    <span className={`text-[10px] font-bold w-4 text-center shrink-0 ${active ? "text-primary" : "text-muted-foreground"}`}>{idx + 1}</span>
                    <span className="flex-1 min-w-0">
                      <span className={`block text-sm font-medium truncate ${active ? "text-foreground" : "text-muted-foreground"}`}>
                        {r.sampleNo.trim() || `样本 ${idx + 1}`}
                      </span>
                      <span className="block text-xs text-muted-foreground/70 truncate">
                        {[r.project, r.patient].filter(Boolean).join(" · ") || "未填写"}
                      </span>
                    </span>
                    {r.locked ? (
                      <Lock size={11} className="text-primary/60 shrink-0" aria-label="OmicsOne 预填，只读" />
                    ) : filled ? (
                      <CheckCircle2 size={12} className="text-emerald-500 shrink-0" />
                    ) : (
                      <Circle size={7} className="text-muted-foreground/40 shrink-0" />
                    )}
                    {rows.length > 1 && (
                      <button
                        onClick={(e) => { e.stopPropagation(); removeRow(idx); }}
                        className="p-0.5 text-slate-300 opacity-0 group-hover:opacity-100 hover:text-red-500 transition-opacity cursor-pointer shrink-0"
                        aria-label="移除样本"
                      >
                        <X size={12} />
                      </button>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* 右栏：选中样本分块详情 */}
        <div className="flex-1 overflow-y-auto min-w-0">
          {rows.length === 0 ? (
            <div className="h-full flex items-center justify-center text-xs text-muted-foreground italic px-6">
              暂无样本，点击右上角「新增样本」开始录入
            </div>
          ) : (
            (() => {
              const idx = Math.min(selectedIdx, rows.length - 1);
              const r = rows[idx];
              // 产品套餐选项 = 检测项目联动（{项目}{后缀}，如 NIFTY标准套餐）；当前值不在选项内（批次产品带出套餐）也保留展示，避免显示断层
              const pkgOptions = (() => {
                const base = r.project ? PACKAGE_SUFFIXES.map(s => `${r.project}${s}`) : [];
                return r.package && !base.includes(r.package) ? [r.package, ...base] : base;
              })();
              return (
                <div className="p-4 space-y-4">
                  {/* 顶部：样本标题 + 导航按钮（上一个/下一个/编辑） + 删除 */}
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-sm font-semibold whitespace-nowrap">样本 {idx + 1}</span>
                      {r.sampleNo.trim() && <span className="font-mono text-xs text-primary truncate">{r.sampleNo}</span>}
                      {r.patient.trim() && <span className="text-xs text-muted-foreground truncate">{r.patient}</span>}
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <Button variant="default" size="sm" disabled={idx === 0} onClick={() => selectSample(idx - 1)}>上一个</Button>
                      <Button variant="default" size="sm" disabled={idx === rows.length - 1} onClick={() => selectSample(idx + 1)}>下一个</Button>
                      <Button variant="default" size="sm" onClick={addRow}>新增样本</Button>
                    </div>
                  </div>

                  {/* 块 1：样本信息（含产品套餐，产品 Select 仅批次含产品行时显示） */}
                  <Card className="py-0 gap-0 overflow-hidden">
                    <div className="px-4 pt-3 pb-3.5 border-b border-border">
                      <p className="text-base font-semibold">样本信息</p>
                    </div>
                    <div className="p-4">
                      <div className="grid grid-cols-1 2xl:grid-cols-2 gap-x-8 gap-y-3">
                        <FieldRow label="样本编号" required>
                          {r.locked ? (
                            <ReadonlyValue value={r.sampleNo} mono />
                          ) : (
                            <input
                              className={`${fieldInput} font-mono`}
                              placeholder="管上条码 / 对外编号"
                              value={draftNo}
                              onChange={(ev) => setDraftNo(ev.target.value)}
                              onBlur={commitDraft}
                            />
                          )}
                        </FieldRow>
                        <FieldRow label="样本类型">
                          {r.locked ? (
                            <ReadonlyValue value={r.sampleType} />
                          ) : (
                            <Select onValueChange={v => updateRow(idx, "sampleType", v)} value={r.sampleType}>
                              <SelectTrigger className="flex-1 min-w-0 border border-border rounded px-2.5 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-card"><SelectValue placeholder="请选择" /></SelectTrigger>
                              <SelectContent>
                                {SAMPLE_TYPE_OPTIONS.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                              </SelectContent>
                            </Select>
                          )}
                        </FieldRow>
                        <FieldRow label="检测项目" required>
                          {r.locked ? (
                            <ReadonlyValue value={r.project} />
                          ) : (
                            <Select onValueChange={(v) => {
                              updateRow(idx, "project", v);
                              // 套餐联动：检测项目变更后旧套餐不匹配新项目 → 清空重新选
                              if (r.package && !r.package.startsWith(v)) updateRow(idx, "package", "");
                            }} value={r.project}>
                              <SelectTrigger className="flex-1 min-w-0 border border-border rounded px-2.5 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-card"><SelectValue placeholder="请选择" /></SelectTrigger>
                              <SelectContent>
                                {PROJECT_OPTIONS.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                              </SelectContent>
                            </Select>
                          )}
                        </FieldRow>
                        {batchInfo?.products && batchInfo.products.length > 0 && (
                          <FieldRow label="产品">
                            {r.locked ? (
                              <ReadonlyValue value={r.package} />
                            ) : (
                              <Select onValueChange={(v) => {
                                const p = batchInfo.products![Number(v)];
                                if (p) updateRow(idx, "package", p.package ?? "");
                              }}>
                                <SelectTrigger className="flex-1 min-w-0 border border-border rounded px-2.5 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-card"><SelectValue placeholder="选择产品" /></SelectTrigger>
                                <SelectContent>
                                  {batchInfo.products.map((p, pi) => (
                                    <SelectItem key={pi} value={String(pi)}>
                                      {p.name}{p.package ? ` · ${p.package}` : ""}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            )}
                          </FieldRow>
                        )}
                        <FieldRow label="产品套餐">
                          {r.locked ? (
                            <ReadonlyValue value={r.package} />
                          ) : (
                            <Select onValueChange={v => updateRow(idx, "package", v)} value={r.package}>
                              <SelectTrigger className="flex-1 min-w-0 border border-border rounded px-2.5 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-card">
                                <SelectValue placeholder={r.project ? "请选择套餐" : "请先选择检测项目"} />
                              </SelectTrigger>
                              <SelectContent>
                                {pkgOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                              </SelectContent>
                            </Select>
                          )}
                        </FieldRow>
                      </div>
                    </div>
                  </Card>

                  {/* 块 2：患者信息（定制字段并入本卡，字典分类存在才显示） */}
                  <Card className="py-0 gap-0 overflow-hidden">
                    <div className="px-4 pt-3 pb-3.5 border-b border-border">
                      <p className="text-base font-semibold">患者信息</p>
                    </div>
                    <div className="p-4">
                      <div className="grid grid-cols-1 2xl:grid-cols-2 gap-x-8 gap-y-3">
                        <FieldRow label="患者姓名" required>
                          {r.locked ? (
                            <ReadonlyValue value={r.patient} />
                          ) : (
                            <input
                              className={fieldInput}
                              placeholder="请输入姓名"
                              value={r.patient}
                              onChange={(ev) => updateRow(idx, "patient", ev.target.value)}
                            />
                          )}
                        </FieldRow>
                        <FieldRow label="性别">
                          {r.locked ? (
                            <ReadonlyValue value={r.gender} />
                          ) : (
                            <Select onValueChange={v => updateRow(idx, "gender", v)} value={r.gender}>
                              <SelectTrigger className="flex-1 min-w-0 border border-border rounded px-2.5 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-card"><SelectValue placeholder="请选择" /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="女">女</SelectItem>
                                <SelectItem value="男">男</SelectItem>
                              </SelectContent>
                            </Select>
                          )}
                        </FieldRow>
                        <FieldRow label="年龄">
                          {r.locked ? (
                            <ReadonlyValue value={r.age} />
                          ) : (
                            <input
                              className={fieldInput}
                              placeholder="请输入"
                              value={r.age}
                              onChange={(ev) => updateRow(idx, "age", ev.target.value)}
                            />
                          )}
                        </FieldRow>
                        {customCats.map(cat => (
                          <FieldRow key={cat} label={cat}>
                            {r.locked ? (
                              <ReadonlyValue value={r.custom[cat] ?? ""} />
                            ) : (
                              <Select onValueChange={v => updateCustom(idx, cat, v)} value={r.custom[cat] ?? ""}>
                                <SelectTrigger className="flex-1 min-w-0 border border-border rounded px-2.5 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-card"><SelectValue placeholder="选填" /></SelectTrigger>
                                <SelectContent>
                                  {(customItems[cat] ?? []).map(opt => <SelectItem key={opt.code} value={opt.name}>{opt.name}</SelectItem>)}
                                </SelectContent>
                              </Select>
                            )}
                          </FieldRow>
                        ))}
                      </div>
                    </div>
                  </Card>

                  {/* 块 3：收样信息 */}
                  <Card className="py-0 gap-0 overflow-hidden">
                    <div className="px-4 pt-3 pb-3.5 border-b border-border">
                      <p className="text-base font-semibold">收样信息</p>
                    </div>
                    <div className="p-4">
                      <div className="grid grid-cols-1 2xl:grid-cols-2 gap-x-8 gap-y-3">
                        <FieldRow label="样本来源">
                          {r.locked ? (
                            <ReadonlyValue value={r.source} />
                          ) : (
                            <Select onValueChange={v => updateRow(idx, "source", v)} value={r.source}>
                              <SelectTrigger className="flex-1 min-w-0 border border-border rounded px-2.5 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-card"><SelectValue placeholder={batchInfo?.source ? batchInfo.source : "请选择"} /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="本院">本院</SelectItem>
                                <SelectItem value="外院">外院</SelectItem>
                              </SelectContent>
                            </Select>
                          )}
                        </FieldRow>
                        <FieldRow label="来源医院">
                          {r.locked ? (
                            <ReadonlyValue value={r.hospital} />
                          ) : (
                            <input
                              className={fieldInput}
                              placeholder={batchInfo?.hospital ? batchInfo.hospital : "选填"}
                              value={r.hospital}
                              onChange={(ev) => updateRow(idx, "hospital", ev.target.value)}
                            />
                          )}
                        </FieldRow>
                        <FieldRow label="收样日期">
                          {r.locked ? (
                            <ReadonlyValue value={r.receiveDate} />
                          ) : (
                            <input
                              type="date"
                              className={fieldInput}
                              value={r.receiveDate}
                              onChange={(ev) => updateRow(idx, "receiveDate", ev.target.value)}
                            />
                          )}
                        </FieldRow>
                      </div>
                    </div>
                  </Card>
                </div>
              );
            })()
          )}
        </div>
      </div>

      {/* 底部提交栏：统计 + 确认入库（登记批次已上移到弹窗 header 左上角，常驻不滚动） */}
      <div className="flex items-center justify-end gap-2 px-4 py-2.5 border-t border-border shrink-0">
        <div className="flex items-center gap-2">
          <button onClick={fillRandom} className="text-[11px] text-muted-foreground hover:text-primary border border-border rounded px-2 py-0.5 transition-colors cursor-pointer">随机填充</button>
          <Button variant="default" onClick={handleSubmit}>
            {submitting ? "入库中..." : "确认入库"}
          </Button>
        </div>
      </div>
    </div>
  );
}
// ─── Excel Upload Steps ──────────────────────────────────────────────────────

