import React, { useRef, useState } from "react";
import { Upload, } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { toast } from "sonner";

export function ExcelUploadStep({ downloading, onDownloadTemplate, onSubmit }: {
  downloading: boolean;
  onDownloadTemplate: () => Promise<void>;
  onSubmit: (file: File) => Promise<void>;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    // 2026-08-26 与其它模式统一：选中文件后由底部「确认入库」提交，后端校验有错弹窗提示
    setFile(f);
  };

  const handleConfirm = async () => {
    if (!file) { toast.warning("请先选择要导入的文件"); return; }
    setSubmitting(true);
    try {
      await onSubmit(file);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="px-6 py-5 space-y-4">
      {/* 上传文件大按钮 */}
      <div className="grid grid-cols-1 gap-3">
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          disabled={submitting}
          className="flex flex-col items-center justify-center gap-1.5 h-24 rounded-xl border-2 border-primary bg-primary/5 hover:bg-primary/10 transition-all cursor-pointer disabled:opacity-60"
        >
          {submitting ? (
            <span className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          ) : (
            <Upload size={20} className="text-primary" />
          )}
          <span className="text-sm font-medium text-primary">{submitting ? "导入中..." : "上传文件"}</span>
          {file ? (
            <span className="text-[10px] text-emerald-600 truncate max-w-full px-2">{file.name}（点击更换）</span>
          ) : (
            <span className="text-[10px] text-muted-foreground">支持 .xlsx .xls .csv</span>
          )}
        </button>
      </div>
      <input
        ref={fileRef}
        type="file"
        accept=".xlsx,.xls,.csv"
        className="hidden"
        onChange={handleFile}
      />

      {/* 底部信息栏：左下载模板小字 + 右确认入库（登记批次已上移弹窗 header 左上角） */}
      <div className="flex items-center justify-between gap-2 pt-2 border-t border-border">
        <button
          type="button"
          onClick={onDownloadTemplate}
          disabled={downloading}
          className="text-xs text-primary hover:underline cursor-pointer disabled:opacity-50"
        >
          {downloading ? "模板生成中..." : "下载模板"}
        </button>
        <Button variant="default" onClick={handleConfirm} className={!file || submitting ? "opacity-50 cursor-not-allowed" : ""}>
          {submitting ? "导入中..." : "确认入库"}
        </Button>
      </div>
    </div>
  );
}

// ─── OmicsOne API：按日期范围批量查询医院侧样本，勾选后入库 ────────────────

/** 本地时区 YYYY-MM-DD（勿用 toISOString，UTC 偏移会差一天） */
