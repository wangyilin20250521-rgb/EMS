import React, { useEffect, useState } from "react";
import { ArrowLeft, Activity, CheckCheck, Scissors, Zap } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { SampleStatusBadge } from "@/app/components/shared/status-badges";

import { getSampleExtraInfo, getSampleTimeline, getSampleSpecimens, STATUS_TO_TIMELINE_LABEL, type Sample } from "@/app/lib/api";
import { toast } from "sonner";
import type { SampleExtraInfo as ExtraInfo, SampleTimelineStep } from "@/app/lib/api";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";

export function SampleDetailPage({ sample, onBack, onEdit }: { sample: Sample; onBack: () => void; onEdit?: () => void }) {
  const [extraInfo, setExtraInfo] = useState<ExtraInfo | null>(null);
  const [timeline, setTimeline] = useState<SampleTimelineStep[]>([]);
  const [specimens, setSpecimens] = useState<Array<{ id: string; status: string; task: string; location: string }>>([]);

  useEffect(() => {
    getSampleExtraInfo(sample.id).then(setExtraInfo);
    getSampleTimeline(sample.id).then(setTimeline);
    getSampleSpecimens(sample.id).then(res => {
      if ('data' in res && res.data) {
        setSpecimens(res.data.map(s => ({ id: s.id, status: s.status, task: s.task, location: s.location })));
      } else {
        // 加载失败时不伪造样例数据，显示空表并提示
        setSpecimens([]);
        toast.error("样例信息加载失败，请刷新重试");
      }
    });
  }, [sample.id]);

  // 后端附加信息未返回时不伪造，显示占位符
  const info = extraInfo ?? null;

  return (
    <div className="p-6 overflow-y-auto h-full space-y-5">
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            title="返回上一页"
            className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer shrink-0"
          >
            <ArrowLeft size={16} />
          </button>
          <div>
            <div className="flex items-center gap-3">
              {/* 内部编号仅系统内部使用，标题展示样本编号（无则兜底内部编号） */}
              <h1 className="text-xl font-semibold" style={{ fontFamily: "'DM Mono', monospace" }}>{(sample as any).sampleNo || sample.id}</h1>
              <SampleStatusBadge status={sample.status} />
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={onEdit}>编辑信息</Button>
          {sample.specimens.includes("未分血") && <Button variant="default"><Scissors size={12} />分血</Button>}
        </div>
      </div>

      {/* Basic info */}
      <Card className="p-5">
        <h3 className="text-sm font-semibold mb-4">基本信息</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-3 text-sm">
          {[
            ["患者", `${sample.patient} · ${sample.gender} · ${sample.age}岁${sample.gestWeek ? ` · 孕${sample.gestWeek}周` : ""}`],
            ["样本类型", sample.type],
            ["检测项目", sample.project],
            ["收样时间", sample.receivedAt],
            ["收样批次", sample.batchId],
            ["优先级", info?.priority ?? "—"],
            ["送检医院", info?.hospital ?? "—"],
            ["送检科室", info?.department ?? "—"],
            ["TAT截止", info?.tatDeadline ?? "—"],
          ].map(([k, v]) => (
            <div key={k}>
              <span className="text-muted-foreground text-xs">{k}</span>
              <p className="text-foreground font-medium mt-0.5">{v}</p>
            </div>
          ))}
        </div>
      </Card>

      {/* Status timeline */}
      <Card className="p-5 overflow-x-auto">
        <h3 className="text-sm font-semibold mb-4 whitespace-nowrap">状态时间线</h3>
        <div className="flex items-center gap-0 min-w-max pb-2">
          {(() => {
            const mappedStatus = STATUS_TO_TIMELINE_LABEL[sample.status] || sample.status;
            const activeIdx = timeline.findIndex(s => s.label === mappedStatus);
            return timeline.map((step, i) => {
              const isDone = activeIdx >= 0 ? i < activeIdx : step.done;
              const isActive = activeIdx >= 0 ? i === activeIdx : (step.active || false);
              return (
                <React.Fragment key={i}>
                  <div className="flex flex-col items-center min-w-[80px]">
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold border-2 ${
                      isDone ? "bg-emerald-500 border-emerald-500 text-white" :
                      isActive ? "bg-blue-600 border-blue-600 text-white" :
                      "bg-card border-border text-muted-foreground"
                    }`}>
                      {isDone ? <CheckCheck size={14} /> : isActive ? <Activity size={14} /> : i + 1}
                    </div>
                    <p className={`text-xs mt-1.5 font-medium text-center ${
                      isDone ? "text-emerald-700 dark:text-emerald-400" :
                      isActive ? "text-blue-700 dark:text-blue-400" :
                      "text-muted-foreground"
                    }`}>{step.label}</p>
                    <p className={`text-[10px] text-center ${
                      isDone ? "text-emerald-600 dark:text-emerald-500" :
                      isActive ? "text-blue-600 dark:text-blue-500" :
                      "text-muted-foreground"
                    }`}>{step.time}</p>
                    {step.operator !== "—" && <p className="text-[10px] text-muted-foreground text-center">{step.operator}</p>}
                  </div>
                  {i < timeline.length - 1 && (
                    <div className={`flex-1 min-w-[30px] h-0.5 mx-1 mb-6 ${
                      isDone ? "bg-emerald-500" : "border-t-2 border-dashed border-border"
                    }`} />
                  )}
                </React.Fragment>
              );
            });
          })()}
        </div>
      </Card>

      {/* Specimens */}
      <Card className="overflow-hidden py-0">
        <div className="px-5 py-3 border-b border-border">
          <h3 className="text-sm font-semibold">关联样例</h3>
        </div>
        <div className="overflow-x-auto">
          <Table className="w-full text-sm">
            <TableHeader className="bg-muted/40 sticky top-0 z-10 backdrop-blur-sm">
              <TableRow>
                {["样例编号", "状态", "关联实验", "存放位置"].map(h => (
                  <TableHead key={h} className="text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-border">
              {specimens.map(sp => (
                <TableRow key={sp.id} className="hover:bg-muted/20">
                  <TableCell className="px-4 py-2.5 font-mono text-sm text-primary">{sp.id}</TableCell>
                  <TableCell className="px-4 py-2.5"><SampleStatusBadge status={sp.status} /></TableCell>
                  <TableCell className="px-4 py-2.5 text-muted-foreground">{sp.task}</TableCell>
                  <TableCell className="px-4 py-2.5 font-mono text-sm text-muted-foreground">{sp.location}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="px-5 py-3 border-t border-border bg-blue-50/50">
          <p className="text-xs text-blue-700 flex items-center gap-1.5">
            <Zap size={11} />
            <span>样本状态继承: <strong>{sample.status}</strong> — 规则1: 样例均为正向，取进度最快状态</span>
          </p>
        </div>
      </Card>
    </div>
  );
}
