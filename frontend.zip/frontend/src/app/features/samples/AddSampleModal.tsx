import React, { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router";
import { RefreshCw, ScanLine, XCircle } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Sheet, SheetContent, SheetTitle } from "@/app/components/ui/sheet";
import { addSampleBatch, getReceptionBatches, importSamplesFromExcel, queryOmicsSamplesByCodes, type UnpackRecord, type OmicsSample } from "@/app/lib/api";
import { downloadBlob } from "@/app/lib/utils/download";
import { toast } from "sonner";
import { errMsg, validateOcrItems } from "./add-sample-types";
import type { InputMode, OcrItem, BatchMode, ManualEntry } from "./add-sample-types";
import { BATCH_MODE_KEY } from "./add-sample-types";
import { BatchOcrStep } from "./BatchOcrStep";
import { ManualInputStep } from "./ManualInputStep";
import { ExcelUploadStep } from "./ExcelUploadStep";
import { OmicsQueryStep } from "./OmicsQueryStep";
import { SheetConfirm } from "./SheetConfirm";
import { BatchSelector } from "./BatchSelector";

export function AddSampleModal({
  initialMode,
  onClose,
  onSubmitted,
}: {
  initialMode: InputMode;
  onClose: () => void;
  onSubmitted: (patients: string[]) => void;
}) {
  // 高拍仪扫描 → 批量上传送检单（实时扫描未开放，不再提供二选一）
  const inputMode: "ocr-batch" | "manual-input" | "excel-upload" | "omics-query" =
    initialMode === "ocr" ? "ocr-batch"
    : initialMode === "manual" ? "manual-input"
    : initialMode === "excel" ? "excel-upload"
    : "omics-query";

  // 批次号：收样登记创建的批次列表（可选关联；无批次时直接录入，内部编号 Single 格式）
  const [batches, setBatches] = useState<UnpackRecord[]>([]);
  const [batchId, setBatchId] = useState("");
  // 批次偏好（无批次/登记批次）：记忆在 localStorage，用户选择一次后每次打开沿用
  const [batchMode, setBatchMode] = useState<BatchMode>(() =>
    localStorage.getItem(BATCH_MODE_KEY) === "batch" ? "batch" : "none"
  );
  const handleBatchModeChange = (m: BatchMode) => {
    setBatchMode(m);
    localStorage.setItem(BATCH_MODE_KEY, m);
  };
  // OmicsOne 预填：扫码/输入/粘贴编号 → 立即查询 → prefillRequest 通知手动填写追加行（查一条加一条，无暂存区）
  const [omicsInput, setOmicsInput] = useState("");
  const [omicsQuerying, setOmicsQuerying] = useState(false);
  const omicsInputRef = useRef<HTMLInputElement>(null);
  const [prefillRequest, setPrefillRequest] = useState<OmicsSample[] | null>(null);

  // 统一查询：匹配样本交给手动填写追加预填行；未匹配提示；查询后保持聚焦便于连续扫码
  const queryOmicsCodes = async (codes: string[]) => {
    setOmicsQuerying(true);
    try {
      const data = await queryOmicsSamplesByCodes(codes);
      const found = data.samples;
      // 未匹配编号：前端按 codes 与返回 samples 差集计算（不依赖后端）
      const matchedNos = new Set(found.map(s => s.sampleNo));
      const unmatched = codes.filter(c => !matchedNos.has(c));
      if (found.length > 0) {
        setPrefillRequest(found);
        toast.success(`已从 OmicsOne 预填 ${found.length} 条样本，请核对后入库`);
      }
      if (unmatched.length === 1) {
        toast.warning(`未查询到 ${unmatched[0]} 样本`);
      } else if (unmatched.length > 1) {
        toast.warning(`未查询到 ${unmatched.length} 个编号：${unmatched.slice(0, 5).join("、")}${unmatched.length > 5 ? ` 等 ${unmatched.length} 个` : ""}`);
      }
    } catch (e) {
      toast.error(`OmicsOne 查询失败：${errMsg(e).slice(0, 100)}`);
    } finally {
      setOmicsQuerying(false);
      omicsInputRef.current?.focus(); // 保持聚焦，连续扫码不用反复点输入框
    }
  };
  // 回车确认：当前输入框内容立即查询，无暂存（查询中忽略新回车，避免并发）
  const handleOmicsQuery = () => {
    if (omicsQuerying) return;
    const code = omicsInput.trim();
    if (!code) { toast.warning("请先扫码/输入样本编号"); return; }
    setOmicsInput(""); // 清空输入框，支持连续扫码
    queryOmicsCodes([code]);
  };
  // 扫码枪默认回车后缀：回车即查询确认（输入法组合输入中的回车一律忽略，避免手动输入被误锁）
  const handleOmicsKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      // isComposing 在部分输入法/浏览器下不可靠，keyCode 229 与 composition 状态双保险
      if (e.nativeEvent.isComposing || e.keyCode === 229 || omicsComposing) return;
      e.preventDefault();
      handleOmicsQuery();
    }
  };
  // 粘贴自动切分（空格/逗号/换行）：一次粘贴多条直接批量查询
  const handleOmicsPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const items = e.clipboardData.getData("text").split(/[\s,，、;；]+/).map(s => s.trim()).filter(Boolean);
    if (items.length === 0) return;
    setOmicsInput("");
    queryOmicsCodes(items);
  };

  // 输入法组合输入中标记（onCompositionStart/End 显式跟踪；部分输入法 keydown 的 isComposing 不可靠）
  const [omicsComposing, setOmicsComposing] = useState(false);
  // 登记批次模式下批次必选：未选阻止提交（无批次模式不受限）
  const validateBatch = (): boolean => {
    if (batchMode === "batch" && !batchId) {
      toast.warning("请选择登记批次");
      return false;
    }
    return true;
  };

  useEffect(() => {
    getReceptionBatches()
      .then((list) => setBatches(list))
      .catch(() => setBatches([]));
  }, []);

  const MODE_TITLES: Record<typeof inputMode, string> = {
    "ocr-batch": "高拍仪扫描",
    "manual-input": "添加样本",
    "excel-upload": "导入样本",
    "omics-query": "OmicsOne 查询",
  };

  /**
   * OCR 结果入库（2026-08 解耦）：直接创建样本，内部编号由后端自动分配（Batch/Single 格式），
   * OCR 识别出的样本编号作为对外编号（sample_no）。
   */
  const handleOcrSubmit = async (items: OcrItem[]) => {
    if (!validateBatch()) return;
    const validationErrors = validateOcrItems(items);
    if (validationErrors.length > 0) {
      toast.error(validationErrors.slice(0, 3).join("；"));
      return;
    }

    const payload: Array<{ sampleNo: string; patient: string; gender?: string; age?: number; type?: string; project?: string; source?: string; hospital?: string; receivedAt?: string }> = [];
    const errList: string[] = [];
    // 批次信息兜底：OCR 未识别出来源/医院/收样日期时，用所选批次的值填充（与手动填写/预填一致）
    const batch = batches.find(b => b.id === batchId);
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const f = (k: string, alt?: string) =>
        item.fields.find(x => x.key === k)?.value ?? (alt ? item.fields.find(x => x.key === alt)?.value : "") ?? "";
      const sampleNo = (f("sampleNo") ?? "").trim();
      const patient = (f("patient", "name") ?? "").trim();
      const gender = f("gender");
      const age = parseInt(f("age"), 10) || 0;
      const ocrType = (f("sampleType") ?? "").trim();
      const ocrProject = (f("project") ?? "").trim();
      const ocrSource = (f("source") ?? "").trim();
      const ocrHospital = (f("hospital") ?? "").trim();
      const ocrDate = (f("receiveDate") ?? "").trim();

      if (!sampleNo) { errList.push(`第 ${i + 1} 张: 未识别出样本编号`); continue; }
      // 患者姓名/性别/年龄非必填（入库登记统一校验）；未识别出样本类型时留空（不强行归类）
      payload.push({
        sampleNo, patient, gender, age, type: ocrType, project: ocrProject || "",
        source: ocrSource || batch?.source || undefined,
        hospital: ocrHospital || batch?.hospital || undefined,
        receivedAt: ocrDate || (batch?.time ?? "").slice(0, 10) || undefined,
      });
    }

    const okPatients: string[] = [];
    if (payload.length > 0) {
      try {
        const res = await addSampleBatch(payload, batchMode === "batch" ? batchId : undefined);
        for (let i = 0; i < payload.length; i++) {
          const fail = res.errors?.find(e => e.index === i);
          if (fail) errList.push(`${payload[i].sampleNo}: ${fail.message}`);
          else okPatients.push(payload[i].patient);
        }
      } catch (e) {
        errList.push(errMsg(e).slice(0, 80));
      }
    }
    if (errList.length > 0) toast.error(`${okPatients.length}/${items.length} 份入库成功，失败: ${errList.join("; ")}`)
    else toast.success(`入库成功：${items.length} 份样本`);
    onSubmitted(okPatients);
  };

  /** 手动填写（2026-08 解耦）：直接创建样本，内部编号自动分配，输入编号为对外编号 */
  const handleManualSubmit = async (entries: ManualEntry[]) => {
    if (!validateBatch()) return;
    const payload: Array<{ sampleNo: string; patient: string; gender?: string; age?: number; type?: string; project?: string; package?: string; extFields?: Record<string, string> }> =
      entries.map(e => ({
        sampleNo: e.sampleNo,
        patient: e.patient,
        gender: e.gender,
        age: e.age,
        type: e.type,
        project: e.project,
        package: e.package,
        extFields: e.customFields,
      }));
    const errList: string[] = [];
    const okPatients: string[] = [];
    try {
      const res = await addSampleBatch(payload, batchMode === "batch" ? batchId : undefined);
      for (let i = 0; i < entries.length; i++) {
        const fail = res.errors?.find(e => e.index === i);
        if (fail) errList.push(`第 ${i + 1} 份 ${entries[i].sampleNo}: ${fail.message}`);
        else okPatients.push(entries[i].patient);
      }
    } catch (e) {
      errList.push(errMsg(e).slice(0, 80));
    }
    if (errList.length > 0) toast.error(`${okPatients.length}/${entries.length} 份入库成功，失败: ${errList.join("; ")}`)
    else toast.success(`入库成功：${entries.length} 份样本`);
    onSubmitted(okPatients);
  };

  /** 下载导入模板（顶部信息栏小按钮，2026-08-31 自大按钮上移） */
  const [downloading, setDownloading] = useState(false);
  const handleDownloadTemplate = async () => {
    if (downloading) return;
    setDownloading(true);
    try {
      const { getApiConfig } = await import("@/app/lib/api/config");
      const { getAuthToken } = await import("@/app/lib/api/http");
      const headers: Record<string, string> = {};
      const token = getAuthToken();
      if (token) headers["Authorization"] = `Bearer ${token}`;
      const resp = await fetch(`${getApiConfig().baseUrl}/sample-reception/template?batchId=${encodeURIComponent(batchMode === "batch" ? batchId : "")}`, { headers });
      if (!resp.ok) { const t = await resp.text().catch(() => ""); throw new Error(t || `HTTP ${resp.status}`); }
      downloadBlob(await resp.blob(), `入库登记模板_${batchMode === "batch" ? batchId : "无批次"}.xlsx`);
    } catch (e) {
      toast.error(String(e).slice(0, 120));
    } finally {
      setDownloading(false);
    }
  };

  /** Excel 导入：后端按样本编号匹配批次内样本并写入患者信息 */
  const handleExcelSubmit = async (file: File) => {
    if (!validateBatch()) return;
    try {
      const res = await importSamplesFromExcel(file, "", batchMode === "batch" ? batchId : "");
      if (res.errors.length > 0) {
        toast.error(`导入完成：成功 ${res.imported} 份，失败 ${res.errors.length} 份（${res.errors.slice(0, 3).map(e => `第${e.row}行 ${e.message}`).join("；")}）`);
      } else {
        toast.success(`导入成功：${res.imported} 份样本已入库`);
      }
      onSubmitted([]);
    } catch (e: any) {
      // 校验失败（后端阻止录入）：弹窗逐行展示错误，用户修正后重传
      const rowErrors = e?.details?.data?.errors as Array<{ row: number; message: string }> | undefined;
      if (Array.isArray(rowErrors) && rowErrors.length > 0) {
        const detail = rowErrors.slice(0, 5).map(er => `第 ${er.row} 行：${er.message}`).join("\n");
        toast.error(`导入未通过，共 ${rowErrors.length} 处错误：\n${detail}${rowErrors.length > 5 ? `\n…等 ${rowErrors.length} 处` : ""}`, { duration: 8000 });
      } else {
        toast.error(`导入失败：${errMsg(e).slice(0, 120)}`);
      }
    }
  };

  /** OmicsOne 勾选入库：直接创建样本，内部编号由后端自动分配（字段已由后端适配层规范化） */
  const handleOmicsSubmit = async (samples: OmicsSample[]) => {
    if (!validateBatch()) return;
    const payload: Array<{ sampleNo: string; patient: string; gender?: string; age?: number; type?: string; project?: string; source?: string; hospital?: string; receivedAt?: string; extId?: string }> =
      samples.map(s => ({
        sampleNo: s.sampleNo,
        patient: s.patient,
        gender: s.gender,
        age: Number(s.age) || 0,
        type: s.type,
        project: s.project,
        source: s.source,
        hospital: s.hospital,
        receivedAt: s.receivedAt,
        extId: s.extId,
      }));
    const errList: string[] = [];
    const okPatients: string[] = [];
    try {
      const res = await addSampleBatch(payload, batchMode === "batch" ? batchId : undefined);
      for (let i = 0; i < samples.length; i++) {
        const fail = res.errors?.find(e => e.index === i);
        if (fail) errList.push(`${samples[i].sampleNo}: ${fail.message}`);
        else okPatients.push(samples[i].patient);
      }
    } catch (e) {
      errList.push(errMsg(e).slice(0, 80));
    }
    if (errList.length > 0) toast.error(`${okPatients.length}/${samples.length} 份入库成功，失败: ${errList.join("; ")}`)
    else toast.success(`入库成功：${samples.length} 份样本`);
    onSubmitted(okPatients);
  };

  /** 未开启引导：关闭弹窗并跳转解决方案（OmicsOne 接口配置在各方案的「接口配置」卡） */
  const navigate = useNavigate();
  const handleGoSettings = () => {
    onClose();
    navigate("/solutions");
  };

  // 关闭保护：有已录入未入库的样本时先弹确认（手动填写模式）
  const [dirty, setDirty] = useState(false);
  const handleDirtyChange = useCallback((d: boolean) => setDirty(d), []);
  // 本地确认层（渲染在 SheetContent 内，避免 Radix 外部点击拦截竞态）
  const [confirmState, setConfirmState] = useState<{ resolve: (v: boolean) => void } | null>(null);
  const closingRef = useRef(false); // 防重入：确认框打开期间重复触发关闭请求会被忽略
  const handleRequestClose = async () => {
    if (closingRef.current) return;
    if (dirty) {
      closingRef.current = true;
      const ok = await new Promise<boolean>((resolve) => setConfirmState({ resolve }));
      closingRef.current = false;
      if (!ok) return;
    }
    onClose();
  };

  // 手动填写 → 右侧抽屉式页面（更宽的录入空间，双栏不局促）；其余模式保留居中弹窗
  if (inputMode === "manual-input") {
    return (
      <Sheet open onOpenChange={(open) => { if (!open) handleRequestClose(); }}>
        <SheetContent side="right" showCloseButton={false} className="w-[50vw] sm:max-w-[50vw] p-0 gap-0 bg-card">
          <SheetTitle className="sr-only">添加样本</SheetTitle>
          {/* Header：左上登记批次 / 右上扫码确认 + 关闭 */}
          <div className="flex items-center justify-between gap-3 px-6 py-4 border-b border-border shrink-0">
            <BatchSelector batches={batches} batchMode={batchMode} batchId={batchId} onBatchModeChange={handleBatchModeChange} onBatchChange={setBatchId} />
            <div className="flex items-center gap-2 min-w-0">
              <div className="relative">
                {omicsQuerying ? (
                  <RefreshCw size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground animate-spin" />
                ) : (
                  <ScanLine size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                )}
                <input
                  ref={omicsInputRef}
                  className="w-44 pl-8 pr-3 py-1.5 text-xs font-mono border border-border rounded-md bg-card outline-none focus:ring-1 focus:ring-primary"
                  placeholder="扫码/输入样本编号，回车确认"
                  value={omicsInput}
                  onChange={e => setOmicsInput(e.target.value)}
                  onKeyDown={handleOmicsKeyDown}
                  onPaste={handleOmicsPaste}
                  onCompositionStart={() => setOmicsComposing(true)}
                  onCompositionEnd={() => setOmicsComposing(false)}
                />
              </div>
              <Button variant="ghost" size="icon-sm" onClick={handleRequestClose} aria-label="关闭" className="shrink-0">
                <XCircle size={18} />
              </Button>
            </div>
          </div>
          {/* Body：双栏索引 + 分块详情 + 底部提交栏 */}
          <div className="flex-1 min-h-0 flex flex-col">
            <ManualInputStep batchInfo={batches.find(b => b.id === batchId)} prefillRequest={prefillRequest} onPrefillConsumed={() => setPrefillRequest(null)} onDirtyChange={handleDirtyChange} onSubmit={handleManualSubmit} />
          </div>
          {/* 关闭保护确认层（渲染在 Sheet 内：点击按钮不会触发 Radix 外部 dismiss） */}
          {confirmState && (
            <SheetConfirm
              title="确认关闭"
              message="当前已录入但未入库的样本信息，关闭后将丢失，确定关闭吗？"
              onConfirm={() => { confirmState.resolve(true); setConfirmState(null); }}
              onCancel={() => { confirmState.resolve(false); setConfirmState(null); }}
            />
          )}
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      {/* 720px × 85vh：与收样登记弹窗统一比例，避免 672px × 90vh 的方块感 */}
      <div className="bg-card rounded-2xl shadow-2xl w-full max-w-[720px] flex flex-col max-h-[85vh]">
        {/* Header（顶部信息栏）：导入样本模式左侧集成登记批次 + 右侧下载模板；其余模式显示标题 */}
        <div className="flex items-center justify-between gap-3 px-6 py-4 border-b border-border shrink-0">
          {inputMode === "excel-upload" ? (
            <BatchSelector batches={batches} batchMode={batchMode} batchId={batchId} onBatchModeChange={handleBatchModeChange} onBatchChange={setBatchId} />
          ) : (
            <h2 className="text-base font-semibold shrink-0" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              {MODE_TITLES[inputMode]}
            </h2>
          )}
          <Button variant="ghost" size="icon-sm" onClick={onClose} aria-label="关闭" className="shrink-0">
            <XCircle size={18} />
          </Button>
        </div>

        {/* Body：直达录入页（批次选择在各模式底部提交栏，确认入库按钮左侧） */}
        <div className="flex-1 min-h-0 flex flex-col">
          <div className="flex-1 overflow-y-auto">
            {inputMode === "ocr-batch" && <BatchOcrStep batches={batches} batchMode={batchMode} batchId={batchId} onBatchModeChange={handleBatchModeChange} onBatchChange={setBatchId} onSubmit={handleOcrSubmit} />}
            {inputMode === "excel-upload" && <ExcelUploadStep downloading={downloading} onDownloadTemplate={handleDownloadTemplate} onSubmit={handleExcelSubmit} />}
            {inputMode === "omics-query" && <OmicsQueryStep batches={batches} batchMode={batchMode} batchId={batchId} onBatchModeChange={handleBatchModeChange} onBatchChange={setBatchId} onGoSettings={handleGoSettings} onSubmit={handleOmicsSubmit} />}
          </div>
        </div>
      </div>
    </div>
  );
}
