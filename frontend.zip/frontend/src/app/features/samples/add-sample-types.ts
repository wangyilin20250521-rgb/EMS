import type { UnpackRecord } from "@/app/lib/api";

export type InputMode = "ocr" | "manual" | "excel" | "omics";

export function errMsg(e: unknown): string {
  // 1. details.message — 后端 { code:"-1", message:"..." } 的真实消息
  const d = (e as any)?.details;
  if (d && typeof d === "object" && typeof (d as any).message === "string" && (d as any).message) return String((d as any).message);
  // 2. message — 从 http.ts 提取的 backendMsg（修复后）或 HTTP statusText（兼容旧版）
  const m = (e as any)?.message;
  if (typeof m === "string" && m) return m;
  return String(e);
}


export interface ManualEntry {
  sampleNo: string;
  patient: string;
  gender: string;
  age: number;
  type: string;
  project: string;
  /** 产品套餐（分产品收样同步，随样本落库） */
  package?: string;
  /** 定制字段（外包员工：自定义字典分类驱动，非必填，存 ext_fields JSONB） */
  customFields?: Record<string, string>;
  realSampleNo?: string;
}

/** 批次的分产品收样明细行（用于手动填写逐行选产品，带出套餐） */
export interface ProductOption {
  name: string;
  sampleType?: string;
  count?: number;
  package?: string;
}

/**
 * 定制字段注册表（外包员工）：由自定义字典分类驱动的扩展信息，备注性质、非必填、可删除。
 * 分类存在（管理员已新增）→ 入库登记对应区域多一项（下拉选项来自该字典）；分类不存在 → 隐藏。
 * 新增字段 = 在此注册表加一行 + 管理员在数据字典创建同名分类。
 */
export const CUSTOM_FIELDS: Array<{ category: string }> = [
  { category: "送检科室" },
  { category: "民族" },
];

// ─── OCR Fields & Validation Logic（手填/OCR/导入共用） ──────────────────────────


export interface OcrField { key: string; label: string; value: string; confidence: number; modified?: boolean }
export interface OcrItem  { id: string; confidence: number; needReview: boolean; fields: OcrField[] }

// 入库登记统一校验（手填/OCR/导入同一套）：样本编号必填；患者姓名/性别/年龄非必填（填了年龄须合法）

export const OCR_REQUIRED_FIELDS = [
  { key: "sampleNo", label: "样本编号" },
] as const;

export function getOcrValue(item: OcrItem, key: string, fallbackKey?: string) {
  return (item.fields.find((field) => field.key === key)?.value
    ?? (fallbackKey ? item.fields.find((field) => field.key === fallbackKey)?.value : "")
    ?? "").trim();
}

export function validateOcrItems(items: OcrItem[]) {
  const errors: string[] = [];
  items.forEach((item, index) => {
    const missing = OCR_REQUIRED_FIELDS
      .filter((field) => !getOcrValue(item, field.key))
      .map((field) => field.label);
    // 年龄非必填；填写时须为 1-120 整数
    const ageStr = getOcrValue(item, "age");
    const age = Number(ageStr);
    if (missing.length > 0) errors.push(`第 ${index + 1} 份：${missing.join("、")}不能为空`);
    else if (ageStr && (!Number.isInteger(age) || age < 1 || age > 120)) errors.push(`第 ${index + 1} 份：年龄须为 1-120 的整数`);
  });
  return errors;
}

// ─── Batch Selection：嵌入各录入模式底部提交栏（确认入库按钮左侧） ─────────────
// 二选一切换（仿异常样本登记开关）：选「无批次」不显示下拉，选「登记批次」才出现批次选择；
// 用户偏好（batchMode）记忆在 localStorage，下次打开沿用上次选择。

export const BATCH_MODE_KEY = "mlims-sample-batch-mode";

export type BatchMode = "none" | "batch";


export interface BatchSelectorProps {
  batches: UnpackRecord[];
  batchMode: BatchMode;
  batchId: string;
  onBatchModeChange: (m: BatchMode) => void;
  onBatchChange: (id: string) => void;
}
