
import { AlertTriangle } from "lucide-react";
import { Button } from "@/app/components/ui/button";

export function SheetConfirm({
  title,
  message,
  onConfirm,
  onCancel,
}: {
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] p-4" onClick={onCancel}>
      <div className="bg-card rounded-[12px] shadow-2xl w-[500px] max-w-[calc(100vw-2rem)] h-[206px] flex flex-col overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="flex items-start gap-3 px-6 pt-6 flex-1">
          <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 bg-blue-100">
            <AlertTriangle size={20} className="text-blue-600" />
          </div>
          <div className="flex-1">
            <h3 className="text-base font-semibold text-foreground">{title}</h3>
            <p className="text-sm text-muted-foreground mt-1">{message}</p>
          </div>
        </div>
        <div className="flex justify-end gap-2 px-6 pb-5">
          <Button variant="ghost" onClick={onCancel}>取消</Button>
          <Button variant="default" onClick={onConfirm}>确认</Button>
        </div>
      </div>
    </div>
  );
}

// ─── Main Component ────────────────────────────────────────────────────────────

/** initialMode：由样本中心信息栏 4 个入口按钮指定录入方式，弹窗直达对应录入页面（无批次/方式选择步骤） */
