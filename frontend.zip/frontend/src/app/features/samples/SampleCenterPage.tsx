import React, { useCallback, useEffect, useState } from "react";
import {
  Download,
  Search,
  Filter,
  ChevronRight,
  Package,
  FlaskConical,
  Circle,
  X,
  Camera,
  ClipboardList,
  Upload,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
} from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { TableCard, TableCardHeader, TableCardFooter } from "@/app/components/shared/table-card";
import { SampleStatusBadge } from "@/app/components/shared/status-badges";

import { getSampleSpecimens, getSamples, deleteSample, PROJECT_OPTIONS, SOURCE_OPTIONS, SAMPLE_TYPE_OPTIONS } from "@/app/lib/api";
import type { Sample, SpecimenDetail } from "@/app/lib/api";
import { AddSampleModal } from "./AddSampleModal";
import type { InputMode } from "./add-sample-types";
import { SampleEditPage } from "./SampleEditPage";
import { usePagination } from "@/app/hooks/usePagination";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { downloadBlob } from "@/app/lib/utils/download";
import { toast } from "sonner";
import { useConfirm } from "@/app/components/shared/ConfirmDialog";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { Sheet, SheetContent, SheetTitle } from "@/app/components/ui/sheet";

// ─── Column Sort（模块级组件：避免函数体内定义导致的重挂载） ─────────────────

export type SampleSortKey = "sampleNo" | "receivedAt" | "tat";

/** 可排序列头：点击切换正/反序，激活列显示方向箭头（EMS 主色） */
function SortableHead({
  label,
  sortKey,
  sortBy,
  sortOrder,
  onSort,
}: {
  label: string;
  sortKey: SampleSortKey;
  sortBy: SampleSortKey | undefined;
  sortOrder: "asc" | "desc";
  onSort: (key: SampleSortKey) => void;
}) {
  const active = sortBy === sortKey;
  return (
    <TableHead className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap select-none">
      <button
        className={`inline-flex items-center gap-1 cursor-pointer transition-colors font-semibold text-sm ${active ? "text-primary" : "hover:text-primary"}`}
        onClick={() => onSort(sortKey)}
        title={`按${label}排序`}
      >
        {label}
        {active ? (
          sortOrder === "asc" ? <ArrowUp size={12} /> : <ArrowDown size={12} />
        ) : (
          <ArrowUpDown size={12} className="text-muted-foreground/40" />
        )}
      </button>
    </TableHead>
  );
}

// ─── Advanced Filter ───────────────────────────────────────────────────────────

const ADVANCED_STATUSES = ["已收样", "已分血", "培养中", "培养完成", "待实验", "实验中", "已完成", "异常"];
interface AdvancedFilter {
  statuses: string[];
  types: string[];
  projects: string[];
  source: string;
  receptionDateStart: string;
  receptionDateEnd: string;
}

function AdvancedFilterPanel({
  value,
  onChange,
  onClose,
}: {
  value: AdvancedFilter;
  onChange: (f: AdvancedFilter) => void;
  onClose: () => void;
}) {
  const toggle = (arr: string[], item: string) =>
    arr.includes(item) ? arr.filter((x) => x !== item) : [...arr, item];

  return (
    <div className="bg-card border border-border rounded-card p-4 shadow-card space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-sm font-semibold text-foreground">高级筛选</span>
        <button
          onClick={onClose}
          className="p-1 text-muted-foreground hover:text-foreground rounded hover:bg-muted transition-colors cursor-pointer"
        >
          <X size={14} />
        </button>
      </div>

      {/* 状态多选 */}
      <div>
        <p className="text-xs font-medium text-muted-foreground mb-2">样本状态</p>
        <div className="flex flex-wrap gap-1.5">
          {ADVANCED_STATUSES.map((s) => (
            <button
              key={s}
              onClick={() => onChange({ ...value, statuses: toggle(value.statuses, s) })}
              className={`px-2.5 py-1 rounded-full text-xs transition-colors border ${
                value.statuses.includes(s)
                  ? "bg-primary text-white border-primary"
                  : "bg-card text-muted-foreground border-border hover:border-primary/60"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* 样本类型 */}
      <div>
        <p className="text-xs font-medium text-muted-foreground mb-2">样本类型</p>
        <div className="flex flex-wrap gap-1.5">
          {SAMPLE_TYPE_OPTIONS.map((t) => (
            <button
              key={t}
              onClick={() => onChange({ ...value, types: toggle(value.types, t) })}
              className={`px-2.5 py-1 rounded-full text-xs transition-colors border ${
                value.types.includes(t)
                  ? "bg-primary text-white border-primary"
                  : "bg-card text-muted-foreground border-border hover:border-primary/60"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="text-xs font-medium text-muted-foreground mb-2">检测项目</p>
        <div className="flex flex-wrap gap-1.5">
          {PROJECT_OPTIONS.map((project) => (
            <button
              key={project}
              onClick={() => onChange({ ...value, projects: toggle(value.projects, project) })}
              className={`px-2.5 py-1 rounded-full text-xs transition-colors border ${
                value.projects.includes(project)
                  ? "bg-primary text-white border-primary"
                  : "bg-card text-muted-foreground border-border hover:border-primary/60"
              }`}
            >
              {project}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="text-xs font-medium text-muted-foreground mb-2">来源</p>
        <div className="flex gap-1.5">
          {SOURCE_OPTIONS.map((src) => (
            <button
              key={src}
              onClick={() => onChange({ ...value, source: value.source === src ? "" : src })}
              className={`px-2.5 py-1 rounded-full text-xs transition-colors border ${value.source === src ? "bg-primary text-white border-primary" : "bg-card text-muted-foreground border-border hover:border-primary/60"}`}
            >
              {src}
            </button>
          ))}
        </div>
      </div>

      {/* 收样时间筛选 */}
      <div>
        <p className="text-xs font-medium text-muted-foreground mb-2">收样时间</p>
        <div className="flex items-center gap-2">
          <input
            type="date"
            value={value.receptionDateStart}
            onChange={(e) => onChange({ ...value, receptionDateStart: e.target.value })}
            className="flex-1 border border-border rounded-md px-2.5 py-1.5 text-xs bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
          />
          <span className="text-xs text-muted-foreground">至</span>
          <input
            type="date"
            value={value.receptionDateEnd}
            onChange={(e) => onChange({ ...value, receptionDateEnd: e.target.value })}
            className="flex-1 border border-border rounded-md px-2.5 py-1.5 text-xs bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
      </div>

      {/* 操作 */}
      <div className="flex justify-end gap-2 pt-1 border-t border-border">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => onChange({ statuses: [], types: [], projects: [], source: "", receptionDateStart: "", receptionDateEnd: "" })}
        >
          清空
        </Button>
      </div>
    </div>
  );
}

export function SampleCenterPage() {
  const confirm = useConfirm();
  const [filter, setFilter] = useState("全部");
  const [editId, setEditId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  // 4 个录入方式入口（2026-08-26 与收样登记统一：平铺信息栏左上角，点击直达对应录入弹窗）
  const [inputMode, setInputMode] = useState<InputMode | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [advFilter, setAdvFilter] = useState<AdvancedFilter>({ statuses: [], types: [], projects: [], source: "", receptionDateStart: "", receptionDateEnd: "" });
  const [tatOverdue, setTatOverdue] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [specimenMap, setSpecimenMap] = useState<Record<string, SpecimenDetail[]>>({});
  // 导出勾选（2026-08-24 简化交互：列表行多选 → 直接导出，移除批次弹窗二次选择）
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());


  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  // 表头全选：当前页全选 / 取消全选
  const toggleSelectAll = () => {
    setSelectedIds(prev =>
      displayed.length > 0 && displayed.every((s: Sample) => prev.has(s.id))
        ? new Set([...prev].filter(id => !displayed.some((s: Sample) => s.id === id)))
        : new Set([...prev, ...displayed.map((s: Sample) => s.id)])
    );
  };

  const handleExport = async () => {
    if (selectedIds.size === 0) { toast.error('请先勾选要导出的样本'); return; }
    setExporting(true);
    try {
      const { getApiConfig } = await import("@/app/lib/api/config");
      const { getAuthToken } = await import("@/app/lib/api/http");
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      const token = getAuthToken();
      if (token) headers["Authorization"] = `Bearer ${token}`;
      const resp = await fetch(`${getApiConfig().baseUrl}/samples/export`, {
        method: "POST",
        headers,
        body: JSON.stringify({ ids: [...selectedIds] }),
      });
      if (!resp.ok) throw new Error("导出失败");
      // 使用后端模板约定的文件名（Content-Disposition 的 export_日期.xlsx），与样本信息模板设计一致
      const cd = resp.headers.get("Content-Disposition") || "";
      const match = /filename="?([^";]+)"?/.exec(cd);
      downloadBlob(await resp.blob(), match?.[1] || `export_${new Date().toISOString().slice(0, 10)}.xlsx`);
    } catch { toast.error('导出失败，请稍后重试'); } finally {
      setExporting(false);
    }
  };

  // 列头排序（样本编号/收样日期/TAT，服务端排序）
  const [sortBy, setSortBy] = useState<SampleSortKey | undefined>(undefined);
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const handleSort = (key: SampleSortKey) => {
    // 同列再点：正/反切换；换列：新列升序
    const nextBy = sortBy === key ? sortBy : key;
    const nextOrder = sortBy === key ? (sortOrder === "asc" ? "desc" : "asc") : "asc";
    setSortBy(nextBy);
    setSortOrder(nextOrder);
    setPaginationFilters({ ...paginationFilters, sortBy: nextBy, sortOrder: nextOrder });
  };

  // Pagination data fetching
  const fetchSamples = useCallback(async (params: { page?: number; pageSize?: number; status?: string; search?: string; receivedAfter?: string; receivedBefore?: string; sortBy?: string; sortOrder?: "asc" | "desc" }) => {
    const result = await getSamples({
      page: params.page ?? 1,
      pageSize: params.pageSize,
      status: params.status,
      search: params.search,
      receivedAfter: params.receivedAfter || undefined,
      receivedBefore: params.receivedBefore || undefined,
      sortBy: params.sortBy,
      sortOrder: params.sortOrder,
    });
    if (!result.ok) throw new Error(result.error.message);
    return result.data;
  }, []);

  const {
    items: pagedSamples,
    total,
    page,
    pageSize,
    loading,
    setPage,
    setPageSize,
    refresh,
    setFilters: setPaginationFilters,
    filters: paginationFilters,
  } = usePagination<Sample, { status?: string; search?: string; receivedAfter?: string; receivedBefore?: string; sortBy?: string; sortOrder?: "asc" | "desc" }>({
    fetcher: fetchSamples,
    initialPageSize: 15,
    initialFilters: { status: undefined, search: undefined, receivedAfter: '', receivedBefore: '' },
  });

  const handleSubmitted = () => {
    setInputMode(null);
    refresh();
  };

  // 将状态 Tab 和搜索框同步到 usePagination 筛选条件，触发后端请求
  useEffect(() => {
    setPaginationFilters({
      ...paginationFilters,
      status: (filter !== '全部' && !['需培养', '培养中', '培养完成'].includes(filter)) ? filter : undefined,
      search: search || undefined,
      receivedAfter: advFilter.receptionDateStart || undefined,
      receivedBefore: advFilter.receptionDateEnd || undefined,
    });
  }, [filter, search]); // 依赖有意收窄：仅筛选条件变化时重查

  const hasAdvFilter =
    advFilter.statuses.length > 0 ||
    advFilter.types.length > 0 ||
    advFilter.projects.length > 0 ||
    advFilter.source !== "" ||
    advFilter.receptionDateStart !== "" ||
    advFilter.receptionDateEnd !== "";

  const filters = ["全部", "需培养", "培养中", "培养完成", "待实验", "实验中", "待测序", "实验失败", "实验异常", "已完成", "异常"];

  // 客户端筛选：仅保留后端无法处理的维度（培养状态、高级筛选、TAT超期）
  const displayed = pagedSamples.filter((s: Sample) => {
    if (filter === "需培养" && s.cultureStatus !== "需培养") return false;
    if (filter === "培养中" && s.cultureStatus !== "培养中") return false;
    if (filter === "培养完成" && s.cultureStatus !== "培养完成") return false;
    if (advFilter.statuses.length > 0 && !advFilter.statuses.includes(s.status)) return false;
    if (advFilter.types.length > 0 && !advFilter.types.includes(s.type)) return false;
    if (advFilter.projects.length > 0 && !advFilter.projects.includes(s.project)) return false;
    if (advFilter.source && s.source !== advFilter.source) return false;
    if (tatOverdue && s.tat !== "超期!") return false;
    return true;
  });

  const toggleExpand = (id: string) => {
    setExpanded(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
        // Lazy-load specimens on expand
        if (!specimenMap[id]) {
          getSampleSpecimens(id).then(res => {
            if (res.ok) setSpecimenMap(prev => ({ ...prev, [id]: res.data }));
          });
        }
      }
      return next;
    });
  };

  return (
    <div className="h-full flex overflow-hidden">
      {/* 主列表区 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-6 pb-6 pt-2 h-full flex flex-col space-y-5 overflow-hidden">
          {/* Table */}
          <div className="flex-1 flex flex-col min-h-0">
          <TableCard>
          <TableCardHeader>
              {/* 录入/导出入口（2026-08-31 调整顺序：导入 → 添加 → 高拍仪扫描 → 导出） */}
              <div className="flex items-center gap-2.5 shrink-0">
                <Button variant="default" size="sm" onClick={() => setInputMode("excel")}>
                  <Upload size={12} />导入样本
                </Button>
                <Button variant="default" size="sm" onClick={() => setInputMode("manual")}>
                  <ClipboardList size={12} />添加样本
                </Button>
                {/* 高拍仪暂未接入设备，先禁用（后续设备就绪后放开） */}
                <Button variant="default" size="sm" disabled title="暂无高拍仪设备，暂不可用" onClick={() => setInputMode("ocr")}>
                  <Camera size={12} />高拍仪扫描
                </Button>
                <Button variant="default" size="sm" onClick={handleExport} className={exporting ? "opacity-50 pointer-events-none" : ""}>
                  <Download size={12} />导出{selectedIds.size > 0 ? `（${selectedIds.size}）` : ""}
                </Button>
              </div>
              <div className="flex items-center gap-2.5 shrink-0">
                <Select value={filter} onValueChange={setFilter}>
                  <SelectTrigger size="sm" className="w-auto h-8 px-2.5 text-xs border border-border rounded-md bg-card">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {filters.map(f => (
                      <SelectItem key={f} value={f}>{f}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="relative">
                  <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input
                    className="w-44 h-8 pl-8 pr-3 text-xs border border-border rounded-md bg-card focus:outline-none focus:ring-2 focus:ring-ring"
                    placeholder="搜索样本编号、患者..."
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                  />
                </div>
                <Button variant="outline" size="sm" className="text-xs" onClick={() => setShowAdvanced(v => !v)}>
                  <Filter size={12} />
                  高级筛选
                  {hasAdvFilter && (
                    <span className="ml-1 w-1.5 h-1.5 rounded-full bg-primary" />
                  )}
                </Button>
                <label className="flex items-center gap-1.5 text-xs cursor-pointer shrink-0 select-none">
                  <input type="checkbox" checked={tatOverdue} onChange={e => setTatOverdue(e.target.checked)} className="rounded" />
                  仅显示TAT超期
                </label>
              </div>
          </TableCardHeader>

            <div className="overflow-x-auto flex-1 scrollbar-hide">
              <Table className="w-full text-sm">
                <TableHeader className="bg-muted/40 border-b border-border sticky top-0 z-10 backdrop-blur-sm">
                  <TableRow>
                    {/* 全选勾选框（置于序号左侧，与 Omics 设计一致） */}
                    <TableHead className="w-8 px-3 py-2.5">
                      <input
                        type="checkbox"
                        className="rounded"
                        checked={displayed.length > 0 && displayed.every((s: Sample) => selectedIds.has(s.id))}
                        onChange={toggleSelectAll}
                        title="全选当前页"
                      />
                    </TableHead>
                    {/* 序号列（跨页连续编号） */}
                    <TableHead className="w-10 px-3 py-2.5 text-left text-sm font-semibold text-foreground">序号</TableHead>
                    <TableHead className="w-8 px-3 py-2.5" />
                    {/* 内部编号仅系统内部使用，不向用户展示；样本编号/收样日期/TAT 支持列头排序 */}
                    <SortableHead label="样本编号" sortKey="sampleNo" sortBy={sortBy} sortOrder={sortOrder} onSort={handleSort} />
                    {["来源", "患者", "样本类型", "检测项目", "状态"].map(h => (
                      <TableHead key={h} className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                    ))}
                    <SortableHead label="收样日期" sortKey="receivedAt" sortBy={sortBy} sortOrder={sortOrder} onSort={handleSort} />
                    <SortableHead label="TAT" sortKey="tat" sortBy={sortBy} sortOrder={sortOrder} onSort={handleSort} />
                    <TableHead className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {displayed.map((s, index) => {
                    const isExpanded = expanded.has(s.id);
                    const specimenList = specimenMap[s.id];
                    const specimenCount = parseInt(String(s.specimens), 10) || 0;
                    const showArrow = specimenCount > 0 || (s as any).hasExperiment;

                    return (
                      <React.Fragment key={s.id}>
                        <TableRow
                          className={`transition-colors ${isExpanded ? "bg-blue-50/40" : "hover:bg-muted/20"} ${(s as any).isCultured ? "bg-cyan-50/10" : ""}`}
                        >
                          <TableCell className="px-3 py-2.5" onClick={e => e.stopPropagation()}>
                            <input
                              type="checkbox"
                              className="rounded"
                              checked={selectedIds.has(s.id)}
                              onChange={() => toggleSelect(s.id)}
                              title="勾选导出"
                            />
                          </TableCell>
                          <TableCell className="px-3 py-2.5 text-sm text-muted-foreground">
                            {(page - 1) * pageSize + index + 1}
                          </TableCell>
                          <TableCell className="px-3 py-2.5" onClick={e => e.stopPropagation()}>
                            {showArrow ? (
                              <button
                                onClick={() => toggleExpand(s.id)}
                                className="text-muted-foreground hover:text-foreground transition-colors p-0.5 rounded"
                              >
                                <ChevronRight size={14} className={`transition-transform ${isExpanded ? "rotate-90" : ""}`} />
                              </button>
                            ) : (
                              <div className="w-5" />
                            )}
                          </TableCell>
                          <TableCell className="px-3 py-2.5">
                            {(s as any).sampleNo ? (
                              <span className="font-mono text-sm text-primary cursor-pointer hover:underline" onClick={() => setEditId(s.id)}>{((s as any).sampleNo)}</span>
                            ) : (
                              <span className="text-xs text-muted-foreground/40 italic">待录入</span>
                            )}
                          </TableCell>
                          <TableCell className="px-3 py-2.5">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-sm font-medium ${(s as any).source === "本院" ? "bg-blue-100 text-blue-700" : "bg-slate-100 text-slate-600"}`}>
                              {(s as any).source ?? "本院"}
                            </span>
                          </TableCell>
                          <TableCell className="px-3 py-2.5 font-medium whitespace-nowrap">{s.patient}</TableCell>
                          <TableCell className="px-3 py-2.5 text-muted-foreground whitespace-nowrap">{s.type}</TableCell>
                          <TableCell className="px-3 py-2.5 text-muted-foreground max-w-[120px] truncate">{s.project}</TableCell>
                          <TableCell className="px-3 py-2.5">
                            <div className="flex flex-col gap-1">
                              <SampleStatusBadge status={s.status} />
                              {(s as any).isCultured && (
                                <div className="flex items-center gap-1 text-[10px] text-cyan-700 font-medium">
                                  <span className="animate-pulse">🧫</span>
                                  {(s as any).cultureDueDate ? `预计 ${(s as any).cultureDueDate}` : "需培养"}
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="px-3 py-2.5 text-sm text-muted-foreground whitespace-nowrap">{s.receivedAt}</TableCell>
                          <TableCell className="px-3 py-2.5">
                            <span className={`text-sm font-medium font-mono ${s.tat === "超期!" ? "text-red-600" : s.tat.includes("36") || s.tat.includes("48") ? "text-amber-600" : "text-muted-foreground"}`}>
                              {s.tat}
                            </span>
                          </TableCell>
                          <TableCell className="px-3 py-2.5" onClick={e => e.stopPropagation()}>
                            <div className="flex gap-1">
                              <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70" onClick={() => setEditId(s.id)}>编辑</Button>
                              <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70" onClick={async () => {
                                if (await confirm({ title: '确认删除', message: `确认删除样本 ${(s as any).sampleNo || s.id}？`, variant: 'danger' })) {
                                  deleteSample(s.id).then(() => { toast.success('样本已删除'); refresh(); }).catch(() => toast.error('删除失败'));
                                }
                              }}>删除</Button>
                            </div>
                          </TableCell>
                        </TableRow>

                        {isExpanded && (
                          <TableRow className="border-b border-border bg-slate-50/60">
                            <TableCell colSpan={12} className="px-0 py-0">
                              {specimenList ? (
                                <div className="pl-12 pr-4 py-3">
                                  <Table className="w-full text-xs">
                                    <TableHeader>
                                      <TableRow className="text-muted-foreground">
                                        <TableHead className="w-8" />
                                        <TableHead className="text-left py-1.5 px-3 font-semibold">样例编号</TableHead>
                                        <TableHead className="text-left py-1.5 px-3 font-semibold">状态</TableHead>
                                        <TableHead className="text-left py-1.5 px-3 font-semibold">关联实验</TableHead>
                                        <TableHead className="text-left py-1.5 px-3 font-semibold">存放位置</TableHead>
                                      </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                      {specimenList.map((sp, i) => (
                                        <TableRow key={sp.id} className={`${i < specimenList.length - 1 ? "border-b border-slate-200/50" : ""}`}>
                                          <TableCell className="py-2 px-1">
                                            {sp.type === "sample" ? <Package size={12} className="text-blue-500" /> : <FlaskConical size={12} className="text-amber-500" />}
                                          </TableCell>
                                          <TableCell className="py-2 px-3 font-mono flex items-center gap-1.5">
                                            {sp.type === "sample" ? "📦" : "🧪"}
                                            {sp.id}
                                          </TableCell>
                                          <TableCell className="py-2 px-3"><SampleStatusBadge status={sp.status} /></TableCell>
                                          <TableCell className="py-2 px-3">
                                            {sp.task !== "—"
                                              ? <span className="font-mono">{sp.task}</span>
                                              : <span className="text-muted-foreground">—</span>
                                            }
                                          </TableCell>
                                          <TableCell className="py-2 px-3 text-muted-foreground font-mono">{sp.location}</TableCell>
                                        </TableRow>
                                      ))}
                                    </TableBody>
                                  </Table>
                                </div>
                              ) : (
                                <div className="pl-12 pr-4 py-4 text-xs text-muted-foreground flex items-center gap-2 italic">
                                  <Circle size={10} className="text-muted-foreground/30" />
                                  暂无实验记录，无法展开
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        )}
                      </React.Fragment>
                    );
                  })}
                </TableBody>
                {/* 空行填充 */}
                {displayed.length < pageSize && (
                  <TableBody>
                    {Array.from({ length: pageSize - displayed.length }).map((_, i) => (
                      <TableRow key={`empty-${i}`} className="h-[48px] border-0">
                        <TableCell colSpan={12}>&nbsp;</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                )}
              </Table>
            </div>
            <TableCardFooter>
              {loading && <div className="text-xs text-muted-foreground py-2 text-center">加载中…</div>}
              <PaginationBar
                page={page}
                pageSize={pageSize}
                total={total}
                onPageChange={setPage}
                onPageSizeChange={setPageSize}
              />
            </TableCardFooter>
          </TableCard>
          </div>
        </div>
      </div>

      {inputMode && (
        <AddSampleModal initialMode={inputMode} onClose={() => setInputMode(null)} onSubmitted={handleSubmitted} />
      )}

      {/* 高级筛选：遮罩交互（聚焦面板，点击遮罩区收起；列表不随面板平移） */}
      {showAdvanced && (
        <div className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-4" onClick={() => setShowAdvanced(false)}>
          <div className="w-[520px] max-w-full max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <AdvancedFilterPanel
              value={advFilter}
              onChange={(f) => {
                setAdvFilter(f);
                setPaginationFilters({
                  ...paginationFilters,
                  receivedAfter: f.receptionDateStart,
                  receivedBefore: f.receptionDateEnd,
                });
              }}
              onClose={() => setShowAdvanced(false)}
            />
          </div>
        </div>
      )}

      {/* 编辑样本：右侧抽屉卡片（原为整页替换，2026-08-31 改为抽屉，列表保持可见） */}
      {editId && (() => {
        const sample = pagedSamples.find((s: Sample) => s.id === editId);
        if (!sample) return null;
        return (
          <Sheet open onOpenChange={(open) => { if (!open) setEditId(null); }}>
            <SheetContent side="right" showCloseButton={false} className="w-[50vw] sm:max-w-[50vw] p-0 gap-0 bg-card">
              <SheetTitle className="sr-only">编辑样本</SheetTitle>
              <div className="flex-1 min-h-0 overflow-hidden">
                <SampleEditPage sample={sample} onBack={() => setEditId(null)} onSaved={() => { refresh(); setEditId(null); }} />
              </div>
            </SheetContent>
          </Sheet>
        );
      })()}
    </div>
  );
}
