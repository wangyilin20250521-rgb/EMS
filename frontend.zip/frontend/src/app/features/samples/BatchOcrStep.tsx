import { useRef, useState } from "react";
import { RefreshCw, Trash2, Upload, X, ZoomIn } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { uploadOCRImage, processOCR } from "@/app/lib/api";
import { toast } from "sonner";
import { validateOcrItems, } from "./add-sample-types";
import type { OcrItem, BatchSelectorProps } from "./add-sample-types";
import { BatchSelector } from "./BatchSelector";

export const MAX_BATCH = 20
export const BATCH_PARALLEL = 3


export interface BatchItem {
  key: string
  preview: string
  queueId: string
  status: "uploading" | "recognizing" | "success" | "error"
  /** 识别字段（与手动填写字段集对齐）：编号/患者/性别/年龄/类型/项目 + 来源/医院/收样日期（识别不到留空手填） */
  fields: { sampleNo: string; patient: string; gender: string; age: string; sampleType: string; project: string; source: string; hospital: string; receiveDate: string }
  error?: string
}

export function BatchOcrStep({ batches, batchMode, batchId, onBatchModeChange, onBatchChange, onSubmit }: BatchSelectorProps & { onSubmit: (items: OcrItem[]) => Promise<void> }) {
  const [items, setItems] = useState<BatchItem[]>([]);
  const [zoomImg, setZoomImg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [submitting, setSubmitting] = useState(false);

  const updateItem = (key: string, patch: Partial<BatchItem>) => {
    setItems(cur => cur.map(i => i.key === key ? { ...i, ...patch } : i));
  };

  const handleBatchFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return
    const list = Array.from(files)
    if (list.length > MAX_BATCH) {
      toast.warning(`一次最多上传 ${MAX_BATCH} 张，本次 ${list.length} 张将只处理前 ${MAX_BATCH} 张`)
      list.length = MAX_BATCH
    }
    const queued = list.map(file => {
      const key = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`
      const item: BatchItem = {
        key, preview: URL.createObjectURL(file), queueId: "", status: "uploading",
        fields: { sampleNo: "", patient: "", gender: "女", age: "", sampleType: "", project: "", source: "", hospital: "", receiveDate: "" }, // 性别默认女，识别到性别时覆盖
      }
      setItems(cur => [...cur, item])
      return { file, item }
    })
    for (let i = 0; i < queued.length; i += BATCH_PARALLEL) {
      await Promise.all(queued.slice(i, i + BATCH_PARALLEL).map(async ({ file, item }) => {
        try {
          const up = await uploadOCRImage(file)
          updateItem(item.key, { queueId: up.queueId, status: "recognizing" })
          const pr = await processOCR(up.queueId)
          const fields = { ...item.fields }
          for (const f of pr.fields ?? []) {
            if (f.key in fields) (fields as any)[f.key] = String(f.value ?? "")
          }
          updateItem(item.key, { status: "success", fields })
        } catch (e) {
          updateItem(item.key, { status: "error", error: String(e).slice(0, 80) })
        }
      }))
    }
  };

  const retryItem = async (key: string) => {
    const item = items.find(i => i.key === key)
    if (!item) return
    updateItem(key, { status: "recognizing", error: undefined })
    try {
      const pr = await processOCR(item.queueId)
      const fields = { ...item.fields }
      for (const f of pr.fields ?? []) {
        if (f.key in fields) (fields as any)[f.key] = String(f.value ?? "")
      }
      updateItem(key, { status: "success", fields })
    } catch (e) {
      updateItem(key, { status: "error", error: String(e).slice(0, 80) })
    }
  };

  const handleSubmit = () => {
    const success = items.filter(i => i.status === "success")
    if (success.length === 0) { toast.error("请先上传并识别送检单图片"); return }
    const ocrItems: OcrItem[] = success.map(i => ({
      id: i.key,
      confidence: 0.9,
      needReview: false,
      fields: [
        { key: "sampleNo", label: "样本编号", value: i.fields.sampleNo, confidence: 0.9 },
        { key: "patient", label: "患者姓名", value: i.fields.patient, confidence: 0.9 },
        { key: "gender", label: "性别", value: i.fields.gender, confidence: 0.9 },
        { key: "age", label: "年龄", value: i.fields.age, confidence: 0.9 },
        { key: "sampleType", label: "样本类型", value: i.fields.sampleType, confidence: 0.9 },
        { key: "project", label: "检测项目", value: i.fields.project, confidence: 0.9 },
        { key: "source", label: "样本来源", value: i.fields.source, confidence: 0.9 },
        { key: "hospital", label: "来源医院", value: i.fields.hospital, confidence: 0.9 },
        { key: "receiveDate", label: "收样日期", value: i.fields.receiveDate, confidence: 0.9 },
      ],
    }))
    const errors = validateOcrItems(ocrItems)
    if (errors.length > 0) {
      toast.error(errors.slice(0, 3).join("；") + (errors.length > 3 ? `；另有 ${errors.length - 3} 份需补充` : ""))
      return
    }
    setSubmitting(true)
    onSubmit(ocrItems).finally(() => setSubmitting(false))
  };

  return (
    <div className="px-6 py-4 space-y-4">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*"
        className="hidden"
        onChange={e => { handleBatchFiles(e.target.files); e.target.value = "" }}
      />
      <div className="flex items-center justify-between">
        <Button variant="default" size="sm" onClick={() => fileInputRef.current?.click()}>
          <Upload size={13} />上传送检单图片（可多选）
        </Button>
        <span className="text-[10px] text-muted-foreground">最多 {MAX_BATCH} 张，3 张并行识别</span>
      </div>
      {items.map(item => (
        <div key={item.key} className="flex gap-3 p-3 bg-white rounded-lg border border-border">
          <img src={item.preview} alt="送检单" title="双击放大查看"
            onDoubleClick={() => setZoomImg(item.preview)}
            className="w-16 h-20 object-cover rounded border border-border shrink-0 cursor-zoom-in" />
          <div className="flex-1 min-w-0">
            {item.status === "uploading" && <p className="text-xs text-muted-foreground">上传中...</p>}
            {item.status === "recognizing" && (
              <p className="text-xs text-muted-foreground flex items-center gap-1"><RefreshCw size={11} className="animate-spin" />识别中...</p>
            )}
            {item.status === "error" && (
              <div className="flex items-center gap-2">
                <p className="text-xs text-red-500 truncate">识别失败: {item.error}</p>
                <Button variant="link" size="xs" className="h-auto px-0" onClick={() => retryItem(item.key)}>重试</Button>
              </div>
            )}
            {item.status === "success" && (
              <div className="grid grid-cols-3 gap-x-3 gap-y-1.5">
                {(["sampleNo", "patient", "gender", "age", "sampleType", "project", "source", "hospital", "receiveDate"] as const).map(f => (
                  <label key={f} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                    {({ sampleNo: "编号*", patient: "患者*", gender: "性别*", age: "年龄*", sampleType: "类型", project: "项目", source: "来源", hospital: "医院", receiveDate: "收样日期" } as const)[f]}
                    <input
                      className="flex-1 min-w-0 px-1.5 py-0.5 border border-border rounded text-[11px] outline-none focus:ring-1 focus:ring-primary"
                      value={item.fields[f]}
                      onChange={e => updateItem(item.key, { fields: { ...item.fields, [f]: e.target.value } })}
                    />
                  </label>
                ))}
              </div>
            )}
          </div>
          <button
            onClick={() => { URL.revokeObjectURL(item.preview); setItems(cur => cur.filter(i => i.key !== item.key)) }}
            className="text-slate-300 hover:text-red-500 self-start p-1"
            aria-label="移除"
          >
            <Trash2 size={14} />
          </button>
        </div>
      ))}
      {items.length === 0 && (
        <p className="text-[10px] text-muted-foreground italic">尚未上传送检单图片</p>
      )}

      <div className="flex items-center justify-between gap-2 pt-2 border-t border-border">
        <BatchSelector batches={batches} batchMode={batchMode} batchId={batchId} onBatchModeChange={onBatchModeChange} onBatchChange={onBatchChange} />
        <Button variant="default" onClick={handleSubmit} className={submitting || items.filter(i => i.status === "success").length === 0 ? "opacity-50 cursor-not-allowed" : ""}>
          {submitting ? "入库中..." : "确认入库"}
        </Button>
      </div>

      {zoomImg && (
        <div className="fixed inset-0 z-[70] bg-black/80 flex items-center justify-center p-8" onClick={() => setZoomImg(null)}>
          <img src={zoomImg} alt="送检单放大" className="max-w-full max-h-full object-contain rounded-lg shadow-2xl" />
          <button onClick={() => setZoomImg(null)} className="absolute top-5 right-5 text-white/80 hover:text-white p-2 rounded-full bg-black/40 hover:bg-black/60 transition-colors" aria-label="关闭放大预览">
            <X size={22} />
          </button>
          <span className="absolute bottom-5 left-1/2 -translate-x-1/2 text-white/60 text-xs flex items-center gap-1">
            <ZoomIn size={12} /> 点击任意处退出
          </span>
        </div>
      )}
    </div>
  );
}

// ─── OmicsOne Smart Prefill（收集/查询逻辑在主组件，扫码框在 header 最右侧，默认开启）───
// 扫码/输入/粘贴收集编号 → 统一查询后经 prefillRequest 通知 ManualInputStep 追加行。
// 系统未配置/接口不可用时查询报错（后端错误透出），不影响手动兜底。

// ─── Manual Entry：+ 新增样本卡片式录入（2026-08 解耦：直接创建，内部编号自动分配）───
// 注意：FieldLabel/ReadonlyValue/FieldRow 必须定义在组件外（模块级）——
// 函数体内定义组件会导致每次渲染生成新函数引用，React 判定组件类型变化
// 而卸载/重挂载整个字段子树，输入框光标会随每次敲键丢失。

