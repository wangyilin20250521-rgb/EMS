import { useEffect, useState } from "react";
import { AlertTriangle, RefreshCw, Search, Settings } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { getOmicsConfig, queryOmicsSamples, type OmicsSample } from "@/app/lib/api";
import { toast } from "sonner";
import { errMsg } from "./add-sample-types";
import type { BatchSelectorProps } from "./add-sample-types";
import { BatchSelector } from "./BatchSelector";

function fmtDate(d: Date): string {
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}


export function OmicsQueryStep({
  batches,
  batchMode,
  batchId,
  onBatchModeChange,
  onBatchChange,
  onGoSettings,
  onSubmit,
}: BatchSelectorProps & {
  onGoSettings: () => void;
  onSubmit: (samples: OmicsSample[]) => Promise<void> | void;
}) {
  // 进步骤先检查配置：未开启/读取失败 → 引导去解决方案（对应方案的接口配置卡；后端路由也会再守卫一道）
  const [cfgState, setCfgState] = useState<"loading" | "disabled" | "ready">("loading");
  const [dateFrom, setDateFrom] = useState(() => fmtDate(new Date(Date.now() - 7 * 86400000)));
  const [dateTo, setDateTo] = useState(() => fmtDate(new Date()));
  const [querying, setQuerying] = useState(false);
  const [samples, setSamples] = useState<OmicsSample[]>([]);
  const [selected, setSelected] = useState<Set<number>>(new Set()); // 按行 index 记录
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    getOmicsConfig()
      .then((cfg) => setCfgState(cfg.enabled ? "ready" : "disabled"))
      .catch(() => {
        setCfgState("disabled");
        toast.error("读取 OmicsOne 配置失败");
      });
  }, []);

  const handleQuery = async () => {
    if (dateFrom > dateTo) { toast.error("开始日期不能晚于结束日期"); return; }
    setQuerying(true);
    try {
      const res = await queryOmicsSamples(dateFrom, dateTo);
      setSamples(res.samples);
      setSelected(new Set());
    } catch (e) {
      toast.error(errMsg(e).slice(0, 120));
    } finally {
      setQuerying(false);
    }
  };

  const toggleSelect = (idx: number) => {
    setSelected(prev => {
      const next = new Set(prev);
      next.has(idx) ? next.delete(idx) : next.add(idx);
      return next;
    });
  };

  const toggleSelectAll = () => {
    setSelected(prev => (prev.size === samples.length && samples.length > 0 ? new Set() : new Set(samples.map((_, i) => i))));
  };

  const handleSubmit = async () => {
    const picked = samples.filter((_, i) => selected.has(i));
    if (picked.length === 0) { toast.warning("请至少勾选一份样本"); return; }
    // 患者姓名非必填（入库登记统一校验），勾选即可入库
    setSubmitting(true);
    // 主组件校验（如登记批次未选）失败时也要恢复按钮状态，允许用户更正配置后再次提交
    try {
      await onSubmit(picked);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="px-6 py-4 space-y-4">
      {cfgState === "loading" && (
        <div className="py-8 text-center text-xs text-muted-foreground flex items-center justify-center gap-2">
          <RefreshCw size={13} className="animate-spin" />读取配置中...
        </div>
      )}

      {cfgState === "disabled" && (
        <div className="flex items-start gap-2 p-3 rounded-xl border-2 border-amber-300 bg-amber-50 text-amber-800 text-xs leading-relaxed">
          <AlertTriangle size={16} className="shrink-0 mt-0.5" />
          <div className="flex-1">
            <p>OmicsOne 接口未开启。请管理员到 <span className="font-semibold">解决方案 → 对应方案 → 接口配置</span> 启用 OmicsOne 接口并填写 IP/端口，应用（重启后端）后生效。</p>
            <Button variant="outline" size="sm" className="mt-2" onClick={onGoSettings}>
              <Settings size={12} />去解决方案
            </Button>
          </div>
        </div>
      )}

      {cfgState === "ready" && (
        <>
          {/* 查询区：日期范围 */}
          <div className="flex items-center gap-2">
            <input
              type="date"
              value={dateFrom}
              onChange={e => setDateFrom(e.target.value)}
              className="flex-1 border border-border rounded-md px-2.5 py-1.5 text-xs bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
            />
            <span className="text-xs text-muted-foreground">至</span>
            <input
              type="date"
              value={dateTo}
              onChange={e => setDateTo(e.target.value)}
              className="flex-1 border border-border rounded-md px-2.5 py-1.5 text-xs bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
            />
            <Button variant="default" size="sm" onClick={handleQuery} className={querying ? "opacity-50 pointer-events-none" : ""}>
              {querying ? <RefreshCw size={12} className="animate-spin" /> : <Search size={12} />}
              {querying ? "查询中..." : "查询"}
            </Button>
          </div>

          {/* 结果表格 */}
          {samples.length > 0 ? (
            <div className="rounded-lg border border-border overflow-hidden">
              <Table className="w-full text-xs">
                <TableHeader className="bg-muted/40">
                  <TableRow>
                    <TableHead className="w-8 px-3 py-2">
                      <input
                        type="checkbox"
                        checked={selected.size === samples.length && samples.length > 0}
                        onChange={toggleSelectAll}
                        className="rounded"
                      />
                    </TableHead>
                    {["样本编号", "患者", "性别", "年龄", "类型", "项目", "医院", "收样日期"].map(h => (
                      <TableHead key={h} className="text-left px-3 py-2 font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {samples.map((s, i) => (
                    <TableRow key={i} className={selected.has(i) ? "bg-primary/5" : "hover:bg-muted/20"}>
                      <TableCell className="px-3 py-2">
                        <input type="checkbox" checked={selected.has(i)} onChange={() => toggleSelect(i)} className="rounded" />
                      </TableCell>
                      <TableCell className="px-3 py-2 font-mono text-primary">
                        {s.sampleNo || <span className="text-muted-foreground/40 italic">待补</span>}
                      </TableCell>
                      <TableCell className="px-3 py-2 font-medium">{s.patient}</TableCell>
                      <TableCell className="px-3 py-2 text-muted-foreground">{s.gender ?? "—"}</TableCell>
                      <TableCell className="px-3 py-2 text-muted-foreground">{s.age ?? "—"}</TableCell>
                      <TableCell className="px-3 py-2 text-muted-foreground">{s.type ?? "—"}</TableCell>
                      <TableCell className="px-3 py-2 text-muted-foreground">{s.project ?? "—"}</TableCell>
                      <TableCell className="px-3 py-2 text-muted-foreground">{s.hospital ?? "—"}</TableCell>
                      <TableCell className="px-3 py-2 text-muted-foreground">{s.receivedAt ?? "—"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <p className="py-8 text-center text-xs text-muted-foreground italic">尚未查询，或该日期范围内未查询到样本</p>
          )}

          {/* 底部提交 */}
          <div className="flex items-center justify-between gap-2 pt-1">
            <BatchSelector batches={batches} batchMode={batchMode} batchId={batchId} onBatchModeChange={onBatchModeChange} onBatchChange={onBatchChange} />
            <div className="flex items-center gap-3">
              <p className="text-[11px] text-muted-foreground">已选 {selected.size} 份 / 共 {samples.length} 份</p>
              <Button variant="default" onClick={handleSubmit} className={selected.size === 0 || submitting ? "opacity-50 cursor-not-allowed" : ""}>
                {submitting ? "入库中..." : "确认入库"}
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ─── Drawer Confirmation Layer ────────────────────────────────────────────────────
// 渲染在 SheetContent 内（DOM 被对话框包含）：Radix 外部点击判定按 DOM 包含关系，
// 确认框按钮点击不会触发对话框 dismiss，避免与关闭拦截竞态导致按钮无效

