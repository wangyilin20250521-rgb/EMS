
import { Switch } from "@/app/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import type { BatchSelectorProps } from "./add-sample-types";

export function BatchSelector({ batches, batchMode, batchId, onBatchModeChange, onBatchChange }: BatchSelectorProps) {
  return (
    <div className="flex items-center gap-2 shrink-0">
      {/* 开关：关=无批次直接录入（不显示下拉），开=登记批次（出现批次选择），与异常样本登记同思路 */}
      <Switch
        checked={batchMode === "batch"}
        onCheckedChange={(on) => onBatchModeChange(on ? "batch" : "none")}
        aria-label="登记至批次号"
      />
      <span className="text-xs text-muted-foreground shrink-0 select-none">登记批次</span>
      {batchMode === "batch" && (
        <Select value={batchId} onValueChange={onBatchChange}>
          <SelectTrigger size="sm" className="w-52 h-8 px-2.5 text-xs border border-border rounded-md bg-card">
            <SelectValue placeholder="请选择批次" />
          </SelectTrigger>
          <SelectContent>
            {batches.map((b) => (
              <SelectItem key={b.id} value={b.id}>
                {b.batchNo}（{b.hospital || "本院"} · {b.actual} 份）
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
    </div>
  );
}

// ─── Document Camera Flow ───────────────────────────────────────────────────────

// ─── Local Image Batch Upload（真实 OCR 识别送检单） ───────────────────────────

