import React from "react";

export const fieldInput = "flex-1 min-w-0 border border-border rounded px-2.5 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary bg-card";

export function FieldLabel({ text, required }: { text: string; required?: boolean }) {
  return (
    <label className="w-[110px] shrink-0 text-sm text-muted-foreground text-right select-none">
      {text}
      {required && <span className="text-red-500 ml-0.5">*</span>}
    </label>
  );
}

/** 只读态值展示（OmicsOne 预填锁定行用，带底色框区别于可编辑输入框） */
export function ReadonlyValue({ value, mono }: { value: string; mono?: boolean }) {
  return (
    <p className={`flex-1 min-w-0 px-2.5 py-1.5 rounded text-sm bg-muted/40 text-foreground truncate ${mono ? "font-mono" : ""}`}>{value || "—"}</p>
  );
}

/** 行式字段容器：label 左 + 控件右（OmicsOne 预填行锁定为只读，手动行始终可编辑） */
export function FieldRow({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 min-w-0">
      <FieldLabel text={label} required={required} />
      {children}
    </div>
  );
}

