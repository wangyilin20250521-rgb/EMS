import { useCallback, useEffect, useRef, useState } from "react";
import {
  Bell, Boxes, CheckCheck, ChevronsLeft, ChevronsRight, FlaskConical,
  Info, Layers, LayoutDashboard, LayoutGrid, LayoutList, Lock, LogOut, Microscope, Pin, Settings, TestTubes, User, X,
} from "lucide-react";
import labelFull from "@/assets/icons/label-full.png";
import labelCollapse from "@/assets/icons/label-collapse.png";
import type { LucideIcon } from "lucide-react";
import { useNavigate } from "react-router";
import { useAuth } from "@/app/hooks/useAuth";
import { isViewAllowed } from "@/app/lib/view-permissions";
import { IconAsset } from "@/app/components/shared/IconAsset";
import {
  acknowledgeAlert, batchAcknowledgeAlerts, getAlertsList,
  type Alert, type ViewId,
} from "@/app/lib/api";

/** 侧边栏导航分组模型（2026-08-27 双模式重构：全量展开 ↔ 5 分组卡片）。
 * 叶子项保持 ViewId 原子性（路由/权限/active 链路零改动）；
 * 权限过滤在叶子项级别，空组在卡片模式整卡隐藏。 */
const NAV_GROUPS: Array<{
  id: string;
  label: string;
  /** 分组卡片大图标：优先 EMS 品牌资产（IconAsset PNG），缺失时回退 lucide icon */
  iconAsset?: string;
  icon: LucideIcon;
  items: Array<{
    id: ViewId;
    label: string;
    iconAsset?: string;
    fallbackIcon: LucideIcon;
    disabled?: boolean;
    /** AI 能力入口：金色高亮（"金色 = AI" 视觉语言，2026-08-27） */
    ai?: boolean;
  }>;
}> = [
  {
    id: "overview", label: "综合", iconAsset: "dashboard", icon: LayoutDashboard,
    items: [
      { id: "dashboard",           iconAsset: "dashboard", fallbackIcon: FlaskConical, label: "仪表盘" },
      { id: "ai-assistant",        iconAsset: "ai",        fallbackIcon: User,         label: "EMS 助手", ai: true },
      { id: "anomaly-center",      iconAsset: "alert",     fallbackIcon: User,         label: "异常中心" },
    ],
  },
  {
    id: "samples", label: "样本管理", iconAsset: "samples", icon: TestTubes,
    items: [
      { id: "unpack-register",     iconAsset: "register", fallbackIcon: User,         label: "收样中心" },
      { id: "sample-center",       iconAsset: "samples",  fallbackIcon: User,         label: "样本中心" },
      { id: "product-management",  iconAsset: "products", fallbackIcon: User,         label: "产物管理" },
    ],
  },
  {
    id: "experiment", label: "实验管理", iconAsset: "sequencer", icon: Microscope,
    items: [
      { id: "sample-prep",         iconAsset: "sample_prep", fallbackIcon: User,      label: "样本制备" },
      { id: "experiment-schedule", iconAsset: "schedule",    fallbackIcon: User,      label: "排单看板" },
      { id: "task-list",           iconAsset: "task-list",   fallbackIcon: User,      label: "任务列表" },
      { id: "sequencing-task",     iconAsset: "sequencer",   fallbackIcon: User,      label: "测序任务", disabled: true },
    ],
  },
  {
    id: "resources", label: "资源管理", iconAsset: "device", icon: Boxes,
    items: [
      { id: "devices",             iconAsset: "device",        fallbackIcon: User,    label: "设备管理" },
      { id: "reagents",            iconAsset: "consumerables", fallbackIcon: User,    label: "试剂管理", disabled: true },
      { id: "documents",           iconAsset: "document",      fallbackIcon: User,    label: "文档归档" },
      { id: "strategy-management", iconAsset: "strategy",      fallbackIcon: User,    label: "策略管理" },
    ],
  },
  {
    id: "system", label: "系统", iconAsset: "settings", icon: Settings,
    items: [
      { id: "settings",            iconAsset: "settings", fallbackIcon: User,        label: "系统设置" },
      { id: "solutions",           iconAsset: "solutions", fallbackIcon: Layers,     label: "解决方案" },
    ],
  },
];

export function Sidebar({ active, onNavigate, collapsed, onToggle, cardView, onToggleView }: {
  active: ViewId;
  onNavigate: (v: ViewId) => void;
  /** 侧边栏宽度：true = 收缩窄栏（88px 全量小图标），false = 展开（204px） */
  collapsed: boolean;
  onToggle: () => void;
  /** 展开状态下的阅读视图：true = 5 分组卡片（收缩阅读），false = 全量图标宫格（全量阅读）；仅 collapsed=false 时生效 */
  cardView: boolean;
  onToggleView: () => void;
}) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [showUser,  setShowUser]  = useState(false);
  const [showBell,  setShowBell]  = useState(false);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [isAcknowledging, setIsAcknowledging] = useState(false);

  const userRef  = useRef<HTMLDivElement>(null);
  const bellRef  = useRef<HTMLButtonElement>(null);
  const popoverRef = useRef<HTMLDivElement>(null);

  // hover 弹层延迟关闭（移出图标/弹层 0.5s 后收起，期间移回则取消）
  const bellCloseTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const userCloseTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scheduleBellClose = () => {
    if (bellCloseTimer.current) clearTimeout(bellCloseTimer.current);
    bellCloseTimer.current = setTimeout(() => setShowBell(false), 500);
  };
  const cancelBellClose = () => {
    if (bellCloseTimer.current) { clearTimeout(bellCloseTimer.current); bellCloseTimer.current = null; }
  };
  const scheduleUserClose = () => {
    if (userCloseTimer.current) clearTimeout(userCloseTimer.current);
    userCloseTimer.current = setTimeout(() => setShowUser(false), 500);
  };
  const cancelUserClose = () => {
    if (userCloseTimer.current) { clearTimeout(userCloseTimer.current); userCloseTimer.current = null; }
  };
  useEffect(() => () => {
    cancelBellClose();
    cancelUserClose();
  }, []);

  const unconfirmedCount = alerts.filter(a => a.status === "未确认").length;

  // 挂载/权限变化时拉取未读数（无警报权限的角色不请求）
  const loadAlerts = useCallback(async () => {
    if (!isViewAllowed(user?.role, "alerts")) return;
    const res = await getAlertsList().catch(() => null);
    if (res?.ok) setAlerts(res.data);
  }, [user?.role]);

  useEffect(() => { void loadAlerts(); }, [loadAlerts]);

  // 点击外部关闭用户弹出层 / 警报弹层
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      const t = e.target as Node;
      if (userRef.current  && !userRef.current.contains(t))  setShowUser(false);
      if (popoverRef.current && !popoverRef.current.contains(t)
          && bellRef.current && !bellRef.current.contains(t)) setShowBell(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const acknowledgeFromPopover = async (id: string) => {
    setIsAcknowledging(true);
    try {
      await acknowledgeAlert(id);
      await loadAlerts();
      setShowBell(false);
      onNavigate("alerts");
    } finally {
      setIsAcknowledging(false);
    }
  };

  const acknowledgeAllFromPopover = async () => {
    const unconfirmedIds = alerts.filter((alert) => alert.status === "未确认").map((alert) => alert.id);
    if (unconfirmedIds.length === 0) return;

    setIsAcknowledging(true);
    try {
      await batchAcknowledgeAlerts(unconfirmedIds);
      await loadAlerts();
    } finally {
      setIsAcknowledging(false);
    }
  };

  // 权限过滤在叶子项级别（disabled 项仍显示为灰）；空组在卡片模式整卡隐藏
  const visibleGroups = NAV_GROUPS.map(g => ({
    ...g,
    items: g.items.filter(item => isViewAllowed(user?.role, item.id)),
  }));
  const visibleItems = visibleGroups.flatMap(g => g.items);

  // 卡片模式 hover 展开状态（250ms 延迟收起，防移向二级菜单时误收）
  const [hoverGroup, setHoverGroup] = useState<string | null>(null);
  const groupLeaveTimer = useRef<number | null>(null);
  const handleGroupEnter = (id: string) => {
    if (groupLeaveTimer.current !== null) {
      window.clearTimeout(groupLeaveTimer.current);
      groupLeaveTimer.current = null;
    }
    setHoverGroup(id);
  };
  const handleGroupLeave = () => {
    if (groupLeaveTimer.current !== null) window.clearTimeout(groupLeaveTimer.current);
    groupLeaveTimer.current = window.setTimeout(() => setHoverGroup(null), 250);
  };
  useEffect(() => () => {
    if (groupLeaveTimer.current !== null) window.clearTimeout(groupLeaveTimer.current);
  }, []);

  // 点击长驻展开（pin）：hover 临时展开之外，点击卡片使其展开长期保持，再点取消
  const [pinnedGroup, setPinnedGroup] = useState<string | null>(null);
  const handleGroupClick = (id: string) => {
    setPinnedGroup(p => (p === id ? null : id));
  };
  const isGroupOpen = (id: string) => hoverGroup === id || pinnedGroup === id;
  const isGroupPinned = (id: string) => pinnedGroup === id;

  const toolBtn =
    "w-9 h-9 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer";

  /** AI 入口金色角标（"金色 = AI" 视觉语言，配合条目 ai: true 使用） */
  const AIBadge = () => (
    <span className="absolute top-0.5 right-0.5 z-10 rounded-full bg-ai-accent px-1 py-px text-[8px] font-bold leading-none text-foreground">
      AI
    </span>
  );

  return (
    <aside
      className="relative flex flex-col h-full border-r border-sidebar-border transition-all duration-200 shrink-0 bg-sidebar"
      style={{ width: collapsed ? 88 : 204 }}
    >
      {/* 宽度展开/收缩按钮 — 圆形，悬浮于右侧边缘，垂直居中（收缩 = 88px 全量小图标窄栏） */}
      <button
        onClick={onToggle}
        title={collapsed ? "展开侧边栏" : "收缩侧边栏"}
        className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 z-20 w-10 h-10 rounded-full bg-sidebar border border-sidebar-border flex items-center justify-center text-primary shadow-sm hover:bg-muted transition-colors cursor-pointer"
      >
        {collapsed ? <ChevronsRight size={14} /> : <ChevronsLeft size={14} />}
      </button>

      {/* Logo */}
      <div className={`flex items-center justify-center shrink-0 ${collapsed ? "h-14" : "h-24 px-4"}`}>
        <img
          src={collapsed ? labelCollapse : labelFull}
          alt="EMS"
          className="object-contain"
          style={{ height: collapsed ? 28 : 56 }}
        />
      </div>

      {/* Nav：收缩 = 88px 全量小图标窄栏（原设计）；展开 = 全量图标宫格 ↔ 5 分组卡片（底部按钮切换阅读视图） */}
      <nav
        className="flex-1 overflow-y-auto overflow-x-hidden py-2 px-2 [&::-webkit-scrollbar]:hidden"
        style={{ scrollbarWidth: "none" }}
      >
        {collapsed ? (
          /* ── 收缩窄栏：全量小图标（原设计，固定不变）── */
          <div className="flex flex-col items-center gap-2">
            {visibleItems.map(item => {
              const isActive   = active === item.id;
              const isDisabled = item.disabled;
              return (
                <button
                  key={item.id}
                  onClick={() => !isDisabled && onNavigate(item.id)}
                  disabled={isDisabled}
                  className={`flex flex-col items-center justify-center gap-1 rounded-xl transition-colors w-16 min-h-14 py-1 ${
                    isDisabled
                      ? "text-muted-foreground cursor-not-allowed opacity-40"
                      : isActive
                        ? "bg-border/60 text-primary cursor-pointer" // 选中：仅灰色反底标记（比悬停深一档），图标不做调亮
                        : "text-muted-foreground hover:bg-muted hover:text-foreground cursor-pointer"
                  } ${item.ai ? "relative" : ""}`}
                >
                  {item.ai && <AIBadge />}
                  <IconAsset
                    name={item.iconAsset ?? ""}
                    size={28}
                    imgWidth={28}
                    imgHeight={28}
                    fallback={<item.fallbackIcon size={24} className="shrink-0" />}
                  />
                  <span className="leading-tight text-center w-full px-0.5 truncate text-xs">
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
        ) : cardView ? (
          /* ── 展开 + 收缩阅读：5 张分组卡片（PMSWeb 功能岛动画：overshoot 回弹 + 卡片纵向展开）── */
          <div className="flex flex-col gap-2">
            {visibleGroups.filter(g => g.items.length > 0).map(g => {
              const groupActive = g.items.some(i => i.id === active);
              const isOpen = isGroupOpen(g.id);
              const isPinned = isGroupPinned(g.id);
              return (
                <div
                  key={g.id}
                  onMouseEnter={() => handleGroupEnter(g.id)}
                  onMouseLeave={handleGroupLeave}
                  onClick={() => handleGroupClick(g.id)}
                  title={isPinned ? "点击取消固定" : "点击固定展开"}
                  className={`w-full ${isOpen ? "max-h-[400px]" : "max-h-[84px]"} overflow-hidden rounded-card border cursor-pointer transition-all duration-[400ms] [transition-timing-function:cubic-bezier(0.34,1.56,0.64,1)] ${
                    isOpen
                      ? "bg-card border-primary/40 shadow-card"
                      : groupActive
                        ? "bg-card border-primary/70"
                        : "bg-card border-border hover:bg-muted/40 hover:border-primary/40"
                  }`}
                >
                  {/* 收起态头部（宽卡片横排）：白底与其他卡片统一，大图标用 EMS 品牌资产（缺省回退 lucide）；点击可 pin 长驻 */}
                  <div className="flex items-center gap-3 h-[84px] px-4 shrink-0">
                    <IconAsset
                      name={g.iconAsset ?? ""}
                      size={48}
                      imgWidth={48}
                      imgHeight={48}
                      fallback={<g.icon size={28} className="shrink-0 text-primary" />}
                    />
                    <span className={`text-base font-semibold truncate flex-1 ${groupActive ? "text-primary-active" : "text-foreground"}`}>
                      {g.label}
                    </span>
                    {isPinned && <Pin size={14} className="shrink-0 text-primary" aria-label="已固定" />}
                  </div>
                  {/* 展开态：二级菜单项（淡入；大触控面积，px-3 py-2.5 text-sm） */}
                  <div className={`px-2 pb-2.5 space-y-1 transition-opacity duration-300 ${isOpen ? "opacity-100" : "opacity-0 pointer-events-none"}`}>
                    {g.items.map(item => {
                      const isActive   = active === item.id;
                      const isDisabled = item.disabled;
                      return (
                        <button
                          key={item.id}
                          onClick={e => { e.stopPropagation(); if (!isDisabled) onNavigate(item.id); }}
                          disabled={isDisabled}
                          className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                            isDisabled
                              ? "text-muted-foreground cursor-not-allowed opacity-40"
                              : isActive
                                ? "bg-border/60 text-primary cursor-pointer" // 选中：仅灰色反底标记（比悬停深一档），图标不做调亮
                                : "text-muted-foreground hover:bg-muted hover:text-foreground cursor-pointer"
                          } ${item.ai ? "relative" : ""}`}
                        >
                          {item.ai && <AIBadge />}
                          <IconAsset
                            name={item.iconAsset ?? ""}
                            size={20}
                            imgWidth={20}
                            imgHeight={20}
                            fallback={<item.fallbackIcon size={18} className="shrink-0" />}
                          />
                          <span className="truncate">{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* ── 展开 + 全量阅读：84×84 图标宫格（原视觉，数据源改为分组平铺）── */
          <div className="grid grid-cols-2 gap-2 justify-items-center">
            {visibleItems.map(item => {
              const isActive   = active === item.id;
              const isDisabled = item.disabled;
              return (
                <button
                  key={item.id}
                  onClick={() => !isDisabled && onNavigate(item.id)}
                  disabled={isDisabled}
                  className={`flex flex-col items-center justify-center gap-1 rounded-xl transition-colors w-[84px] h-[84px] ${
                    isDisabled
                      ? "text-muted-foreground cursor-not-allowed opacity-40"
                      : isActive
                        ? "bg-border/60 text-primary cursor-pointer" // 选中：仅灰色反底标记（比悬停深一档），图标不做调亮
                        : "text-muted-foreground hover:bg-muted hover:text-foreground cursor-pointer"
                  } ${item.ai ? "relative" : ""}`}
                >
                  {item.ai && <AIBadge />}
                  <IconAsset
                    name={item.iconAsset ?? ""}
                    size={44}
                    imgWidth={60}
                    imgHeight={44}
                    fallback={<item.fallbackIcon size={36} className="shrink-0" />}
                  />
                  <span className="leading-tight text-center w-full px-0.5 truncate text-sm">
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </nav>

      {/* Bottom toolbar：通知 / 暗色切换 / 用户 */}
      <div className="border-t border-sidebar-border px-2 pt-1.5 pb-2">
        <div className={`flex items-center ${collapsed ? "flex-col gap-1" : "justify-around"}`}>

          {/* 预警通知（hover 展示：移入显示，移出图标/弹层 0.5s 后收起；未确认列表 / 全部确认 / 查看全部） */}
          {isViewAllowed(user?.role, "alerts") && (
            <div
              className="relative"
              onMouseEnter={() => { cancelBellClose(); if (!showBell) void loadAlerts(); setShowBell(true); }}
              onMouseLeave={scheduleBellClose}
            >
              <button
                ref={bellRef}
                title="警报通知"
                aria-label="警报通知"
                className={`${toolBtn} relative`}
              >
                <Bell size={15} />
                {unconfirmedCount > 0 && (
                  <span className="absolute top-0.5 right-0.5 min-w-[12px] h-3 px-0.5 bg-red-500 text-white text-[8px] font-bold rounded-full flex items-center justify-center leading-none">
                    {unconfirmedCount > 9 ? "9+" : unconfirmedCount}
                  </span>
                )}
              </button>

              {/* 警报弹层（自 TopBar 迁移，视觉对齐新版） */}
              {showBell && (
                <div
                  ref={popoverRef}
                  className="absolute left-full bottom-0 ml-2 w-80 bg-card border border-border rounded-xl shadow-xl z-50 overflow-hidden"
                  role="dialog"
                  aria-label="警报通知列表"
                >
                  {/* Header */}
                  <div className="flex items-center justify-between px-4 py-3 border-b border-border">
                    <span className="text-sm font-semibold text-foreground">
                      警报通知
                      {unconfirmedCount > 0 && (
                        <span className="ml-2 inline-flex items-center justify-center w-5 h-5 rounded-full bg-red-500 text-white text-[10px] font-bold">
                          {unconfirmedCount}
                        </span>
                      )}
                    </span>
                    <div className="flex items-center gap-1">
                      {alerts.some((alert) => alert.status === "未确认") && (
                        <button
                          onClick={() => void acknowledgeAllFromPopover()}
                          disabled={isAcknowledging}
                          className="text-xs text-muted-foreground hover:text-primary flex items-center gap-1 px-2 py-1 rounded hover:bg-muted transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                          title="全部确认"
                        >
                          <CheckCheck size={13} />
                          全部确认
                        </button>
                      )}
                      <button
                        onClick={() => setShowBell(false)}
                        aria-label="关闭警报通知"
                        className="p-1 text-muted-foreground hover:text-foreground rounded hover:bg-muted transition-colors cursor-pointer"
                      >
                        <X size={13} />
                      </button>
                    </div>
                  </div>

                  {/* Alert List */}
                  <div className="max-h-72 overflow-y-auto">
                    {alerts.length === 0 ? (
                      <div className="py-8 text-center text-sm text-muted-foreground">暂无警报</div>
                    ) : (
                      alerts.map((alert) => (
                        <button
                          type="button"
                          key={alert.id}
                          onClick={() => void acknowledgeFromPopover(alert.id)}
                          disabled={isAcknowledging || alert.status !== "未确认"}
                          aria-label={`查看警报：${alert.title}${alert.status === "未确认" ? "，未确认" : "，已确认"}`}
                          className={`w-full flex items-start gap-3 px-4 py-3 border-b border-border/50 last:border-b-0 text-left cursor-pointer hover:bg-muted/40 transition-colors ${
                            alert.status !== "未确认" ? "opacity-60" : ""
                          } disabled:cursor-default disabled:opacity-60`}
                        >
                          {/* Unread dot */}
                          <div className="mt-1.5 shrink-0">
                            {alert.status !== "未确认" ? (
                              <div className="w-2 h-2 rounded-full bg-transparent" />
                            ) : (
                              <div
                                className={`w-2 h-2 rounded-full ${
                                  alert.level === "警告" ? "bg-red-500" : "bg-primary"
                                }`}
                              />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p
                              className={`text-xs leading-relaxed ${
                                alert.status !== "未确认"
                                  ? "text-muted-foreground font-normal"
                                  : "text-foreground font-semibold"
                              }`}
                            >
                              {alert.title}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                              <span
                                className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                                  alert.level === "警告"
                                    ? "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400"
                                    : "bg-primary-light-9 text-primary-active"
                                }`}
                              >
                                {alert.level}
                              </span>
                              <span className="text-[10px] text-muted-foreground">{alert.time}</span>
                            </div>
                          </div>
                        </button>
                      ))
                    )}
                  </div>

                  {/* Footer */}
                  <div className="px-4 py-2.5 border-t border-border bg-muted/30">
                    <button
                      onClick={() => {
                        setShowBell(false);
                        onNavigate("alerts");
                      }}
                      className="w-full text-xs text-center text-primary hover:underline font-medium cursor-pointer"
                    >
                      查看全部警报
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 阅读视图切换（仅两列展开状态生效）：全量图标宫格 ↔ 5 分组卡片 */}
          {!collapsed && (
            <button
              onClick={onToggleView}
              title={cardView ? "全量阅读（图标宫格）" : "收缩阅读（分组卡片）"}
              aria-label={cardView ? "全量阅读" : "收缩阅读"}
              className={toolBtn}
            >
              {cardView ? <LayoutGrid size={15} /> : <LayoutList size={15} />}
            </button>
          )}

          {/* 用户弹出层（hover 展示：移入显示，移出图标/弹层 0.5s 后收起） */}
          <div
            ref={userRef}
            className="relative"
            onMouseEnter={() => { cancelUserClose(); setShowUser(true); }}
            onMouseLeave={scheduleUserClose}
          >
            <button
              title={user?.displayName ?? "用户"}
              className={toolBtn}
            >
              <User size={15} />
            </button>
            {showUser && (
              <div className="absolute left-full bottom-0 ml-2 z-50 w-52 bg-card border border-border rounded-lg shadow-lg overflow-hidden">
                <div className="text-center px-3 py-3.5">
                  <div className="w-12 h-12 rounded-full bg-muted border-2 border-border mx-auto flex items-center justify-center">
                    <User size={22} className="text-muted-foreground" />
                  </div>
                  <p className="font-semibold text-foreground mt-2 text-sm leading-tight">
                    {user?.displayName ?? "用户"}
                  </p>
                  <p className="flex items-center justify-center gap-1 text-[10px] text-muted-foreground mt-0.5">
                    <Info size={10} />
                    <span>EMS v1.0</span>
                  </p>
                </div>
                <div className="border-t border-border grid grid-cols-2 divide-x divide-border">
                  <button
                    onClick={() => { navigate("/user-info"); setShowUser(false); }}
                    className="flex items-center justify-center gap-1 py-2.5 text-xs text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer"
                  >
                    <Lock size={12} />
                    修改密码
                  </button>
                  <button
                    onClick={() => { void logout(); setShowUser(false); }}
                    className="flex items-center justify-center gap-1 py-2.5 text-xs text-muted-foreground hover:text-destructive hover:bg-muted transition-colors cursor-pointer"
                  >
                    <LogOut size={12} />
                    退出登录
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </aside>
  );
}
