import type { ViewId } from "@/app/lib/api";

const BREADCRUMBS: Partial<Record<ViewId, string>> = {
  dashboard:            "综合 › 仪表盘",
  "ai-assistant":       "综合 › EMS 助手",
  alerts:               "综合 › 警报",
  "unpack-register":    "样本管理 › 收样中心",
  "strategy-management":"资源管理 › 策略管理",
  "sample-center":      "样本管理 › 样本中心",
  "product-management": "样本管理 › 产物管理",
  "sample-prep":        "实验管理 › 样本制备",
  "sample-collect":     "实验管理 › 样本采集",
  "sequencing-task":    "实验管理 › 测序任务",
  "experiment-schedule":"实验管理 › 排单看板",
  "task-list":          "实验管理 › 任务列表",
  "anomaly-center":     "综合 › 异常中心",
  devices:              "资源管理 › 设备管理",
  reagents:             "资源管理 › 试剂管理",
  documents:            "资源管理 › 文档归档",
  settings:             "系统 › 系统设置",
  solutions:            "系统 › 解决方案",
};

/**
 * 顶栏：仅展示当前页面面包屑。
 * 主题切换、通知、用户操作已移至侧边栏底部工具栏。
 */
export function TopBar({ active }: { active: ViewId; onNavigate?: (v: ViewId) => void }) {
  const fullText = BREADCRUMBS[active] ?? "实验生产系统";
  const parts = fullText.split(" › ");
  const hasParent = parts.length > 1;

  return (
    <header className="pt-2.5 pb-1 px-6 shrink-0 z-10">
      <p className="text-sm text-muted-foreground">
        {hasParent ? (
          <>
            <span>{parts[0]}</span>
            <span className="mx-1">›</span>
            <span className="font-semibold text-foreground">{parts.slice(1).join(" › ")}</span>
          </>
        ) : (
          <span className="font-semibold text-foreground">{fullText}</span>
        )}
      </p>
    </header>
  );
}
