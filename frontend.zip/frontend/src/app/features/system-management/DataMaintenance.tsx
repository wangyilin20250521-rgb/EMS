import { useState, useCallback, useEffect } from "react";
import { Database, RefreshCw, Sprout } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { formatBytes, formatIso } from "./shared";
import { getBackupRecords, createBackup, restoreBackup, getDemoSeedStatus, seedDemoData, clearDemoData, type BackupRecord, type DemoSeedStatus } from "@/app/lib/api";
import { toast } from "sonner";

export function DataMaintenance() {
  const [backing, setBacking] = useState(false);
  const [backups, setBackups] = useState<BackupRecord[]>([]);
  const [backupsLoading, setBackupsLoading] = useState(true);
  const [restoreTarget, setRestoreTarget] = useState<BackupRecord | null>(null);
  const [restoring, setRestoring] = useState(false);
  // 演示数据（2026-09-17）：状态 + 播种/清空（管理员；生产档案 DB_RESET_WEB=false 下播种被服务端拒绝）
  const [seedStatus, setSeedStatus] = useState<DemoSeedStatus | null>(null);
  const [seedBusy, setSeedBusy] = useState<"seed" | "clear" | null>(null);
  const [confirmAction, setConfirmAction] = useState<"seed" | "clear" | null>(null);

  const loadSeedStatus = useCallback(() => {
    getDemoSeedStatus().then(setSeedStatus).catch(() => setSeedStatus(null));
  }, []);
  useEffect(() => { loadSeedStatus(); }, [loadSeedStatus]);

  const doSeedOrClear = async () => {
    if (!confirmAction) return;
    setSeedBusy(confirmAction);
    try {
      if (confirmAction === "seed") {
        await seedDemoData();
        toast.success("演示数据已灌入");
      } else {
        await clearDemoData();
        toast.success("演示数据已清空");
      }
    } catch (err: any) {
      toast.error(err?.message || "操作失败");
    } finally {
      setSeedBusy(null);
      setConfirmAction(null);
      loadSeedStatus();
    }
  };

  const loadBackups = useCallback(() => {
    setBackupsLoading(true);
    getBackupRecords()
      .then(data => setBackups(data))
      .catch(() => setBackups([]))
      .finally(() => setBackupsLoading(false));
  }, []);

  useEffect(() => { loadBackups(); }, [loadBackups]);

  const doBackup = async () => {
    setBacking(true);
    try {
      await createBackup();
      toast.success("备份创建成功");
      loadBackups();
    } catch (err: any) {
      toast.error(err?.message || "创建备份失败");
    } finally {
      setBacking(false);
    }
  };

  const doRestore = async () => {
    if (!restoreTarget) return;
    setRestoring(true);
    try {
      await restoreBackup(restoreTarget.id);
      toast.success(`已恢复 ${restoreTarget.id} 的备份数据`);
      setRestoreTarget(null);
    } catch (err: any) {
      toast.error(err?.message || "恢复备份失败");
    } finally {
      setRestoring(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* 三卡一行，等高（同系统配置卡规格） */}
      <div className="grid grid-cols-1 lg:grid-cols-3 auto-rows-fr gap-5">
        {/* 自动备份 — 暂未实现（敬请期待占位） */}
        <Card className="p-5 flex flex-col opacity-60 grayscale-[30%]">
          <h3 className="text-sm font-semibold mb-4 text-muted-foreground">自动备份</h3>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">定时自动备份</p>
              <p className="text-xs text-muted-foreground">每日凌晨 2:00，保留 30 天</p>
            </div>
            <div className="w-8 h-5 rounded-full bg-gray-200 relative shrink-0" style={{ minWidth: 40, height: 22 }}>
              <span className="absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-gray-300" />
            </div>
          </div>
          <div className="mt-auto pt-4 flex justify-end">
            <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-500">敬请期待</span>
          </div>
        </Card>

        {/* 手动备份 */}
        <Card className="p-5 flex flex-col">
          <h3 className="text-sm font-semibold mb-4">手动备份</h3>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">创建数据快照</p>
              <p className="text-xs text-muted-foreground">备份全部数据表，可用于恢复</p>
            </div>
            <Button variant="secondary" size="sm" onClick={backing ? undefined : doBackup} className={backing ? "opacity-50 pointer-events-none" : ""}>
              <Database size={12} />{backing ? "备份中..." : "立即备份"}
            </Button>
          </div>
        </Card>

        {/* 演示数据管理（2026-09-17）：播种/清空演示数据集，供演示与空环境测试切换 */}
        <Card className="p-5 flex flex-col">
          <div className="flex items-center gap-2 mb-4">
            <h3 className="text-sm font-semibold">演示数据</h3>
            {seedStatus?.seeded ? (
              <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700">已播种</span>
            ) : (
              <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-muted text-muted-foreground">未播种</span>
            )}
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            灌入或清空演示数据集（批次 7、样本 124、任务 18 等），仅供演示与测试；生产环境灌入会被服务端拒绝。
          </p>
          <div className="mt-auto pt-4 flex items-center gap-2">
            <Button variant="secondary" size="sm"
              onClick={() => setConfirmAction("seed")}
              disabled={seedBusy !== null}>
              <Sprout size={12} />{seedBusy === "seed" ? "灌入中..." : "灌入演示数据"}
            </Button>
            <Button variant="outline" size="sm"
              onClick={() => setConfirmAction("clear")}
              disabled={seedBusy !== null}>
              {seedBusy === "clear" ? "清空中..." : "清空演示数据"}
            </Button>
          </div>
        </Card>
      </div>

      {/* 备份记录（平铺，无卡片） */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold">备份记录</p>
          <span className="text-sm text-muted-foreground">{backups.length} 条</span>
        </div>
        <Table className="w-full text-sm">
          <TableHeader className="border-b border-border">
            <TableRow>{["备份ID", "备份时间", "文件大小", "包含表数", "操作"].map(h => (
              <TableHead key={h} className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
            ))}</TableRow>
          </TableHeader>
          <TableBody className="divide-y divide-border">
            {backupsLoading ? (
              <TableRow><TableCell colSpan={5} className="px-3 py-12 text-center text-muted-foreground">
                <RefreshCw size={16} className="animate-spin inline mr-2" />加载中...
              </TableCell></TableRow>
            ) : backups.length === 0 ? (
              <TableRow><TableCell colSpan={5} className="px-3 py-8 text-center text-sm text-muted-foreground">暂无备份记录，请先创建备份</TableCell></TableRow>
            ) : backups.map(b => (
              <TableRow key={b.id} className="hover:bg-muted/20 transition-colors">
                <TableCell className="px-3 py-3 font-mono text-sm text-muted-foreground">{b.id}</TableCell>
                <TableCell className="px-3 py-3 font-mono text-sm text-muted-foreground">{formatIso(b.createdAt)}</TableCell>
                <TableCell className="px-3 py-3 text-sm font-mono">{formatBytes(b.size)}</TableCell>
                <TableCell className="px-3 py-3 text-sm">{b.tables} 张表</TableCell>
                <TableCell className="px-3 py-3">
                  <Button variant="ghost" size="sm" onClick={() => setRestoreTarget(b)}>恢复</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* 演示数据操作确认 */}
      {confirmAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-card rounded-2xl shadow-2xl w-[420px]">
            <div className="px-6 py-4 border-b border-border">
              <h2 className="text-base font-semibold">{confirmAction === "seed" ? "灌入演示数据" : "清空演示数据"}</h2>
            </div>
            <div className="p-6 space-y-3">
              {confirmAction === "seed" ? (
                <>
                  <p className="text-sm">将按标记清理旧演示数据后重新灌入完整演示数据集。</p>
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-800">
                    灌入会覆盖既有演示数据（收样批次 7、样本 124 例、任务 18、建库结果 118、产物 190、异常工单 3）。
                  </div>
                </>
              ) : (
                <>
                  <p className="text-sm">将按标记删除全部演示数据（样本、批次、任务、结果、产物、异常工单等）。</p>
                  <p className="text-xs text-red-600 font-medium">清空后系统为空环境，可重新灌入。</p>
                </>
              )}
              <p className="text-xs text-muted-foreground">执行约需 5~10 秒，期间请勿关闭页面。</p>
            </div>
            <div className="px-6 py-4 border-t border-border flex justify-end gap-2">
              <Button variant="outline" onClick={() => setConfirmAction(null)}>取消</Button>
              <Button variant={confirmAction === "seed" ? "default" : "destructive"} onClick={doSeedOrClear}
                className={seedBusy ? "opacity-50 pointer-events-none" : ""}>
                {seedBusy === "seed" ? "灌入中..." : seedBusy === "clear" ? "清空中..." : confirmAction === "seed" ? "确认灌入" : "确认清空"}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Restore confirmation */}
      {restoreTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-card rounded-2xl shadow-2xl w-[400px]">
            <div className="px-6 py-4 border-b border-border flex items-center justify-between">
              <h2 className="text-base font-semibold">恢复数据</h2>
              <button onClick={() => setRestoreTarget(null)} className="text-muted-foreground hover:text-foreground cursor-pointer text-lg">×</button>
            </div>
            <div className="p-6 space-y-3">
              <p className="text-sm">确定要将系统数据恢复到以下备份点？</p>
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                <p className="text-xs font-mono text-amber-800">{restoreTarget.id}</p>
                <p className="text-xs text-amber-700 mt-1">备份时间: {formatIso(restoreTarget.createdAt)}</p>
                <p className="text-xs text-amber-700">文件大小: {formatBytes(restoreTarget.size)}</p>
              </div>
              <p className="text-xs text-red-600 font-medium">此操作不可逆，当前数据将被覆盖！</p>
            </div>
            <div className="px-6 py-4 border-t border-border flex justify-end gap-2">
              <Button variant="outline" onClick={() => setRestoreTarget(null)}>取消</Button>
              <Button variant="destructive" onClick={doRestore} className={restoring ? "opacity-50 pointer-events-none" : ""}>
                {restoring ? "恢复中..." : "确认恢复"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
