import type { FieldError } from "@/app/lib/validation";
import type { SystemLogEntry as LogEntry, SystemUser as User } from "@/app/lib/api";

export type SubPage =
  | "用户与角色"
  | "系统配置"
  | "日志"
  | "数据字典"
  | "实验流程"
  | "数据维护";


export function FieldErrorText({ error }: { error?: FieldError }) {
  if (!error) return null;
  return <p className="mt-1 text-xs text-red-600">{error.message}</p>;
}

export function FormErrorSummary({ errors }: { errors: FieldError[] }) {
  if (errors.length === 0) return null;

  return (
    <div className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
      <p className="font-semibold mb-1">请修正以下校验错误后再提交：</p>
      <ul className="list-disc pl-4 space-y-0.5">
        {errors.map((error) => <li key={`${error.field}-${error.code}`}>{error.message}</li>)}
      </ul>
    </div>
  );
}

// ─── Shared Helpers ─────────────────────────────────────────────────────────

export function Toggle({ enabled, onChange }: { enabled: boolean; onChange: () => void }) {
  return (
    <button onClick={onChange}
      className={`w-10 h-5 rounded-full relative transition-colors cursor-pointer shrink-0`}
      style={{ minWidth: 40, height: 22, background: enabled ? "var(--primary)" : "var(--switch-background)" }}>
      <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${enabled ? "left-[21px]" : "left-0.5"}`} />
    </button>
  );
}

export function userStatusStyle(s: User["status"]) {
  return {
    "正常":     "bg-emerald-50 text-emerald-700",
    "首次登录": "bg-blue-50 text-blue-700",
    "已禁用":   "bg-gray-100 text-gray-500",
    "已锁定":   "bg-red-50 text-red-700",
  }[s];
}

export function actionStyle(a: LogEntry["action"]) {
  return {
    "新增":   "bg-emerald-50 text-emerald-700",
    "修改":   "bg-blue-50 text-blue-700",
    "删除":   "bg-red-50 text-red-700",
    "登录":   "bg-gray-100 text-gray-600",
    "导出":   "bg-amber-50 text-amber-700",
    "权限变更": "bg-purple-50 text-purple-700",
  }[a];
}

// ─── Sub Pages ───────────────────────────────────────────────────────────────


export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function formatIso(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleString("zh-CN", { hour12: false });
  } catch { return iso; }
}
