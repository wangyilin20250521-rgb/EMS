import { useCallback, useEffect, useState } from "react";
import { Card } from "@/app/components/ui/card";
import { BloodProcessModal } from "./BloodProcessModal";
import { SiroProcessModal } from "./SiroProcessModal";
import { fetchBloodProcessList, fetchSiroProcessList } from "@/app/lib/api/siro";
import { SIRO_DEVICE_OPTIONS } from "@/app/lib/api";

/** 实验流程管理（2026-09-18 自数据字典独立）：分血流程与 SIRO 实验流程模板的统一入口。
 * 卡片规格对齐系统配置页（370px 等高）；中间按配置行样式展示各设备模板数量（弹窗增删后自动刷新）。 */

type DeviceCounts = Record<string, number>;

const emptyCounts = () => Object.fromEntries(SIRO_DEVICE_OPTIONS.map(d => [d, 0])) as DeviceCounts;

/**按设备类型归并计数（数量嵌在 process_info 下，API 侧下划线 / 展示侧连字符都兼容） */
function countByDevice(list: any[]): DeviceCounts {
  const counts = emptyCounts();
  for (const p of list) {
    const info = p.process_info ?? p;
    const t = String(info.device_type || info.deviceType || p.device_type || "").replace("_", "-").toUpperCase();
    const key = SIRO_DEVICE_OPTIONS.find(d => t === d);
    if (key) counts[key] += 1;
  }
  return counts;
}

export function ProcessManagement() {
  const [bloodOpen, setBloodOpen] = useState(false);
  const [siroOpen, setSiroOpen] = useState(false);
  const [bloodCounts, setBloodCounts] = useState<DeviceCounts>(emptyCounts);
  const [siroCounts, setSiroCounts] = useState<DeviceCounts>(emptyCounts);

  const loadStats = useCallback(() => {
    fetchBloodProcessList()
      .then((list: any[]) => setBloodCounts(countByDevice(list)))
      .catch(() => {});
    fetchSiroProcessList()
      .then((list: any[]) => setSiroCounts(countByDevice(list)))
      .catch(() => {});
  }, []);
  useEffect(() => { loadStats(); }, [loadStats]);

  const closeAndRefresh = (close: () => void) => () => { close(); loadStats(); };

  const renderRows = (counts: DeviceCounts) => (
    <div className="space-y-3">
      {SIRO_DEVICE_OPTIONS.map(d => (
        <div key={d} className="flex items-center justify-between">
          <p className="text-sm">{d}</p>
          <span className="text-sm text-muted-foreground">{counts[d]} 条</span>
        </div>
      ))}
    </div>
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 auto-rows-fr gap-5">
      <Card
        className="p-5 min-h-[370px] flex flex-col cursor-pointer transition-all hover:border-primary/30 hover:shadow-md"
        onClick={() => setBloodOpen(true)}
      >
        <h3 className="text-sm font-semibold mb-4">分血流程</h3>
        <div>{renderRows(bloodCounts)}</div>
      </Card>
      <Card
        className="p-5 min-h-[370px] flex flex-col cursor-pointer transition-all hover:border-primary/30 hover:shadow-md"
        onClick={() => setSiroOpen(true)}
      >
        <h3 className="text-sm font-semibold mb-4">实验流程（SIRO）</h3>
        <div>{renderRows(siroCounts)}</div>
      </Card>
      <BloodProcessModal open={bloodOpen} onClose={closeAndRefresh(() => setBloodOpen(false))} />
      <SiroProcessModal open={siroOpen} onClose={closeAndRefresh(() => setSiroOpen(false))} />
    </div>
  );
}
