import { useState, useCallback } from "react";
import { Download, } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { usePagination } from "@/app/hooks/usePagination";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { actionStyle } from "./shared";
import { LogTabs, type LogView, TIME_RANGES, rangeDates } from "./LogTabs";
import { getSystemLogs, exportSystemLogs, type SystemLogEntry as LogEntry } from "@/app/lib/api";
import { fmtBeijing } from "@/app/lib/utils/time";
import { triggerFileDownload } from "@/app/lib/utils/download";

export function OperationLog({ view, onViewChange }: { view: LogView; onViewChange: (v: LogView) => void }) {
  const [expanded, setExpanded] = useState<Set<number>>(new Set());
  const [exporting, setExporting] = useState(false);
  const [timeRange, setTimeRange] = useState<string>("全部");

  const fetchLogs = useCallback(async (params: { page?: number; pageSize?: number; module?: string; action?: string; dateFrom?: string; dateTo?: string }) => {
    return getSystemLogs({
      page: params.page,
      pageSize: params.pageSize,
      module: params.module && params.module !== '全部' ? params.module : undefined,
      action: params.action && params.action !== '全部' ? params.action : undefined,
      dateFrom: params.dateFrom || undefined,
      dateTo: params.dateTo || undefined,
    });
  }, []);

  const {
    items: pagedLogs,
    total,
    page,
    pageSize,
    loading,
    setPage,
    setPageSize,
    setFilters,
    filters,
  } = usePagination<LogEntry, { module?: string; action?: string; dateFrom?: string; dateTo?: string }>({
    fetcher: fetchLogs,
    initialPageSize: 20,
    initialFilters: { module: '全部', action: '全部', dateFrom: '', dateTo: '' },
  });

  const { module: moduleFilter = '全部', action: actionFilter = '全部', dateFrom = '', dateTo = '' } = filters;

  const handleExport = async () => {
    setExporting(true);
    try {
      const res = await exportSystemLogs({
        module: moduleFilter !== '全部' ? moduleFilter : undefined,
        action: actionFilter !== '全部' ? actionFilter : undefined,
        dateFrom: dateFrom || undefined,
        dateTo: dateTo || undefined,
      });
      triggerFileDownload(res.downloadUrl, res.filename);
    } catch { /* ignore */ } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <LogTabs view={view} onChange={onViewChange} />
        <div className="flex items-center gap-1 p-0.5 bg-muted rounded-lg">
          {TIME_RANGES.map(opt => (
            <button key={opt} onClick={() => setFilters({ ...filters, ...rangeDates(opt) })}
              className={`px-3 py-1 text-xs rounded-md transition-colors font-medium cursor-pointer ${timeRange === opt ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>
              {opt}
            </button>
          ))}
        </div>
        <Select onValueChange={v => setFilters({ ...filters, action: v })} value={actionFilter}>
  <SelectTrigger className="w-auto border border-border rounded-md px-3 py-1.5 text-sm bg-card focus:outline-none"><SelectValue /></SelectTrigger>
  <SelectContent>

          {["全部", "登记", "批次补录", "删除批次", "批量入库", "终止", "投递", "维护安排"].map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
        
  </SelectContent>
</Select>
        <Select onValueChange={v => setFilters({ ...filters, module: v })} value={moduleFilter}>
  <SelectTrigger className="w-auto border border-border rounded-md px-3 py-1.5 text-sm bg-card focus:outline-none"><SelectValue /></SelectTrigger>
  <SelectContent>

          {["全部", "收样中心", "样本中心", "任务管理", "测序对接", "设备管理"].map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
        
  </SelectContent>
</Select>
        <div className="ml-auto">
          <Button variant="outline" size="sm" onClick={() => { if (!exporting) handleExport(); }} className={exporting ? "opacity-50 pointer-events-none" : ""}>{exporting ? "导出中..." : <><Download size={12} />导出 Excel</>}</Button>
        </div>
      </div>

      <Table className="w-full text-sm">
            <TableHeader className="border-b border-border">
              <TableRow>{["操作时间", "操作人", "模块", "操作类型", "操作描述", "操作"].map(h => (
                <TableHead key={h} className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
              ))}</TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-border">
              {loading ? (
                <TableRow><TableCell colSpan={6} className="px-4 py-8 text-center text-sm text-muted-foreground">加载中...</TableCell></TableRow>
              ) : pagedLogs.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="px-4 py-8 text-center text-sm text-muted-foreground">暂无日志记录</TableCell></TableRow>
              ) : pagedLogs.map((l, i) => (
                <TableRow key={i} className="hover:bg-muted/20 transition-colors">
                  <TableCell className="px-3 py-3 font-mono text-sm text-muted-foreground whitespace-nowrap">{fmtBeijing(l.time)}</TableCell>
                  <TableCell className="px-3 py-3">
                    <p className="text-sm font-medium">{l.user}</p>
                    <p className="text-xs text-muted-foreground font-mono">{l.username}</p>
                  </TableCell>
                  <TableCell className="px-3 py-3 text-sm">{l.module}</TableCell>
                  <TableCell className="px-3 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${actionStyle(l.action)}`}>{l.action}</span>
                  </TableCell>
                  <TableCell className="px-3 py-3 text-sm text-muted-foreground max-w-xs">
                    <span className={`block ${expanded.has(i) ? "whitespace-pre-wrap break-words" : "truncate"}`}>{l.desc}{expanded.has(i) && l.ip ? `
[IP: ${l.ip}]` : ""}</span>
                  </TableCell>
                  <TableCell className="px-3 py-3">
                    <Button variant="ghost" size="sm" onClick={() => setExpanded(prev => {
                      const next = new Set(prev);
                      if (next.has(i)) next.delete(i); else next.add(i);
                      return next;
                    })}>{expanded.has(i) ? "收起" : "详情"}</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

      <PaginationBar page={page} pageSize={pageSize} total={total} onPageChange={(p) => { setExpanded(new Set()); setPage(p); }} onPageSizeChange={(s) => { setExpanded(new Set()); setPageSize(s); }} />
    </div>
  );
}

