import React, { useState } from "react";
import {
  Users, Settings, FileText, Workflow, BookOpen, Database,
} from "lucide-react";
import { UserRoleManagement } from "./UserRoleManagement";
import { SystemConfig } from "./SystemConfigPanel";
import { LogCenter } from "./LogCenter";
import { DataDictionary } from "./DataDictionary";
import { ProcessManagement } from "./ProcessManagement";
import { DataMaintenance } from "./DataMaintenance";
import type { SubPage } from "./shared";

/**
 * 系统设置（2026-09-18 迁移后）：仅保留各医院/项目分支通用的平台级配置与系统管理工具。
 * 医院档案已迁至「解决方案」模块（features/solutions/），基础配置与接口卡归各方案详情功能卡。
 * 数据维护 2026-09-18 定案回归此处：备份/恢复/演示数据操作运行态数据库，与方案模板无耦合，
 * 与用户/日志/字典同属管理员系统工具。
 * 数据字典亦在此（定案：字典内容为平台通用设计——检测项目等不随项目变化；
 * 个别医院差异仍可经方案 dictOverrides 出厂覆盖）。
 */

const NAV_ITEMS: Array<{ id: SubPage; icon: React.ElementType; label: string }> = [
  { id: "用户与角色", icon: Users,   label: "用户与角色" },
  { id: "数据字典", icon: BookOpen,  label: "数据字典" },
  { id: "系统配置", icon: Settings,  label: "系统配置" },
  { id: "实验流程", icon: Workflow,  label: "实验流程" },
  { id: "数据维护", icon: Database,  label: "数据维护" },
  { id: "日志", icon: FileText,    label: "日志" },
];

export function SystemManagementContent() {
  const [subPage, setSubPage] = useState<SubPage>("用户与角色");

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Top tabs navigation */}
      <div className="border-b border-border bg-card px-6 pt-2">
        <div className="flex items-center gap-1">
          {NAV_ITEMS.map(item => {
            const Icon = item.icon;
            const isActive = subPage === item.id;
            return (
              <button key={item.id} onClick={() => setSubPage(item.id)}
                className={`flex items-center gap-2 px-4 py-2.5 border-b-2 -mb-px text-sm font-medium transition-colors cursor-pointer ${isActive ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"}`}>
                <Icon size={14} className="shrink-0" />
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 p-6 overflow-y-auto">
        {subPage === "用户与角色" && <UserRoleManagement />}
        {subPage === "系统配置" && <SystemConfig />}
        {subPage === "日志" && <LogCenter />}
        {subPage === "数据字典" && <DataDictionary />}
        {subPage === "实验流程" && <ProcessManagement />}
        {subPage === "数据维护" && <DataMaintenance />}
      </div>
    </div>
  );
}

export const SystemManagementPage = SystemManagementContent;
