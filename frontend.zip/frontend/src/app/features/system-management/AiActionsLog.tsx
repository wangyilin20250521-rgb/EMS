import { useState, useCallback } from "react";
import { Download, RefreshCw } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { usePagination } from "@/app/hooks/usePagination";
import { LogTabs, type LogView } from "./LogTabs";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { getAiActions, type AiActionRow } from "@/app/lib/api";
import { fmtBeijing } from "@/app/lib/utils/time";

const AI_ACTION_STATUS: Record<string, { label: string; className: string }> = {
  pending:   { label: "待确认", className: "bg-ai-accent/20 text-ai-accent" },
  confirmed: { label: "已执行", className: "bg-chart-2/20 text-chart-2" },
  cancelled: { label: "已取消", className: "bg-muted text-muted-foreground" },
  failed:    { label: "执行失败", className: "bg-destructive/15 text-destructive" },
  expired:   { label: "已过期", className: "bg-muted text-muted-foreground" },
};

export function AiActionsLog({ view, onViewChange }: { view: LogView; onViewChange: (v: LogView) => void }) {
  const [expandedArgs, setExpandedArgs] = useState<Set<number>>(new Set());
  const [exporting, setExporting] = useState(false);

  const fetchActions = useCallback(async (params: { page?: number; pageSize?: number }) => {
    return getAiActions({
      page: params.page,
      pageSize: params.pageSize,
    });
  }, []);

  const {
    items: aiActions,
    total,
    page,
    pageSize,
    loading,
    setPage,
    refresh,
  } = usePagination<AiActionRow>({
    fetcher: fetchActions,
    initialPageSize: 20,
  });

  const handleExport = async () => {
    setExporting(true);
    try {
      const res = await getAiActions({ page: 1, pageSize: 500 });
      // 导出为 CSV（前端轻量实现，避免引入 xlsx 依赖）
      const header = ["时间", "工具", "摘要", "状态", "提议人", "确认人", "参数", "错误"];
      const rows = res.items.map((r) => [
        r.created_at, r.tool_name, `"${(r.summary ?? "").replace(/"/g, '""')}"`, r.status,
        r.username, r.confirm_username ?? "", `"${JSON.stringify(r.args).replace(/"/g, '""')}"`,
        r.error ? `"${r.error.replace(/"/g, '""')}"` : "",
      ]);
      const csv = [header.join(","), ...rows.map((r) => r.join(","))].join("\n");
      const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `AI操作审计_${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch { /* ignore */ } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <LogTabs view={view} onChange={onViewChange} />
        <div className="ml-auto flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={refresh} disabled={loading}>
            <RefreshCw size={12} className={loading ? "animate-spin" : ""} />刷新
          </Button>
          <Button variant="outline" size="sm" onClick={() => { if (!exporting) void handleExport(); }} className={exporting ? "opacity-50 pointer-events-none" : ""}>
            {exporting ? "导出中..." : <><Download size={12} />导出 CSV</>}
          </Button>
        </div>
      </div>

      <Table className="w-full text-sm">
        <TableHeader className="border-b border-border">
              <TableRow>{["操作时间", "工具", "摘要", "状态", "提议人", "确认人", "参数"].map((h) => (
                <TableHead key={h} className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
              ))}</TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-border">
              {loading ? (
                <TableRow><TableCell colSpan={7} className="px-3 py-8 text-center text-sm text-muted-foreground">加载中...</TableCell></TableRow>
              ) : aiActions.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="px-3 py-8 text-center text-sm text-muted-foreground">暂无 AI 操作记录（AI 提议写操作后才会留痕）</TableCell></TableRow>
              ) : aiActions.map((r) => {
                const meta = AI_ACTION_STATUS[r.status] ?? { label: r.status, className: "bg-muted text-muted-foreground" };
                const expanded = expandedArgs.has(r.id);
                return (
                  <TableRow key={r.id} className="hover:bg-muted/20 transition-colors">
                    <TableCell className="px-3 py-3 font-mono text-sm text-muted-foreground whitespace-nowrap">
                      {fmtBeijing(r.created_at)}
                    </TableCell>
                    <TableCell className="px-3 py-3 font-mono text-sm">{r.tool_name}</TableCell>
                    <TableCell className="px-3 py-3 text-sm text-muted-foreground max-w-xs truncate" title={r.summary}>
                      {r.summary || "—"}
                    </TableCell>
                    <TableCell className="px-3 py-3">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${meta.className}`}>{meta.label}</span>
                    </TableCell>
                    <TableCell className="px-3 py-3 text-sm">{r.username}</TableCell>
                    <TableCell className="px-3 py-3 text-sm">{r.confirm_username ?? "—"}</TableCell>
                    <TableCell className="px-3 py-3 text-sm">
                      <button type="button" onClick={() => setExpandedArgs(prev => {
                        const next = new Set(prev);
                        if (next.has(r.id)) next.delete(r.id); else next.add(r.id);
                        return next;
                      })} className="text-primary hover:underline cursor-pointer">
                        {expanded ? "收起" : "查看"}
                      </button>
                      {expanded && (
                        <pre className="mt-1 max-h-32 overflow-auto whitespace-pre-wrap break-words rounded bg-muted/60 border border-border px-2 py-1 font-mono text-[10px] leading-4 text-muted-foreground">
                          {JSON.stringify(r.args, null, 2)}
                          {r.error ? `\n错误: ${r.error}` : ""}
                        </pre>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          <PaginationBar page={page} total={total} onPageChange={setPage} pageSize={pageSize} />
    </div>
  );
}
