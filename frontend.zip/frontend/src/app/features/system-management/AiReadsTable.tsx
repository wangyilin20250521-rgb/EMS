import { useState, useCallback } from "react";
import { RefreshCw, Download } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { usePagination } from "@/app/hooks/usePagination";
import { LogTabs, type LogView } from "./LogTabs";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { getAiReads, type AiReadRow } from "@/app/lib/api";
import { fmtBeijing } from "@/app/lib/utils/time";

const READ_MODES: Record<string, { label: string; className: string }> = {
  query_database: { label: "自由查询", className: "bg-chart-2/20 text-chart-2" },
  bridge:         { label: "业务查询", className: "bg-primary/15 text-primary" },
  kb:             { label: "知识库", className: "bg-ai-accent/20 text-ai-accent" },
};

/** AI 读操作审计（2026-09-11 ai_reads）：自由 SQL / 只读桥 / KB 检索的"谁查了什么"留痕 */
export function AiReadsTable({ view, onViewChange }: { view: LogView; onViewChange: (v: LogView) => void }) {
  const [expandedTargets, setExpandedTargets] = useState<Set<number>>(new Set());
  const [exporting, setExporting] = useState(false);

  const fetchReads = useCallback(async (params: { page?: number; pageSize?: number }) => {
    return getAiReads({
      page: params.page,
      pageSize: params.pageSize,
    });
  }, []);

  const {
    items: reads,
    total,
    page,
    pageSize,
    loading,
    setPage,
    refresh,
  } = usePagination<AiReadRow>({
    fetcher: fetchReads,
    initialPageSize: 20,
  });

  const handleExport = async () => {
    setExporting(true);
    try {
      const res = await getAiReads({ page: 1, pageSize: 500 });
      const esc = (s: string) => `"${s.replace(/"/g, '""')}"`;
      const rows = res.items.map((r) => [
        fmtBeijing(r.ts),
        READ_MODES[r.mode]?.label ?? r.mode,
        esc(r.target),
        r.ok ? (r.row_count != null ? `${r.row_count} 行` : "成功") : "失败",
        r.duration_ms != null ? String(r.duration_ms) : "",
        esc(r.username),
        esc(r.error ?? ""),
      ].join(","));
      const csv = "\uFEFF" + [["时间", "方式", "查询内容", "结果", "耗时(ms)", "查询人", "错误"].join(","), ...rows].join("\n");
      const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = `AI读操作审计_${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch { /* ignore */ } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <LogTabs view={view} onChange={onViewChange} />
        <div className="ml-auto flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExport} disabled={exporting}>
            <Download size={12} />{exporting ? "导出中..." : "导出 CSV"}
          </Button>
          <Button variant="outline" size="sm" onClick={refresh} disabled={loading}>
            <RefreshCw size={12} className={loading ? "animate-spin" : ""} />刷新
          </Button>
        </div>
      </div>

      <Table className="w-full text-sm">
        <TableHeader className="border-b border-border">
              <TableRow>{["时间", "方式", "查询内容", "结果", "耗时", "查询人"].map((h) => (
                <TableHead key={h} className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
              ))}</TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-border">
              {loading ? (
                <TableRow><TableCell colSpan={6} className="px-3 py-8 text-center text-sm text-muted-foreground">加载中...</TableCell></TableRow>
              ) : reads.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="px-3 py-8 text-center text-sm text-muted-foreground">暂无 AI 读操作记录（AI 执行查询后才会留痕）</TableCell></TableRow>
              ) : reads.map((r) => {
                const meta = READ_MODES[r.mode] ?? { label: r.mode, className: "bg-muted text-muted-foreground" };
                const expanded = expandedTargets.has(r.id);
                return (
                  <TableRow key={r.id} className="hover:bg-muted/20 transition-colors">
                    <TableCell className="px-3 py-3 font-mono text-sm text-muted-foreground whitespace-nowrap">
                      {fmtBeijing(r.ts)}
                    </TableCell>
                    <TableCell className="px-3 py-3 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${meta.className}`}>{meta.label}</span>
                      {r.tool_name && <span className="ml-2 font-mono text-xs text-muted-foreground">{r.tool_name}</span>}
                    </TableCell>
                    <TableCell className="px-3 py-3 text-sm max-w-md">
                      <button type="button" onClick={() => setExpandedTargets(prev => {
                        const next = new Set(prev);
                        if (next.has(r.id)) next.delete(r.id); else next.add(r.id);
                        return next;
                      })} className={`text-left cursor-pointer ${expanded ? "whitespace-pre-wrap break-all font-mono text-xs" : "truncate w-full text-muted-foreground"}`} title={r.target}>
                        {r.target}
                      </button>
                      {expanded && r.error && (
                        <pre className="mt-1 max-h-32 overflow-auto whitespace-pre-wrap break-words rounded bg-destructive/10 border border-border px-2 py-1 font-mono text-[10px] leading-4 text-destructive">
                          错误: {r.error}
                        </pre>
                      )}
                    </TableCell>
                    <TableCell className="px-3 py-3 text-sm whitespace-nowrap">
                      {r.ok
                        ? <span className="text-chart-2">{r.row_count != null ? `${r.row_count} 行` : "成功"}</span>
                        : <span className="text-destructive">失败</span>}
                    </TableCell>
                    <TableCell className="px-3 py-3 font-mono text-sm text-muted-foreground whitespace-nowrap">
                      {r.duration_ms != null ? `${r.duration_ms} ms` : "—"}
                    </TableCell>
                    <TableCell className="px-3 py-3 text-sm whitespace-nowrap">{r.username}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
          <PaginationBar page={page} total={total} onPageChange={setPage} pageSize={pageSize} />
    </div>
  );
}
