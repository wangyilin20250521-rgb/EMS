import React, { useEffect, useState, useCallback, useRef } from "react"
import { fetchBloodProcessList, importBloodProcess, deleteBloodProcess } from "@/app/lib/api/siro"
import { SIRO_DEVICE_OPTIONS } from "@/app/lib/api"
import { Button } from "@/app/components/ui/button";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/app/components/ui/dialog"
import { Download, Loader, Plus, Trash2 } from "lucide-react"
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";

function formatBeijingTime(isoStr: string | undefined): string {
  if (!isoStr) return "-"
  const d = new Date(isoStr)
  const beijing = new Date(d.getTime() + 8 * 60 * 60 * 1000)
  return beijing.toISOString().replace("T", " ").replace(/\.\d{3}Z$/, "")
}

function triggerJsonDownload(item: any) {
  const blob = new Blob([JSON.stringify(item, null, 2)], { type: "application/json" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = `${item.process_no || "blood-process"}.json`
  a.click()
  URL.revokeObjectURL(url)
}

interface Props {
  open: boolean
  onClose: () => void
}

export function BloodProcessModal({ open, onClose }: Props) {
  const [processes, setProcesses] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [importError, setImportError] = useState<string | null>(null)
  const [importing, setImporting] = useState(false)
  const [deleting, setDeleting] = useState<string | null>(null)
  const [deviceFilter, setDeviceFilter] = useState<string>("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const loadProcesses = useCallback(async () => {
    setLoading(true); setError(null)
    try { setProcesses(await fetchBloodProcessList()) } catch (err: any) { setError(err?.message || "加载失败") }
    finally { setLoading(false) }
  }, [])

  const filtered = deviceFilter
    ? processes.filter(p => {
        const info = typeof p.process_info === "string" ? JSON.parse(p.process_info) : (p.process_info || {})
        return info.deviceType === deviceFilter || info.device_type === deviceFilter
      })
    : processes

  useEffect(() => { if (open) loadProcesses() }, [open, loadProcesses])

  const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setImportError(null); setImporting(true)
    try {
      const text = await file.text()
      const parsed = JSON.parse(text)
      if (!Array.isArray(parsed)) { setImportError("分血流程格式错误：根节点必须是数组"); return }
      for (let i = 0; i < parsed.length; i++) {
        const m = parsed[i]
        if (!m.methodId || !m.methodName) { setImportError(`第 ${i + 1} 个分血方法缺少必填字段（methodId / methodName）`); return }
        if (!m.deviceType) { setImportError(`第 ${i + 1} 个分血方法缺少 deviceType`); return }
        if (!m.workbench || !Array.isArray(m.workbench.columns)) { setImportError(`第 ${i + 1} 个分血方法缺少 workbench.columns`); return }
        if (m.workbench.columns.length === 0) { setImportError(`第 ${i + 1} 个分血方法的 workbench.columns 不能为空`); return }
      }
      await importBloodProcess(parsed)
      await loadProcesses()
    } catch (err: any) {
      setImportError(err instanceof SyntaxError ? "JSON 格式不合法" : (err?.message || "导入失败"))
    } finally {
      setImporting(false)
      if (fileInputRef.current) fileInputRef.current.value = ""
    }
  }

  const handleDelete = async (processNo: string) => {
    if (!confirm(`确定删除流程 ${processNo}？`)) return
    setDeleting(processNo)
    try { await deleteBloodProcess(processNo); await loadProcesses() } catch (err: any) { setError(err?.message || "删除失败") }
    finally { setDeleting(null) }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose() }}>
      <DialogContent className="!max-w-[70vw] h-[65vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>流程管理（分血）</DialogTitle>
        </DialogHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Select onValueChange={v => setDeviceFilter(v)} value={deviceFilter}>
  <SelectTrigger className="w-auto text-xs border border-border rounded-md px-2 py-1.5 bg-card focus:outline-none focus:ring-2 focus:ring-ring"><SelectValue placeholder="全部设备类型" /></SelectTrigger>
  <SelectContent>

              
              {SIRO_DEVICE_OPTIONS.map(d => {
                const apiName = d.replace("-", "_");
                return <SelectItem key={d} value={apiName}>{apiName}</SelectItem>;
              })}
            
  </SelectContent>
</Select>
            <span className="text-xs text-muted-foreground">{filtered.length > 0 ? `共 ${filtered.length} 条` : ""}</span>
          </div>
          <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-medium cursor-pointer hover:bg-primary/90">
            <Plus size={12} />{importing ? <><Loader size={12} className="animate-spin" />导入中...</> : "导入流程"}
            <input ref={fileInputRef} type="file" accept=".json" className="hidden" onChange={handleFileImport} disabled={importing} />
          </label>
        </div>
        {importError && <p className="text-xs text-red-600">{importError}</p>}
        <div className="flex-1 overflow-y-auto min-h-0">
          {loading ? (
            <div className="flex items-center justify-center py-16 text-muted-foreground"><Loader size={16} className="animate-spin mr-2" />加载中...</div>
          ) : error ? (
            <div className="flex flex-col items-center py-12 gap-2 text-red-600"><p className="text-sm">{error}</p><Button variant="ghost" onClick={loadProcesses}>重试</Button></div>
          ) : filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-16">{deviceFilter ? `暂无 ${deviceFilter} 类型的分血流程` : "暂无分血流程"}</p>
          ) : (
            <div className="overflow-x-auto border border-border rounded-lg">
              <Table className="w-full text-sm">
                <TableHeader className="bg-muted/40 border-b border-border">
                  <TableRow>{["流程编号","名称","设备类型","创建时间","操作"].map(h => <TableHead key={h} className="text-left px-4 py-2.5 text-sm font-semibold text-foreground">{h}</TableHead>)}</TableRow>
                </TableHeader>
                <TableBody className="divide-y divide-border">
                  {filtered.map((p: any) => {
                    const info = typeof p.process_info === "string" ? JSON.parse(p.process_info) : (p.process_info || {})
                    return (
                      <TableRow key={p.process_no} className="hover:bg-muted/20">
                        <TableCell className="px-4 py-2.5 font-mono text-sm">{p.process_no}</TableCell>
                        <TableCell className="px-4 py-2.5">{info.process_name || info.methodName || "-"}</TableCell>
                        <TableCell className="px-4 py-2.5 text-sm text-muted-foreground">{info.device_type || info.deviceType || "-"}</TableCell>
                        <TableCell className="px-4 py-2.5 text-sm text-muted-foreground">{formatBeijingTime(p.create_time)}</TableCell>
                        <TableCell className="px-4 py-2.5">
                          <div className="flex gap-1">
                            <button onClick={() => triggerJsonDownload(p)} className="inline-flex items-center gap-1 px-2 py-1 text-xs text-muted-foreground hover:text-primary rounded cursor-pointer"><Download size={11} />下载</button>
                            <button onClick={() => handleDelete(p.process_no)} disabled={deleting === p.process_no} className="inline-flex items-center gap-1 px-2 py-1 text-xs text-muted-foreground hover:text-red-600 rounded cursor-pointer disabled:opacity-50">{deleting === p.process_no ? <Loader size={11} className="animate-spin" /> : <Trash2 size={11} />}删除</button>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
