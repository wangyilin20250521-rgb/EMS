import React, { useEffect, useState, useCallback } from "react"
import { fetchSiroProcessList, importSiroProcess, deleteSiroProcess } from "@/app/lib/api/siro"
import { SIRO_DEVICE_OPTIONS } from "@/app/lib/api"
import { Button } from "@/app/components/ui/button";

import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/app/components/ui/dialog"
import { Download, Loader, Plus, Trash2 } from "lucide-react"
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";

interface ProcessItem {
  process_no: string
  create_time?: string
  process_info?: Record<string, any>
  steps?: any[]
}

async function triggerJsonDownload(process: ProcessItem) {
  // Fetch full detail to get steps
  const { getSiroProcessDetail } = await import("@/app/lib/api/siro")
  const detail = await getSiroProcessDetail(process.process_no)
  const full = detail || process
  const blob = new Blob([JSON.stringify(full, null, 2)], { type: "application/json" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = `${process.process_no}.json`
  a.click()
  URL.revokeObjectURL(url)
}

function formatBeijingTime(isoStr: string | undefined): string {
  if (!isoStr) return "-"
  const d = new Date(isoStr)
  const beijing = new Date(d.getTime() + 8 * 60 * 60 * 1000)
  return beijing.toISOString().replace("T", " ").replace(/\.\d{3}Z$/, "")
}

function parseProcessInfo(process: ProcessItem): Record<string, any> {
  const raw = process.process_info
  if (!raw) return {}
  return typeof raw === "string" ? JSON.parse(raw) : raw
}

interface Props {
  open: boolean
  onClose: () => void
}

export function SiroProcessModal({ open, onClose }: Props) {
  const [processes, setProcesses] = useState<ProcessItem[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Import state
  const [importError, setImportError] = useState<string | null>(null)
  const [importing, setImporting] = useState(false)

  const [deleting, setDeleting] = useState<string | null>(null)
  const [deviceFilter, setDeviceFilter] = useState<string>("")

  const loadProcesses = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const list = await fetchSiroProcessList(deviceFilter || undefined)
      setProcesses(list)
    } catch (err: any) {
      setError(err?.message || "加载失败")
    } finally {
      setLoading(false)
    }
  }, [deviceFilter])

  useEffect(() => {
    if (open) loadProcesses()
  }, [open, loadProcesses])

  const fileInputRef = React.useRef<HTMLInputElement>(null)

  const handleFileImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setImportError(null)
    setImporting(true)
    try {
      const text = await file.text()
      const parsed = JSON.parse(text)
      if (Array.isArray(parsed)) {
        setImportError("检测到分血流程格式，请在「样本制备 → 流程管理（分血）」中导入")
        return
      }
      if (!parsed.process_info || typeof parsed.process_info !== "object") {
        setImportError("缺少 process_info 字段")
        return
      }
      if (!Array.isArray(parsed.steps)) {
        setImportError("steps 必须是数组")
        return
      }
      await importSiroProcess(parsed.process_info, parsed.steps)
      await loadProcesses()
    } catch (err: any) {
      if (err instanceof SyntaxError) {
        setImportError("JSON 格式不合法")
      } else {
        setImportError(err?.message || "导入失败")
      }
    } finally {
      setImporting(false)
      // Reset file input so same file can be re-selected
      if (fileInputRef.current) fileInputRef.current.value = ""
    }
  }

  const handleDelete = async (processNo: string) => {
    if (!confirm(`确定删除流程 ${processNo}？`)) return
    setDeleting(processNo)
    try {
      await deleteSiroProcess(processNo)
      await loadProcesses()
    } catch (err: any) {
      setError(err?.message || "删除失败")
    } finally {
      setDeleting(null)
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose() }}>
      <DialogContent className="!max-w-[70vw] h-[65vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            SIRO 流程管理
          </DialogTitle>
        </DialogHeader>

        {/* Toolbar */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Select onValueChange={v => setDeviceFilter(v)} value={deviceFilter}>
  <SelectTrigger className="w-auto text-xs border border-border rounded-md px-2 py-1.5 bg-card focus:outline-none focus:ring-2 focus:ring-ring"><SelectValue placeholder="全部设备类型" /></SelectTrigger>
  <SelectContent>

              
              {SIRO_DEVICE_OPTIONS.map(d => {
                const apiName = d.replace("-", "_");
                return <SelectItem key={d} value={apiName}>{apiName}</SelectItem>;
              })}
            
  </SelectContent>
</Select>
            <span className="text-xs text-muted-foreground">
              {processes.length > 0 ? `共 ${processes.length} 条流程` : ""}
            </span>
          </div>
          <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-medium cursor-pointer hover:bg-primary/90 transition-colors">
            <Plus size={12} />
            {importing ? <><Loader size={12} className="animate-spin" />导入中...</> : "导入流程"}
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleFileImport}
              disabled={importing}
            />
          </label>
        </div>

        {importError && (
          <p className="text-xs text-red-600 px-1">{importError}</p>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto min-h-0">
          {loading && (
            <div className="flex items-center justify-center py-16 text-muted-foreground gap-2">
              <Loader size={16} className="animate-spin" /> 加载中...
            </div>
          )}

          {error && (
            <div className="flex flex-col items-center justify-center py-12 gap-2 text-red-600">
              <p className="text-sm">{error}</p>
              <Button variant="ghost" onClick={loadProcesses}>重试</Button>
            </div>
          )}

          {!loading && !error && processes.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-2">
              <p className="text-sm">暂无流程</p>
              <p className="text-xs">点击"导入流程"手动上传，或等待开发者平台推送</p>
            </div>
          )}

          {!loading && !error && processes.length > 0 && (
            <div className="overflow-x-auto border border-border rounded-lg">
              <Table className="w-full text-sm">
                <TableHeader className="bg-muted/40 border-b border-border">
                  <TableRow>
                    {["流程编号", "名称", "设备类型", "版本", "创建时间", "操作"].map((h) => (
                      <TableHead key={h} className={`text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap ${h === "名称" ? "w-[35%]" : ""}`}>{h}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody className="divide-y divide-border">
                  {processes.map((p) => {
                    const info = parseProcessInfo(p)
                    return (
                      <TableRow key={p.process_no} className="hover:bg-muted/20 transition-colors">
                        <TableCell className="px-4 py-2.5 font-mono text-sm whitespace-nowrap">{p.process_no}</TableCell>
                        <TableCell className="px-4 py-2.5 max-w-xs">{info.process_name || "-"}</TableCell>
                        <TableCell className="px-4 py-2.5 text-sm text-muted-foreground">{info.device_type || "-"}</TableCell>
                        <TableCell className="px-4 py-2.5 text-sm">{info.current_version || "-"}</TableCell>
                        <TableCell className="px-4 py-2.5 text-sm text-muted-foreground">{formatBeijingTime(p.create_time)}</TableCell>
                        <TableCell className="px-4 py-2.5">
                          <div className="flex gap-1">
                            <button
                              onClick={() => triggerJsonDownload(p)}
                              className="inline-flex items-center gap-1 px-2 py-1 text-xs text-muted-foreground hover:text-primary hover:bg-primary/5 rounded transition-colors cursor-pointer"
                            >
                              <Download size={11} />下载
                            </button>
                            <button
                              onClick={() => handleDelete(p.process_no)}
                              disabled={deleting === p.process_no}
                              className="inline-flex items-center gap-1 px-2 py-1 text-xs text-muted-foreground hover:text-red-600 hover:bg-red-50 rounded transition-colors cursor-pointer disabled:opacity-50"
                            >
                              {deleting === p.process_no ? (
                                <Loader size={11} className="animate-spin" />
                              ) : (
                                <Trash2 size={11} />
                              )}删除
                            </button>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
