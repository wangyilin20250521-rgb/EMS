import { useState, useEffect } from "react";
import { z } from "zod";
import { Save, RefreshCw } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { useFormValidation } from "@/app/hooks/useFormValidation";
import { useDarkMode } from "@/app/hooks/useDarkMode";
import { FieldErrorText, FormErrorSummary, Toggle } from "./shared";
import { getSystemConfig, updateSystemSecurityConfig } from "@/app/lib/api";
import { toast } from "sonner";

/**
 * 系统配置（2026-09-18 迁移后瘦身）：仅保留各项目分支通用的平台级配置。
 * 基础配置与 HIS/OmicsOne/测序接口卡已迁至「解决方案 → 对应方案」（基础配置/接口配置卡，2026-09-18）。
 */

const securityConfigSchema = z.object({
  timeout: z.coerce.number().int("会话超时必须为整数").min(5, "会话超时不能少于 5 分钟").max(480, "会话超时不能超过 480 分钟"),
  lockCount: z.coerce.number().int("锁定次数必须为整数").min(1, "锁定次数不能少于 1 次").max(20, "锁定次数不能超过 20 次"),
  lockTime: z.coerce.number().int("锁定时间必须为整数").min(1, "锁定时间不能少于 1 分钟").max(1440, "锁定时间不能超过 1440 分钟"),
  pwdCycle: z.coerce.number().int("密码周期必须为整数").min(1, "密码周期不能少于 1 天").max(365, "密码周期不能超过 365 天"),
  desensitize: z.boolean(),
});

export function SystemConfig() {
  const [security, setSecurity] = useState({ timeout: 30, lockCount: 5, lockTime: 30, pwdCycle: 90, desensitize: true });
  const [configLoading, setConfigLoading] = useState(true);
  const [savingSecurity, setSavingSecurity] = useState(false);
  const securityValidation = useFormValidation(securityConfigSchema);

  useEffect(() => {
    getSystemConfig()
      .then(cfg => setSecurity(cfg.security))
      .catch(() => {})
      .finally(() => setConfigLoading(false));
  }, []);

  const saveSecurityConfig = async () => {
    const result = securityValidation.validate(security);
    if (!result.success) return;
    setSavingSecurity(true);
    try {
      await updateSystemSecurityConfig(security);
      toast.success("安全配置已保存");
    } catch (err: any) {
      toast.error(err?.message || "保存安全配置失败");
    } finally {
      setSavingSecurity(false);
    }
  };

  // 外观配置：深色模式（系统配置页明暗切换卡片，与侧边栏底部切换按钮并存）
  const { dark, toggle: toggleDark } = useDarkMode();

  if (configLoading) {
    return (
      <div className="flex items-center justify-center py-16 text-muted-foreground text-sm gap-2">
        <RefreshCw size={16} className="animate-spin" />加载配置中...
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 auto-rows-fr gap-5">
      {/* 外观配置（B 设计：深色模式 + 界面语言） */}
      <Card className="p-5 flex flex-col">
        <h3 className="text-sm font-semibold mb-4">外观配置</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">深色模式</p>
              <p className="text-xs text-muted-foreground">开启后界面切换为深色外观，设置自动持久化</p>
            </div>
            <Toggle enabled={dark} onChange={toggleDark} />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">界面语言</p>
              <p className="text-xs text-muted-foreground">切换界面文案显示语言</p>
            </div>
            <div className="flex items-center gap-1 border border-border rounded-md p-0.5">
              <button className="text-xs px-2.5 py-1 rounded bg-primary/10 text-primary font-medium cursor-default">简体中文</button>
              <button onClick={() => toast.info("英文支持即将上线")} className="text-xs px-2.5 py-1 rounded text-muted-foreground hover:text-foreground transition-colors cursor-pointer">English</button>
            </div>
          </div>
        </div>
      </Card>

      {/* 安全配置 */}
      <Card className="p-5 flex flex-col">
        <h3 className="text-sm font-semibold mb-4">安全配置</h3>
        <FormErrorSummary errors={securityValidation.errors} />
        <div className="space-y-4">
          {[
            { key: "timeout" as const,   label: "会话超时（分钟）",     suffix: "分钟" },
            { key: "lockCount" as const, label: "登录失败锁定次数",     suffix: "次" },
            { key: "lockTime" as const,  label: "锁定时间（分钟）",     suffix: "分钟" },
            { key: "pwdCycle" as const,  label: "密码更换周期（天）",   suffix: "天" },
          ].map(f => (
            <div key={f.key} className="flex items-center justify-between">
              <label className="text-sm">{f.label}</label>
              <div className="flex items-center gap-2">
                <input type="number" value={security[f.key]} onChange={e => setSecurity(p => ({ ...p, [f.key]: +e.target.value }))}
                  onFocus={() => securityValidation.clearErrors(f.key)}
                  className={`w-20 border rounded-md px-2 py-1 text-sm text-center focus:outline-none focus:ring-2 focus:ring-ring ${securityValidation.getFieldError(f.key) ? "border-red-300 bg-red-50/30" : "border-border"}`} />
                <span className="text-xs text-muted-foreground w-10">{f.suffix}</span>
              </div>
              <FieldErrorText error={securityValidation.getFieldError(f.key)} />
            </div>
          ))}
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm">数据脱敏</p>
              <p className="text-xs text-muted-foreground">开启后患者信息脱敏显示</p>
            </div>
            <Toggle enabled={security.desensitize} onChange={() => setSecurity(p => ({ ...p, desensitize: !p.desensitize }))} />
          </div>
        </div>
        <div className="mt-auto pt-4 flex justify-end">
          <Button variant="default" size="sm" onClick={saveSecurityConfig} className={savingSecurity ? "opacity-50 pointer-events-none" : ""}>
            <Save size={12} />{savingSecurity ? "保存中..." : "保存"}
          </Button>
        </div>
      </Card>

    </div>
  );
}
