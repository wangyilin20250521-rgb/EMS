import { useState, useEffect } from "react";
import { Plus, Trash2, RefreshCw } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { useConfirm } from "@/app/components/shared/ConfirmDialog";
import { createDictItem, updateDictItem, deleteDictItem, getDictItems, getDictCategories, getDictMeta, deleteDictCategory } from "@/app/lib/api/system";
import { DICT_CATEGORIES } from "@/app/lib/api";
import { toast } from "sonner";

export function DataDictionary() {
  const [selectedCat, setSelectedCat] = useState<string>("样本类型");
  const [itemsMap, setItemsMap] = useState<Record<string, Array<{ code: string; name: string; sort: number; status: string }>>>({});
  const [loadingItems, setLoadingItems] = useState(false);
  const [showItemModal, setShowItemModal] = useState(false);
  const [editItem, setEditItem] = useState<{ code: string; name: string; sort: string; status: string } | null>(null);
  const [isNewItem, setIsNewItem] = useState(false);
  // 自定义字典分类（预置 8 个之外的动态分类）+ 分类描述；
  // 2026-09-21 起新增入口已移除，仅展示/删除存量自定义分类
  const [customCategories, setCustomCategories] = useState<string[]>([]);
  const [dictMeta, setDictMeta] = useState<Record<string, { description?: string }>>({});

  const items = itemsMap[selectedCat] ?? [];

  // 系统预置分类（硬编码分组，展开为全集用于区分自定义）
  const PRESET_CATS = Object.values(DICT_CATEGORIES).flat();

  // 加载自定义分类（后端 dict:* 全集 - 预置）+ 分类描述
  useEffect(() => {
    getDictCategories().then(all => {
      setCustomCategories(Object.keys(all).filter(c => !PRESET_CATS.includes(c)));
    }).catch(() => {});
    getDictMeta().then(setDictMeta).catch(() => {});
  }, []); // 仅挂载时加载一次

  // 分类切换时从后端 API 刷新数据
  useEffect(() => {
    if (!selectedCat) return;
    setLoadingItems(true);
    getDictItems(selectedCat).then(data => {
      if (Array.isArray(data) && data.length > 0) {
        setItemsMap(prev => ({ ...prev, [selectedCat]: data.map(item => ({ ...item })) }));
      }
    }).catch(() => { /* 后端不可用时保留已有数据 */ })
      .finally(() => setLoadingItems(false));
  }, [selectedCat]);

  const handleDeleteCategory = async (cat: string) => {
    const ok = await confirm({
      title: "删除字典分类",
      message: `确认删除分类「${cat}」？其字典项与定制字段入口将一并移除（历史样本数据保留）`,
      variant: "danger",
    });
    if (!ok) return;
    try {
      await deleteDictCategory(cat);
      toast.success(`分类「${cat}」已删除`);
      setCustomCategories(prev => prev.filter(c => c !== cat));
      if (selectedCat === cat) setSelectedCat("样本类型");
    } catch (e: any) {
      toast.error(e?.message || "删除分类失败");
    }
  };

  const displayItems = items;

  const openNewItem = () => {
    setIsNewItem(true);
    // 编码 / 排序均自动分配（编码 AUTO{n}、排序按现有项数递增），无需用户输入
    setEditItem({ code: "", name: "", sort: "", status: "启用" });
    setShowItemModal(true);
  };

  const openEditItem = (item: { code: string; name: string; sort: number; status: string }) => {
    setIsNewItem(false);
    setEditItem({ ...item, sort: String(item.sort) });
    setShowItemModal(true);
  };

  const saveItem = async () => {
    if (!editItem || !editItem.name.trim()) return;
    const newItem = { name: editItem.name.trim(), status: editItem.status };
    // 同名预检（编码不上屏，同名项在界面无法区分；后端亦有 409 兜底）
    const dup = (itemsMap[selectedCat] ?? []).some(it =>
      it.name === newItem.name && (isNewItem || it.code !== editItem.code));
    if (dup) { toast.error("该分类下已存在同名项"); return; }
    try {
      let createdCode: string | undefined;
      if (isNewItem) {
        // 编码（AUTO{n}）与排序均后端自动分配
        const res = await createDictItem(selectedCat, newItem);
        createdCode = res.code;
      } else {
        // 编码保持不变（定位用）；编辑不改变排序（保持原序号）
        await updateDictItem(selectedCat, editItem.code, { name: newItem.name, status: newItem.status as "启用" | "禁用" });
      }
      setItemsMap(prev => {
        const current = prev[selectedCat] ?? [];
        if (isNewItem) {
          return { ...prev, [selectedCat]: [...current, { ...newItem, code: createdCode ?? `AUTO${current.length}`, sort: current.length }] };
        } else {
          return { ...prev, [selectedCat]: current.map(it => it.code === editItem.code ? { ...it, ...newItem } : it) };
        }
      });
      setShowItemModal(false);
      setEditItem(null);
    } catch {
      toast.error("保存失败，请稍后重试");
    }
  };

  const toggleItemStatus = async (code: string) => {
    const current = itemsMap[selectedCat] ?? [];
    const target = current.find(it => it.code === code);
    if (!target) return;
    const newStatus = target.status === "启用" ? "禁用" : "启用";
    try {
      await updateDictItem(selectedCat, code, { status: newStatus as "启用" | "禁用" });
      setItemsMap(prev => ({
        ...prev,
        [selectedCat]: (prev[selectedCat] ?? []).map(it => it.code === code ? { ...it, status: newStatus } : it),
      }));
    } catch {
      toast.error("操作失败，请稍后重试");
    }
  };

  const confirm = useConfirm();

  const deleteItem = async (item: { code: string; name: string }) => {
    const ok = await confirm({
      title: "删除字典项",
      message: `确定删除「${item.name}」吗？该操作不可恢复。若已被业务数据引用，将删除失败，请改用「禁用」。`,
      confirmText: "删除",
      variant: "danger",
    });
    if (!ok) return;
    try {
      await deleteDictItem(selectedCat, item.code);
      setItemsMap(prev => ({
        ...prev,
        [selectedCat]: (prev[selectedCat] ?? []).filter(it => it.code !== item.code),
      }));
      toast.success("删除成功");
    } catch (e: any) {
      toast.error(e?.message || "删除失败，请稍后重试");
    }
  };

  return (
    <div className="flex gap-5 text-sm">
      {/* Left: 字典分类（分组标签 + 分类平铺 + 组间分隔线，无卡片，与用户与角色模块同款布局） */}
      <div className="w-52 shrink-0 space-y-4">
        {(Object.entries(DICT_CATEGORIES) as [string, string[]][]).map(([group, cats], idx) => (
          <div key={group} className={idx > 0 ? "border-t border-border/60 pt-4" : ""}>
            <p className="px-2.5 pb-1.5 text-sm font-medium text-muted-foreground/80 tracking-[0.2em]">{group}</p>
            {cats.map(cat => (
              <button key={cat} onClick={() => setSelectedCat(cat)}
                className={`w-full text-left px-2.5 py-2 rounded-md transition-colors cursor-pointer ${selectedCat === cat ? "bg-blue-50 text-primary font-medium" : "text-foreground hover:bg-muted/50"}`}>
                {cat}
              </button>
            ))}
          </div>
        ))}

        {/* 自定义字典（存量展示 + 删除；新增入口已移除，删除 = 定制字段从入库登记消失，历史数据保留） */}
        {customCategories.length > 0 && (
          <div className="border-t border-border/60 pt-4">
            <p className="px-2.5 pb-1.5 text-sm font-medium text-muted-foreground/80 tracking-[0.2em]">自定义字典</p>
            {customCategories.map(cat => (
              <div key={cat} className="flex items-center rounded-md transition-colors hover:bg-muted/50">
                <button onClick={() => setSelectedCat(cat)} title={dictMeta[cat]?.description || ""}
                  className={`flex-1 text-left px-2.5 py-2 rounded-md transition-colors cursor-pointer ${selectedCat === cat ? "text-primary font-medium" : "text-foreground"}`}>
                  {cat}
                </button>
                <button
                  onClick={() => handleDeleteCategory(cat)}
                  title="删除分类（定制字段随之从入库登记消失）"
                  className="p-1.5 mr-1 text-slate-300 hover:text-red-500 transition-colors cursor-pointer shrink-0"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* 实验流程管理已独立为系统设置「实验流程」tab（2026-09-18） */}
      </div>

      {/* Right: items */}
      <div className="flex-1 min-w-0 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <p className="text-sm font-semibold">{selectedCat}</p>
            <span className="text-sm text-muted-foreground">{displayItems.length} 项</span>
          </div>
          <Button variant="default" size="sm" onClick={openNewItem}><Plus size={12} />新增字典项</Button>
        </div>

        <Table className="w-full text-sm">
          <TableHeader className="border-b border-border">
            <TableRow>{["排序", "名称", "状态", "操作"].map(h => (
              <TableHead key={h} className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
            ))}</TableRow>
          </TableHeader>
          <TableBody className="divide-y divide-border">
            {loadingItems ? (
              <TableRow>
                <TableCell colSpan={4} className="px-3 py-12 text-center text-muted-foreground">
                  <RefreshCw size={16} className="animate-spin inline mr-2" />加载中...
                </TableCell>
              </TableRow>
            ) : displayItems.length > 0 ? displayItems.map((item) => (
              <TableRow key={item.code} className="hover:bg-muted/20 transition-colors">
                <TableCell className="px-3 py-3 text-center font-mono text-sm text-muted-foreground">{String(item.sort).padStart(2, "0")}</TableCell>
                <TableCell className="px-3 py-3 font-medium">{item.name}</TableCell>
                <TableCell className="px-3 py-3">
                  <span className={`px-2 py-0.5 rounded-full text-sm font-medium ${item.status === "启用" ? "bg-emerald-50 text-emerald-700" : "bg-gray-100 text-gray-500"}`}>{item.status}</span>
                </TableCell>
                <TableCell className="px-3 py-3">
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" onClick={() => openEditItem(item)}>编辑</Button>
                    <Button variant="ghost" size="sm" onClick={() => toggleItemStatus(item.code)}>{item.status === "启用" ? "禁用" : "启用"}</Button>
                    <Button variant="ghost" size="sm" onClick={() => deleteItem(item)}>删除</Button>
                  </div>
                </TableCell>
              </TableRow>
            )) : (
              <TableRow><TableCell colSpan={4} className="px-3 py-8 text-center text-sm text-muted-foreground">
                暂无字典项，请点击「新增字典项」添加
              </TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add/Edit item modal */}
      {showItemModal && editItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-card rounded-2xl shadow-2xl w-[400px]">
            <div className="px-6 py-4 border-b border-border flex items-center justify-between">
              <h2 className="text-base font-semibold">{isNewItem ? "新增字典项" : "编辑字典项"}</h2>
              <button onClick={() => setShowItemModal(false)} className="text-muted-foreground hover:text-foreground cursor-pointer text-lg">×</button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">名称<span className="text-red-500 ml-0.5">*</span></label>
                <input
                  value={editItem.name}
                  onChange={e => setEditItem(p => p ? { ...p, name: e.target.value } : p)}
                  className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">状态</label>
                <Select onValueChange={v => setEditItem(p => p ? { ...p, status: v } : p)} value={editItem.status}>
  <SelectTrigger className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring bg-card"><SelectValue /></SelectTrigger>
  <SelectContent>

                  <SelectItem value="启用">启用</SelectItem>
                  <SelectItem value="禁用">禁用</SelectItem>
                
  </SelectContent>
</Select>
              </div>
            </div>
            <div className="px-6 py-4 border-t border-border flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowItemModal(false)}>取消</Button>
              <Button variant="default" onClick={saveItem}>保存</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
