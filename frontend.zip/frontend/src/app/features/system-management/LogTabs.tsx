// ─── 日志中心共享件 ──────────────────────────────────────────────────────────
// 三个日志视图（人工/AI写/AI读）共用的 tab 分段控件与类型。
// tabs 不再独占一行（2026-09-21）：合并进各视图工具栏行左侧，右侧为搜索/筛选/导出。

export type LogView = "manual" | "ai-writes" | "ai-reads";

export const LOG_VIEWS: Array<[LogView, string]> = [
  ["manual", "人工操作"],
  ["ai-writes", "AI 写操作"],
  ["ai-reads", "AI 读操作"],
];

/** 视图切换分段控件（工具栏行最左侧，样式与样本制备页日期筛选同款） */
export function LogTabs({ view, onChange }: { view: LogView; onChange: (v: LogView) => void }) {
  return (
    <div className="flex items-center gap-0.5 p-0.5 bg-muted rounded-lg">
      {LOG_VIEWS.map(([key, label]) => (
        <button key={key} onClick={() => onChange(key)}
          className={`px-3 py-1.5 text-sm rounded-md transition-colors font-medium cursor-pointer ${view === key ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}>
          {label}
        </button>
      ))}
    </div>
  );
}

/** 日志时间快捷范围（全部/今日/近3日/近7日） */
export const TIME_RANGES = ["全部", "今日", "近3日", "近7日"] as const;

const fmtDate = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

/**快捷范围 → 查询日期区间（YYYY-MM-DD；全部 = 空区间） */
export function rangeDates(range: string): { dateFrom: string; dateTo: string } {
  if (range === "全部") return { dateFrom: "", dateTo: "" };
  const today = new Date();
  const days = range === "今日" ? 1 : range === "近3日" ? 3 : 7;
  return { dateFrom: fmtDate(new Date(today.getTime() - (days - 1) * 86400000)), dateTo: fmtDate(today) };
}
