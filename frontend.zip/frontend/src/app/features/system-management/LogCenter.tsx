import { useState } from "react";
import { OperationLog } from "./OperationLog";
import { AiActionsLog } from "./AiActionsLog";
import { AiReadsTable } from "./AiReadsTable";
import { LogView } from "./LogTabs";

/** 日志中心：人工操作 / AI 写操作 / AI 读操作 三源统一入口（2026-09-18 由「操作日志」+「AI 操作」两个 tab 合并）。
 * 2026-09-21：tab 分段控件合并进各视图工具栏行左侧（LogTabs），不再独占一行。 */
export function LogCenter() {
  const [view, setView] = useState<LogView>("manual");

  return (
    <div className="space-y-4">
      {view === "manual" && <OperationLog view={view} onViewChange={setView} />}
      {view === "ai-writes" && <AiActionsLog view={view} onViewChange={setView} />}
      {view === "ai-reads" && <AiReadsTable view={view} onViewChange={setView} />}
    </div>
  );
}
