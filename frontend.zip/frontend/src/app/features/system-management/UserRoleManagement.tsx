import { useState, useCallback, useEffect } from "react";
import { z } from "zod";
import { Plus, RefreshCw, Users, Shield, Info } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { useFormValidation } from "@/app/hooks/useFormValidation";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { FieldErrorText, FormErrorSummary, userStatusStyle } from "./shared";
import { getSystemUsers, createSystemUser, updateSystemUser, toggleSystemUserStatus, getSystemRoles } from "@/app/lib/api";
import type { SystemUser as User, SystemRole as Role } from "@/app/lib/api";
import { ROLE_VIEW_LIMITS } from "@/app/lib/view-permissions";
import { fmtBeijing } from "@/app/lib/utils/time";
import { toast } from "sonner";

const USERNAME_RULE = "账户仅限英文和数字，长度 3-32";
const NAME_RULE = "姓名仅限中文，最多 50 字";

/** 新增用户表单 */
const userFormSchema = z.object({
  username: z.string().trim().regex(/^[A-Za-z0-9]{3,32}$/, USERNAME_RULE),
  name: z.string().trim().regex(/^[\u4e00-\u9fa5]{0,50}$/, NAME_RULE),
  phone: z.string().trim().optional().refine((value) => !value || /^1\d{10}$/.test(value), "手机号格式不正确"),
  email: z.string().trim().optional().refine((value) => !value || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(value), "邮箱格式不正确"),
  password: z.string().min(8, "初始密码至少 8 位"),
  confirmPassword: z.string().min(1, "请确认密码"),
  role: z.string().trim().min(1, "角色必选"),
}).superRefine((data, context) => {
  if (data.password !== data.confirmPassword) {
    context.addIssue({ code: "custom", path: ["confirmPassword"], message: "两次输入的密码不一致" });
  }
});

/** 编辑用户抽屉（密码留空 = 不修改） */
const userEditSchema = z.object({
  username: z.string().trim().regex(/^[A-Za-z0-9]{3,32}$/, USERNAME_RULE),
  name: z.string().trim().regex(/^[\u4e00-\u9fa5]{0,50}$/, NAME_RULE),
  role: z.string().trim().min(1, "角色必选"),
  password: z.string().refine((v) => v === "" || v.length >= 8, "新密码至少 8 位"),
});

/** 角色可见视图 → 展示名（白名单当前仅含这 5 个视图，见 lib/view-permissions.ts） */
const VIEW_LABELS: Record<string, string> = {
  "sample-prep": "样本制备",
  "experiment-schedule": "排单看板",
  "task-list": "任务列表",
  "devices": "设备管理",
  "documents": "文档归档",
};

/** 用户与角色（2026-09-18 由「用户管理」+「角色管理」合并）：左侧角色列表（真实人数）筛选右侧用户表，角色为系统预置、权限矩阵不提供编辑 */
export function UserRoleManagement() {
  const [users, setUsers] = useState<User[]>([]);
  const [usersLoading, setUsersLoading] = useState(true);
  const [roles, setRoles] = useState<Role[]>([]);
  // 左侧选中："全部" 或角色名
  const [selectedRole, setSelectedRole] = useState<string>("全部");
  // 菜单范围抽屉
  const [scopeRole, setScopeRole] = useState<Role | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [editUser, setEditUser] = useState<User | null>(null);
  const [editForm, setEditForm] = useState({ username: "", name: "", role: "", password: "" });
  const [newUser, setNewUser] = useState({ username: "", name: "", phone: "", email: "", password: "", confirmPassword: "", role: "" });
  const [saving, setSaving] = useState(false);
  const { validate, errors, clearErrors, getFieldError } = useFormValidation(userFormSchema);
  const editV = useFormValidation(userEditSchema);

  const loadUsers = useCallback(() => {
    setUsersLoading(true);
    getSystemUsers()
      .then(data => setUsers(data))
      .catch(() => setUsers([]))
      .finally(() => setUsersLoading(false));
  }, []);

  useEffect(() => {
    loadUsers();
    getSystemRoles().then(setRoles).catch(() => {});
  }, [loadUsers]);

  const visibleUsers = selectedRole === "全部" ? users : users.filter(u => (u.roles ?? []).includes(selectedRole));

  const roleUserCount = (roleName: string) => users.filter(u => (u.roles ?? []).includes(roleName)).length;

  const setUserField = (field: keyof typeof newUser, value: string) => {
    setNewUser(prev => ({ ...prev, [field]: value }));
    clearErrors(field);
  };

  const closeAddUser = () => {
    setShowAdd(false);
    clearErrors();
  };

  const submitAddUser = async () => {
    const result = validate(newUser);
    if (!result.success) return;
    setSaving(true);
    try {
      await createSystemUser({
        username: newUser.username,
        name: newUser.name,
        phone: newUser.phone,
        email: newUser.email,
        password: newUser.password,
        role: newUser.role,
      });
      toast.success("用户创建成功");
      closeAddUser();
      loadUsers();
    } catch (err: any) {
      toast.error(err?.message || "创建用户失败");
    } finally {
      setSaving(false);
    }
  };

  const openEditUser = (u: User) => {
    setEditUser(u);
    editV.clearErrors();
    setEditForm({ username: u.username, name: u.name ?? "", role: u.roles[0] ?? "", password: "" });
  };

  const closeEditUser = () => {
    setEditUser(null);
    editV.clearErrors();
  };

  // 只发送有变化的字段（后端为部分更新，users.ts PUT /:id），未提及字段（如手机号）保持不变
  const saveEditUser = async () => {
    if (!editUser) return;
    const result = editV.validate({ username: editForm.username, name: editForm.name, role: editForm.role, password: editForm.password });
    if (!result.success) return;
    try {
      const payload: { username?: string; name?: string; role?: string; password?: string } = { role: editForm.role };
      if (editForm.username !== editUser.username) payload.username = editForm.username;
      if (editForm.name.trim() !== (editUser.name ?? "")) payload.name = editForm.name.trim();
      if (editForm.password !== "") payload.password = editForm.password;
      await updateSystemUser(editUser.id, payload);
      toast.success("用户信息已更新");
      closeEditUser();
      loadUsers();
    } catch (err: any) {
      toast.error(err?.message || "更新用户失败");
    }
  };

  const doToggleUserStatus = async (u: User) => {
    const newStatus = u.status === "已禁用" ? "正常" : "已禁用";
    try {
      await toggleSystemUserStatus(u.id, newStatus as "正常" | "已禁用");
      toast.success(`用户已${newStatus === "已禁用" ? "禁用" : "启用"}`);
      loadUsers();
    } catch (err: any) {
      toast.error(err?.message || "操作失败");
    }
  };

  return (
    <div className="flex gap-5 text-sm">
      {/* Left: 角色列表（预置四角色，真实人数统计；点击筛选右侧用户表） */}
      <div className="w-52 shrink-0 space-y-1">
        <p className="px-1 pb-1 text-sm font-semibold text-muted-foreground">角色</p>
        <button onClick={() => setSelectedRole("全部")}
          className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-md text-sm transition-colors cursor-pointer ${selectedRole === "全部" ? "bg-blue-50 text-primary font-medium" : "text-foreground hover:bg-muted/50"}`}>
          <Users size={14} className="shrink-0" />
          <span className="flex-1 text-left">全部用户</span>
          <span className="font-mono text-sm text-muted-foreground">{users.length}</span>
        </button>
        {roles.map(r => {
          const active = selectedRole === r.name;
          return (
            <div key={r.id} className={`flex items-center rounded-md transition-colors ${active ? "bg-blue-50" : "hover:bg-muted/50"}`}>
              <button onClick={() => setSelectedRole(r.name)}
                className={`flex-1 flex items-center gap-2 px-2.5 py-2 text-left text-sm cursor-pointer ${active ? "text-primary font-medium" : ""}`}>
                <Shield size={13} className={`shrink-0 ${active ? "text-primary" : "text-muted-foreground"}`} />
                <span className="flex-1 truncate">{r.name}</span>
                <span className="font-mono text-sm text-muted-foreground">{roleUserCount(r.name)}</span>
              </button>
              <button onClick={() => setScopeRole(r)} title="查看菜单范围"
                className="p-1.5 mr-1 text-slate-300 hover:text-primary transition-colors cursor-pointer shrink-0">
                <Info size={13} />
              </button>
            </div>
          );
        })}
      </div>

      {/* Right: 用户表（无搜索/筛选，纯列表） */}
      <div className="flex-1 min-w-0 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <p className="text-sm font-semibold">{selectedRole === "全部" ? "全部用户" : selectedRole}</p>
            <span className="text-sm text-muted-foreground">{visibleUsers.length} 人</span>
          </div>
          <Button variant="default" size="sm" onClick={() => {
            // 打开前重置表单，避免上次残留的密码值导致"两次输入不一致"误报；选中角色时预填
            setNewUser({ username: "", name: "", phone: "", email: "", password: "", confirmPassword: "", role: selectedRole !== "全部" ? selectedRole : "" });
            setShowAdd(true);
          }}><Plus size={12} />新增用户</Button>
        </div>

        <Table className="w-full text-sm">
            <TableHeader className="border-b border-border">
              <TableRow>{["账户", "姓名", "角色", "状态", "最后登录", "创建时间", "操作"].map(h => (
                <TableHead key={h} className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
              ))}</TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-border">
              {usersLoading ? (
                <TableRow><TableCell colSpan={7} className="px-3 py-12 text-center text-muted-foreground">
                  <RefreshCw size={16} className="animate-spin inline mr-2" />加载中...
                </TableCell></TableRow>
              ) : visibleUsers.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="px-3 py-12 text-center text-sm text-muted-foreground">暂无用户数据</TableCell></TableRow>
              ) : visibleUsers.map(u => (
                  <TableRow key={u.id} className="hover:bg-muted/20 transition-colors">
                    <TableCell className="px-3 py-3 font-mono text-sm text-primary">{u.username}</TableCell>
                    <TableCell className="px-3 py-3 font-medium">{u.name}</TableCell>
                    <TableCell className="px-3 py-3">
                      <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full text-sm font-medium">{u.roles[0]}</span>
                    </TableCell>
                    <TableCell className="px-3 py-3"><span className={`px-2 py-0.5 rounded-full text-sm font-medium ${userStatusStyle(u.status)}`}>{u.status}</span></TableCell>
                    <TableCell className="px-3 py-3 text-sm text-muted-foreground whitespace-nowrap">{u.lastLogin}</TableCell>
                    <TableCell className="px-3 py-3 text-sm text-muted-foreground whitespace-nowrap" title={fmtBeijing(u.createdAt)}>{fmtBeijing(u.createdAt).slice(0, 10)}</TableCell>
                    <TableCell className="px-3 py-3">
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" className="text-primary hover:bg-primary/10 hover:text-primary" onClick={() => openEditUser(u)}>编辑</Button>
                        <Button variant="ghost" size="sm" className="text-primary hover:bg-primary/10 hover:text-primary" onClick={() => doToggleUserStatus(u)}>{u.status === "已禁用" ? "启用" : "禁用"}</Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
      </div>

      {/* 角色菜单范围抽屉（只读：角色为系统预置，可见范围由 view-permissions 白名单决定） */}
      {scopeRole && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/40" onClick={() => setScopeRole(null)}>
          <div className="bg-card w-[420px] max-w-[90vw] h-full shadow-2xl p-6 space-y-5 overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-base font-semibold flex items-center gap-2"><Shield size={15} className="text-primary" />{scopeRole.name}</h2>
                <span className="inline-block mt-1.5 px-2 py-0.5 rounded-full text-sm font-medium bg-blue-50 text-blue-700">{scopeRole.type}</span>
              </div>
              <button onClick={() => setScopeRole(null)} className="text-muted-foreground hover:text-foreground cursor-pointer text-lg">×</button>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">{scopeRole.desc}</p>
            <div className="bg-muted/30 rounded-lg px-4 py-2.5 flex items-center justify-between">
              <p className="text-sm text-muted-foreground">当前用户数</p>
              <p className="font-mono text-sm font-medium">{roleUserCount(scopeRole.name)}</p>
            </div>
            <div>
              <p className="text-sm font-semibold text-muted-foreground mb-2">菜单可见范围</p>
              {ROLE_VIEW_LIMITS[scopeRole.name] ? (
                <div className="flex flex-wrap gap-1.5">
                  {ROLE_VIEW_LIMITS[scopeRole.name].map(v => (
                    <span key={v} className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full text-sm">{VIEW_LABELS[v] ?? v}</span>
                  ))}
                </div>
              ) : (
                <p className="text-sm">全部菜单（当前版本未限制该角色的可见视图）</p>
              )}
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                角色为系统预置，不可增删改名；可见范围由系统统一配置，暂不支持按角色自定义勾选。
              </p>
            </div>
            <Button variant="outline" className="w-full" onClick={() => setScopeRole(null)}>关闭</Button>
          </div>
        </div>
      )}

      {/* Add user modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-card rounded-2xl shadow-2xl w-[520px] max-h-[85vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-border flex items-center justify-between">
              <h2 className="text-base font-semibold">新增用户</h2>
              <button onClick={closeAddUser} className="text-muted-foreground hover:text-foreground text-lg cursor-pointer">×</button>
            </div>
            <div className="p-6 space-y-4">
              <FormErrorSummary errors={errors} />
              <div className="grid grid-cols-2 gap-4">
                {[
                  { key: "username" as const, label: "账户", placeholder: "仅英文和数字", required: true },
                  { key: "name" as const,     label: "姓名",  placeholder: "选填，仅中文", required: false },
                  { key: "email" as const,    label: "邮箱",  placeholder: "选填", required: false },
                ].map(f => (
                  <div key={f.key}>
                    <label className="text-sm font-medium mb-1 block">{f.label}{f.required && <span className="text-red-500 ml-0.5">*</span>}</label>
                    <input value={newUser[f.key]} onChange={e => setUserField(f.key, e.target.value)} placeholder={f.placeholder} className={`w-full border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring ${getFieldError(f.key) ? "border-red-300 bg-red-50/30" : "border-border"}`} />
                    <FieldErrorText error={getFieldError(f.key)} />
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">初始密码<span className="text-red-500 ml-0.5">*</span></label>
                  <input type="password" value={newUser.password} onChange={e => setUserField("password", e.target.value)} className={`w-full border rounded-md px-3 py-1.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-ring ${getFieldError("password") ? "border-red-300 bg-red-50/30" : "border-border"}`} />
                  <FieldErrorText error={getFieldError("password")} />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">确认密码<span className="text-red-500 ml-0.5">*</span></label>
                  <input type="password" value={newUser.confirmPassword} onChange={e => setUserField("confirmPassword", e.target.value)} className={`w-full border rounded-md px-3 py-1.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-ring ${getFieldError("confirmPassword") ? "border-red-300 bg-red-50/30" : "border-border"}`} />
                  <FieldErrorText error={getFieldError("confirmPassword")} />
                </div>
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">角色<span className="text-red-500 ml-0.5">*</span></label>
                <Select onValueChange={v => setUserField("role", v)} value={newUser.role}>
  <SelectTrigger className={`w-full border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring ${getFieldError("role") ? "border-red-300 bg-red-50/30" : "border-border"}`}><SelectValue placeholder="请选择角色" /></SelectTrigger>
  <SelectContent>

                  {roles.map(r => <SelectItem key={r.id} value={r.name}>{r.name}</SelectItem>)}

  </SelectContent>
</Select>
                <FieldErrorText error={getFieldError("role")} />
              </div>
              <p className="text-sm text-muted-foreground bg-amber-50 border border-amber-100 rounded-md px-3 py-2">首次登录后将强制修改密码</p>
            </div>
            <div className="px-6 py-4 border-t border-border flex justify-end gap-2">
              <Button variant="outline" onClick={closeAddUser}>取消</Button>
              <Button variant="default" onClick={submitAddUser} className={saving ? "opacity-50 pointer-events-none" : ""}>{saving ? "创建中..." : "确定"}</Button>
            </div>
          </div>
        </div>
      )}

      {/* Edit user drawer */}
      {editUser && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/40" onClick={closeEditUser}>
          <div className="bg-card w-[420px] max-w-[90vw] h-full shadow-2xl p-6 space-y-5 overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-start justify-between">
              <h2 className="text-base font-semibold">编辑用户</h2>
              <button onClick={closeEditUser} className="text-muted-foreground hover:text-foreground cursor-pointer text-lg">×</button>
            </div>
            <FormErrorSummary errors={editV.errors} />
            <div>
              <label className="text-sm font-medium mb-1 block">账户<span className="text-red-500 ml-0.5">*</span></label>
              <input value={editForm.username} onChange={e => setEditForm(p => ({ ...p, username: e.target.value }))}
                className={`w-full border rounded-md px-3 py-1.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-ring ${editV.getFieldError("username") ? "border-red-300 bg-red-50/30" : "border-border"}`} />
              <FieldErrorText error={editV.getFieldError("username")} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">姓名</label>
              <input value={editForm.name} onChange={e => setEditForm(p => ({ ...p, name: e.target.value }))} placeholder="选填，仅中文"
                className={`w-full border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring ${editV.getFieldError("name") ? "border-red-300 bg-red-50/30" : "border-border"}`} />
              <FieldErrorText error={editV.getFieldError("name")} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">角色<span className="text-red-500 ml-0.5">*</span></label>
              <Select onValueChange={v => setEditForm(p => ({ ...p, role: v }))} value={editForm.role}>
  <SelectTrigger className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring bg-card"><SelectValue /></SelectTrigger>
  <SelectContent>

                {roles.map(r => <SelectItem key={r.id} value={r.name}>{r.name}</SelectItem>)}

  </SelectContent>
</Select>
              <FieldErrorText error={editV.getFieldError("role")} />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">新密码</label>
              <input type="password" value={editForm.password} onChange={e => setEditForm(p => ({ ...p, password: e.target.value }))} placeholder="留空则不修改" autoComplete="new-password"
                className={`w-full border rounded-md px-3 py-1.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-ring ${editV.getFieldError("password") ? "border-red-300 bg-red-50/30" : "border-border"}`} />
              <FieldErrorText error={editV.getFieldError("password")} />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={closeEditUser}>取消</Button>
              <Button variant="default" onClick={saveEditUser}>保存</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
