import { Plus, Edit2, Trash2, FileCog, Workflow } from "lucide-react";
import { Button } from "@/app/components/ui/button";

import { PanelSidebar } from "@/app/components/shared/PanelSidebar";
import { panelCardCls, panelIconCls } from "@/app/components/shared/panel-styles";
import { MarqueeText, CardTag } from "@/app/components/shared/MarqueeText";
import type { StrategyRule as Rule } from "@/app/lib/api";
import { RULE_STUDY, RULE_STATUS_META } from "./strategy-constants";
import { scheduleProjectOf, SCHEDULE_WIRING_NOTE } from "./strategy-model";
import { RuleDifficultyStars } from "./shared";

/**
 * 左侧规则列表：只渲染与回调上抛（编辑/删除/新建编排留在页级）。
 * 卡面 = 单行标题（跑马灯）+ 分类/状态灰标签；难度星右上角，hover 淡出让位编辑/删除钮。
 */
export function RuleSidebar({
  rules,
  activeRuleId,
  onSelect,
  onEdit,
  onDelete,
  onCreate,
}: {
  rules: Rule[];
  activeRuleId: string | null;
  onSelect: (id: string) => void;
  onEdit: (rule: Rule) => void;
  onDelete: (rule: Rule) => void;
  onCreate: () => void;
}) {
  return (
    <PanelSidebar
      icon={FileCog}
      title="规则列表"
      count={`${rules.length} 条`}
      action={
        <Button variant="default" size="icon-sm" onClick={onCreate} aria-label="新建规则">
          <Plus size={14} />
        </Button>
      }
    >
        {rules.length === 0 ? (
          <p className="text-[14px] text-muted-foreground text-center py-8">暂无规则，点击下方按钮创建</p>
        ) : (
          rules.map((r) => {
            // 自动排单虚拟卡（task-schedule-rules#项目）：全字段已接线，状态"生效"；
            // 难度沿用文件级 3（最高档）；不显示编辑/删除（修改与删除走 AI 对话）
            const project = scheduleProjectOf(r.id);
            const study = project
              ? { level: 3, status: "ok" as const, effect: SCHEDULE_WIRING_NOTE }
              : RULE_STUDY[r.id];
            const statusMeta = study ? RULE_STATUS_META[study.status] : null;
            const active = activeRuleId === r.id;
            return (
              <div
                key={r.id}
                onClick={() => onSelect(r.id)}
                className={panelCardCls({ active, disabled: !r.enabled })}
              >
                {/* 难度五角星（1-3 星；hover/focus 淡出，让位给编辑/删除） */}
                {study && (
                  <div className="absolute top-2.5 right-3 h-6 flex items-center pointer-events-none transition-opacity group-hover:opacity-0 group-focus-within:opacity-0">
                    <RuleDifficultyStars level={study.level} />
                  </div>
                )}

                    {/* hover 操作（右上角浮层；focus-within 保证键盘可达）；虚拟卡不显示
                        （修改/删除自动排单项目走 AI 对话——避免误删整文件） */}
                    {!project && (
                    <div className="absolute top-2.5 right-2.5 flex gap-1 opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity">
                      <button
                        onClick={(e) => { e.stopPropagation(); onEdit(r); }}
                        aria-label={`编辑规则 ${r.name}`}
                        className="p-1.5 rounded-md text-muted-foreground hover:text-primary hover:bg-muted transition-colors cursor-pointer"
                      >
                        <Edit2 size={12} />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); onDelete(r); }}
                        aria-label={`删除规则 ${r.name}`}
                        className="p-1.5 rounded-md text-muted-foreground hover:text-red-600 hover:bg-muted transition-colors cursor-pointer"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                    )}

                    {/* 卡面：图标 + 单行标题（超长悬浮跑马灯）+ 副行灰标签（分类 · 生效状态），
                        与文档归档/解决方案侧边栏同一套卡面结构（MarqueeText/CardTag） */}
                    <div className={panelIconCls(active)}>
                      {project ? <Workflow size={15} /> : <FileCog size={15} />}
                    </div>
                    <div className="min-w-0 flex-1 pr-10">
                      <MarqueeText
                        text={r.name}
                        className={`text-[14px] font-medium leading-snug ${active ? "text-primary" : "text-foreground"}`}
                      />
                      <div className="flex flex-wrap gap-1 mt-1">
                        <CardTag>{r.category}</CardTag>
                        {/* 停用优先于生效状态（停用规则的"生效"标签会误导） */}
                        {!r.enabled
                          ? <CardTag>已停用</CardTag>
                          : statusMeta && <CardTag>{statusMeta.label}</CardTag>}
                      </div>
                    </div>
              </div>
            );
          })
        )}
    </PanelSidebar>
  );
}
