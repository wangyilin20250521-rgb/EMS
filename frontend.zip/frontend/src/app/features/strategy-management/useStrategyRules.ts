/**
 * 手动规则列表与元数据编排 hook（P1-C 拆分）——文件/元数据并发加载、
 * 新建（快速创建弹窗受控状态）、删除、编辑保存。页级无条件调用。
 * 2026-09-16：自动排单规则（task-schedule-rules）按项目展开为虚拟卡片。
 * 2026-09-24：新建弹窗改为"选规则卡片 + 命名"——自动排单类并入既有文件（默认启用）；
 * 其余类从出厂基线模板派生新文件（文件名由服务端按「名字+日期-序号」生成）。
 */
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";

import type {
  StrategyRule as Rule,
  RuleMetaEntry,
} from "@/app/lib/api";
import { getApiConfig, getRulesMeta, saveRuleMeta } from "@/app/lib/api";
import { apiGet, getAuthToken } from "@/app/lib/api/http";
import { useConfirm } from "@/app/components/shared/ConfirmDialog";
import { fmtBeijingNow } from "./shared";
import {
  buildScheduleProjectTemplate, expandScheduleRules, mapRuleFilesToRules,
  RULE_CATALOG, SCHEDULE_CARD_PREFIX, SCHEDULE_FILE,
} from "./strategy-model";

export function useStrategyRules() {
  const confirm = useConfirm();
  // 规则集合（约原 39 行）
  const [rules, setRules] = useState<Rule[]>([]);

  // ─── Quick-create state（弹窗挂载由页级条件渲染控制） ───
  const [showQuickCreate, setShowQuickCreate] = useState(false);
  const [quickName, setQuickName] = useState("");
  /** 新建弹窗选中的规则类型（出厂规则目录 key，如 tat-rules；null=未选） */
  const [quickType, setQuickType] = useState<string | null>(null);
  const [quickCreateBusy, setQuickCreateBusy] = useState(false);

  // 加载规则文件列表 + 元数据 + 自动排单配置（并发；元数据失败单独兜底空对象，文件失败整体置空）；
  // 自动排单规则按项目展开为虚拟卡片（存储层仍是单文件，消费链路零改动）
  const reload = useCallback(() => {
    return Promise.all([
      apiGet<Array<{ name: string; size: number; updatedAt: string }>>("/strategy-rules/files"),
      getRulesMeta().catch(() => ({} as Record<string, RuleMetaEntry>)),
      apiGet<Record<string, unknown>>("/strategy-rules/schedule").catch(() => ({} as Record<string, unknown>)),
    ])
      .then(([files, savedMeta, scheduleCfg]) => {
        setRules(expandScheduleRules(mapRuleFilesToRules(files, savedMeta), scheduleCfg as Record<string, any>))
      })
      .catch(() => setRules([]))
  }, [])

  useEffect(() => { void reload() }, [reload])

  const persistRuleMeta = (id: string, patch: RuleMetaEntry): Promise<boolean> => {
    return saveRuleMeta(id, patch)
      .then(() => true)
      .catch(e => {
        toast.error(e?.message || "元数据保存失败")
        return false
      })
  }

  /** 打开新建弹窗（2026-09-24 改版：先选规则卡片再命名，不再有"自定义分类/空壳文件"；类型默认不预选） */
  const openQuickCreate = () => { setQuickType(null); setQuickName(""); setShowQuickCreate(true); }

  /** 关闭并复位新建弹窗（Esc/取消共用） */
  const closeQuickCreate = () => { setShowQuickCreate(false); setQuickName(""); setQuickType(null); }

  /** 新建自动排单项目：基础模板（4 要素，enabled=true）→ 后端 read-modify-write 并入 task-schedule-rules → 刷新列表 */
  const handleCreateScheduleProject = async () => {
    const project = quickName.trim();
    if (!project) return;
    if (rules.some((r) => r.id === `${SCHEDULE_CARD_PREFIX}${project}`)) {
      toast.error(`项目「${project}」已有自动排单规则，请直接在卡片上对话调整`);
      return;
    }
    setQuickCreateBusy(true)
    try {
      const base = getApiConfig().baseUrl
      const hdrs: Record<string, string> = { "Content-Type": "application/json" }
      const tk = getAuthToken(); if (tk) hdrs["Authorization"] = `Bearer ${tk}`
      const res = await fetch(`${base}/strategy-rules/schedule-project`, {
        method: "POST", headers: hdrs,
        body: JSON.stringify({ project, rule: buildScheduleProjectTemplate() }),
      })
      const json = await res.json()
      if (json.code !== "0") throw new Error(json.message || "创建失败")
      await reload()
      toast.success(`「自动排单（${project}）」已创建并启用（含基础模板，点击卡片可直接对话调整）`)
    } catch (e) {
      toast.error((e as Error)?.message || "创建失败")
    } finally {
      setQuickCreateBusy(false)
    }
    setShowQuickCreate(false)
    setQuickName("")
    setQuickType(null)
  };

  /** 从出厂模板新建规则文件：服务端按「名字+日期-序号」生成文件名（如 rule260924-1.py），
   * 内容取所选类型的出厂基线模板；创建后写元数据（分类=所选类型、默认启用）并刷新列表。 */
  const handleCreateFromTemplate = async () => {
    const name = quickName.trim();
    const entry = RULE_CATALOG.find(r => r.type === quickType)
    if (!name || !entry) return;
    const now = fmtBeijingNow();
    setQuickCreateBusy(true)
    try {
      const base = getApiConfig().baseUrl
      const hdrs: Record<string, string> = { "Content-Type": "application/json" }
      const tk = getAuthToken(); if (tk) hdrs["Authorization"] = `Bearer ${tk}`
      const res = await fetch(`${base}/strategy-rules/files/from-template`, {
        method: "POST", headers: hdrs,
        body: JSON.stringify({ type: entry.type, name }),
      })
      const json = await res.json()
      if (json.code !== "0") throw new Error(json.message || "创建失败")
      const key = String(json.data?.key ?? "")
      if (key) {
        // 元数据（显示名/分类/启用态）落 .meta.json；失败仅提示，不影响已创建的文件
        void persistRuleMeta(key, {
          name, category: entry.category, enabled: true, priority: "中",
          updatedBy: "当前用户", updatedAt: now,
          fields: [{ label: "来源模板", value: entry.label }, { label: "文件", value: `${key}.py` }],
        })
      }
      await reload()
      toast.success(`${key}.py 已创建（模板源自「${entry.label}」）`)
    } catch (e) {
      toast.error((e as Error)?.message || "创建失败")
    } finally {
      setQuickCreateBusy(false)
    }
    setShowQuickCreate(false);
    setQuickName("");
    setQuickType(null);
  };

  const handleQuickCreate = () => {
    if (quickType === SCHEDULE_FILE) { void handleCreateScheduleProject(); return; }
    void handleCreateFromTemplate();
  };

  const handleDeleteRule = async (rule: Rule) => {
    if (!(await confirm({ title: "确认删除", message: `确认删除规则文件 ${rule.id}.py？`, variant: "danger" }))) return
    setRules(prev => prev.filter(r => r.id !== rule.id))
    const base = getApiConfig().baseUrl
    const h: Record<string, string> = {}
    const t = getAuthToken(); if (t) h["Authorization"] = `Bearer ${t}`
    try { await fetch(`${base}/strategy-rules/files/${rule.id}`, { method: "DELETE", headers: h }); toast.success(`${rule.id}.py 已删除`) } catch { /* ignore */ }
  };

  /** 编辑抽屉保存：先本地更新（列表立即反映），关抽屉由调用方回调，再异步保存元数据 */
  const handleEditSaved = (updated: Rule, closeDrawer: () => void) => {
    setRules(prev => prev.map(r => r.id === updated.id ? updated : r));
    closeDrawer();
    persistRuleMeta(updated.id, { name: updated.name, enabled: updated.enabled, priority: updated.priority, fields: updated.fields, updatedBy: updated.updatedBy, updatedAt: updated.updatedAt })
      .then(ok => { if (ok) toast.success("规则已保存"); });
  };

  return {
    rules,
    showQuickCreate,
    quickName,
    setQuickName,
    quickType,
    setQuickType,
    quickCreateBusy,
    openQuickCreate,
    closeQuickCreate,
    handleQuickCreate,
    handleDeleteRule,
    handleEditSaved,
  };
}
