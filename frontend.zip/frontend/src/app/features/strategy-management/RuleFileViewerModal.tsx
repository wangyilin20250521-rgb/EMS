import { Download, FileText, Upload, X } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import type { StrategyRule as Rule } from "@/app/lib/api";

/** 可导入替换的八个预置规则文件前缀（非预置文件仅展示与下载，2026-09 原样保留） */
const LEGACY_FILE_PREFIXES = ["tat-rules","naming-rules","hospital-config","qc-rules","control-rules","split-rules","anomaly-rules","workflow-rules"] as const

/**
 * 规则文件查看弹窗（P1-C 拆分）——只负责渲染规则源码与操作按钮；
 * 打开/读取/下载/导入由 useRuleFileViewer 编排。
 *
 * 2026-09-16 起无入口引用：策略管理页按用户要求对用户隐藏规则文件（Python 为底层维护物，
 * 用户侧无感知，仅保留一键「AI 智能介绍」）。文件保留待用（如需回退/复用文件查看能力）。
 */
export function RuleFileViewerModal({
  rule,
  format,
  content,
  loading,
  onClose,
  onDownload,
  onImportReplace,
}: {
  rule: Rule | null;
  format: "json" | "py";
  content: Array<{ name: string; type: string; content: string }>;
  loading: boolean;
  onClose: () => void;
  onDownload: (file: { name: string; content: string }) => void;
  onImportReplace: (fileKey: string, fileName: string) => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="bg-card rounded-2xl shadow-2xl w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden">
        <div className="px-5 py-4 border-b border-border flex items-center justify-between shrink-0">
          <div>
            <h2 className="text-[14px] font-semibold">{rule?.name} · 规则源码</h2>
            <p className="text-[14px] text-muted-foreground mt-0.5">{format === "json" ? "JSON 规则文件 — 纯数据配置，保存即时生效" : "Python 规则文件 — 由 Python runner 加载"}</p>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-muted rounded transition-colors text-muted-foreground cursor-pointer"><X size={16} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-5">
          {loading ? (
            <p className="text-center text-[14px] text-muted-foreground py-8 animate-pulse">加载中…</p>
          ) : content.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <FileText size={32} className="text-muted-foreground mb-3" />
              <p className="text-[14px] font-medium text-muted-foreground mb-1">该分类暂无规则文件</p>
              <p className="text-[14px] text-muted-foreground">「{rule?.category}」对应的 .py 规则文件，可直接编辑或通过 AI 对话自动调整。</p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Skill prompt section */}
              {rule && (
                <div className="bg-card border border-border rounded-xl p-4">
                  <p className="text-[14px] font-bold text-muted-foreground uppercase tracking-widest mb-2">Skill 描述</p>
                  <p className="text-[14px] text-foreground leading-relaxed">
                    <span className="font-semibold">分类：</span>{rule.category}
                    <span className="text-muted-foreground ml-4">— Python 规则文件，由后端 <code className="text-[14px] bg-blue-100 px-1 rounded">_runner.py</code> 统一加载执行。</span>
                  </p>
                  <div className="mt-2 text-[14px] text-muted-foreground space-y-1">
                    {format === "json" ? (
                      <p>• 文件格式：纯 JSON 对象（本身即规则字典），无注释无代码，保存即时生效</p>
                    ) : (
                      <p>• 文件格式：Python <code className="text-[14px] bg-blue-100 px-1 rounded">RULES = {'{...}'}</code> 纯数据字典，可选 <code className="text-[14px] bg-blue-100 px-1 rounded">def get(context)</code></p>
                    )}
                    <p>• 执行方式：后端按文件 mtime 自动重载，保存后无需重启即时生效</p>
                    <p>• 修改即时生效：保存文件后自动清除缓存，下次业务调用即用新值</p>
                    <p>• 可通过 AI 对话描述需求，AI 基于模板自动生成或修改 .py 文件内容</p>
                  </div>
                </div>
              )}

              {/* Code section */}
              {content.map((f, i) => {
                const fileKey = LEGACY_FILE_PREFIXES.find(k => f.name.startsWith(k)) ?? ""
                return (
                <div key={i} className="border border-border rounded-xl overflow-hidden">
                  <div className="px-3 py-2 bg-muted/30 border-b border-border flex items-center justify-between">
                    <span className="text-[14px] font-mono font-medium">{f.name}</span>
                    <div className="flex items-center gap-1">
                      <Button variant="default" onClick={() => onDownload(f)}
                        className="inline-flex items-center gap-1 px-2 py-0.5 text-[14px] text-white bg-primary hover:bg-primary/90 rounded transition-colors cursor-pointer">
                        <Download size={11} />下载
                      </Button>
                      {fileKey && (
                        <Button variant="default" onClick={() => onImportReplace(fileKey, f.name)}
                          className="inline-flex items-center gap-1 px-2 py-0.5 text-[14px] text-white bg-primary hover:bg-primary/90 rounded transition-colors cursor-pointer">
                          <Upload size={11} />导入替换
                        </Button>
                      )}
                      <span className="text-[14px] text-muted-foreground uppercase bg-slate-200 dark:bg-slate-700 px-1.5 py-0.5 rounded">{f.type}</span>
                    </div>
                  </div>
                  <pre className="p-4 text-[14px] font-mono overflow-x-auto whitespace-pre-wrap max-h-96 overflow-y-auto bg-slate-50 dark:bg-slate-900">{f.content || "(空文件)"}</pre>
                </div>
                )
              })}
            </div>
          )}
        </div>
        <div className="px-5 py-3 border-t border-border bg-muted/10 shrink-0 flex justify-end">
          <Button variant="default" onClick={onClose}
            size="sm" className="text-[14px]">关闭</Button>
        </div>
      </div>
    </div>
  );
}
