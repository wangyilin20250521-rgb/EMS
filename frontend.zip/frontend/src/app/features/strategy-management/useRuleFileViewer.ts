/**
 * 规则文件查看器 hook（P1-C 拆分）——状态与按需读取（先开窗再请求）、
 * 下载与导入替换。导入保持八个预置文件前缀判断与 .py 限制，不机械统一 API。
 *
 * 2026-09-16 起无入口引用：策略管理页按用户要求对用户隐藏规则文件（查看规则文件/清理按钮移除，
 * 只保留一键「AI 智能介绍」）。文件保留待用（如需回退/复用文件查看能力）。
 */
import { useState } from "react";
import { toast } from "sonner";

import type { StrategyRule as Rule } from "@/app/lib/api";
import { getApiConfig } from "@/app/lib/api";
import { getAuthToken } from "@/app/lib/api/http";

export function useRuleFileViewer() {
  // ─── Rules viewer state ───
  const [showRulesViewer, setShowRulesViewer] = useState(false);
  const [rulesViewerContent, setRulesViewerContent] = useState<Array<{ name: string; type: string; content: string }>>([]);
  const [rulesViewerLoading, setRulesViewerLoading] = useState(false);
  const [rulesViewerFormat, setRulesViewerFormat] = useState<"json" | "py">("py");

  /** 打开查看器：先开窗（loading 态）再请求文件内容，失败由 finally 收尾 */
  const handleViewRules = async (rule: Rule) => {
    if (!rule) return;
    const fileName = rule.id; // id = file name (e.g., "tat-rules")
    setShowRulesViewer(true);
    setRulesViewerLoading(true);
    try {
      const base = getApiConfig().baseUrl
      const headers: Record<string, string> = {}
      const t = getAuthToken(); if (t) headers["Authorization"] = `Bearer ${t}`
      const res = await fetch(`${base}/strategy-rules/files/${fileName}`, { headers })
      const json = await res.json()
      const content = json?.data?.content ?? ""
      const fmt: "json" | "py" = json?.data?.format === "json" ? "json" : "py"
      setRulesViewerFormat(fmt);
      setRulesViewerContent([{ name: `${fileName}.${fmt}`, type: fmt === "json" ? "json" : "python", content }]);
    } finally {
      setRulesViewerLoading(false);
    }
  };

  const closeViewer = () => setShowRulesViewer(false);

  /** 下载当前文件内容为本地文件 */
  const handleDownload = (file: { name: string; content: string }) => {
    const blob = new Blob([file.content], { type: "text/x-python" })
    const url = URL.createObjectURL(blob); const a = document.createElement("a")
    a.href = url; a.download = file.name; a.click(); URL.revokeObjectURL(url)
  };

  /** 导入替换：选择 .py 文件 → PUT 覆盖 → 成功后关窗提示（fileKey 由调用方按八前缀判定后传入） */
  const handleImportReplace = (fileKey: string, fileName: string) => {
    const input = document.createElement("input"); input.type = "file"
    input.accept = ".py"
    input.onchange = async () => {
      const file = input.files?.[0]; if (!file) return
      const text = await file.text()
      try {
        const base = getApiConfig().baseUrl
        const hdr2: Record<string,string>={"Content-Type":"application/json"}
        const tk2=getAuthToken();if(tk2)hdr2["Authorization"]=`Bearer ${tk2}`
        await fetch(`${base}/strategy-rules/files/${fileKey}`,{method:"PUT",headers:hdr2,body:JSON.stringify({content:text})})
        toast.success(`${fileName} 已更新`)
        setShowRulesViewer(false)
      } catch (e) { toast.error((e as Error)?.message || "导入失败") }
    }
    input.click()
  };

  return {
    showRulesViewer,
    rulesViewerContent,
    rulesViewerLoading,
    rulesViewerFormat,
    handleViewRules,
    closeViewer,
    handleDownload,
    handleImportReplace,
  };
}
