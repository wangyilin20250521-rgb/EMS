import { useState } from "react";

import type { StrategyRule as Rule } from "@/app/lib/api";
import { EditDrawer } from "./EditDrawer";
import { RuleSidebar } from "./RuleSidebar";
import { QuickCreateRuleModal } from "./QuickCreateRuleModal";
import { StrategyChatPanel } from "./StrategyChatPanel";
import { useStrategyRules } from "./useStrategyRules";
import { useStrategyChat } from "./useStrategyChat";

/**
 * 策略管理页（P1-C 拆分）——只保留当前规则 ID/编辑目标/区域组装；
 * 规则列表与元数据、聊天编排分别收编 useStrategyRules / useStrategyChat。
 * 编排 hook 页级无条件调用（不随弹窗切换挂载），切规则不重置输入草稿/流式状态/AbortController。
 * 2026-09-16：Tab 栏（规则总览/流程引擎/状态机）与规则文件查看器对用户隐藏——只剩规则总览；
 * 规则文件（Python）为底层维护物，用户侧无感知，仅保留一键「AI 智能介绍」。
 */
export function StrategyManagementContent() {
  const [editRule, setEditRule] = useState<Rule | null>(null);

  // ─── Active rule for chat ───
  const [activeRuleId, setActiveRuleId] = useState<string | null>(null);

  const rulesState = useStrategyRules();
  const chat = useStrategyChat({ activeRuleId, rules: rulesState.rules });

  const activeRule = rulesState.rules.find(r => r.id === activeRuleId) ?? null;

  return (
    <div className="h-full flex flex-col">
      {editRule && <EditDrawer rule={editRule} onClose={() => setEditRule(null)} onSaved={(updated) => {
        rulesState.handleEditSaved(updated, () => setEditRule(null));
      }} />}

      {/* Body: left nav + right chat */}
      <div className="flex-1 flex min-h-0">
          {/* ── Left: all rule cards ── */}
          <RuleSidebar
            rules={rulesState.rules}
            activeRuleId={activeRuleId}
            onSelect={(id) => { setActiveRuleId(id); setTimeout(() => chat.chatInputRef.current?.focus(), 50); }}
            onEdit={(r) => setEditRule(r)}
            onDelete={(r) => rulesState.handleDeleteRule(r)}
            onCreate={rulesState.openQuickCreate}
          />

          {/* Quick-create modal（2026-09-24 改版：规则卡片选择 + 底部命名） */}
          {rulesState.showQuickCreate && (
            <QuickCreateRuleModal
              type={rulesState.quickType}
              onTypeChange={(t) => { rulesState.setQuickType(t); rulesState.setQuickName(""); }}
              name={rulesState.quickName}
              onNameChange={rulesState.setQuickName}
              onSubmit={rulesState.handleQuickCreate}
              onCancel={rulesState.closeQuickCreate}
              busy={rulesState.quickCreateBusy}
            />
          )}

          {/* ── Right: full chat area ── */}
          <StrategyChatPanel
            activeRule={activeRule}
            messages={chat.chatMessages}
            input={chat.chatInput}
            onInputChange={chat.setChatInput}
            streaming={chat.chatStreaming}
            onSend={chat.handleChatSend}
            onStop={chat.stopChatStream}
            onExplainRule={chat.handleExplainRule}
            onAnswerQuestion={chat.handleAnswerQuestion}
            onConfirmProposal={chat.confirmStrategyProposal}
            onCancelProposal={chat.cancelStrategyProposal}
            scrollRef={chat.chatScrollRef}
            endRef={chat.chatEndRef}
            inputRef={chat.chatInputRef}
            onScroll={chat.handleChatScroll}
          />
        </div>

    </div>
  );
}

export const StrategyManagementPage = StrategyManagementContent;
