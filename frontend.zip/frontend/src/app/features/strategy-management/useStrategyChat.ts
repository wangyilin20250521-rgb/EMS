/**
 * 策略聊天编排 hook（P1-C 拆分）——聊天状态与滚动（zustand 内存态）、
 * SSE 流/确认/续流编排。页级无条件调用：切规则不重置输入草稿/流式状态/AbortController。
 * 页级差异点保留：apply=合入 zustand 末条 streaming 消息（无 charts 字段）；
 * onError=追加 ❌ 文本后收尾（与 assistant 页"替换整条"语义不同）。
 * rAF 节流 / tool_update 尾行 / KB 溯源 📎 行 / 迟到事件丢弃均由 stream-turn 引擎处理。
 */
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";

import type { StrategyRule as Rule } from "@/app/lib/api";
import { useStrategyChatStore, type ChatMessage } from "./strategy-chat-store";
import { streamChat, answerChatQuestion } from "@/app/lib/utils/sse";
import type { ActionProposal } from "@/app/lib/utils/sse";
import { buildStreamCallbacks, type TurnPatch } from "@/app/lib/chat/stream-turn";
import { confirmAiAction, cancelAiAction } from "@/app/lib/api/ai";
import { useDelegationSeeds } from "@/app/hooks/useDelegationSeeds";
import { buildStrategyPrompt, makeWelcomeMessage } from "./strategy-model";

export function useStrategyChat({ activeRuleId, rules }: { activeRuleId: string | null; rules: Rule[] }) {
  // ── Chat state (per-rule, in-memory via zustand — cleared on refresh) ──
  const chatHistory = useStrategyChatStore(s => s.chats);
  const updateChats = useStrategyChatStore(s => s.updateChats);
  const [chatInput, setChatInput] = useState("");
  const [chatStreaming, setChatStreaming] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const chatInputRef = useRef<HTMLTextAreaElement>(null);
  const chatAbortRef = useRef<AbortController | null>(null);

  const activeRule = rules.find(r => r.id === activeRuleId) ?? null;
  // EMS 助手代办问答（原汁原味）：以普通 user/ai 消息对合入，位置 = 欢迎语之后、本面板会话之前；
  // 虚拟卡 id（task-schedule-rules#<项目>）回退规则文件名，与委派时的 targetRef 同口径
  const { seeds } = useDelegationSeeds("strategy", activeRuleId ? activeRuleId.split("#")[0] : null);
  const chatMessages: ChatMessage[] = activeRuleId
    ? [...(chatHistory[activeRuleId]?.slice(0, 1) ?? []), ...seeds, ...(chatHistory[activeRuleId]?.slice(1) ?? [])]
    : [];

  // Ensure active rule has an initial welcome message
  useEffect(() => {
    if (activeRuleId && !chatHistory[activeRuleId]) {
      const rule = rules.find(r => r.id === activeRuleId);
      if (rule) {
        updateChats(prev => ({ ...prev, [activeRuleId]: [makeWelcomeMessage(rule)] }));
      }
    }
  }, [activeRuleId, rules]);

  const chatScrollRef = useRef<HTMLDivElement>(null);
  const [chatPinnedToBottom, setChatPinnedToBottom] = useState(true);

  // 用户上滚超过阈值时暂停自动滚动，回到底部附近自动恢复
  const handleChatScroll = () => {
    const el = chatScrollRef.current;
    if (!el) return;
    setChatPinnedToBottom(el.scrollHeight - el.scrollTop - el.clientHeight < 100);
  };

  useEffect(() => {
    if (chatPinnedToBottom) chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages, chatPinnedToBottom]);

  // ── 2026-09-04 组F：轮次回调收编 lib/chat/stream-turn 引擎 ──
  // 页级只保留两个差异点：apply=合入 zustand 末条 streaming 消息（无 charts 字段）；
  // onError=追加 ❌ 文本后收尾（与 assistant 页"替换整条"语义不同）。
  const applyChatPatch = (patch: TurnPatch) => {
    const ruleId = activeRuleId;
    updateChats(prev => {
      if (!ruleId) return prev;
      const msgs: ChatMessage[] = prev[ruleId] ?? [];
      const last = msgs[msgs.length - 1];
      if (last?.role === "ai" && last.streaming) {
        return {
          ...prev,
          [ruleId]: [...msgs.slice(0, -1), {
            ...last,
            text: patch.text,
            process: patch.process,
            proposals: patch.proposals,
            questions: patch.questions,
            ruleFiles: patch.ruleFiles,
          }],
        };
      }
      return prev;
    });
  };

  /** 停止生成：abort + 清 streaming 标志（2026-09-04 修复：此前末条消息 streaming 残留，spinner 不消失） */
  const stopChatStream = () => {
    if (chatAbortRef.current) { chatAbortRef.current.abort(); chatAbortRef.current = null; }
    setChatStreaming(false);
    const ruleId = activeRuleId;
    updateChats(prev => {
      if (!ruleId) return prev;
      const msgs: ChatMessage[] = prev[ruleId] ?? [];
      const last = msgs[msgs.length - 1];
      if (last?.role === "ai" && last.streaming) {
        return { ...prev, [ruleId]: [...msgs.slice(0, -1), { ...last, streaming: false }] };
      }
      return prev;
    });
  };

  const buildStrategyTurnCallbacks = (pendingId: string, onDone: () => void) => {
    const ruleId = activeRuleId;
    return buildStreamCallbacks({
      idPrefix: pendingId,
      apply: applyChatPatch,
      trackCharts: false, // 策略页消息模型无 charts 字段
      onDone,
      onError: (msg) => {
        updateChats(prev => {
          if (!ruleId) return prev;
          const msgs: ChatMessage[] = prev[ruleId] ?? [];
          const last = msgs[msgs.length - 1];
          if (last?.role === "ai" && last.streaming) {
            return { ...prev, [ruleId]: [...msgs.slice(0, -1), { ...last, text: last.text + `\n❌ ${msg}`, streaming: false }] };
          }
          return prev;
        });
        onDone();
      },
    });
  };

  const handleChatSend = (overrideText?: string) => {
    const text = (overrideText ?? chatInput).trim();
    if (!text || chatStreaming || !activeRuleId) return;
    const rule = rules.find(r => r.id === activeRuleId);
    if (!rule) return;

    const addMsgs = (msgs: ChatMessage[]) => {
      updateChats(prev => ({ ...prev, [activeRuleId]: [...(prev[activeRuleId] ?? []), ...msgs] }));
    };
    const finishStreaming = () => {
      chatAbortRef.current = null;
      setChatStreaming(false);
      updateChats(prev => {
        const msgs: ChatMessage[] = prev[activeRuleId] ?? [];
        const last = msgs[msgs.length - 1];
        if (last?.role === "ai" && last.streaming) {
          return { ...prev, [activeRuleId]: [...msgs.slice(0, -1), { ...last, streaming: false }] };
        }
        return prev;
      });
    };

    // Build context-rich prompt with rule info
    const promptText = buildStrategyPrompt(rule, text);

    addMsgs([{ role: "user", text }]);
    if (overrideText === undefined) setChatInput("");
    setChatStreaming(true);
    const msgId = `strategy-send-${Date.now()}`;
    addMsgs([{ id: msgId, role: "ai", text: "", process: [], streaming: true }]);

    // SSE to agent-server using shared streamChat utility + lib/chat 引擎
    if (chatAbortRef.current) { chatAbortRef.current.abort(); }
    const controller = streamChat(promptText, buildStrategyTurnCallbacks(msgId, finishStreaming), { strategy: true, sessionId: `strategy-${activeRuleId}` });
    chatAbortRef.current = controller;
  };

  // 回答 AI 结构化提问（ask_user → question 卡片 → POST /api/chat/answer 续流，2026-09 Phase A）
  const handleAnswerQuestion = (questionId: string, answer: string, field?: string) => {
    if (!activeRuleId || chatStreaming) return;
    if (chatAbortRef.current) { chatAbortRef.current.abort(); chatAbortRef.current = null; }

    const answerFinishStreaming = () => {
      chatAbortRef.current = null;
      setChatStreaming(false);
      updateChats(prev => {
        const msgs: ChatMessage[] = prev[activeRuleId] ?? [];
        const last = msgs[msgs.length - 1];
        if (last?.role === "ai" && last.streaming) {
          return { ...prev, [activeRuleId]: [...msgs.slice(0, -1), { ...last, streaming: false }] };
        }
        return prev;
      });
    };

    // 标记对应卡片已答
    updateChats(prev => ({
      ...prev,
      [activeRuleId]: (prev[activeRuleId] ?? []).map(m =>
        m.questions ? { ...m, questions: m.questions.map(q => q.questionId === questionId ? { ...q, answered: true } : q) } : m
      ),
    }));

    // 新起一条 streaming AI 消息承接回答流（回调集与 handleChatSend 共用引擎）
    const msgId = `strategy-answer-${Date.now()}`;
    updateChats(prev => ({
      ...prev,
      [activeRuleId]: [...(prev[activeRuleId] ?? []), { id: msgId, role: "ai" as const, text: "", process: [], streaming: true }],
    }));
    setChatStreaming(true);

    const controller = answerChatQuestion(`strategy-${activeRuleId}`, questionId, answer, buildStrategyTurnCallbacks(msgId, answerFinishStreaming), field);
    chatAbortRef.current = controller;
  };

  // Clear the chat for the active rule — chats only drive .py/.json edits, files are the source of truth
  // （strategy 会话不落盘，agent-server 无对应对话记录，无需 deleteConversation）
  const handleClearChat = () => {
    if (!activeRuleId || !activeRule) return
    if (chatAbortRef.current) { chatAbortRef.current.abort(); chatAbortRef.current = null; setChatStreaming(false); }
    updateChats(prev => ({ ...prev, [activeRuleId]: [makeWelcomeMessage(activeRule)] }));
    toast.success("对话记录已清理");
  };

  // ── P2 收编（2026-08-27）：AI 规则写操作走确认端点（strategy_rule.update_file → 金色确认卡）──
  const patchProposalStatus = (proposalId: string, patch: Partial<ActionProposal>) => {
    updateChats(prev => {
      const next: Record<string, ChatMessage[]> = {};
      for (const [ruleId, msgs] of Object.entries(prev)) {
        next[ruleId] = msgs.map(m => ({
          ...m,
          proposals: m.proposals?.map(p => p.proposalId === proposalId ? { ...p, ...patch } : p),
        }));
      }
      return next;
    });
  };

  // 2026-09-04 组F：确认/取消请求收编 lib/api/ai（fetch 与 assistant 页共用一份）
  const confirmStrategyProposal = async (proposalId: string) => {
    try {
      const r = await confirmAiAction(proposalId);
      if (r.ok) {
        patchProposalStatus(proposalId, { status: "confirmed" });
        toast.success("规则已保存");
      } else {
        patchProposalStatus(proposalId, { status: "failed", result: r.message });
        toast.error(r.message);
      }
    } catch {
      patchProposalStatus(proposalId, { status: "failed", result: "网络错误" });
      toast.error("网络错误，请重试");
    }
  };

  const cancelStrategyProposal = async (proposalId: string) => {
    try {
      const r = await cancelAiAction(proposalId);
      if (r.ok) {
        patchProposalStatus(proposalId, { status: "cancelled" });
        toast.success("已取消");
      } else {
        toast.error(r.message);
      }
    } catch {
      toast.error("网络错误，请重试");
    }
  };

  /** AI 智能介绍（对齐文档归档）：一键让 AI 完整介绍当前规则并自动发送（不占用输入框草稿） */
  const handleExplainRule = () => {
    const rule = rules.find(r => r.id === activeRuleId);
    if (!rule) return;
    handleChatSend(`请完整介绍「${rule.name}」这条规则：它的作用、全部配置项及各配置项的含义，并用一个使用示例说明。`);
  };

  return {
    chatMessages,
    chatInput,
    setChatInput,
    chatStreaming,
    chatScrollRef,
    chatEndRef,
    chatInputRef,
    handleChatScroll,
    handleChatSend,
    handleExplainRule,
    stopChatStream,
    handleClearChat,
    handleAnswerQuestion,
    confirmStrategyProposal,
    cancelStrategyProposal,
  };
}
