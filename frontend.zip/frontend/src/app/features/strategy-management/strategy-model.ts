/**
 * 策略管理页纯函数层(P1-C 拆分)——欢迎语、规则文件摘要映射与排序、
 * 新建规则派生、聊天 prompt 拼装。全部无状态无副作用,页面与各编排 hook 共用。
 */

import type {
  StrategyRule as Rule,
  StrategyRuleCategory as RuleCategory,
  RuleMetaEntry,
} from "@/app/lib/api";
import type { ChatMessage } from "./strategy-chat-store";
import { RULE_STUDY } from "./strategy-constants";

// ── 预置规则文件 → 分类/展示名(已保存元数据缺省时的兜底) ──
export const RULE_FILE_CATEGORY_MAP: Record<string, { category: RuleCategory; label: string; intro: string }> = {
  "hospital-config": {
    category: "医院基础配置", label: "检验中心基础配置",
    intro: "医院名称、科室名与系统标题等基础信息，系统设置页可改；各页面的抬头都取这里的值。",
  },
  "tat-rules": {
    category: "TAT规则", label: "TAT 期限配置",
    intro: "按检测项目配置报告时限（天）：接样登记与样本入库时据此算每个样本的 TAT 截止日与剩余天数，未列出的项目按 7 天兜底。",
  },
  "naming-rules": {
    category: "命名规则", label: "样本编号规范",
    intro: "批次号前缀与序号位数、样本/样例编号模板；批次号生成与 AI 批量建样本的编号校验都用它（样本编号本身是扫描管码）。",
  },
  "qc-rules": {
    category: "QC判定规则", label: "CNVseq QC 判定",
    intro: "测序 QC 阈值（q30、数据量）与不通过时的动作，测序报告判定读取，与项目无关。",
  },
  "anomaly-rules": {
    category: "异常处置规则", label: "标准异常处置流程",
    intro: "异常码 → 等级 / 建议处置动作 / 升级时限 / 通知角色；收样异常上报时按它回填等级与处置建议。",
  },
  "split-rules": {
    category: "分血规则", label: "标准分血方案",
    intro: "按项目与样本类型配置默认分血份数与备份份数，制备登记时作参考；实际分血以上位机回执为准。",
  },
  "control-rules": {
    category: "质控品规则", label: "标准质控品配置",
    intro: "排板时质控品的插入计划（阳性/阴性/空白的位置与数量），排单插孔按它取值。",
  },
  "workflow-rules": {
    category: "排板规则", label: "实验流程配置",
    intro: "按项目配置实验步骤序列与所需设备型号；排单默认设备与产品线提示读取它，步骤序列接线中。",
  },
  "task-schedule-rules": {
    category: "自动排单", label: "自动排单",
    intro: "按项目配置自动排单四要素（触发点 / 样本排序 / 每批数量 / 质控品）；样本入库达标即自动建待审预排单，新建项目默认启用。",
  },
}

/**新建规则弹窗的规则目录（顺序 = 学习目录：基础 → 进阶；每类一种规则，卡片标题取 label） */
export const RULE_CATALOG_ORDER: string[] = [
  "hospital-config", "tat-rules", "naming-rules", "qc-rules",
  "anomaly-rules", "split-rules", "control-rules", "workflow-rules", "task-schedule-rules",
]

export interface RuleCatalogEntry { type: string; category: RuleCategory; label: string; intro: string }

/**新建弹窗卡片清单（label/intro 与列表卡片同源） */
export const RULE_CATALOG: RuleCatalogEntry[] = RULE_CATALOG_ORDER
  .filter(t => RULE_FILE_CATEGORY_MAP[t])
  .map(t => ({ type: t, ...RULE_FILE_CATEGORY_MAP[t] }))

/** 规则欢迎语(选中规则后的首条 AI 消息) */
export function makeWelcomeMessage(rule: Rule): ChatMessage {
  const project = scheduleProjectOf(rule.id)
  if (project) {
    return {
      role: "ai",
      text: `你好！当前正在编辑「${rule.name}」规则（自动排单）。你可以直接用自然语言调整这个项目：触发数量、样本排序、每批数量、质控品、设备策略等。`,
    }
  }
  return {
    role: "ai",
    text: `你好！当前正在编辑规则「${rule.name}」（${rule.category}）。你可以用自然语言描述需求，我来帮你调整这条规则的配置。${
      rule.id === "task-schedule-rules" ? "新增自动排单规则需先与 AI 确认 4 个要素（触发点、样本排序、自动排单数量、质控品）。" : ""
    }`,
  }
}

// ── 自动排单规则虚拟卡（2026-09-16 用户反馈）：task-schedule-rules 按项目拆成独立卡片 ──
// 存储层保持"单文件按项目组织"（task-schedule-rules.py 的 RULES[project]），消费链路零改动；
// 展示层每项目一张卡（"每多一个项目、用户新增一张卡片"的使用习惯），虚拟卡 id = `task-schedule-rules#<项目名>`。

export const SCHEDULE_FILE = "task-schedule-rules"
export const SCHEDULE_CARD_PREFIX = `${SCHEDULE_FILE}#`

/** 虚拟卡 id → 项目名（非虚拟卡返回 null） */
export function scheduleProjectOf(ruleId: string): string | null {
  return ruleId.startsWith(SCHEDULE_CARD_PREFIX) ? ruleId.slice(SCHEDULE_CARD_PREFIX.length) : null
}

/** 单个项目参数的悬停摘要（触发/每批/排序） */
export function scheduleRuleBrief(cfg: Record<string, any> | undefined): { label: string; value: string }[] {
  const c = cfg ?? {}
  const trigger = c.trigger ?? {}
  const ordering = c.ordering ?? {}
  const sortLabel = ordering.sortBy === "sampleNo" ? "样本编号" : ordering.sortBy === "priority" ? "优先级" : ordering.sortBy === "sampleType" ? "样本类型" : "创建时间"
  return [
    { label: "触发点", value: trigger.type === "time" ? `每 ${trigger.value} 分钟` : `攒够 ${trigger.value ?? "-"} 管` },
    { label: "每批数量", value: String(c.autoScheduleCount ?? "-") },
    { label: "样本排序", value: `${sortLabel} ${ordering.direction === "desc" ? "降序" : "升序"}` },
  ]
}

/** 自动排单接线状态说明（服务端消费范围：count/time 触发、sampleType 等排序、批量、设备+溢出拆分、qc 质控孔、条码、流程号——全字段接线） */
export const SCHEDULE_WIRING_NOTE = "全部接线：count/time 触发、sampleType 排序、每批数量、设备+溢出拆分、qc 质控孔、条码、流程号"

/** 展开 task-schedule-rules 为每项目一张虚拟卡（其余规则原样，虚拟卡原位替换总卡） */
export function expandScheduleRules(rules: Rule[], scheduleCfg: Record<string, any>): Rule[] {
  if (!scheduleCfg || Object.keys(scheduleCfg).length === 0) return rules
  const out: Rule[] = []
  for (const r of rules) {
    if (r.id !== SCHEDULE_FILE) { out.push(r); continue }
    for (const [project, cfg] of Object.entries(scheduleCfg)) {
      const brief = scheduleRuleBrief(cfg as Record<string, any>)
      out.push({
        id: `${SCHEDULE_CARD_PREFIX}${project}`,
        name: `自动排单（${project}）`,
        category: r.category,
        enabled: (cfg as any)?.enabled !== false,
        priority: r.priority,
        fields: brief.map((b) => ({ label: b.label, value: b.value })),
        updatedBy: r.updatedBy,
        updatedAt: r.updatedAt,
      })
    }
  }
  return out
}

/** 新建项目的基础模板（与出厂文件任一项目块同构；sampleType 排序已接线生效） */
export function buildScheduleProjectTemplate(): Record<string, unknown> {
  return {
    enabled: true,
    trigger: { type: "count", value: 16 },
    ordering: { sortBy: "sampleNo", direction: "asc" },
    autoScheduleCount: 16,
    deviceStrategy: { defaultDevice: "SIRO-16", deviceCapacity: 16, overflow: [] },
    processNo: "",
    wellLayout: { barcodeStart: 1, barcodeStep: 1 },
    qc: {
      positiveControl: { count: 1, wells: "rule:每16样本末位" },
      negativeControl: { count: 1, wells: "rule:每16样本末位" },
      blankControl: { count: 1, wells: "fixed:[A1]" },
    },
  }
}

/** 后端文件摘要 + 已保存元数据 → 规则列表(含学习目录难度排序) */
export function mapRuleFilesToRules(
  files: Array<{ name: string; size: number; updatedAt: string }>,
  savedMeta: Record<string, RuleMetaEntry>,
): Rule[] {
  const mapped: Rule[] = (files || []).map(f => {
    const meta = RULE_FILE_CATEGORY_MAP[f.name]
    const saved = savedMeta[f.name]
    return {
      id: f.name,
      name: saved?.name ?? meta?.label ?? f.name,
      category: (saved?.category as RuleCategory) ?? meta?.category ?? "自定义" as RuleCategory,
      enabled: saved?.enabled ?? true,
      priority: saved?.priority ?? "中",
      fields: saved?.fields ?? [{ label: "文件", value: f.name + ".py" }, { label: "更新时间", value: f.updatedAt }],
      updatedBy: saved?.updatedBy ?? "系统",
      updatedAt: saved?.updatedAt ?? f.updatedAt,
    }
  })
  // 2026-09-11：按学习目录难度升序（序号固定，便于逐条研究）；目录外新建规则仍排末尾
  // （沿用 2026-09-01"新建不插队"的意图），同难度内按更新时间升序
  mapped.sort((a, b) => {
    const la = RULE_STUDY[a.id]?.level ?? 99;
    const lb = RULE_STUDY[b.id]?.level ?? 99;
    return la !== lb ? la - lb : (a.updatedAt ?? "").localeCompare(b.updatedAt ?? "");
  });
  return mapped
}

/** 发送消息时的上下文 prompt 拼装(规则信息 + 回答要求 + 用户需求) */
export function buildStrategyPrompt(rule: Rule, text: string): string {
  const project = scheduleProjectOf(rule.id)
  const lines = [
    `当前正在编辑规则: ${rule.name}`,
    `规则分类: ${rule.category}`,
  ]
  if (project) {
    lines.push(
      `聚焦范围: 自动排单规则文件（task-schedule-rules）的项目节点「${project}」——修改时仅调整该项目的节点内容，其余项目保持原样`,
      `规则文件: data/rules/task-schedule-rules.py（规则文件内容已在对话前自动注入，直接基于内容回答即可）`,
    )
  } else {
    lines.push(`规则文件: data/rules/${rule.id}.py（规则文件内容已在对话前自动注入，直接基于内容回答即可）`)
  }
  lines.push(
    `规则字段: ${JSON.stringify(rule.fields)}`,
    ``,
    `回答要求: 只输出最终结论/建议的规则内容，不要展示推理过程，不要原样输出规则文件的代码实现（需要引用时用一句话概括，不使用代码块）`,
    ``,
    `用户需求: ${text}`,
  )
  return lines.join("\n")
}
