import type { StrategyRuleCategory as RuleCategory } from "@/app/lib/api";

export const CATEGORY_COLORS: Record<RuleCategory, string> = {
  "自动排单": "bg-blue-50 text-blue-700",
  "分血规则": "bg-rose-50 text-rose-700",
  "异常处置规则": "bg-indigo-50 text-indigo-700",
  "排板规则": "bg-violet-50 text-violet-700",
  "质控品规则": "bg-emerald-50 text-emerald-700",
  "QC判定规则": "bg-orange-50 text-orange-700",
  "TAT规则": "bg-red-50 text-red-700",
  "命名规则": "bg-cyan-50 text-cyan-700",
  "医院基础配置": "bg-slate-100 text-slate-700",
  "自定义": "bg-pink-50 text-pink-700",
};

// ── 规则学习目录（2026-09-11）：按难度从易到难固定排序 + 生效状态标注 ─────
// 背景：此前列表按更新时间排序，9 条规则平铺无差别，难分辨哪些真正被系统消费。
// level 1=JSON 参数配置 2=Python 规则逻辑（字典匹配/多消费方联动） 3=自动排单（调度引擎）
// 2026-09-21 用户设计：档位由 4 压为 3，卡面右上角 1-3 颗五角星直接标难度（不再悬浮时显示）
// status ok=完整生效 partial=部分字段生效 spec=暂无消费点；目录外规则（用户新建）排末尾、不标注
export type RuleStudyStatus = "ok" | "partial" | "spec";
export const RULE_STUDY: Record<string, { level: number; status: RuleStudyStatus; effect: string }> = {
  "hospital-config":     { level: 1, status: "ok",      effect: "顶部医院名 / 科室名 / 浏览器标题" },
  "tat-rules":           { level: 1, status: "ok",      effect: "接样按项目算 TAT 截止日（唯一受启用开关控制）" },
  "naming-rules":        { level: 1, status: "partial", effect: "仅批次号前缀与序号位数生效；样本编号是扫描管码" },
  "qc-rules":            { level: 1, status: "ok",      effect: "测序报告 q30/yield 阈值判定（与项目无关）" },
  "anomaly-rules":       { level: 2, status: "ok",      effect: "异常上报回填等级 + 建议处置 + 升级时限" },
  "split-rules":         { level: 2, status: "ok",      effect: "制备默认分血方案文案（实际以上位机回执为准）" },
  "control-rules":       { level: 2, status: "ok",      effect: "排板质控插入计划（参考值，不强制）" },
  "workflow-rules":      { level: 2, status: "partial", effect: "排单默认设备 + 产品线软提示；steps 步骤序列未接入" },
  "task-schedule-rules": { level: 3, status: "ok",      effect: "收样后自动建待审预排单：count/time 触发、sampleType 等排序、每批数量、设备+溢出拆分、qc 质控孔、条码、流程号全部生效" },
};
export const RULE_STATUS_META: Record<RuleStudyStatus, { label: string; cls: string }> = {
  ok:      { label: "生效",   cls: "bg-emerald-50 text-emerald-600" },
  partial: { label: "部分",   cls: "bg-amber-50 text-amber-600" },
  spec:    { label: "待接线", cls: "bg-rose-50 text-rose-600" },
};

/** Beijing-time formatted date string like "8月10日" */
/** 回答中的代码块默认折叠为「查看代码」，点击展开（推理/规则代码不直接展示给用户） */

export const STRATEGY_TABS = [
  { label: "规则总览", disabled: false },
  { label: "流程引擎", disabled: true },
  { label: "状态机", disabled: true },
] as const;

