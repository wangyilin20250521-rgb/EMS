import { create } from "zustand"
import type { ActionProposal, QuestionSpec, RuleFileSpec } from "@/app/lib/utils/sse"

// ─── Strategy Chat Store（仅内存） ────────────────────────────────────────────
// Per-rule AI chat records live in memory — a page refresh clears them.
// The .py/.json rule files on the backend are the source of truth; chats are
// ephemeral helpers for adjusting rule code.

export interface ChatProcessItem {
  id: string
  type: "thinking" | "tool"
  text: string
}

export interface ChatMessage {
  id?: string
  role: "user" | "ai"
  text: string
  streaming?: boolean
  process?: ChatProcessItem[]
  /** AI 规则写操作提议（strategy_rule.update_file → 金色确认卡，2026-08-27 收编） */
  proposals?: ActionProposal[]
  /** AI 结构化提问（ask_user → question 事件，2026-09 Phase A） */
  questions?: QuestionSpec[]
  /** 规则文件卡（show_rule_file → rule_file_request 事件；2026-09-16 用户主动索取时展示预览与下载） */
  ruleFiles?: RuleFileSpec[]
}

interface StrategyChatStore {
  chats: Record<string, ChatMessage[]>
  /** Functional update over the chats map */
  updateChats: (fn: (chats: Record<string, ChatMessage[]>) => Record<string, ChatMessage[]>) => void
}

export const useStrategyChatStore = create<StrategyChatStore>((set) => ({
  chats: {},
  updateChats: (fn) => set((state) => ({ chats: fn(state.chats) })),
}))
