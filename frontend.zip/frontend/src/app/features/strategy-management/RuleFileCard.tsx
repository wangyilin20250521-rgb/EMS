import { useState } from "react";
import { Download, Eye, EyeOff, FileCode2, Loader2 } from "lucide-react";
import { getApiConfig } from "@/app/lib/api";
import { getAuthToken } from "@/app/lib/api/http";
import type { RuleFileSpec } from "@/app/lib/utils/sse";

/**
 * 规则文件卡（show_rule_file 虚拟工具 → rule_file_request 事件；2026-09-16）：
 * 分层暴露策略——默认文件对用户隐藏（自然语言微调由 AI 提议自动写入），
 * 仅用户主动索取时（"把规则文件给我看看/让我下载"）在对话流内出现本卡。
 * 预览 = 按需拉取文件内容（等宽 pre 可滚动，仅拉一次）；下载 = Blob 本地保存为 {file}.{py|json}。
 */
export function RuleFileCard({ spec }: { spec: RuleFileSpec }) {
  const [content, setContent] = useState<string | null>(null);
  const [fmt, setFmt] = useState<"py" | "json">("py");
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);

  /** 拉取文件内容（缓存；失败静默返回 null，卡片保持可重试） */
  const fetchFile = async (): Promise<string | null> => {
    if (content !== null) return content;
    setLoading(true);
    try {
      const base = getApiConfig().baseUrl;
      const headers: Record<string, string> = {};
      const t = getAuthToken(); if (t) headers["Authorization"] = `Bearer ${t}`;
      const res = await fetch(`${base}/strategy-rules/files/${spec.file}`, { headers });
      const json = await res.json();
      const c: string = json?.data?.content ?? "";
      setFmt(json?.data?.format === "json" ? "json" : "py");
      setContent(c);
      return c;
    } catch {
      return null;
    } finally {
      setLoading(false);
    }
  };

  const togglePreview = async () => {
    if (open) { setOpen(false); return; }
    await fetchFile();
    setOpen(true);
  };

  const handleDownload = async () => {
    const c = content ?? await fetchFile();
    if (c == null) return;
    const blob = new Blob([c], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${spec.file}.${fmt}`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="rounded-xl border border-border bg-card overflow-hidden w-full">
      <div className="flex items-center gap-2.5 px-3 py-2.5">
        <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 dark:text-slate-300 shrink-0">
          <FileCode2 size={15} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-[14px] text-foreground truncate">{spec.name}</p>
          {/* 扩展名在拉取前未知（.py/.json），副文案不预判；下载文件名在拉取后按真实格式生成 */}
          <p className="text-[12px] text-muted-foreground truncate">{spec.file} · 规则文件</p>
        </div>
        <button
          type="button"
          onClick={() => void togglePreview()}
          className="shrink-0 inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-border text-[14px] text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer"
        >
          {loading ? <Loader2 size={12} className="animate-spin" /> : open ? <EyeOff size={12} /> : <Eye size={12} />}
          {open ? "收起" : "预览"}
        </button>
        <button
          type="button"
          onClick={() => void handleDownload()}
          className="shrink-0 inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-primary/90 text-white text-[14px] hover:bg-primary transition-colors cursor-pointer"
        >
          <Download size={12} />下载
        </button>
      </div>
      {open && (
        <div className="border-t border-border bg-muted/20">
          <pre className="px-3 py-2.5 overflow-auto max-h-[320px] text-[12px] leading-relaxed font-mono text-foreground/85 m-0 whitespace-pre">
            {content ?? ""}
          </pre>
        </div>
      )}
    </div>
  );
}
