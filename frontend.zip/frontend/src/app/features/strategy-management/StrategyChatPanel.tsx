import type { RefObject } from "react";
import { Bot, Sparkles } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

import type { StrategyRule as Rule } from "@/app/lib/api";
import type { ChatMessage } from "./strategy-chat-store";
import { CATEGORY_COLORS, RULE_STATUS_META, RULE_STUDY } from "./strategy-constants";
import { scheduleProjectOf } from "./strategy-model";
import { CollapsibleCode, RuleDifficultyStars } from "./shared";
import { Table, TableHead, TableCell } from "@/app/components/ui/table";
import { DecisionCard, isDecisionMessage } from "@/app/features/ai-assistant/components/DecisionCard";
import { StreamingIndicator } from "@/app/components/shared/StreamingIndicator";
import { AIThinkingTrace } from "@/app/components/shared/AIThinkingTrace";
import { RuleFileCard } from "./RuleFileCard";
import { ChatComposer } from "@/app/components/shared/ChatComposer"
import { isDelegationSeedId } from "@/app/hooks/useDelegationSeeds"

/**
 * 策略聊天面板（P1-C 拆分）——规则详情头（标题 + 徽标 + AI 智能介绍，对齐文档归档）、
 * 消息区（决策卡/气泡/ActionProposalCard/QuestionCard）、输入区只负责渲染与回调上抛；
 * 状态与 SSE 编排由 useStrategyChat 持有。
 * 2026-09-16：规则文件对用户隐身（查看规则文件/清理按钮移除），只保留一键 AI 智能介绍。
 */
export function StrategyChatPanel({
  activeRule,
  messages,
  input,
  onInputChange,
  streaming,
  onSend,
  onStop,
  onExplainRule,
  onAnswerQuestion,
  onConfirmProposal,
  onCancelProposal,
  scrollRef,
  endRef,
  inputRef,
  onScroll,
}: {
  activeRule: Rule | null;
  messages: ChatMessage[];
  input: string;
  onInputChange: (value: string) => void;
  streaming: boolean;
  onSend: () => void;
  onStop: () => void;
  onExplainRule: () => void;
  onAnswerQuestion: (questionId: string, answer: string, field?: string) => void;
  onConfirmProposal: (proposalId: string) => Promise<void>;
  onCancelProposal: (proposalId: string) => Promise<void>;
  scrollRef: RefObject<HTMLDivElement | null>;
  endRef: RefObject<HTMLDivElement | null>;
  inputRef: RefObject<HTMLTextAreaElement | null>;
  onScroll: () => void;
}) {
  // 自动排单虚拟卡：状态固定"生效"（全字段已接线）；文件卡按学习目录查
  const scheduleProject = activeRule ? scheduleProjectOf(activeRule.id) : null;
  const study = activeRule
    ? scheduleProject
      ? { level: 3, status: "ok" as const }
      : RULE_STUDY[activeRule.id]
    : undefined;
  return (
    <div className="flex-1 flex flex-col min-w-0">
      {/* 规则详情头（对齐文档归档：默认态只留 标题 + 徽标 + 右上角 AI 智能介绍） */}
      <div className="px-5 py-3.5 border-b border-border flex items-start justify-between gap-4 shrink-0">
        <div className="min-w-0">
          <h1 className="text-[14px] font-semibold text-foreground truncate">{activeRule ? activeRule.name : "策略管理"}</h1>
          {activeRule ? (
            <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
              <span className={`px-1.5 py-0.5 rounded text-[14px] font-medium ${CATEGORY_COLORS[activeRule.category]}`}>{activeRule.category}</span>
              {study && <span className={`px-1.5 py-0.5 rounded text-[14px] font-medium ${RULE_STATUS_META[study.status].cls}`}>{RULE_STATUS_META[study.status].label}</span>}
              {study && <span className="text-[14px] text-muted-foreground"><RuleDifficultyStars level={study.level} /></span>}
              {activeRule.updatedAt && <span className="text-[14px] text-muted-foreground">更新 {activeRule.updatedAt.slice(0, 10)}</span>}
            </div>
          ) : (
            <p className="text-[14px] text-muted-foreground mt-1">点击左侧规则卡片开始对话</p>
          )}
        </div>
        <button
          type="button"
          onClick={onExplainRule}
          disabled={!activeRule || streaming}
          className="shrink-0 inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-primary/90 text-white text-[14px] font-medium hover:bg-primary transition-colors cursor-pointer shadow-sm shadow-primary/20 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Sparkles size={13} />AI 智能介绍
        </button>
      </div>

      {/* Chat messages — full area */}
      <div ref={scrollRef} onScroll={onScroll} className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
        {!activeRule ? (
          <div className="flex items-center justify-center h-full text-center">
            <div className="space-y-3">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                <Bot size={26} className="text-blue-600 dark:text-blue-400" />
              </div>
              <p className="text-[14px] font-medium text-muted-foreground">点击左侧规则卡片开始对话</p>
              <p className="text-[14px] text-muted-foreground">对话记录仅保存在内存中，刷新页面后自动清空</p>
            </div>
          </div>
        ) : (
          messages.map((m, i) => {
            // 决策卡：AI 含提议/提问且流式结束 → 整条回复渲染为一张大卡
            const decision = isDecisionMessage(m);
            return (
            <div key={i} className={`flex flex-col gap-1.5 ${m.role === "user" ? "items-end" : "items-start"}`}>
              {decision ? (
                <>
                  {(m.process?.length ?? 0) > 0 && (
                    <AIThinkingTrace items={m.process!} streaming={!!m.streaming} />
                  )}
                  <DecisionCard
                    text={m.text ?? ""}
                    proposals={m.proposals ?? []}
                    questions={m.questions ?? []}
                    onConfirm={(id) => onConfirmProposal(id)}
                    onCancel={(id) => onCancelProposal(id)}
                    onAnswer={(qid, field, answer) => onAnswerQuestion(qid, answer, field)}
                    disabled={streaming}
                  />
                </>
              ) : m.role === "user" ? (
                // 用户消息：右侧白底卡片（与 AI 平文形态形成主次对比）；
                // 委派记录（主助手代问）加标注——文本是主助手的委派原文，非用户本人发言
                <div className="flex flex-col items-end gap-1 max-w-[85%]">
                  {isDelegationSeedId(m.id) && (
                    <span className="text-[12px] text-muted-foreground">EMS 助手代问（委派记录）</span>
                  )}
                  <div className="px-3 py-2 rounded-2xl text-[14px] leading-relaxed bg-card border border-border text-foreground rounded-br-sm">
                    {m.text}
                  </div>
                </div>
              ) : (
                <>
                  {(m.process?.length ?? 0) > 0 && (
                    <AIThinkingTrace items={m.process!} streaming={!!m.streaming} />
                  )}
                  {/* AI 正文：无卡片平文打字（AI Native 形态）；行距 1.9 + 段落/列表间距（2026-09-17 用户反馈：行距偏密） */}
                  <div className="w-full max-w-3xl text-[14px] leading-[1.9] space-y-3 text-foreground [&_li]:my-1">
                    {m.streaming ? (
                      // 2026-09 优化：流式期间轻量纯文本渲染（避免 ReactMarkdown 每次 delta 全量解析导致的卡顿）；结束后一次性 markdown
                      <p className="whitespace-pre-wrap text-[14px] leading-[1.9]">{m.text}</p>
                    ) : (
                      <div className="strategy-chat-markdown space-y-3 [&_li]:my-1">
                        <ReactMarkdown
                          remarkPlugins={[remarkGfm]}
                          components={{
                            a: ({ children, ...props }) => <a {...props} target="_blank" rel="noreferrer" className="text-primary underline underline-offset-2" />,
                            code: ({ node, className, children, ...props }) => <code {...props} className={`${className ?? ""} rounded bg-muted px-1 py-0.5 font-mono text-[0.8125em]`}>{children}</code>,
                            pre: ({ children }) => <CollapsibleCode>{children}</CollapsibleCode>,
                            table: ({ children }) => <div className="my-2 overflow-x-auto"><Table className="w-full border-collapse text-left text-[14px]">{children}</Table></div>,
                            th: ({ children }) => <TableHead className="border border-border bg-muted px-3 py-1.5 font-semibold">{children}</TableHead>,
                            td: ({ children }) => <TableCell className="border border-border px-3 py-1.5">{children}</TableCell>,
                          }}
                        >
                          {m.text}
                        </ReactMarkdown>
                      </div>
                    )}
                    {m.streaming && <StreamingIndicator text={m.text} process={m.process} />}
                  </div>
                </>
              )}
              {/* 规则文件卡（show_rule_file；仅用户主动索取时出现：预览 + 下载） */}
              {m.role === "ai" && (m.ruleFiles?.length ?? 0) > 0 && (
                <div className="mt-2 space-y-2 w-full max-w-3xl">
                  {m.ruleFiles?.map((f) => <RuleFileCard key={f.file} spec={f} />)}
                </div>
              )}
              {/* 流式期间不渲染任何可点卡片（2026-09-22 对齐主助手）：提议/提问统一由流结束后的
                  DecisionCard 一次性完整呈现，避免未完成内容上的误点确认与"先小后大"闪烁 */}
            </div>
            );
          })
        )}
        <div ref={endRef} />
      </div>

      {/* Chat input */}
      <div className="px-4 py-3 shrink-0 space-y-2">
        <ChatComposer
          inputRef={inputRef}
          value={input}
          onChange={onInputChange}
          onSend={onSend}
          onStop={onStop}
          streaming={streaming}
          disabled={!activeRule}
          placeholder={!activeRule ? "请先点击左侧规则卡片" : streaming ? "AI 正在回复..." : "输入规则需求"}
        />
      </div>
    </div>
  );
}
