import { useState } from "react";
import { Eye, Plus, Save, Trash2, X } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import type { StrategyRule as Rule } from "@/app/lib/api";
import { getApiConfig, getAuthToken } from "@/app/lib/api";
import { Toggle, fmtBeijingNow } from "./shared";

export function EditDrawer({ rule, onClose, onSaved }: { rule: Rule; onClose: () => void; onSaved: (updated: Rule) => void }) {
  const [name, setName] = useState(rule.name);
  const [enabled, setEnabled] = useState(rule.enabled);
  const [priority, setPriority] = useState(rule.priority);
  const [fields, setFields] = useState<{ label: string; value: string }[]>(rule.fields);

  // ── Preview: pending metadata + rule file source ─────────────────────
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewContent, setPreviewContent] = useState("");
  const [previewFormat, setPreviewFormat] = useState<"json" | "py">("py");

  const handlePreview = async () => {
    setPreviewOpen(true);
    setPreviewLoading(true);
    try {
      const base = getApiConfig().baseUrl
      const headers: Record<string, string> = {}
      const t = getAuthToken(); if (t) headers["Authorization"] = `Bearer ${t}`
      const res = await fetch(`${base}/strategy-rules/files/${rule.id}`, { headers })
      const json = await res.json()
      setPreviewContent(json?.data?.content ?? "")
      setPreviewFormat(json?.data?.format === "json" ? "json" : "py")
    } catch {
      setPreviewContent("")
    } finally {
      setPreviewLoading(false)
    }
  };

  const addField = () => setFields(prev => [...prev, { label: "新条件", value: "" }]);
  const removeField = (idx: number) => setFields(prev => prev.length > 1 ? prev.filter((_, i) => i !== idx) : prev);
  const updateField = (idx: number, patch: Partial<{ label: string; value: string }>) =>
    setFields(prev => prev.map((f, i) => i === idx ? { ...f, ...patch } : f));

  const handleSave = () => {
    const updatedAt = fmtBeijingNow();
    onSaved({
      ...rule,
      name: name.trim() || rule.name,
      enabled,
      priority,
      updatedBy: "当前用户",
      updatedAt,
      fields: fields.filter(f => f.label.trim() || f.value.trim()),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="flex-1 bg-black/30" onClick={onClose} />
      <div className="w-[480px] bg-card h-full flex flex-col shadow-2xl">
        <div className="px-6 py-4 border-b border-border flex items-center justify-between shrink-0">
          <h2 className="text-base font-semibold">编辑规则</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground cursor-pointer"><X size={16} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          <div>
            <label className="text-[14px] font-medium mb-1 block">规则名称</label>
            <input value={name} onChange={e => setName(e.target.value)} className="w-full border border-border rounded-md px-3 py-2 text-[14px] focus:outline-none focus:ring-2 focus:ring-ring" />
          </div>
          <div className="flex items-center justify-between py-1">
            <div>
              <p className="text-[14px] font-medium">启用状态</p>
              <p className="text-[14px] text-muted-foreground">关闭后规则不再执行</p>
            </div>
            <Toggle enabled={enabled} onChange={() => setEnabled(!enabled)} />
          </div>
          <div>
            <label className="text-[14px] font-medium mb-1 block">优先级</label>
            <Select onValueChange={v => setPriority(v as Rule["priority"])} value={priority}>
  <SelectTrigger className="w-full border border-border rounded-md px-3 py-2 text-[14px] focus:outline-none focus:ring-2 focus:ring-ring"><SelectValue /></SelectTrigger>
  <SelectContent>

              {["高", "中", "低"].map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
            
  </SelectContent>
</Select>
          </div>
          <div className="border-t border-border pt-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-[14px] font-semibold text-muted-foreground uppercase tracking-wider">条件配置</p>
              <button type="button" onClick={addField} className="text-[14px] text-primary hover:underline cursor-pointer flex items-center gap-1"><Plus size={11} />添加条件</button>
            </div>
            <div className="space-y-3">
              {fields.map((f, index) => (
                <div key={index} className="grid grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)_auto] gap-2 items-end">
                  <div>
                    <label className="text-[14px] text-muted-foreground mb-1 block">字段名称</label>
                    <input value={f.label} onChange={e => updateField(index, { label: e.target.value })} placeholder="如：检测项目" className="w-full border border-border rounded-md px-2.5 py-2 text-[14px] focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                  <div>
                    <label className="text-[14px] text-muted-foreground mb-1 block">条件值</label>
                    <input value={f.value} onChange={e => updateField(index, { value: e.target.value })} placeholder="请输入条件值" className="w-full border border-border rounded-md px-2.5 py-2 text-[14px] focus:outline-none focus:ring-2 focus:ring-ring" />
                  </div>
                  <button type="button" onClick={() => removeField(index)} disabled={fields.length === 1}
                    className="p-2 text-muted-foreground hover:text-red-600 disabled:opacity-35 disabled:cursor-not-allowed cursor-pointer">
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}
            </div>
          </div>
          <div className="border-t border-border pt-4">
            <p className="text-[14px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">动作配置</p>
            <div className="bg-muted/30 rounded-lg p-3 text-[14px] text-muted-foreground">规则满足条件后将自动执行对应动作（按规则类型预设）</div>
          </div>
        </div>
        <div className="px-6 py-4 border-t border-border flex justify-between shrink-0">
          <Button variant="outline" size="sm" onClick={handlePreview} className="text-[14px]"><Eye size={12} />预览效果</Button>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={onClose} className="text-[14px]">取消</Button>
            <Button variant="default" onClick={handleSave} className="text-[14px]"><Save size={12} />保存</Button>
          </div>
        </div>
      </div>

      {/* Preview modal: pending metadata + rule file source */}
      {previewOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40 p-4" onClick={() => setPreviewOpen(false)}>
          <div className="bg-card rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col overflow-hidden" onClick={e => e.stopPropagation()}>
            <div className="px-5 py-4 border-b border-border flex items-center justify-between shrink-0">
              <div>
                <h3 className="text-[14px] font-semibold">规则预览</h3>
                <p className="text-[14px] text-muted-foreground mt-0.5">{name.trim() || rule.name} · {rule.category}</p>
              </div>
              <button onClick={() => setPreviewOpen(false)} className="p-1 hover:bg-muted rounded transition-colors text-muted-foreground cursor-pointer"><X size={16} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              <div className="grid grid-cols-2 gap-3 text-[14px]">
                <div className="border border-border rounded-lg p-3">
                  <p className="text-muted-foreground mb-1">启用状态</p>
                  <p className="font-medium">{enabled ? "已启用" : "已停用"}</p>
                </div>
                <div className="border border-border rounded-lg p-3">
                  <p className="text-muted-foreground mb-1">优先级</p>
                  <p className="font-medium">{priority}</p>
                </div>
              </div>
              <div className="border border-border rounded-lg p-3 text-[14px]">
                <p className="text-muted-foreground mb-2">条件字段</p>
                {fields.filter(f => f.label.trim() || f.value.trim()).length === 0 ? (
                  <p className="text-muted-foreground">（无）</p>
                ) : (
                  <div className="space-y-1">
                    {fields.filter(f => f.label.trim() || f.value.trim()).map((f, i) => (
                      <p key={i}><span className="text-muted-foreground">{f.label || "—"}:</span> <span className="font-medium">{f.value || "—"}</span></p>
                    ))}
                  </div>
                )}
              </div>
              <div className="border border-border rounded-lg overflow-hidden">
                <div className="px-3 py-2 bg-muted/30 border-b border-border">
                  <p className="text-[14px] font-mono font-medium">{rule.id}.{previewFormat}</p>
                </div>
                <pre className="p-3 text-[14px] font-mono overflow-x-auto whitespace-pre-wrap max-h-64 overflow-y-auto bg-slate-50 dark:bg-slate-900">{previewLoading ? "加载中…" : previewContent || "(空文件)"}</pre>
              </div>
            </div>
            <div className="px-5 py-3 border-t border-border flex justify-end shrink-0">
              <Button variant="default" size="sm" onClick={() => setPreviewOpen(false)} className="text-[14px]">关闭</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main Page ───────────────────────────────────────────────────────────────

