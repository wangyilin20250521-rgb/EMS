import { Button } from "@/app/components/ui/button";
import { RULE_CATALOG, SCHEDULE_FILE } from "./strategy-model";
import { CATEGORY_COLORS } from "./strategy-constants";

/**
 * 新建规则弹窗（2026-09-24 改版）——宽弹窗 + 三列规则卡片：
 * 每张卡 = 一种出厂规则（标题=规则名、小字=分类与一句话介绍），选中后在底部输入名字 → 创建。
 * 两类创建口径：自动排单相关（task-schedule-rules）= 按项目在既有文件里新增节点并默认启用；
 * 其余规则 = 从出厂基线档案的同名模板派生一个新规则文件（文件名由服务端生成）。
 * 2026-09-24 精简：去掉顶部标题/说明与底部实现细节提示（选中态与禁用态自解释）。
 */
export function QuickCreateRuleModal({
  type,
  onTypeChange,
  name,
  onNameChange,
  onSubmit,
  onCancel,
  busy,
}: {
  type: string | null;
  onTypeChange: (type: string) => void;
  name: string;
  onNameChange: (value: string) => void;
  onSubmit: () => void;
  onCancel: () => void;
  busy?: boolean;
}) {
  const schedule = type === SCHEDULE_FILE;
  const canSubmit = !!type && !!name.trim() && !busy;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-6" onClick={onCancel}>
      <div
        role="dialog"
        aria-label="新建规则"
        className="bg-card rounded-2xl shadow-2xl w-full max-w-5xl max-h-[86vh] flex flex-col"
        onClick={e => e.stopPropagation()}
        onKeyDown={e => { if (e.key === "Escape") onCancel(); }}
      >
        {/* 规则卡片网格（三列） */}
        <div className="flex-1 min-h-0 overflow-y-auto px-6 pt-6 pb-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {RULE_CATALOG.map(r => {
              const active = r.type === type;
              return (
                <button
                  key={r.type}
                  type="button"
                  onClick={() => onTypeChange(r.type)}
                  className={`text-left p-4 rounded-xl border transition-colors cursor-pointer ${
                    active
                      ? "border-primary/60 bg-primary/5 ring-1 ring-primary/30"
                      : "border-border bg-card hover:border-primary/30 hover:bg-muted/40"
                  }`}
                >
                  <div className="flex items-baseline gap-2 flex-wrap">
                    <span className="text-[16px] font-semibold text-foreground">{r.label}</span>
                    <span className={`px-1.5 py-0.5 rounded text-[11px] font-medium ${CATEGORY_COLORS[r.category]}`}>{r.category}</span>
                  </div>
                  <p className="text-[12px] text-muted-foreground leading-relaxed mt-2 line-clamp-2">{r.intro}</p>
                  {r.type === SCHEDULE_FILE && (
                    <p className="text-[11px] text-primary/90 mt-2">按检测项目新建，创建后默认启用</p>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* 底部：命名 + 创建（2026-09-24：去掉字段名标签行，占位文案自解释） */}
        <div className="px-6 py-4 border-t border-border shrink-0 flex items-center gap-3">
          <input
            autoFocus={!!type}
            aria-label={schedule ? "检测项目名称" : "规则名称"}
            value={name}
            onChange={e => onNameChange(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && canSubmit) onSubmit(); if (e.key === "Escape") onCancel(); }}
            placeholder={schedule ? "输入检测项目名称，如 NIFTY、WES、CNVseq" : "输入规则名称，如 新规则"}
            className="flex-1 min-w-0 border border-border rounded-lg px-3 py-2 text-[14px] bg-card focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <div className="flex gap-2 shrink-0">
            <Button variant="ghost" size="sm" onClick={onCancel} className="text-[14px]">取消</Button>
            <Button variant="default" size="sm" onClick={onSubmit} disabled={!canSubmit} className="text-[14px]">
              {busy ? "创建中…" : "创建"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
