import React, { useState } from "react";
import { ChevronDown, Star } from "lucide-react";
import { markdownChildrenText } from "@/app/components/shared/MarkdownPre";

/** 规则难度标记（2026-09-21 用户设计）：卡面右上角 1-3 颗黑边白底五角星、不带颜色——
 * 1 星=JSON 参数配置，2 星=Python 规则逻辑，3 星=自动排单（调度引擎）。 */
export function RuleDifficultyStars({ level }: { level: number }) {
  return (
    <span className="inline-flex items-center gap-0.5" title={`难度 ${level}/3`} aria-label={`难度 ${level}/3`}>
      {Array.from({ length: level }, (_, i) => (
        <Star key={i} size={10} strokeWidth={1.75} className="text-foreground fill-card" />
      ))}
    </span>
  );
}

export function CollapsibleCode({ children }: { children?: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  // LLM 空代码围栏守卫（2026-09-22）：空块直接不渲染，连"查看代码"入口也不出
  if (!markdownChildrenText(children).trim()) return null;
  return (
    <div className="my-2">
      <button
        onClick={() => setOpen(v => !v)}
        className="text-[14px] text-primary hover:underline flex items-center gap-1 cursor-pointer"
      >
        <ChevronDown size={11} className={`transition-transform ${open ? "rotate-180" : ""}`} />
        {open ? "收起代码" : "查看代码"}
      </button>
      {open && (
        <pre className="mt-1 overflow-x-auto rounded-lg bg-muted p-3 text-[14px] text-foreground border border-border">{children}</pre>
      )}
    </div>
  );
}

export function fmtBeijingNow(): string {
  const now = new Date();
  const bj = new Date(now.getTime() + 8 * 60 * 60 * 1000);
  return `${bj.getUTCMonth() + 1}月${bj.getUTCDate()}日`;
}

// Rule metadata (name/enabled/priority/fields) is persisted server-side in
// data/rules/.meta.json via GET/PUT /strategy-rules/meta — see lib/api/strategy.ts

export function Toggle({ enabled, onChange }: { enabled: boolean; onChange: () => void }) {
  return (
    <button onClick={e => { e.stopPropagation(); onChange(); }}
      className="rounded-full relative transition-colors cursor-pointer shrink-0"
      style={{ minWidth: 36, height: 20, background: enabled ? "var(--primary)" : "var(--switch-background)" }}>
      <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${enabled ? "left-[17px]" : "left-0.5"}`} />
    </button>
  );
}

