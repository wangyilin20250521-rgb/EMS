import { useCallback, useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, FlaskConical, Search } from "lucide-react";
import { ChartCard } from "@/app/components/shared/ChartCard";
import { DataTable, type DataTableColumn } from "@/app/components/shared/DataTable";
import { SampleStatusBadge } from "@/app/components/shared/status-badges";
import { usePagination } from "@/app/hooks/usePagination";
import { getSamples } from "@/app/lib/api";
import type { Sample, ViewId } from "@/app/lib/api";

/**
 * 样本快捷查询卡片：与 SampleCenterPage 相同的 usePagination + getSamples 服务端分页，
 * 固定高度 + 内部滚动，确保与左侧大卡片等高。
 */
export function SampleQuickQueryCard({ onNavigate, className }: { onNavigate: (v: ViewId) => void; className?: string }) {
  // ─── 复用 SampleCenterPage 相同的服务端分页模式 ───
  const fetchSamples = useCallback(
    async (params: { page?: number; pageSize?: number; search?: string }) => {
      const result = await getSamples({
        page: params.page ?? 1,
        pageSize: params.pageSize,
        search: params.search || undefined,
      });
      if (!result.ok) throw new Error(result.error.message);
      return result.data;
    },
    [],
  );

  const {
    items: rawSamples,
    total,
    page,
    pageSize,
    loading,
    error,
    setPage,
    setPageSize,
    setFilters,
  } = usePagination<Sample, { search?: string }>({
    fetcher: fetchSamples,
    initialPageSize: 5,
    initialFilters: { search: undefined },
  });

  // 客户端 slice 保底：后端可能忽略 pageSize 返回更多数据
  const samples = rawSamples.slice(0, pageSize);
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  // ─── Search Input 300ms Debounce ───
  const [input, setInput] = useState("");
  useEffect(() => {
    const timer = setTimeout(() => {
      setFilters({ search: input || undefined });
    }, 300);
    return () => clearTimeout(timer);
  }, [input, setFilters]);

  // ─── Column Definitions（以样本中心 SampleCenterPage 的真实字段/渲染逻辑为准；卡片空间有限，取核心 6 列） ───
  const columns = useMemo<DataTableColumn<Sample>[]>(
    () => [
      {
        key: "id", title: "样本编号", mono: true, link: true,
        render: (r) => (r.sampleNo ? r.sampleNo : <span className="text-muted-foreground/40 italic">待录入</span>),
      },
      { key: "patient", title: "患者", render: (r) => <span className="font-medium whitespace-nowrap">{r.patient}</span> },
      { key: "project", title: "检测项目", ellipsis: true },
      {
        key: "status", title: "状态",
        render: (r) => (
          <div className="flex flex-col gap-1">
            <SampleStatusBadge status={r.status} />
            {(r as any).isCultured && (
              <span className="text-[10px] text-cyan-700 font-medium">🧫 需培养</span>
            )}
          </div>
        ),
      },
      { key: "receivedAt", title: "收样日期" },
      {
        key: "tat", title: "TAT", mono: true,
        render: (r) => (
          <span className={`font-medium ${
            r.tat === "超期!" ? "text-red-600"
            : r.tat.includes("36") || r.tat.includes("48") ? "text-amber-600"
            : "text-muted-foreground"
          }`}>
            {r.tat}
          </span>
        ),
      },
    ],
    [],
  );

  return (
    <ChartCard
      title="样本快捷查询"
      icon={<FlaskConical size={14} />}
      className={className}
      actions={
        <div className="relative">
          <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="搜索编号 / 患者 / 项目"
            className="h-7 w-44 pl-7 pr-2 text-xs border border-border rounded-md bg-card focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
      }
    >
      {error ? (
        <div className="h-32 flex items-center justify-center text-xs text-destructive">{error}</div>
      ) : (
        <div className="flex flex-col h-full overflow-hidden">
          <div className="flex-1 overflow-y-auto min-h-0 [&::-webkit-scrollbar]:hidden" style={{ scrollbarWidth: "none" }}>
            <DataTable<Sample>
              columns={columns}
              rows={samples}
              rowKey={r => r.id}
              indexColumn
              onRowClick={() => onNavigate("sample-center")}
              emptyText={input ? "未找到匹配样本" : "暂无样本数据"}
              loading={loading}
            />
          </div>
          <div className="shrink-0 mt-2 flex items-center justify-between text-xs text-muted-foreground">
            <span>共 {total} 条</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage(page - 1)}
                disabled={page <= 1}
                className="p-1 rounded hover:bg-muted disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronLeft size={14} />
              </button>
              <span className="tabular-nums">{page}/{totalPages}</span>
              <button
                onClick={() => setPage(page + 1)}
                disabled={page >= totalPages}
                className="p-1 rounded hover:bg-muted disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </div>
      )}
    </ChartCard>
  );
}
