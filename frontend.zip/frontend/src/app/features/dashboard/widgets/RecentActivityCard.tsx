import {
  Activity,
  AlertTriangle,
  CheckCheck,
  CheckCircle2,
  History,
  TrendingUp,
  XCircle,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { ChartCard } from "@/app/components/shared/ChartCard";
import type { DashboardActivity } from "@/app/lib/api";

const ACTIVITY_ICON_MAP: Record<string, LucideIcon> = {
  CheckCheck,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  XCircle,
};

/** 最近活动卡：现有能力以新卡片头部规范重呈现（FR-013） */
export function RecentActivityCard({
  activities,
  error,
}: {
  activities: DashboardActivity[];
  error?: string;
}) {
  return (
    <ChartCard title="最近活动" icon={<History size={14} />}>
      {error ? (
        <div className="h-32 flex items-center justify-center text-xs text-destructive">{error}</div>
      ) : activities.length === 0 ? (
        <div className="h-32 flex items-center justify-center text-xs text-muted-foreground">
          暂无活动
        </div>
      ) : (
        <div className="space-y-3 max-h-48 overflow-y-auto [&::-webkit-scrollbar]:hidden">
          {activities.map((a, i) => {
            const Icon = ACTIVITY_ICON_MAP[a.icon] ?? Activity;
            return (
              <div key={i} className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center shrink-0 mt-0.5">
                  <Icon size={12} className={a.color} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground">{a.text}</p>
                </div>
                <span className="text-[11px] text-muted-foreground shrink-0 mt-0.5">{a.time}</span>
              </div>
            );
          })}
        </div>
      )}
    </ChartCard>
  );
}
