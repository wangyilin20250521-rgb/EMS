import { Activity } from "lucide-react";
import { ChartCard } from "@/app/components/shared/ChartCard";
import { HealthDonutCard } from "@/app/components/shared/HealthDonutCard";
import type { HealthSummary } from "@/app/features/dashboard/types";

/**
 * 运行健康卡（US3）：HealthDonutCard 呈现设备在线率环图。
 * 指标缺失（healthSummary 为 null）时显占位，不虚构数据（FR-005）。
 */
export function HealthWidget({ summary, error }: { summary: HealthSummary | null; error?: string }) {
  return (
    <ChartCard title="运行健康" icon={<Activity size={14} />}>
      {error ? (
        <div className="h-28 flex items-center justify-center text-xs text-destructive">{error}</div>
      ) : !summary ? (
        <div className="h-28 flex items-center justify-center text-xs text-muted-foreground">
          设备指标暂不可用
        </div>
      ) : (
        <HealthDonutCard online={summary.online} total={summary.total} />
      )}
    </ChartCard>
  );
}
