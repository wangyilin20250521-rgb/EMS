import { BellRing } from "lucide-react";
import { ChartCard } from "@/app/components/shared/ChartCard";
import { AlertPanelCard } from "@/app/components/shared/AlertPanelCard";
import type { ViewId } from "@/app/lib/api";
import type { AlertSummary } from "@/app/features/dashboard/types";

/**
 * TAT 预警面板（US3）：AlertPanelCard 呈现预警/超期双计数。
 * 指标加载失败时显占位文案，不虚构数据（FR-005）。
 */
export function AlertPanelWidget({
  summary,
  error,
  onNavigate,
  isAllowed,
}: {
  summary: AlertSummary;
  error?: string;
  onNavigate: (v: ViewId) => void;
  isAllowed: (v: ViewId) => boolean;
}) {
  const goAnomaly = isAllowed("anomaly-center") ? () => onNavigate("anomaly-center") : undefined;

  return (
    <ChartCard title="TAT 预警" icon={<BellRing size={14} />}>
      {error ? (
        <div className="h-28 flex items-center justify-center text-xs text-destructive">{error}</div>
      ) : (
        <AlertPanelCard
          warning={summary.warning}
          overdue={summary.overdue}
          onWarningClick={goAnomaly}
          onOverdueClick={goAnomaly}
        />
      )}
    </ChartCard>
  );
}
