import { TrendingUp } from "lucide-react";
import { ChartCard } from "@/app/components/shared/ChartCard";
import { GradientBarChart } from "../charts";
import type { BarDatum } from "@/app/lib/api";

/**
 * 收样趋势卡：数据由页面日期范围筛选驱动后端 /dashboard/reception-trend
 * （单日按时段 slots / 多日按天 MM-DD），由 GradientBarChart 渐变柱状图封装渲染。
 * 标题随筛选范围动态（今日收样趋势 / 近7日收样趋势 / …）。
 */
export function TrendCard({
  data,
  title = "收样趋势",
  error,
}: {
  data: BarDatum[];
  title?: string;
  error?: string;
}) {
  return (
    <ChartCard title={title} icon={<TrendingUp size={14} />}>
      {error ? (
        <div className="h-[220px] flex items-center justify-center text-xs text-destructive">{error}</div>
      ) : data.length === 0 ? (
        <div className="h-[220px] flex items-center justify-center text-xs text-muted-foreground">
          暂无收样数据
        </div>
      ) : (
        <GradientBarChart data={data} seriesName="收样量" height={220} />
      )}
    </ChartCard>
  );
}
