import { BarChart3, PieChart } from "lucide-react";
import { GradientBarChart, CenterDonutChart } from "../charts";
import type { ChartDatum } from "@/app/lib/api";

export type DistributionChartMode = "bar" | "donut";

/** 分布图切换按钮组（供外部卡片头部复用） */
export function DistributionModeToggle({
  mode,
  onChange,
}: {
  mode: DistributionChartMode;
  onChange: (m: DistributionChartMode) => void;
}) {
  return (
    <div className="flex rounded-md border border-border overflow-hidden">
      {(["bar", "donut"] as DistributionChartMode[]).map(m => (
        <button
          key={m}
          onClick={() => onChange(m)}
          className={`flex items-center gap-1 px-2 py-1 text-[11px] transition-colors cursor-pointer ${
            mode === m
              ? "bg-primary text-primary-foreground"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          {m === "bar" ? <BarChart3 size={11} /> : <PieChart size={11} />}
          {m === "bar" ? "柱状图" : "环状图"}
        </button>
      ))}
    </div>
  );
}

/**
 * 样本状态分布内容（无卡片包装）：柱状图/环状图 + 图例，
 * 由外部容器提供卡片结构和头部。
 */
export function DistributionContent({
  data,
  error,
  mode,
}: {
  data: ChartDatum[];
  error?: string;
  mode: DistributionChartMode;
}) {
  const barData = data.map(d => ({ time: d.name, count: d.value }));
  const colors = data.map(d => d.color);

  if (error) {
    return <div className="h-[220px] flex items-center justify-center text-xs text-destructive">{error}</div>;
  }

  return (
    <>
      {mode === "bar" ? (
        <GradientBarChart data={barData} seriesName="样本数" height={190} colors={colors} />
      ) : (
        <CenterDonutChart data={data} height={190} />
      )}
      {/* 图例：两形态一致 */}
      <div className="flex flex-wrap gap-x-3 gap-y-1 mt-3">
        {data.map(d => (
          <div key={d.name} className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full shrink-0" style={{ background: d.color }} />
            <span className="text-[11px] text-muted-foreground">
              {d.name} ({d.value})
            </span>
          </div>
        ))}
      </div>
    </>
  );
}
