import { Zap } from "lucide-react";
import { ChartCard } from "@/app/components/shared/ChartCard";
import { IconAsset } from "@/app/components/shared/IconAsset";
import { STAT_TILE_TONE_CLASSES, type StatTileTone } from "@/app/components/shared/StatTile";
import type { ViewId } from "@/app/lib/api";

interface QuickAction {
  label: string;
  iconAsset: string;
  view: ViewId;
  tone: StatTileTone;
}

/** 快速操作入口配置（EMS 特有模块，图标与侧边栏统一，风格与 StatTile 对齐） */
const QUICK_ACTIONS: QuickAction[] = [
  { label: "收样中心", iconAsset: "register",  view: "unpack-register",  tone: "blue" },
  { label: "样本中心", iconAsset: "samples",   view: "sample-center",    tone: "green" },
  { label: "策略管理", iconAsset: "strategy",  view: "strategy-management", tone: "amber" },
  { label: "EMS 助手",  iconAsset: "ai",        view: "ai-assistant",     tone: "teal" },
];

export function QuickActionsCard({
  onNavigate,
  isAllowed,
}: {
  onNavigate: (v: ViewId) => void;
  /** 角色权限过滤：无权限的入口直接隐藏（避免点击后被路由守卫弹回） */
  isAllowed: (v: ViewId) => boolean;
}) {
  const visible = QUICK_ACTIONS.filter(a => isAllowed(a.view));
  if (visible.length === 0) return null;

  return (
    <ChartCard title="快速操作" icon={<Zap size={14} />}>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {visible.map(a => {
          const toneClasses = STAT_TILE_TONE_CLASSES[a.tone];
          return (
            <button
              key={a.label}
              onClick={() => onNavigate(a.view)}
              className={`relative w-full overflow-hidden rounded-xl border border-border/60 bg-gradient-to-br p-4 text-left transition-all hover:shadow-md hover:-translate-y-0.5 cursor-pointer ${toneClasses}`}
            >
              <div className="flex items-start justify-between gap-2">
                <span className="text-sm font-medium">{a.label}</span>
                <div className="shrink-0 opacity-90">
                  <IconAsset name={a.iconAsset} size={32} />
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </ChartCard>
  );
}
