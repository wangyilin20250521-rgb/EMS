import { StatTile } from "@/app/components/shared/StatTile";
import type { ViewId } from "@/app/lib/api";
import type { StageStat } from "@/app/features/dashboard/types";

/** 流程阶段指标瓷砖组：配置驱动（dashboard-config.json stageTiles），点击跳转 */
export function StageTiles({
  stages,
  onNavigate,
  isAllowed,
}: {
  stages: StageStat[];
  onNavigate: (v: ViewId) => void;
  /** 角色权限过滤：无权限的跳转目标不响应（避免被路由守卫弹回） */
  isAllowed: (v: ViewId) => boolean;
}) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
      {stages.map(s => (
        <StatTile
          key={s.key}
          label={s.label}
          value={s.value}
          tone={s.tone}
          iconAsset={s.iconAsset}
          onClick={() => {
            if (isAllowed(s.target)) onNavigate(s.target);
          }}
        />
      ))}
    </div>
  );
}
