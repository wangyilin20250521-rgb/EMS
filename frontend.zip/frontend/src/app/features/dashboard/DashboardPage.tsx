import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, PieChart } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { toast } from "sonner";
import { ChartCard } from "@/app/components/shared/ChartCard";
import { StageTiles } from "./widgets/StageTiles";
import { DistributionContent, DistributionModeToggle, type DistributionChartMode } from "./widgets/DistributionCard";
import { TrendCard } from "./widgets/TrendCard";
import { RecentActivityCard } from "./widgets/RecentActivityCard";
import { SampleQuickQueryCard } from "./widgets/SampleQuickQueryCard";
import { HealthWidget } from "./widgets/HealthWidget";
import { QuickActionsCard } from "./widgets/QuickActionsCard";
import { AlertPanelCard } from "@/app/components/shared/AlertPanelCard";
import { useDashboardData } from "@/app/hooks/useDashboardData";
import { useAuth } from "@/app/hooks/useAuth";
import { isViewAllowed } from "@/app/lib/view-permissions";
import type { DashboardDateRange, ViewId } from "@/app/lib/api";

/**
 * 首页（瘦编排页）：仅负责布局网格与 widgets 组合，
 * 数据加载/派生全部由 useDashboardData 承担。
 * 顶部工具条保留日期范围筛选（今日/近7日/近30日/自定义）+ 最后更新/手动刷新。
 */
export function DashboardPage({ onNavigate }: { onNavigate: (v: ViewId) => void }) {
  const { user } = useAuth();

  // ─── Date Range Filter: Today / Last 7 Days / Last 30 Days / Custom（本页独有功能，保留） ───
  type RangePreset = "today" | "7d" | "30d" | "custom";
  const fmtDate = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const [preset, setPreset] = useState<RangePreset>("today");
  const [customFrom, setCustomFrom] = useState(() => fmtDate(new Date(Date.now() - 6 * 86400000)));
  const [customTo, setCustomTo] = useState(() => fmtDate(new Date()));
  const range = useMemo<DashboardDateRange>(() => {
    if (preset === "today") return { dateFrom: fmtDate(new Date()), dateTo: fmtDate(new Date()) };
    if (preset === "7d") return { dateFrom: fmtDate(new Date(Date.now() - 6 * 86400000)), dateTo: fmtDate(new Date()) };
    if (preset === "30d") return { dateFrom: fmtDate(new Date(Date.now() - 29 * 86400000)), dateTo: fmtDate(new Date()) };
    return { dateFrom: customFrom, dateTo: customTo };
  }, [preset, customFrom, customTo]);
  const rangeLabel = preset === "today" ? "今日收样" : preset === "7d" ? "近7日收样" : preset === "30d" ? "近30日收样" : "区间收样";
  const trendTitle = rangeLabel.replace("收样", "收样趋势");

  const {
    distribution,
    tatWarnings,
    activities,
    trendBarData,
    errors,
    stageStats,
    alertSummary,
    healthSummary,
  } = useDashboardData(range, rangeLabel);

  const [distMode, setDistMode] = useState<DistributionChartMode>("bar");

  const allowed = (v: ViewId) => isViewAllowed(user?.role, v);
  const overdueCount = tatWarnings.filter(w => w.isOverdue).length;

  // 自定义范围 from > to 时提示（不请求）
  useEffect(() => {
    if (preset === "custom" && customFrom > customTo) toast.error("开始日期不能晚于结束日期");
  }, [preset, customFrom, customTo]);

  return (
    <div className="px-6 pb-6 pt-2 space-y-3 overflow-y-auto [&::-webkit-scrollbar]:hidden h-full" style={{ scrollbarWidth: "none" }}>
      {/* 上方：左侧大卡片（指标瓷砖 + 分布图，3:2 加宽，头部集成日期范围筛选）/ 右侧样本快捷查询 */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 items-stretch">
        <div className="lg:col-span-3 bg-card rounded-card border border-border shadow-card flex flex-col overflow-hidden">
          <div className="flex items-center gap-2 px-4 pt-4 pb-3">
            <span className="flex items-center justify-center text-primary shrink-0"><PieChart size={14} /></span>
            <h3 className="text-sm font-semibold text-foreground flex-1 min-w-0 truncate">样本状态分布</h3>
            <DistributionModeToggle mode={distMode} onChange={setDistMode} />
            {/* 日期范围筛选（全局作用于下方各卡片） */}
            <div className="flex items-center gap-1.5">
              <Select value={preset} onValueChange={(v) => setPreset(v as RangePreset)}>
                <SelectTrigger size="sm" className="w-24 h-8 px-2.5 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">今日</SelectItem>
                  <SelectItem value="7d">近7日</SelectItem>
                  <SelectItem value="30d">近30日</SelectItem>
                  <SelectItem value="custom">自定义</SelectItem>
                </SelectContent>
              </Select>
              {preset === "custom" && (
                <div className="flex items-center gap-1.5">
                  <input
                    type="date"
                    className="h-8 px-2 text-xs border border-border rounded-md bg-card focus:outline-none focus:ring-2 focus:ring-ring"
                    value={customFrom}
                    onChange={(e) => setCustomFrom(e.target.value)}
                  />
                  <span className="text-xs text-muted-foreground">至</span>
                  <input
                    type="date"
                    className="h-8 px-2 text-xs border border-border rounded-md bg-card focus:outline-none focus:ring-2 focus:ring-ring"
                    value={customTo}
                    onChange={(e) => setCustomTo(e.target.value)}
                  />
                </div>
              )}
            </div>
          </div>
          <div className="px-4 pb-2">
            <StageTiles stages={stageStats} onNavigate={onNavigate} isAllowed={allowed} />
          </div>
          <div className="flex-1 px-4 pb-4 pt-4 min-h-0">
            <DistributionContent data={distribution} error={errors.distribution} mode={distMode} />
          </div>
        </div>
        <div className="lg:col-span-2 lg:relative">
          <div className="lg:absolute lg:inset-0">
            <SampleQuickQueryCard onNavigate={onNavigate} className="h-full" />
          </div>
        </div>
      </div>

      {/* 中间：TAT 预警明细 / 运行健康 / 收样趋势 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <ChartCard
          title="TAT 预警"
          icon={<AlertTriangle size={14} />}
          actions={
            overdueCount > 0 ? (
              <span className="text-[10px] text-red-600 font-medium bg-red-50 dark:bg-red-950 px-2 py-0.5 rounded-full">
                {overdueCount}条超期
              </span>
            ) : undefined
          }
        >
          {errors.warnings ? (
            <div className="h-[220px] flex items-center justify-center text-xs text-destructive">
              {errors.warnings}
            </div>
          ) : (
            <>
              {/* 双色预警面板（B 设计）：预警/超期计数，点击跳异常中心 */}
              <AlertPanelCard
                warning={alertSummary.warning}
                overdue={alertSummary.overdue}
                className="h-auto shrink-0"
                onWarningClick={allowed("anomaly-center") ? () => onNavigate("anomaly-center") : undefined}
                onOverdueClick={allowed("anomaly-center") ? () => onNavigate("anomaly-center") : undefined}
              />
              {/* 预警明细列表（A 逻辑，与面板同源 tat-warnings；封顶 200px，多了卡内滚动，不撑高卡片） */}
              <div className="mt-3 flex-1 min-h-0 max-h-[200px] space-y-2 overflow-y-auto [&::-webkit-scrollbar]:hidden">
                {tatWarnings.map(item => (
                  <div
                    key={item.sampleId}
                    className={`flex items-center justify-between text-xs p-2 rounded ${
                      item.isOverdue
                        ? "bg-red-50 dark:bg-red-950/40"
                        : "bg-amber-50 dark:bg-amber-950/40"
                    }`}
                  >
                    <span className="font-mono text-[11px] text-muted-foreground">
                      {item.sampleId.slice(-3)}
                    </span>
                    <span className="text-foreground font-medium">
                      {item.patient} · {item.project}
                    </span>
                    <span className={`font-medium ${item.isOverdue ? "text-red-600" : "text-amber-600"}`}>
                      {item.tatRemaining}
                    </span>
                  </div>
                ))}
                {tatWarnings.length === 0 && (
                  <div className="py-4 flex items-center justify-center text-xs text-muted-foreground">
                    暂无预警
                  </div>
                )}
              </div>
            </>
          )}
        </ChartCard>
        <HealthWidget summary={healthSummary} error={errors.stats} />
        <TrendCard data={trendBarData} title={trendTitle} error={errors.trendSeries} />
      </div>

      {/* 快速操作（快捷入口，ChartCard 卡片化呈现） */}
      <QuickActionsCard onNavigate={onNavigate} isAllowed={allowed} />

      {/* 底部：最近活动 */}
      <RecentActivityCard activities={activities} error={errors.activities} />
    </div>
  );
}
