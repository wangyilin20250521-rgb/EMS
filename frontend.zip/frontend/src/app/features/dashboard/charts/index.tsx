import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { ChartDatum, BarDatum } from "@/app/lib/api";

const TOOLTIP_STYLE: React.CSSProperties = {
  background: "var(--card)",
  border: "1px solid var(--border)",
  borderRadius: 8,
  fontSize: 12,
  color: "var(--foreground)",
};

const AXIS_TICK = { fontSize: 11, fill: "var(--muted-foreground)" };

/** 渐变柱状图：每柱 linearGradient（上深下浅），颜色取自数据项 color */
export function GradientBarChart({
  data,
  height = 200,
  seriesName = "数量",
  colors,
}: {
  data: BarDatum[];
  height?: number;
  seriesName?: string;
  /** 每柱颜色（与 data 等长），缺省用统一蓝色渐变 */
  colors?: string[];
}) {
  if (data.length === 0) {
    return <div className="flex items-center justify-center text-xs text-muted-foreground" style={{ height }}>暂无数据</div>;
  }
  return (
    <div style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
          <defs>
            {data.map((d, i) => {
              const baseColor = colors?.[i] ?? "#4ba1fd";
              return (
                <linearGradient key={i} id={`bar-grad-${i}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={baseColor} stopOpacity={1} />
                  <stop offset="100%" stopColor={baseColor} stopOpacity={0.6} />
                </linearGradient>
              );
            })}
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
          <XAxis dataKey="time" tick={AXIS_TICK} axisLine={false} tickLine={false} />
          <YAxis tick={AXIS_TICK} axisLine={false} tickLine={false} allowDecimals={false} />
          <Tooltip contentStyle={TOOLTIP_STYLE} cursor={{ fill: "var(--muted)", opacity: 0.4 }} />
          <Bar dataKey="count" name={seriesName} radius={[4, 4, 0, 0]} maxBarSize={28}>
            {data.map((_, i) => (
              <Cell key={i} fill={`url(#bar-grad-${i})`} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

/** 带中心总计的环图：颜色取自数据项 color */
export function CenterDonutChart({
  data,
  height = 200,
  centerLabel = "总计",
}: {
  data: ChartDatum[];
  height?: number;
  centerLabel?: string;
}) {
  const total = data.reduce((s, d) => s + d.value, 0);
  if (data.length === 0 || total === 0) {
    return <div className="flex items-center justify-center text-xs text-muted-foreground" style={{ height }}>暂无数据</div>;
  }
  return (
    <div className="relative" style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            innerRadius="60%"
            outerRadius="85%"
            paddingAngle={2}
            startAngle={90}
            endAngle={-270}
            stroke="none"
          >
            {data.map((d, i) => (
              <Cell key={i} fill={d.color} />
            ))}
          </Pie>
          <Tooltip contentStyle={TOOLTIP_STYLE} />
        </PieChart>
      </ResponsiveContainer>
      {/* 中心总计 */}
      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
        <span
          className="text-xl font-bold text-foreground tabular-nums leading-none"
          style={{ fontFamily: "'DM Mono', monospace" }}
        >
          {total}
        </span>
        <span className="text-[10px] text-muted-foreground mt-1">{centerLabel}</span>
      </div>
    </div>
  );
}

/** 多系列平滑面积图：每项目一条曲线 + 图例 + 日期轴（feature 004 US4） */
export function MultiSeriesAreaChart({
  rows,
  seriesNames,
  height = 240,
}: {
  /** 行数据：{ date: string; [项目名]: number }[] */
  rows: Array<Record<string, string | number>>;
  seriesNames: string[];
  height?: number;
}) {
  if (rows.length === 0) {
    return <div className="flex items-center justify-center text-xs text-muted-foreground" style={{ height }}>暂无数据</div>;
  }
  return (
    <div style={{ height }}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChartWrapper rows={rows} seriesNames={seriesNames} />
      </ResponsiveContainer>
    </div>
  );
}

// Omics 换肤（2026-08-27）：与 theme.css --chart-1..5 同色系
const SERIES_COLORS = ["#4ba1fd", "#25b865", "#ff7d00", "#f53f3f", "#0fc6c2"];

function AreaChartWrapper({
  rows,
  seriesNames,
}: {
  rows: Array<Record<string, string | number>>;
  seriesNames: string[];
}) {
  return (
    <AreaChart data={rows} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
      <defs>
        {seriesNames.map((name, i) => (
          <linearGradient key={name} id={`area-grad-${i}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={SERIES_COLORS[i % SERIES_COLORS.length]} stopOpacity={0.35} />
            <stop offset="100%" stopColor={SERIES_COLORS[i % SERIES_COLORS.length]} stopOpacity={0.02} />
          </linearGradient>
        ))}
      </defs>
      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
      <XAxis dataKey="date" tick={AXIS_TICK} axisLine={false} tickLine={false} />
      <YAxis tick={AXIS_TICK} axisLine={false} tickLine={false} allowDecimals={false} />
      <Tooltip contentStyle={TOOLTIP_STYLE} />
      <Legend wrapperStyle={{ fontSize: 11 }} />
      {seriesNames.map((name, i) => (
        <Area
          key={name}
          type="monotone"
          dataKey={name}
          stroke={SERIES_COLORS[i % SERIES_COLORS.length]}
          strokeWidth={2}
          fill={`url(#area-grad-${i})`}
          dot={false}
          activeDot={{ r: 3 }}
        />
      ))}
    </AreaChart>
  );
}
