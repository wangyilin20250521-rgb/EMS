/**
 * Dashboard 视图模型类型（UI 升级 feature 004 首页重构）。
 * 纯前端视图模型，非后端数据契约——后端类型仍以 lib/api/types.ts 为准（api 层零改动）。
 */
import type { ViewId } from "@/app/lib/api";
import type { StatTileTone } from "@/app/components/shared/StatTile";

/** 流程阶段指标瓷砖：dashboard-config.json stageTiles 配置 + 后端值合并 */
export interface StageStat {
  key: string;
  label: string;
  value: number;
  tone: StatTileTone;
  iconAsset: string;
  target: ViewId;
}

/** TAT 预警汇总：getTatWarnings 按 isOverdue 分组计数 */
export interface AlertSummary {
  overdue: number;
  warning: number;
}

/** 运行健康汇总：设备在线/总数（含 SIRO 合并） */
export interface HealthSummary {
  online: number;
  total: number;
}
