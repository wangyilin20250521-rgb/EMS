import { Plus, XCircle } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { EMPTY_PRODUCT_LINE, type ProductLineItem } from "./unpack-register-model";

// ─── Per-Product Detail Dynamic Rows（仅 detail 模式渲染） ─────────────────────────

/** 产品收样明细动态行：按行选择产品/样本类型并填写数量，整数组更新交由上层回调 */
export function ProductLinesSection({ products, onChange, dictProductOptions, dictSampleTypeOptions }: {
  products: ProductLineItem[];
  onChange: (next: ProductLineItem[]) => void;
  dictProductOptions: string[];
  dictSampleTypeOptions: string[];
}) {
  const addLine = () => {
    onChange([...products, { ...EMPTY_PRODUCT_LINE }]);
  };
  const removeLine = (idx: number) => {
    onChange(products.filter((_, i) => i !== idx));
  };
  const updateLine = <K extends keyof ProductLineItem>(idx: number, field: K, val: ProductLineItem[K]) => {
    onChange(products.map((p, i) => (i === idx ? { ...p, [field]: val } : p)));
  };

  return (
    <div className="space-y-3">
      <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">分产品核对数量</p>

      <div className="space-y-2">
        {products.length === 0 ? (
          <p className="text-[10px] text-muted-foreground italic bg-card/50 p-3 rounded-lg border border-dashed border-border text-center">暂无产品明细，点击下方 + 号添加</p>
        ) : (
          products.map((p, idx) => (
            <div key={idx} className="flex items-center gap-2 animate-in fade-in slide-in-from-right-1 duration-200">
              {/* 产品类型（产品套餐/编号录入移到入库登记阶段补充） */}
              <Select onValueChange={v => updateLine(idx, 'name', v)} value={p.name}>
                <SelectTrigger className="flex-1 px-2 py-1.5 text-xs border border-border rounded-md bg-card outline-none"><SelectValue placeholder="请选择产品" /></SelectTrigger>
                <SelectContent>
                  {dictProductOptions.map(opt => <SelectItem key={idx + opt} value={opt}>{opt}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select onValueChange={v => updateLine(idx, 'sampleType', v)} value={p.sampleType}>
                <SelectTrigger className="w-20 px-2 py-1.5 text-xs border border-border rounded-md bg-card outline-none"><SelectValue placeholder="请选择" /></SelectTrigger>
                <SelectContent>
                  {dictSampleTypeOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                </SelectContent>
              </Select>
              <div className="relative w-24">
                <input
                  type="number"
                  className="w-full pl-2 pr-6 py-1.5 text-xs border border-border rounded-md outline-none focus:ring-1 focus:ring-primary"
                  value={p.count || ""}
                  placeholder="数量"
                  onChange={e => updateLine(idx, 'count', +e.target.value)}
                />
                <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground">管</span>
              </div>
              <button
                onClick={() => removeLine(idx)}
                className="text-slate-300 hover:text-red-500 p-1 cursor-pointer"
              >
                <XCircle size={14} />
              </button>
            </div>
          ))
        )}
      </div>

      {/* 底部 + 号：点击新增一行明细 */}
      <button
        onClick={addLine}
        aria-label="添加产品明细"
        className="w-full flex items-center justify-center py-1 rounded-lg border border-dashed border-border text-muted-foreground hover:text-primary hover:border-primary/50 transition-colors cursor-pointer"
      >
        <Plus size={14} />
      </button>
    </div>
  );
}
