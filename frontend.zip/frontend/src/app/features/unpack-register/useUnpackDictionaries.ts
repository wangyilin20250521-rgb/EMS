import { useEffect, useState } from "react";
import { HOSPITAL_OPTIONS, PROJECT_OPTIONS, SAMPLE_TYPE_OPTIONS, SOURCE_OPTIONS } from "@/app/lib/api";
import { getDictItems } from "@/app/lib/api/system";

// ─── 收样登记字典：从后端 API 拉取实时选项，失败时回退到静态常量 ────────────────

/** 返回来源/医院/产品/样本类型四组下拉选项（原弹窗内联逻辑等价搬运） */
export function useUnpackDictionaries() {
  const [dictSourceOptions, setDictSourceOptions] = useState<string[]>([...SOURCE_OPTIONS]);
  const [dictHospitalOptions, setDictHospitalOptions] = useState<string[]>([...HOSPITAL_OPTIONS]);
  const [dictProductOptions, setDictProductOptions] = useState<string[]>([...PROJECT_OPTIONS]);
  const [dictSampleTypeOptions, setDictSampleTypeOptions] = useState<string[]>([...SAMPLE_TYPE_OPTIONS]);
  useEffect(() => {
    const fetchDict = (cat: string, setter: (v: string[]) => void, fallback: readonly string[]) => {
      getDictItems(cat).then(data => {
        if (Array.isArray(data) && data.length > 0) setter(data.map((it) => it.name));
      }).catch(() => setter([...fallback]));
    };
    fetchDict("样本来源", setDictSourceOptions, SOURCE_OPTIONS);
    fetchDict("来源医院", setDictHospitalOptions, HOSPITAL_OPTIONS);
    fetchDict("检测项目", setDictProductOptions, PROJECT_OPTIONS);
    fetchDict("样本类型", setDictSampleTypeOptions, SAMPLE_TYPE_OPTIONS);
  }, []);
  return { dictSourceOptions, dictHospitalOptions, dictProductOptions, dictSampleTypeOptions };
}
