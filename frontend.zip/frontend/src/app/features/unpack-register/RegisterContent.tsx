import { useEffect } from "react";
import { AlertTriangle, FileArchive, QrCode } from "lucide-react";
import { Input } from "@/app/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import type { UnpackFormState } from "@/app/lib/api/types";
import { ProductLinesSection } from "./ProductLinesSection";
import { ScanBarcodeSection, type ScanVerifyState } from "./ScanBarcodeSection";
import { ReceptionAnomalySection } from "./ReceptionAnomalySection";
import { computeAutoTubeCount, EMPTY_PRODUCT_LINE, type AnomalyDraft, type RegisterMode } from "./unpack-register-model";

// ─── Fill Registration Info（公共字段 + 按模式的条件区块） ──────────────────────

/** 登记表单主体：公共字段一行 + 收样明细（管数/单据数 + 按模式的产品明细/扫码区块） + 异常登记 + 备注 */
export function RegisterContent({ mode, newForm, setNewForm, anomalies, setAnomalies,
  currentAnomaly, setCurrentAnomaly, showAnomaly, setShowAnomaly,
  barcodes, setBarcodes, verifyMap, onBarcodeAdded,
  dictSourceOptions, dictHospitalOptions, dictProductOptions, dictSampleTypeOptions }: {
  mode: RegisterMode;
  newForm: UnpackFormState;
  setNewForm: React.Dispatch<React.SetStateAction<UnpackFormState>>;
  anomalies: AnomalyDraft[];
  setAnomalies: React.Dispatch<React.SetStateAction<AnomalyDraft[]>>;
  /** 当前异常录入草稿（生命周期仍在弹窗层，本组件仅透传给异常区） */
  currentAnomaly: AnomalyDraft;
  setCurrentAnomaly: React.Dispatch<React.SetStateAction<AnomalyDraft>>;
  showAnomaly: boolean;
  setShowAnomaly: (v: boolean) => void;
  barcodes: string[];
  setBarcodes: React.Dispatch<React.SetStateAction<string[]>>;
  /** 扫码实时复核状态映射（主组件持有，扫码即查 HIS） */
  verifyMap: Record<string, ScanVerifyState>;
  /** 新增条码 → 主组件触发实时复核 */
  onBarcodeAdded: (code: string) => void;
  dictSourceOptions: string[];
  dictHospitalOptions: string[];
  dictProductOptions: string[];
  dictSampleTypeOptions: string[];
}) {
  const addProductLine = () => {
    setNewForm(f => ({
      ...f,
      products: [...f.products, { ...EMPTY_PRODUCT_LINE }]
    }));
  };

  // 样本管总数自动统计（不允许手填的模式）：
  // 分产品模式 = 产品明细合计 + 异常样本数量（异常也占管），实收单据数同步联动（与管总数一致）；
  // 扫码模式 = 条码数量。覆盖模式切换/清空等非输入路径，防止残留手填值。
  useEffect(() => {
    const auto = computeAutoTubeCount(mode, newForm.products, barcodes.length, anomalies.length);
    if (auto !== null && newForm.actualTubes !== auto) {
      setNewForm(f => ({ ...f, actualTubes: auto }));
    }
  }, [mode, newForm.products, barcodes, anomalies]); // 依赖有意收窄：仅这些字段变化时同步管数

  return (
    <div className="space-y-6">
      {/* 顶部四字段一行（弹窗加宽至 max-w-3xl 后容纳） */}
      <div className="grid grid-cols-4 gap-4">
        <div>
          <label className="text-xs text-muted-foreground block mb-1">样本来源</label>
          <Select value={newForm.source} onValueChange={v => setNewForm(f => ({ ...f, source: v, hospital: v === "本院" ? "本院" : (f.hospital === "本院" ? "" : f.hospital) }))}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="选择样本来源" />
            </SelectTrigger>
            <SelectContent>
              {dictSourceOptions.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs text-muted-foreground block mb-1">来源医院</label>
          {/* 联动：来源=本院时来源医院置灰锁定为本院，不支持修改 */}
          <Select
            value={newForm.source === "本院" ? "本院" : newForm.hospital}
            onValueChange={v => setNewForm(f => ({ ...f, hospital: v }))}
            disabled={newForm.source === "本院"}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="选择来源医院" />
            </SelectTrigger>
            <SelectContent>
              {/* 联动：来源=外院时医院选项过滤掉「本院」 */}
              {(newForm.source === "本院" ? dictHospitalOptions : dictHospitalOptions.filter(o => o !== "本院")).map(o => (
                <SelectItem key={o} value={o}>{o}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs text-muted-foreground block mb-1">收样时间</label>
          <input
            type="date"
            value={newForm.receiveTime}
            onChange={e => setNewForm(f => ({ ...f, receiveTime: e.target.value }))}
            className="w-full border border-border rounded-md px-3 py-1.5 text-sm bg-card focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <div>
          <label className="text-xs text-muted-foreground block mb-1">收样人</label>
          <Input value={newForm.receiver} onChange={e => setNewForm(f => ({ ...f, receiver: e.target.value }))} className="w-full" />
        </div>
      </div>

      {/* Unified Receipt Section */}
      <div className="space-y-4">
        <label className="text-xs font-semibold text-foreground">收样明细</label>

        <div className="bg-muted/20 p-4 rounded-xl border border-border space-y-4">
          {/* Total Actual Received */}
          <div className="grid grid-cols-2 gap-4 border-b border-border pb-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-blue-700 mb-1">
                <QrCode size={14} />
                <span className="text-xs font-semibold">1. 样本管总数</span>
              </div>
              {/* 分产品/扫码模式：分别由产品明细、扫码条码自动统计，不允许手动输入（仅快速收样可手填） */}
              <input
                type="number"
                disabled={mode !== "tubes"}
                className={`w-full px-3 py-2 border border-border rounded-md text-sm outline-none font-bold shadow-inner ${mode !== "tubes" ? "bg-muted/40 text-foreground cursor-not-allowed" : "bg-card text-foreground"}`}
                value={newForm.actualTubes}
                onChange={e => {
                  // 联动：管数变化时实收单据数同步为相同值（单据数单独修改不影响管数）
                  const v = Math.max(1, parseInt(e.target.value) || 0);
                  setNewForm(f => ({ ...f, actualTubes: v, actualPapers: v }));
                }}
                min={1} step={1}
              />
            </div>
            <div className="space-y-1 border-l border-border pl-4">
              <div className="flex items-center gap-2 text-blue-700 mb-1">
                <FileArchive size={14} />
                <span className="text-xs font-semibold">2. 实收单据数</span>
              </div>
              {/* 实收单据数始终手动填写（分产品/扫码模式管总数自动、单据数手填，可多可少） */}
              <input
                type="number"
                className="w-full px-3 py-2 border border-border rounded-md text-sm outline-none font-bold bg-card text-foreground"
                value={newForm.actualPapers}
                onChange={e => setNewForm({...newForm, actualPapers: Math.max(1, parseInt(e.target.value) || 0)})}
                min={1} step={1}
              />
            </div>
          </div>

          {/* 申报 vs 单据数软提示（不阻断） */}
          {newForm.actualTubes > 0 && newForm.actualTubes < newForm.actualPapers && (
            <p className="text-[11px] text-amber-600 flex items-center gap-1">
              <AlertTriangle size={11} className="shrink-0" />申报管数（{newForm.actualTubes}）小于实收单据数（{newForm.actualPapers}），请核对
            </p>
          )}

          {/* Per-Product Breakdown — 仅「管数+产品明细」模式渲染（必填） */}
          {mode === "detail" && (
            <ProductLinesSection
              products={newForm.products}
              onChange={products => setNewForm(f => {
                // 分产品模式：样本管总数 = 明细合计 + 异常数；实收单据数同步联动（不允许手填）
                const sum = products.filter(p => p.count > 0).reduce((s, p) => s + p.count, 0) + anomalies.length;
                return { ...f, products, actualTubes: sum };
              })}
              dictProductOptions={dictProductOptions}
              dictSampleTypeOptions={dictSampleTypeOptions}
            />
          )}

          {/* 扫码录入 — 仅「扫码收样」模式渲染（必填，实时 HIS 复核） */}
          {mode === "scan" && (
            <ScanBarcodeSection
              barcodes={barcodes}
              onChange={setBarcodes}
              verifyMap={verifyMap}
              onBarcodeAdded={onBarcodeAdded}
            />
          )}
        </div>

        <ReceptionAnomalySection
          anomalies={anomalies} setAnomalies={setAnomalies}
          currentAnomaly={currentAnomaly} setCurrentAnomaly={setCurrentAnomaly}
          showAnomaly={showAnomaly} setShowAnomaly={setShowAnomaly}
          dictProductOptions={dictProductOptions}
        />
      </div>

      <div>
        <label className="text-xs text-muted-foreground block mb-1">备注信息</label>
        <Input placeholder="可输入批次特殊说明..." className="w-full" value={newForm.remark}
          onChange={e => setNewForm(f => ({ ...f, remark: e.target.value }))} />
      </div>
    </div>
  );
}
