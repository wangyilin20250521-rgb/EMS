import { useCallback, useState } from "react";
import { toast } from "sonner";
import { UNPACK_DEFAULT_FORM, hisVerifyReception, registerSampleReception, reportReceptionAnomaly } from "@/app/lib/api";
import type { UnpackFormState } from "@/app/lib/api/types";
import { useConfirm } from "@/app/components/shared/ConfirmDialog";
import type { ScanVerifyState } from "./ScanBarcodeSection";
import {
  buildAnomalyReports,
  buildBarcodeToSampleId,
  buildRegisterPayload,
  collectUnpackWarnings,
  EMPTY_PRODUCT_LINE,
  validateUnpackForm,
  type AnomalyDraft,
  type RegisterMode,
} from "./unpack-register-model";
import { showAmberToast, showUnpackFailToast, showUnpackSuccessToast } from "./unpack-register-toast";
import { useUnpackDictionaries } from "./useUnpackDictionaries";

// ─── 收样登记编排：表单/字典/HIS 实时复核/校验/保存（原弹窗内联逻辑等价搬运） ──────

function todayStr(): string {
  const n = new Date()
  return `${n.getFullYear()}-${pad(n.getMonth() + 1)}-${pad(n.getDate())}`
}
function pad(v: number) { return String(v).padStart(2, '0') }

/** initialMode：由收样登记页三个入口按钮指定登记模式；关闭/成功回调均为无参 void，由原弹窗顶层传入 */
export function useUnpackRegistration({ initialMode, username, onClose, onSaved }: {
  initialMode: RegisterMode;
  /** 当前登录用户名（收样人默认值与脏检查基线用） */
  username: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const confirm = useConfirm();
  const mode = initialMode;
  // 扫码实时复核状态映射：扫码即调 HIS 抓取信息，未匹配自动进异常登记（无需复核步骤）
  const [verifyMap, setVerifyMap] = useState<Record<string, ScanVerifyState>>({});

  // 产品收样模式默认给一行空白产品明细（产品类型留空待选），其他模式无明细行
  const initialProducts = initialMode === "detail" ? [{ ...EMPTY_PRODUCT_LINE }] : [];
  const [newForm, setNewForm] = useState<UnpackFormState>({
    ...UNPACK_DEFAULT_FORM,
    source: "本院",
    hospital: "本院",
    receiver: username,
    receiveTime: todayStr(),
    products: initialProducts,
  });
  const [anomalies, setAnomalies] = useState<AnomalyDraft[]>([]);
  const [currentAnomaly, setCurrentAnomaly] = useState<AnomalyDraft>({ id: "", reason: "", product: "", photo: null });
  const [showAnomaly, setShowAnomaly] = useState(false);
  const [barcodes, setBarcodes] = useState<string[]>([]);

  const { dictSourceOptions, dictHospitalOptions, dictProductOptions, dictSampleTypeOptions } = useUnpackDictionaries();

  // ─── Real-time Scan Verification：扫一个查一个（2026-08-31 取代原批量 HIS 复核步骤） ───
  // 未开启 HIS 时后端直接返回 found=true（零网络请求）；未匹配 → 自动进异常登记
  const verifyBarcode = useCallback((code: string) => {
    setVerifyMap(prev => ({ ...prev, [code]: { status: "checking" } }));
    hisVerifyReception([code])
      .then((data) => {
        const r = data.results?.[0];
        if (r?.found) {
          setVerifyMap(prev => ({ ...prev, [code]: { status: "matched", patient: r.patient } }));
        } else {
          setVerifyMap(prev => ({ ...prev, [code]: { status: "unmatched" } }));
          // 未匹配 → 默认进异常登记（reason 取"信息缺失"，用户可进异常区改）
          setAnomalies(prev => prev.some(a => a.id === code)
            ? prev
            : [...prev, { id: code, reason: "信息缺失", product: "", photo: null }]);
        }
      })
      .catch(() => setVerifyMap(prev => ({ ...prev, [code]: { status: "unmatched" } })));
  }, []);

  const resetForm = () => {
    setNewForm({ ...UNPACK_DEFAULT_FORM, source: "本院", hospital: "本院", receiver: username, receiveTime: todayStr(), products: initialProducts });
    setAnomalies([]);
    setCurrentAnomaly({ id: "", reason: "", product: "", photo: null });
    setShowAnomaly(false);
    setBarcodes([]);
  };

  const isFormDirty = () => {
    // 空白基线 = 初始形态：产品收样模式的单行空产品行视为"未填写"，关闭弹窗不误报丢失
    const blankForm = { ...UNPACK_DEFAULT_FORM, source: "本院", hospital: "本院", receiver: username, receiveTime: todayStr(), products: initialProducts };
    return JSON.stringify(newForm) !== JSON.stringify(blankForm) || anomalies.length > 0 || barcodes.length > 0;
  };

  const closeModal = async () => {
    if (isFormDirty() && !(await confirm({ title: "确认关闭", message: "已填写信息将丢失，确认关闭？" }))) return;
    resetForm();
    onClose();
  };

  /** 模式必填校验：不通过时弹出琥珀提示并返回 false */
  const validateForm = (): boolean => {
    const msg = validateUnpackForm({ mode, form: newForm, anomalies, barcodes });
    if (msg) {
      showAmberToast(msg);
      return false;
    }
    return true;
  };

  const handleSave = async () => {
    if (!validateForm()) return;

    // 一致性软提示：不阻断提交，差异会随批次落库并在列表/详情标记
    const warns = collectUnpackWarnings({ mode, form: newForm, anomalies, barcodes });
    if (warns.length > 0) toast.warning(warns.join("；"));

    // 捕获提交快照（resetForm 会清空）：登记载荷 + 异常列表 + 条码（异常绑定在请求返回后按快照映射）
    const payload = buildRegisterPayload(mode, newForm, barcodes);
    const currentAnomalies = [...anomalies];
    const currentBarcodes = [...barcodes];

    // 先关闭弹窗并清空表单
    resetForm();
    onClose();
    // Submit asynchronously
    try {
      const result = await registerSampleReception(payload);
      // apiPost 已保证 code=0 才返回，失败会 throw
      showUnpackSuccessToast(result.message || "收样登记成功");
      // 上报异常样本：扫码模式按条码精确绑定后端生成的占位行（sampleIds 与 barcodes 索引对齐）；
      // 其他模式优先真实样本 ID；均未命中时挂批次级（related = batchId），条码留待样本中心录入后人工关联
      const barcodeToSampleId = buildBarcodeToSampleId(mode, currentBarcodes, result.sampleIds);
      const reports = buildAnomalyReports(currentAnomalies, barcodeToSampleId, result.sampleIds || [], result.batchId || result.batchNo || "");
      if (reports.length > 0) {
        const outcomes = await Promise.allSettled(reports.map(reportReceptionAnomaly));
        const failed = outcomes.filter(o => o.status === "rejected").length;
        if (failed > 0) {
          toast.warning(`${failed} 条异常上报失败，请到异常中心手动登记`);
        }
      }
      onSaved();
    } catch (err) {
      showUnpackFailToast((err as { message?: string })?.message || "保存失败，请检查网络连接");
    }
  };

  return {
    mode,
    newForm, setNewForm,
    anomalies, setAnomalies,
    currentAnomaly, setCurrentAnomaly,
    showAnomaly, setShowAnomaly,
    barcodes, setBarcodes,
    verifyMap, verifyBarcode,
    dictSourceOptions, dictHospitalOptions, dictProductOptions, dictSampleTypeOptions,
    closeModal,
    handleSave,
  };
}
