import { useRef } from "react";
import { Camera, QrCode, XCircle } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { toast } from "sonner";
import type { AnomalyDraft } from "./unpack-register-model";

// ─── 异常样本登记区块（异常条目保持弹窗级生命周期，本组件只负责录入与列表展示） ────

/** 异常登记区：展开开关 + 录入表单（条码/产品/原因/凭证照片）+ 已添加列表；照片仅本地展示不随请求发送 */
export function ReceptionAnomalySection({ anomalies, setAnomalies, currentAnomaly, setCurrentAnomaly, showAnomaly, setShowAnomaly, dictProductOptions }: {
  anomalies: AnomalyDraft[];
  setAnomalies: React.Dispatch<React.SetStateAction<AnomalyDraft[]>>;
  /** 当前录入草稿（状态由弹窗层持有，本组件仅读写） */
  currentAnomaly: AnomalyDraft;
  setCurrentAnomaly: React.Dispatch<React.SetStateAction<AnomalyDraft>>;
  showAnomaly: boolean;
  setShowAnomaly: (v: boolean) => void;
  dictProductOptions: string[];
}) {
  const handleAnomalyAdd = () => {
    // 必填校验：缺失时明确提示并定位焦点（原为静默 return，用户无法得知失败原因）
    if (!currentAnomaly.id.trim()) {
      toast.error("请输入异常条码/样本ID");
      return;
    }
    if (!currentAnomaly.reason) {
      toast.error("请选择异常原因");
      reasonTriggerRef.current?.focus();
      return;
    }
    setAnomalies(prev => [...prev, { ...currentAnomaly }]);
    setCurrentAnomaly({ id: "", reason: "", product: "", photo: null });
    // 添加成功后列表滚动到底部，让新增样本可见（避免"不知道是否添加成功"的错觉）
    requestAnimationFrame(() => {
      if (anomalyListRef.current) anomalyListRef.current.scrollTop = anomalyListRef.current.scrollHeight;
    });
  };

  const handlePhotoClick = () => {
    photoInputRef.current?.click();
  };

  // 异常原因下拉 trigger 引用：必填校验失败时定位焦点
  const reasonTriggerRef = useRef<HTMLButtonElement>(null);
  // 已添加异常样本列表引用：添加成功后滚动到底部展示新增项
  const anomalyListRef = useRef<HTMLDivElement>(null);
  // 凭证照片文件输入引用（照片仅本地展示，不随登记请求发送）
  const photoInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setCurrentAnomaly(prev => ({ ...prev, photo: ev.target?.result as string }));
    };
    reader.readAsDataURL(file);
    // 重置 input 以便再次选择同一文件时仍能触发 onChange
    e.target.value = '';
  };

  return (
    <>
      {/* Anomaly section — toggle to enable（两种模式都保留） */}
      <div className="flex items-center gap-3 py-1">
        <button onClick={() => setShowAnomaly(!showAnomaly)} className="w-10 h-5 rounded-full relative transition-colors shrink-0 cursor-pointer" style={{ minWidth: 40, height: 22, background: showAnomaly ? "var(--primary)" : "var(--switch-background)" }}>
          <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${showAnomaly ? "left-[21px]" : "left-0.5"}`} />
        </button>
        <span className="text-xs font-medium text-muted-foreground">异常样本登记 {anomalies.length > 0 ? `(${anomalies.length})` : ""}</span>
      </div>

      {showAnomaly && (
        <div className="p-4 bg-card border border-border rounded-xl space-y-4">
          <div className="space-y-4 animate-in fade-in slide-in-from-top-1 duration-200">
            <div className="bg-card p-4 rounded-lg border border-blue-100 shadow-sm space-y-4">
              {/* 异常三字段一行（弹窗加宽后容纳） */}
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase">异常条码/样本ID<span className="text-red-500 ml-0.5">*</span></label>
                  <div className="relative">
                    <QrCode size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <input
                      className="w-full pl-8 pr-3 py-2 text-xs border border-border rounded-md outline-none focus:ring-1 focus:ring-blue-500"
                      placeholder="输入或扫描条码"
                      value={currentAnomaly.id}
                      onChange={e => setCurrentAnomaly({...currentAnomaly, id: e.target.value})}
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase">产品</label>
                  <Select onValueChange={v => setCurrentAnomaly({...currentAnomaly, product: v})} value={currentAnomaly.product}>
                    <SelectTrigger className="w-full px-2 py-2 text-xs border border-border rounded-md outline-none bg-card"><SelectValue placeholder="请选择产品" /></SelectTrigger>
                    <SelectContent>
                      {dictProductOptions.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase">异常原因<span className="text-red-500 ml-0.5">*</span></label>
                  <Select onValueChange={v => setCurrentAnomaly({...currentAnomaly, reason: v})} value={currentAnomaly.reason}>
                    <SelectTrigger ref={reasonTriggerRef} className="w-full px-2 py-2 text-xs border border-border rounded-md outline-none bg-card"><SelectValue placeholder="请选择异常原因" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="管身破损">管身破损</SelectItem>
                      <SelectItem value="条码模糊/脱落">条码模糊/脱落</SelectItem>
                      <SelectItem value="液量不足/干管">液量不足/干管</SelectItem>
                      <SelectItem value="样本类型不符">样本类型不符</SelectItem>
                      <SelectItem value="信息缺失">信息缺失</SelectItem>
                      <SelectItem value="实物缺失">实物缺失</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <input ref={photoInputRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
                  <div onClick={handlePhotoClick} className="w-10 h-10 bg-slate-50 border border-dashed border-slate-300 rounded-lg flex items-center justify-center text-slate-400 cursor-pointer hover:border-blue-500 hover:text-blue-500 transition-colors overflow-hidden">
                    {currentAnomaly.photo ? <img src={currentAnomaly.photo} alt="凭证" className="w-full h-full object-cover" /> : <Camera size={18} />}
                  </div>
                  <span className="text-[10px] text-slate-400">{currentAnomaly.photo ? '已选择照片（点击可更换）' : '点击上传凭证照片'}</span>
                </div>
                <Button variant="plain" size="sm" className="px-6" onClick={handleAnomalyAdd}>
                  确认添加
                </Button>
              </div>
            </div>

            {anomalies.length > 0 && (
              <div ref={anomalyListRef} className="space-y-2 max-h-36 overflow-y-auto pr-1">
                {anomalies.map((ano, idx) => (
                  <div key={idx} className="flex items-center justify-between bg-card px-3 py-2.5 rounded-lg border border-blue-100 text-xs shadow-sm">
                    <div className="flex items-center gap-4">
                      <span className="font-mono font-bold text-blue-800 bg-blue-50 px-1.5 py-0.5 rounded">{ano.id}</span>
                      {ano.product && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 font-medium">{ano.product}</span>
                      )}
                      <span className="text-foreground font-medium">{ano.reason}</span>
                      {ano.photo && <img src={ano.photo} alt="凭证" className="w-6 h-6 rounded object-cover border border-border" />}
                    </div>
                    <button onClick={() => setAnomalies(prev => prev.filter((_, i) => i !== idx))} className="text-slate-300 hover:text-red-500 transition-colors cursor-pointer"><XCircle size={16} /></button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
