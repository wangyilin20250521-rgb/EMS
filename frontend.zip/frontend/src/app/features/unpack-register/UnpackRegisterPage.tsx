import { useState, useEffect, useCallback } from "react";
import {
  Search,
  XCircle,
  Boxes,
  ClipboardList,
  ScanLine,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
} from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { TableCard, TableCardHeader, TableCardFooter } from "@/app/components/shared/table-card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import {
  UNPACK_DATE_FILTERS,
  getReceptionStats,
  getUnpackRecords,
  getBatchSamples,
  updateBatchMeta,
  deleteReceptionBatch,
  getReceptionDateFilters,
} from "@/app/lib/api";
import type { UnpackStatValue, UnpackRecord, BatchSample } from "@/app/lib/api";
import { SOURCE_OPTIONS } from "@/app/lib/constants/options";
import { useConfirm } from "@/app/components/shared/ConfirmDialog";
import { toast } from "sonner";
import { usePagination } from "@/app/hooks/usePagination";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { UnpackRegisterModal, type RegisterMode } from "./UnpackRegisterModal";

// ─── Column Sort（模块级组件：避免函数体内定义导致的重挂载） ─────────────────

type UnpackSortKey = "receivedAt" | "updatedAt";

/** 可排序列头：点击切换正/反序，激活列显示方向箭头（EMS 主色） */
function SortableHead({
  label,
  sortKey,
  sortBy,
  sortOrder,
  onSort,
}: {
  label: string;
  sortKey: UnpackSortKey;
  sortBy: UnpackSortKey | undefined;
  sortOrder: "asc" | "desc";
  onSort: (key: UnpackSortKey) => void;
}) {
  const active = sortBy === sortKey;
  return (
    <TableHead className="text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap select-none">
      <button
        className={`inline-flex items-center gap-1 cursor-pointer transition-colors font-semibold text-sm ${active ? "text-primary" : "hover:text-primary"}`}
        onClick={() => onSort(sortKey)}
        title={`按${label}排序`}
      >
        {label}
        {active ? (
          sortOrder === "asc" ? <ArrowUp size={12} /> : <ArrowDown size={12} />
        ) : (
          <ArrowUpDown size={12} className="text-muted-foreground/40" />
        )}
      </button>
    </TableHead>
  );
}

// ─── Last Operation Time Formatting（ISO → 本地 YYYY-MM-DD HH:mm） ──────────────

function fmtUpdatedAt(iso?: string): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

export function UnpackRegisterPage() {
  const [dateFilter, setDateFilter] = useState<string>("全部");
  // 日期筛选选项：从后端拉取，失败回退静态常量
  const [dateFilterOptions, setDateFilterOptions] = useState<string[]>([...UNPACK_DATE_FILTERS]);
  useEffect(() => {
    getReceptionDateFilters().then(data => {
      if (Array.isArray(data) && data.length > 0) setDateFilterOptions(data);
    }).catch(() => setDateFilterOptions([...UNPACK_DATE_FILTERS]));
  }, []);
  // 三个收样模式入口按钮：平铺在卡片信息栏左上角，点击直达对应模式的登记表单
  const [registerMode, setRegisterMode] = useState<RegisterMode | null>(null);
  const [search, setSearch] = useState("");
  // ─── Batch Edit Modal（2026-08-24：列表操作列「编辑」直接打开，无需先进详情） ───
  const [editBatch, setEditBatch] = useState<any>(null);
  const [editForm, setEditForm] = useState({ source: "", hospital: "", receiver: "", receivedAt: "", actualTubes: 0, actualPapers: 0, notes: "" });
  const [editSaving, setEditSaving] = useState(false);
  const confirm = useConfirm();

  // ─── Batch Detail/Edit Merged Drawer：已录入样本加载 ───
  const [batchSamples, setBatchSamples] = useState<BatchSample[]>([]);

  // 打开抽屉时加载已录入样本
  useEffect(() => {
    if (editBatch) {
      getBatchSamples(editBatch.batchNo).then(setBatchSamples).catch(() => setBatchSamples([]));
    }
  }, [editBatch?.batchNo]);

  // 批次信息展示态/编辑态：默认文字展示（详情风格），点「修改」或点值进入编辑
  const [batchInfoEditing, setBatchInfoEditing] = useState(false);
  // 抽屉只读标志：true = 详情（批次号点击，纯展示）；false = 编辑（编辑按钮，可修改）
  const [drawerReadonly, setDrawerReadonly] = useState(false);

  // 统一打开抽屉：readonly=true 详情展示，false 可编辑
  const openBatchDrawer = (r: any, readonly: boolean) => {
    setDrawerReadonly(readonly);
    setBatchInfoEditing(false); // 每次打开默认展示态
    setEditForm({
      source: r.source || "本院",
      hospital: r.hospital || "",
      receiver: r.receiver || "",
      receivedAt: (r.time || "").slice(0, 10),
      actualTubes: r.actual ?? 0,
      actualPapers: (r as any).papers ?? 0,
      notes: r.notes || "",
    });
    setEditBatch(r);
  };
  /** 详情：批次号点击（纯展示，不支持修改） */
  const openDetail = (r: any) => openBatchDrawer(r, true);
  /** 编辑：列表操作列「编辑」（可修改批次信息） */
  const openEditBatch = (r: any) => openBatchDrawer(r, false);

  const saveEditBatch = async () => {
    if (!editBatch) return;
    setEditSaving(true);
    try {
      await updateBatchMeta(editBatch.batchNo, {
        source: editForm.source,
        hospital: editForm.hospital,
        receiver: editForm.receiver,
        receivedAt: editForm.receivedAt || undefined,
        actualTubes: editForm.actualTubes,
        actualPapers: editForm.actualPapers,
        notes: editForm.notes,
      });
      toast.success("批次信息已更新");
      setEditBatch(null);
      refresh();
      loadStats();
    } catch (e: any) {
      toast.error(e?.message || "保存失败");
    } finally {
      setEditSaving(false);
    }
  };

  // ─── Batch Delete：二次确认，有关联（样本/任务/异常）时后端拒绝 ───
  const handleDeleteBatch = async (r: any) => {
    const ok = await confirm({
      title: "确认删除批次",
      message: `确认删除批次 ${r.batchNo}？删除后不可恢复。\n已关联样本/任务的批次将无法删除。`,
      variant: "danger",
      confirmText: "删除",
    });
    if (!ok) return;
    try {
      await deleteReceptionBatch(r.batchNo);
      toast.success("批次已删除");
      refresh();
      loadStats();
    } catch (e: any) {
      toast.error(e?.message || "删除失败");
    }
  };

  // 列头排序（收样时间/最后操作时间，服务端排序）
  const [sortBy, setSortBy] = useState<UnpackSortKey | undefined>(undefined);
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const handleSort = (key: UnpackSortKey) => {
    // 同列再点：正/反切换；换列：新列升序
    const nextBy = sortBy === key ? sortBy : key;
    const nextOrder = sortBy === key ? (sortOrder === "asc" ? "desc" : "asc") : "asc";
    setSortBy(nextBy);
    setSortOrder(nextOrder);
    setFilters({ dateFilter, search, sortBy: nextBy, sortOrder: nextOrder });
  };

  const fetchRecords = useCallback(async (params: { page?: number; pageSize?: number; dateFilter?: string; search?: string; sortBy?: string; sortOrder?: "asc" | "desc" }) => {
    return getUnpackRecords({ dateFilter: params.dateFilter, search: params.search, sortBy: params.sortBy, sortOrder: params.sortOrder, page: params.page, pageSize: params.pageSize });
  }, []);

  const {
    items: records,
    total,
    page,
    pageSize,
    setPage,
    setPageSize,
    setFilters,
    refresh,
  } = usePagination<UnpackRecord, { dateFilter: string; search: string; sortBy?: string; sortOrder?: "asc" | "desc" }>({
    fetcher: fetchRecords,
    initialPageSize: 15,
    initialFilters: { dateFilter: "全部", search: "" },
  });

  // 列表刷新后同步抽屉中的批次聚合数据（projects/products/calculated 等），不覆盖用户已编辑的表单
  useEffect(() => {
    if (editBatch && records) {
      const fresh = records.find((r: any) => r.batchNo === editBatch.batchNo);
      if (fresh) setEditBatch(fresh);
    }
  }, [records, editBatch?.batchNo]);

  const handleDateFilterChange = (f: string) => {
    setDateFilter(f);
    setFilters({ dateFilter: f, search, sortBy, sortOrder });
    loadStats(f); // 统计卡片跟随日期筛选（显式传新值，避免 state 未更新的竞态）
  };

  // 收样统计（批次数/收样管数，跟随日期筛选）：以文字展示在卡片头部信息栏，不占单独卡片
  const [unpackStats, setUnpackStats] = useState<UnpackStatValue[]>([]);
  const loadStats = useCallback((df?: string) => { getReceptionStats(df ?? dateFilter).then(setUnpackStats).catch(() => {}); }, [dateFilter]);
  useEffect(() => { loadStats(); }, [loadStats]);

  const statValue = (key: string) => unpackStats.find(s => s.key === key)?.value ?? 0;

  const handleSearchChange = (val: string) => {
    setSearch(val);
    setFilters({ dateFilter, search: val, sortBy, sortOrder });
  };

  const displayed = records;

  return (
    <div className="px-6 pb-6 pt-2 h-full flex flex-col space-y-5">
      <div className="flex-1 flex flex-col min-h-0">
        <TableCard>
        <TableCardHeader>
          {/* 三个收样模式入口（直达对应登记表单） */}
          <div className="flex items-center gap-2.5 shrink-0">
            <Button size="sm" onClick={() => setRegisterMode("tubes")}>
              <Boxes size={12} />快速收样
            </Button>
            <Button size="sm" onClick={() => setRegisterMode("detail")}>
              <ClipboardList size={12} />产品收样
            </Button>
            <Button size="sm" onClick={() => setRegisterMode("scan")}>
              <ScanLine size={12} />扫码收样
            </Button>
          </div>
          <div className="flex items-center gap-2.5 shrink-0">
              {/* 简约统计（跟随时间筛选）：批次数 / 收样管数 */}
              <div className="flex items-center gap-2.5 text-xs text-muted-foreground whitespace-nowrap">
                <span>批次数 <span className="font-semibold font-mono text-foreground">{statValue("today-batches")}</span></span>
                <span className="text-border">·</span>
                <span>收样管数 <span className="font-semibold font-mono text-foreground">{statValue("today-total-tubes")}</span></span>
              </div>
              <Select value={dateFilter} onValueChange={(v) => handleDateFilterChange(v)}>
                <SelectTrigger size="sm" className="w-auto h-8 px-2.5 text-xs border border-border rounded-md bg-card">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {dateFilterOptions.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                </SelectContent>
              </Select>
              <div className="relative">
                <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input className="w-48 pl-8 pr-3 h-8 text-xs border border-border rounded-md bg-card focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="搜索批次号、来源医院..."
                  value={search} onChange={e => handleSearchChange(e.target.value)} />
              </div>
          </div>
        </TableCardHeader>

          <div className="flex-1 overflow-auto">

          <Table className="w-full text-sm">
            <TableHeader className="bg-muted/40 border-b border-border sticky top-0">
              <TableRow>
                {/* 收样时间/最后操作时间支持列头排序（服务端） */}
                {["序号", "批次号", "来源", "收样医院"].map(h => (
                  <TableHead key={h} className="text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                ))}
                <SortableHead label="收样时间" sortKey="receivedAt" sortBy={sortBy} sortOrder={sortOrder} onSort={handleSort} />
                {["实收管数", "样本登记数量", "异常样本数量", "最后操作人"].map(h => (
                  <TableHead key={h} className="text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                ))}
                <SortableHead label="最后操作时间" sortKey="updatedAt" sortBy={sortBy} sortOrder={sortOrder} onSort={handleSort} />
                <TableHead className="text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {displayed.map((r, index) => (
                <TableRow key={r.id} className="border-b border-border hover:bg-muted/20 transition-colors group">
                  {/* 序号列（跨页连续编号） */}
                  <TableCell className="px-4 py-3 text-sm text-muted-foreground">
                    {(page - 1) * pageSize + index + 1}
                  </TableCell>
                  <TableCell className="px-4 py-3 font-mono text-sm text-primary cursor-pointer hover:underline" onClick={() => openDetail(r)}>{r.batchNo}</TableCell>
                  <TableCell className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded font-medium ${r.source === "本院" ? "bg-blue-50 text-blue-700" : "bg-slate-100 text-slate-600"}`}>
                      {r.source}
                    </span>
                  </TableCell>
                  <TableCell className="px-4 py-3">
                    <p className="font-medium">{r.hospital}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5 opacity-0 group-hover:opacity-100 transition-opacity">{(r as any).detail}</p>
                  </TableCell>
                  <TableCell className="px-4 py-3 text-sm text-muted-foreground">{r.time}</TableCell>
                  <TableCell className="px-4 py-3 font-mono text-center">
                    <span className={(r as any).calculated != null && (r as any).calculated !== (r as any).actual ? "text-amber-600 font-bold" : "text-foreground"}>{/* 申报管数，与实际统计不一致时高亮 */}
                      {(r as any).actual}
                    </span>
                  </TableCell>
                  <TableCell className="px-4 py-3 font-mono text-center">
                    <span className={(r as any).actual !== (r as any).recorded ? "text-amber-600 font-bold" : "text-foreground"}>{/* 样本录入数，与实收管数不一致时高亮 */}
                      {(r as any).recorded}
                    </span>
                  </TableCell>
                  <TableCell className="px-4 py-3 font-mono text-center">
                    <span className={(r as any).anomalies > 0 ? "text-red-600 font-bold" : "text-muted-foreground"}>{(r as any).anomalies}</span>
                  </TableCell>
                  <TableCell className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">{r.updatedBy || "—"}</TableCell>
                  <TableCell className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">{fmtUpdatedAt(r.updatedAt)}</TableCell>
                  <TableCell className="px-4 py-3">
                    <div className="flex gap-1">
                      {/* 操作列统一为蓝色文字链接（仅编辑/删除，2026-08-31 移除详情入口） */}
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70" onClick={() => openEditBatch(r)}>编辑</Button>
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70" onClick={() => handleDeleteBatch(r)}>删除</Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </div>
          <TableCardFooter>
            <PaginationBar page={page} pageSize={pageSize} total={total} onPageChange={setPage} onPageSizeChange={setPageSize} />
          </TableCardFooter>
        </TableCard>
      </div>


      {registerMode && (
        <UnpackRegisterModal
          initialMode={registerMode}
          onClose={() => setRegisterMode(null)}
          onSaved={() => { refresh(); loadStats(); }}
        />
      )}

      {/* 批次详情/编辑抽屉：详情（批次号点击，纯展示取消修改）与编辑（编辑按钮）共用右侧卡片 */}
      {editBatch && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/40" onClick={() => setEditBatch(null)} />
          <div className="relative w-[480px] max-w-full h-full bg-card shadow-2xl flex flex-col">
            <div className="px-6 py-4 border-b border-border flex items-center justify-between shrink-0">
              <h2 className="text-base font-semibold">{drawerReadonly ? "批次详情" : "编辑批次"} <span className="text-xs font-mono text-muted-foreground ml-1">{editBatch.batchNo}</span></h2>
              <Button variant="ghost" size="icon-sm" onClick={() => setEditBatch(null)} aria-label="关闭" className="shrink-0"><XCircle size={18} /></Button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {/* 批次信息：默认文字展示（详情风格），点「修改」/点值进入编辑态 */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-muted-foreground">批次信息</p>
                  {/* 详情模式（readonly）取消修改功能，仅展示 */}
                  {!drawerReadonly && (batchInfoEditing ? (
                    <button className="text-xs text-muted-foreground hover:text-foreground cursor-pointer" onClick={() => setBatchInfoEditing(false)}>完成</button>
                  ) : (
                    <button className="text-xs text-primary hover:underline cursor-pointer" onClick={() => setBatchInfoEditing(true)}>修改</button>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {batchInfoEditing ? (
                    <>
                      {/* 编辑态：来源下拉 + 文本输入（联动：来源=本院时来源医院置灰锁定为本院） */}
                      <div className="space-y-1">
                        <label className="text-xs font-medium block">样本来源</label>
                        <Select value={editForm.source} onValueChange={v => setEditForm(f => ({ ...f, source: v, hospital: v === "本院" ? "本院" : f.hospital }))}>
                          <SelectTrigger className="w-full border border-border rounded-md px-3 py-1.5 text-sm bg-card"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {SOURCE_OPTIONS.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-medium block">来源医院</label>
                        <input
                          className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring disabled:bg-muted disabled:text-muted-foreground disabled:cursor-not-allowed"
                          value={editForm.source === "本院" ? "本院" : editForm.hospital}
                          disabled={editForm.source === "本院"}
                          onChange={e => setEditForm(f => ({ ...f, hospital: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-medium block">收样人</label>
                        <input
                          className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                          value={editForm.receiver}
                          onChange={e => setEditForm(f => ({ ...f, receiver: e.target.value }))}
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-xs font-medium block">收样时间</label>
                        <input
                          type="date"
                          className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                          value={editForm.receivedAt}
                          onChange={e => setEditForm(f => ({ ...f, receivedAt: e.target.value }))}
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      {/* 展示态：文字（点击值进入编辑态） */}
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">样本来源</p>
                        <p className={`text-sm ${!drawerReadonly ? "cursor-pointer hover:text-primary transition-colors" : ""}`} onClick={() => !drawerReadonly && setBatchInfoEditing(true)}>{editForm.source || "—"}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">来源医院</p>
                        <p className={`text-sm ${!drawerReadonly ? "cursor-pointer hover:text-primary transition-colors" : ""}`} onClick={() => !drawerReadonly && setBatchInfoEditing(true)}>{editForm.hospital || "—"}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">收样人</p>
                        <p className={`text-sm ${!drawerReadonly ? "cursor-pointer hover:text-primary transition-colors" : ""}`} onClick={() => !drawerReadonly && setBatchInfoEditing(true)}>{editForm.receiver || "—"}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground">收样时间</p>
                        <p className={`text-sm ${!drawerReadonly ? "cursor-pointer hover:text-primary transition-colors" : ""}`} onClick={() => !drawerReadonly && setBatchInfoEditing(true)}>{editForm.receivedAt || "—"}</p>
                      </div>
                    </>
                  )}
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">批次号</p>
                    <p className="text-sm font-mono font-semibold">{editBatch.batchNo}</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">实际统计管数</p>
                    <p className={`text-sm ${(editBatch as any).calculated != null && (editBatch as any).calculated !== editBatch.actual ? "text-amber-600 font-bold" : ""}`}>
                      {(editBatch as any).calculated != null ? (editBatch as any).calculated : "—"}
                    </p>
                  </div>
                </div>
              </div>

              {/* 检测项目（按录入样本聚合）；分产品模式已有逐行明细，不再显示聚合 */}
              {editBatch.projects && (!editBatch.products || editBatch.products.length === 0) && (
                <div className="space-y-2">
                  <p className="text-xs text-muted-foreground">检测项目</p>
                  <p className="text-sm bg-muted/40 rounded-lg p-3">{editBatch.projects}</p>
                </div>
              )}

              {/* 分产品收样明细（结构化落库：产品类型/套餐/编号/样本类型/数量） */}
              {editBatch.products && editBatch.products.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs text-muted-foreground">分产品明细</p>
                  <div className="border border-border rounded-lg overflow-hidden">
                    <Table className="w-full text-xs">
                      <TableHeader className="bg-muted/40">
                        <TableRow>
                          {["产品类型", "产品套餐", "样本类型", "数量"].map(h => (
                            <TableHead key={h} className="text-left px-3 py-2 font-semibold text-foreground">{h}</TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody className="divide-y divide-border">
                        {editBatch.products.map((p: any, i: number) => (
                          <TableRow key={i}>
                            <TableCell className="px-3 py-2">{p.name}</TableCell>
                            <TableCell className="px-3 py-2">{p.package || "—"}</TableCell>
                            <TableCell className="px-3 py-2">{p.sampleType || "—"}</TableCell>
                            <TableCell className="px-3 py-2">{p.count ?? "—"} 管</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}

              {/* 登记概要：实收管数/单据数（编辑可改，详情只读展示） */}
              <div className="border border-border rounded-xl p-4 space-y-3">
                <p className="text-xs font-semibold">登记概要</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] text-muted-foreground block">实收管数</label>
                    {drawerReadonly ? (
                      <p className="text-sm font-medium">{editForm.actualTubes} 管</p>
                    ) : (
                      <input type="number" min={0} className="w-full px-3 py-1.5 border border-border rounded-md text-sm bg-card"
                        value={editForm.actualTubes}
                        onChange={e => setEditForm(f => ({ ...f, actualTubes: Math.max(0, parseInt(e.target.value) || 0) }))} />
                    )}
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-muted-foreground block">实收单据数</label>
                    {drawerReadonly ? (
                      <p className="text-sm font-medium">{editForm.actualPapers} 单</p>
                    ) : (
                      <input type="number" min={0} className="w-full px-3 py-1.5 border border-border rounded-md text-sm bg-card"
                        value={editForm.actualPapers}
                        onChange={e => setEditForm(f => ({ ...f, actualPapers: Math.max(0, parseInt(e.target.value) || 0) }))} />
                    )}
                  </div>
                </div>
              </div>

              {/* 已录入样本（只读） */}
              <div className="space-y-2">
                <p className="text-xs font-semibold text-muted-foreground">样本中心已录入 · {batchSamples.length} 管</p>
                {batchSamples.length === 0 ? (
                  <p className="text-xs text-muted-foreground italic">该批次暂无样本录入</p>
                ) : (
                  <div className="border border-border rounded-lg divide-y divide-border">
                    {batchSamples.map(r => (
                      <div key={r.sampleNo} className="px-3 py-2 flex items-center justify-between gap-2">
                        <span className="text-[11px] font-mono truncate">{r.sampleNo}</span>
                        <span className="text-[11px] text-muted-foreground shrink-0">{r.project || "—"} · {r.type || "—"}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 备注（编辑可改，详情只读；补充信息放底部） */}
              <div className="space-y-1">
                <label className="text-xs font-medium block">备注</label>
                {drawerReadonly ? (
                  <p className="text-sm whitespace-pre-wrap bg-muted/40 rounded-lg p-3">{editForm.notes || "—"}</p>
                ) : (
                  <textarea
                    rows={3}
                    className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                    value={editForm.notes}
                    onChange={e => setEditForm(f => ({ ...f, notes: e.target.value }))}
                  />
                )}
              </div>
            </div>
            {/* 底部操作栏：详情模式不展示（纯查看，右上角关闭即可） */}
            {!drawerReadonly && (
              <div className="px-6 py-4 border-t border-border flex justify-end gap-2 shrink-0">
                <Button variant="outline" onClick={() => setEditBatch(null)}>取消</Button>
                <Button variant="default" onClick={saveEditBatch} className={editSaving ? "opacity-50 pointer-events-none" : ""}>
                  {editSaving ? "保存中..." : "保存"}
                </Button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
