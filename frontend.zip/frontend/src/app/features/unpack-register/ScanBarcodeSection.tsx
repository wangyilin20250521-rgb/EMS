import { useEffect, useRef, useState } from "react";
import { CheckCircle2, Loader2, ScanLine, XCircle } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { toast } from "sonner";
import { mergeBarcodeInput, splitPastedBarcodes } from "./unpack-register-model";

// ─── Scan Barcode Entry（仅 scan 模式渲染） ─────────────────────────────────

/** 扫码实时复核状态：条码 → 复核中/匹配(带患者信息)/未匹配（未匹配自动进异常登记） */
export type ScanVerifyState =
  | { status: "checking" }
  | { status: "matched"; patient?: string }
  | { status: "unmatched" };

/** 扫码录入区块：回车/粘贴连续添加（重复跳过并提示），复核状态由上层实时写入 verifyMap */
export function ScanBarcodeSection({ barcodes, onChange, verifyMap, onBarcodeAdded }: {
  barcodes: string[];
  onChange: (next: string[]) => void;
  /** 实时复核状态映射（扫码即查 HIS，未匹配自动进异常登记） */
  verifyMap: Record<string, ScanVerifyState>;
  /** 新增条码时回调（主组件触发实时复核） */
  onBarcodeAdded: (code: string) => void;
}) {
  const [inputVal, setInputVal] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  // 进入扫码模式即聚焦，扫码枪可连续作业
  useEffect(() => { inputRef.current?.focus(); }, []);

  // 追加条码（trim + 空值过滤 + 同批次去重，重复跳过不打断）；新增的码立即触发实时复核
  const addBarcodes = (raw: string[]) => {
    const { appended, dupes } = mergeBarcodeInput(barcodes, raw);
    if (dupes.length > 0) toast.warning(`条码 ${dupes[0]}${dupes.length > 1 ? ` 等 ${dupes.length} 条` : ""} 已存在，已跳过`);
    if (appended.length > 0) {
      onChange([...barcodes, ...appended]);
      appended.forEach(onBarcodeAdded);
    }
  };

  // 扫码枪默认回车后缀：回车即添加并保持聚焦
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addBarcodes([inputVal]);
      setInputVal("");
      inputRef.current?.focus();
    }
  };

  // 粘贴自动切分（支持 Excel 整列/混合分隔符）
  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const items = splitPastedBarcodes(e.clipboardData.getData("text"));
    if (items.length > 0) { addBarcodes(items); setInputVal(""); }
  };

  return (
    <div className="space-y-3">
      {/* 实时复核说明 */}
      <p className="text-[11px] text-blue-700 bg-blue-50 border border-blue-100 rounded-lg px-3 py-2 flex items-center gap-1.5">
        <ScanLine size={12} className="shrink-0" />
        扫码后实时调用 HIS 抓取信息；未匹配到的条码自动进入异常登记
      </p>
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <ScanLine size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            ref={inputRef}
            className="w-full pl-8 pr-3 py-2 text-xs font-mono border border-border rounded-md outline-none focus:ring-1 focus:ring-primary bg-card"
            placeholder="扫描或输入样本条码，回车添加"
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
          />
        </div>
        <Button variant="default" size="sm" onClick={() => { addBarcodes([inputVal]); setInputVal(""); inputRef.current?.focus(); }}>
          添加
        </Button>
      </div>

      <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
        {barcodes.length === 0 ? (
          <p className="text-[10px] text-muted-foreground italic bg-card/50 p-3 rounded-lg border border-dashed border-border text-center">暂无条码，请使用扫码枪扫描或手动输入</p>
        ) : (
          barcodes.map((b, idx) => {
            const v = verifyMap[b];
            return (
              <div key={idx} className="flex items-center justify-between bg-card px-3 py-1.5 rounded-lg border border-border text-xs">
                <span className="flex items-center gap-1.5 min-w-0">
                  <span className="text-muted-foreground/50 mr-0.5 shrink-0">{idx + 1}.</span>
                  <span className="font-mono text-primary truncate">{b}</span>
                  {/* 实时复核状态 */}
                  {v?.status === "checking" && (
                    <span className="flex items-center gap-1 text-muted-foreground shrink-0">
                      <Loader2 size={10} className="animate-spin" />复核中
                    </span>
                  )}
                  {v?.status === "matched" && (
                    <span className="flex items-center gap-1 text-emerald-600 shrink-0">
                      <CheckCircle2 size={11} />匹配
                      {v.patient && <span className="text-muted-foreground">{v.patient}</span>}
                    </span>
                  )}
                  {v?.status === "unmatched" && (
                    <span className="flex items-center gap-1 text-red-600 shrink-0">
                      <XCircle size={11} />未匹配，已进异常登记
                    </span>
                  )}
                </span>
                <button onClick={() => onChange(barcodes.filter((_, i) => i !== idx))} className="text-slate-300 hover:text-red-500 transition-colors cursor-pointer shrink-0 ml-2"><XCircle size={14} /></button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
