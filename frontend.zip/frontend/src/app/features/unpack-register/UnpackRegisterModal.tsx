import { Fragment } from "react";
import { XCircle } from "lucide-react";
import { useAuth } from "@/app/hooks/useAuth";
import { Button } from "@/app/components/ui/button";
import { RegisterContent } from "./RegisterContent";
import { useUnpackRegistration } from "./useUnpackRegistration";
import type { RegisterMode } from "./unpack-register-model";

// ─── 类型 re-export（原路径兼容）：既有 `import { UnpackRegisterModal, type RegisterMode }` 不受拆分影响 ───

export type { RegisterMode };
export type { ScanVerifyState } from "./ScanBarcodeSection";

/** 步骤标签按模式动态（2026-08-31：扫码收样取消 HIS 复核步骤，改为扫码实时复核） */
const STEP_LABELS: Record<RegisterMode, string[]> = {
  tubes:  ["填写登记信息"],
  detail: ["填写登记信息"],
  scan:   ["填写登记信息"],
};

// ─── Main Component: Registration Wizard Modal ────────────────────────────────────────

/** initialMode：由收样登记页三个入口按钮指定登记模式，弹窗直接展示对应登记表单（无模式选择步骤） */
export function UnpackRegisterModal({ initialMode, onClose, onSaved }: {
  initialMode: RegisterMode;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { user } = useAuth();
  const {
    mode,
    newForm, setNewForm,
    anomalies, setAnomalies,
    currentAnomaly, setCurrentAnomaly,
    showAnomaly, setShowAnomaly,
    barcodes, setBarcodes,
    verifyMap, verifyBarcode,
    dictSourceOptions, dictHospitalOptions, dictProductOptions, dictSampleTypeOptions,
    closeModal,
    handleSave,
  } = useUnpackRegistration({ initialMode, username: user?.username ?? "", onClose, onSaved });

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      {/* 720px × 85vh：宽高比约 1.2:1，避免 768px × 90vh 的方块感；内容常规时弹窗随内容收高 */}
      <div className="bg-card rounded-2xl shadow-2xl w-full max-w-[720px] flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
          <h2 className="text-base font-semibold" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            新建收样登记
          </h2>
          <Button variant="ghost" size="icon-sm" onClick={closeModal} aria-label="关闭" className="shrink-0">
            <XCircle size={18} />
          </Button>
        </div>

        {/* 步骤指示器（各模式单步：填写登记信息） */}
        <div className="flex items-center px-6 py-3 border-b border-border shrink-0 bg-muted/10">
          {STEP_LABELS[mode].map((label, i) => (
            <Fragment key={i}>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors bg-primary text-white">{i + 1}</div>
                <span className="text-sm font-semibold text-foreground">{label}</span>
              </div>
              {i < STEP_LABELS[mode].length - 1 && <div className="flex-1 h-px mx-3 bg-border" />}
            </Fragment>
          ))}
        </div>

        {/* Body：登记表单（所有模式；扫码模式内嵌实时 HIS 复核，无独立复核步骤） */}
        <div className="flex-1 overflow-y-auto px-6 py-5">
          <RegisterContent
            mode={mode}
            newForm={newForm} setNewForm={setNewForm}
            anomalies={anomalies} setAnomalies={setAnomalies}
            currentAnomaly={currentAnomaly} setCurrentAnomaly={setCurrentAnomaly}
            showAnomaly={showAnomaly} setShowAnomaly={setShowAnomaly}
            barcodes={barcodes} setBarcodes={setBarcodes}
            verifyMap={verifyMap} onBarcodeAdded={verifyBarcode}
            dictSourceOptions={dictSourceOptions} dictHospitalOptions={dictHospitalOptions}
            dictProductOptions={dictProductOptions} dictSampleTypeOptions={dictSampleTypeOptions}
          />
        </div>

        {/* Footer：扫码模式「创建批次」，其余「登记」（2026-08-31 取消 HIS 复核步骤） */}
        <div className="flex items-center justify-end px-6 py-4 border-t border-border shrink-0">
          <Button variant="default" onClick={handleSave}>
            {mode === "scan" ? "创建批次" : "登记"}
          </Button>
        </div>
      </div>
    </div>
  );
}
