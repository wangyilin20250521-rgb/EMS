import type { SampleReceptionPayload, UnpackFormState } from "@/app/lib/api/types";
import type { ReceptionAnomalyReportPayload } from "@/app/lib/api/sample-reception";

// ─── 收样登记纯模型：类型/常量/条码去重切分/计数公式/校验/载荷映射/异常绑定 ─────────
// 本文件不依赖 React 状态；提示、重置与请求等副作用由 useUnpackRegistration 执行。

/** 登记方式：仅管数 / 管数+产品明细（分产品核对）/ 扫码收样（管数+批量条码） */
export type RegisterMode = "tubes" | "detail" | "scan";

/** 异常样本草稿（列表项与当前录入草稿共用）：条码/样本ID、异常原因、产品、本地照片（仅展示，不随请求发送） */
export interface AnomalyDraft {
  id: string;
  reason: string;
  product: string;
  photo: string | null;
}

/** 产品收样明细行（与 UnpackFormState.products 元素同型） */
export type ProductLineItem = UnpackFormState["products"][number];

/** 产品收样明细的空白行（产品类型/样本类型均留空待选，数量 0） */
export const EMPTY_PRODUCT_LINE: ProductLineItem = { name: "", count: 0, sampleType: "" };

// ─── 条码处理（纯函数；重复提示与状态更新由调用方执行） ─────────────────────────

/**
 * 追加条码去重：trim + 空值过滤 + 同批次去重（重复跳过不打断）。
 * appended = 本次实际新增；dupes = 重复项（调用方据此提示，空输入两者均为空数组）
 */
export function mergeBarcodeInput(existing: string[], raw: string[]): { appended: string[]; dupes: string[] } {
  const fresh = raw.map(b => b.trim()).filter(Boolean);
  if (fresh.length === 0) return { appended: [], dupes: [] };
  const seen = new Set(existing);
  const dupes: string[] = [];
  const appended: string[] = [];
  for (const b of fresh) {
    if (seen.has(b)) { dupes.push(b); continue; }
    seen.add(b);
    appended.push(b);
  }
  return { appended, dupes };
}

/** 粘贴自动切分（支持 Excel 整列/混合分隔符） */
export function splitPastedBarcodes(text: string): string[] {
  return text.split(/[\s,，、;；]+/).map(s => s.trim()).filter(Boolean);
}

// ─── 计数公式（展示/校验口径含异常管；登记请求的正常管数不含异常，两者不可统一） ──

/** 正数量产品行的合计（异常样本不计入） */
export function sumActiveProductCount(products: UnpackFormState["products"]): number {
  return products.filter(p => p.count > 0).reduce((s, p) => s + p.count, 0);
}

/**
 * 自动统计的样本管总数（展示口径，异常也占管）：
 * detail = 产品明细合计 + 异常样本数量；scan = 条码数量；tubes 为手填模式不自动统计（返回 null）
 */
export function computeAutoTubeCount(
  mode: RegisterMode,
  products: UnpackFormState["products"],
  barcodeCount: number,
  anomalyCount: number,
): number | null {
  if (mode === "detail") return sumActiveProductCount(products) + anomalyCount;
  if (mode === "scan") return barcodeCount;
  return null;
}

// ─── 校验（返回首条错误提示文案；一致性软警告独立返回，不阻断） ──────────────────

export interface UnpackValidateInput {
  mode: RegisterMode;
  form: UnpackFormState;
  anomalies: AnomalyDraft[];
  barcodes: string[];
}

/** 模式必填校验（handleSave 与扫码模式「下一步」共用）：通过返回 null，否则返回首条错误提示（由调用方弹出） */
export function validateUnpackForm({ mode, form, anomalies, barcodes }: UnpackValidateInput): string | null {
  const activeProducts = form.products.filter(p => p.count > 0);
  const hasProducts = mode === "detail" && activeProducts.length > 0;
  // 明细模式必填：产品类型必选（行内留空不能提交），至少一行 count>0 的明细
  if (mode === "detail" && activeProducts.some(p => !p.name)) {
    return "请为每行明细选择产品类型";
  }
  if (mode === "detail" && !hasProducts) {
    return "请填写明细数量";
  }
  // 扫码模式必填：至少一个条码
  if (mode === "scan" && barcodes.length === 0) {
    return "请至少扫描/录入一个样本条码";
  }
  // 校验公式：样本管总数 = 正常样本合计 + 异常样本数量（异常也占管）
  // 分产品/扫码模式为自动统计，快速收样为手填 → 手填值不得少于异常数
  if (mode === "tubes" && form.actualTubes < anomalies.length) {
    return `样本管总数（${form.actualTubes}）不能少于异常样本数（${anomalies.length}）`;
  }
  if (mode === "scan" && anomalies.length > barcodes.length) {
    return `异常样本数（${anomalies.length}）超过扫描条码数（${barcodes.length}），请核对`;
  }
  const tubeCount = mode === "scan"
    ? barcodes.length
    : (hasProducts
      ? activeProducts.reduce((s, p) => s + p.count, 0) + anomalies.length
      : (form.actualTubes ?? 0));
  if (tubeCount <= 0) {
    // 分产品模式管数由明细汇总，空明细时提示添加产品而非填管数
    return mode === "detail" ? "请先添加产品明细并填写数量" : "请填写样本管总数";
  }
  return null;
}

/** 一致性校对（软提示不阻断）：申报数 vs 各模式自动统计的实际数，返回差异提示列表 */
export function collectUnpackWarnings({ mode, form, anomalies, barcodes }: UnpackValidateInput): string[] {
  const activeProducts = form.products.filter(p => p.count > 0);
  const hasProducts = mode === "detail" && activeProducts.length > 0;
  const tubes = form.actualTubes;
  const papers = form.actualPapers;
  const anomalyCount = anomalies.length;
  const productTotal = hasProducts ? activeProducts.reduce((s, p) => s + p.count, 0) : 0;
  const warns: string[] = [];
  if (tubes < papers) warns.push(`申报管数（${tubes}）小于实收单据数（${papers}）`);
  if (tubes < anomalyCount) warns.push(`申报管数（${tubes}）小于异常样本数（${anomalyCount}）`);
  if (hasProducts && tubes !== productTotal + anomalies.length) warns.push(`申报管数（${tubes}）与实际统计（分产品合计 ${productTotal}${anomalies.length > 0 ? ` + ${anomalies.length} 个异常` : ""}）不一致`);
  if (mode === "scan" && tubes !== barcodes.length) warns.push(`申报管数（${tubes}）与实际统计（条码数 ${barcodes.length}）不一致`);
  return warns;
}

// ─── 载荷映射与异常绑定（纯函数；请求/提示由 useUnpackRegistration 执行） ──────────

/** 构建收样登记请求载荷：正常管数不含异常（展示/校验口径见 computeAutoTubeCount，勿统一公式） */
export function buildRegisterPayload(mode: RegisterMode, form: UnpackFormState, barcodes: string[]): SampleReceptionPayload {
  const activeProducts = form.products.filter(p => p.count > 0);
  const hasProducts = mode === "detail" && activeProducts.length > 0;
  // Build per-sample arrays from product lines:
  // e.g. [{name:"NIFTY",count:2,type:"血液"}, {name:"WES",count:2,type:"羊水"}]
  //   → projects: ["NIFTY","NIFTY","WES","WES"]  sampleTypes: ["血液","血液","羊水","羊水"]
  const perSampleProjects: string[] = [];
  const perSampleTypes: string[] = [];
  for (const p of activeProducts) {
    for (let i = 0; i < p.count; i++) {
      perSampleProjects.push(p.name);
      // 样本类型非必选：留空占位（数组索引与 projects 按管对齐，后端占位行类型为空，后续入库登记可补）
      perSampleTypes.push(p.sampleType || "");
    }
  }
  // 管数：扫码模式取条码数（校验保证与实收管数一致），明细模式取产品明细合计，仅管数模式取实收管数
  const tubeCount = mode === "scan"
    ? barcodes.length
    : (hasProducts
      ? activeProducts.reduce((s, p) => s + p.count, 0)
      : (form.actualTubes ?? 0));
  return {
    projects: perSampleProjects.length > 0 ? perSampleProjects : undefined,
    sampleTypes: perSampleTypes.length > 0 ? perSampleTypes : undefined,
    barcodes: mode === "scan" ? barcodes : undefined,
    // 2026-08-31：实时复核模式未匹配条码已自动进异常登记（走下方 currentAnomalies 上报），不再传 hisUnmatched
    receivedAt: form.receiveTime,
    // 备注只存用户实际填写的内容（产品明细已结构化落库，不再自动拼接 "NIFTY:1,..." 到备注）
    notes: form.remark,
    // 分产品收样明细（结构化落库）：产品类型/样本类型/数量（产品套餐/编号移到入库登记阶段补充）
    products: activeProducts.map(p => ({
      name: p.name,
      sampleType: p.sampleType,
      count: p.count,
    })),
    tubeCount,
    source: form.source,
    hospital: form.hospital,
    actualTubes: form.actualTubes,
    actualPapers: form.actualPapers,
    receiver: form.receiver,
  };
}

/** 异常绑定第一步：扫码模式按条码精确绑定后端生成的占位行（sampleIds 与 barcodes 索引对齐） */
export function buildBarcodeToSampleId(mode: RegisterMode, barcodes: string[], sampleIds?: string[]): Record<string, string> {
  const barcodeToSampleId: Record<string, string> = {};
  if (mode === "scan" && Array.isArray(sampleIds)) {
    barcodes.forEach((bc, i) => {
      const id = sampleIds[i];
      if (bc && id) barcodeToSampleId[bc] = id;
    });
  }
  return barcodeToSampleId;
}

/**
 * 异常绑定第二步：构建异常上报载荷。
 * 优先条码映射到的样本 ID；其他模式优先真实样本 ID；均未命中时挂批次级（related = batchId），
 * 条码留待样本中心录入后人工关联
 */
export function buildAnomalyReports(
  anomalies: AnomalyDraft[],
  barcodeToSampleId: Record<string, string>,
  backendIds: string[],
  batchId: string,
): ReceptionAnomalyReportPayload[] {
  return anomalies.map((ano, i) => ({
    sampleId: barcodeToSampleId[ano.id] ?? backendIds[i] ?? undefined,
    batchId,
    barcode: ano.id,
    reason: ano.reason,
    product: ano.product || undefined,
  }));
}
