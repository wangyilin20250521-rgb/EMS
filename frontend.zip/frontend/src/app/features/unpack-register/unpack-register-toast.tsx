import { AlertTriangle, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";

// ─── 收样登记提示渲染器（原弹窗内联 toast.custom 的等价搬运） ──────────────────
// hook 为 .ts 不承载 JSX，三种自定义样式集中在此由 useUnpackRegistration 调用。

/** 琥珀色警示（校验失败/一致性提示） */
export function showAmberToast(msg: string) {
  toast.custom(() => (
    <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 text-amber-800 px-4 py-3 rounded-lg shadow-lg">
      <AlertTriangle size={18} className="text-amber-500 shrink-0" />
      <span className="text-sm font-medium">{msg}</span>
    </div>
  ));
}

/** 绿色成功提示（收样登记成功，带后端 message） */
export function showUnpackSuccessToast(msg: string) {
  toast.custom(() => (
    <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-lg shadow-lg">
      <CheckCircle2 size={18} className="text-emerald-500 shrink-0" />
      <span className="text-sm font-medium">{msg}</span>
    </div>
  ));
}

/** 红色失败提示（保存失败，带错误信息） */
export function showUnpackFailToast(msg: string) {
  toast.custom(() => (
    <div className="flex items-center gap-2 bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg shadow-lg">
      <XCircle size={18} className="text-red-500 shrink-0" />
      <span className="text-sm font-medium">{msg}</span>
    </div>
  ));
}
