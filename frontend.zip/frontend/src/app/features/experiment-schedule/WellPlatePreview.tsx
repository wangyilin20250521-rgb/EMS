import { useRef, useState } from "react";
import { WELL_PLATE_CONFIG, type SIRODeviceType, } from "@/app/lib/api";
import { CONTROL_LABELS, CONTROL_COLORS, getControlType, } from "./schedule-page-types";
import type { Specimen } from "./schedule-page-types";

export function WellPlatePreview({
  deviceType,
  specimens,
  editable = false,
  onReorder,
}: {
  deviceType: SIRODeviceType;
  specimens: (Specimen | undefined)[];
  editable?: boolean;
  onReorder?: (fromIdx: number, toIdx: number) => void;
}) {
  const cfg = WELL_PLATE_CONFIG[deviceType];
  const wellDragIndex = useRef<number | null>(null);
  const [wellDragOver, setWellDragOver] = useState<number | null>(null);

  const handleWellDragStart = (idx: number) => { wellDragIndex.current = idx; };
  const handleWellDragEnd = () => { wellDragIndex.current = null; setWellDragOver(null); };

  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        <span className="text-xs font-semibold text-muted-foreground">{deviceType} 孔板布局</span>
        <span className="text-[11px] text-muted-foreground">{specimens.filter((s) => !!s).length} / {cfg.total} 孔已分配</span>
        {editable && <span className="text-[11px] text-blue-500 ml-auto">拖拽孔位可交换样本位置</span>}
      </div>
      {/* 与手动排单孔板同款：外框网格 + 行列号 + 设备未用列灰显 + 录入列按条码自适应加宽 */}
      {(() => {
        const usedCols = new Set<number>();
        specimens.forEach((sp, i) => { if (sp) usedCols.add(i % cfg.cols); });
        const colWidth = (c: number) => {
          if (!usedCols.has(c)) return "2.25rem";
          let maxLen = 0;
          specimens.forEach((sp, i) => { if (sp && i % cfg.cols === c) maxLen = Math.max(maxLen, sp.specimenId.length); });
          return `${Math.min(130, Math.max(36, maxLen * 7 + 10))}px`;
        };
        const colsTemplate = `16px ${Array.from({ length: cfg.plateCols }, (_, c) => colWidth(c)).join(" ")}`;
        return (
        <div className="border border-border rounded-lg overflow-hidden w-fit p-0.5 bg-card">
        {/* 列号 */}
        <div className="grid gap-0.5 mb-0.5" style={{ gridTemplateColumns: colsTemplate }}>
          <div />
          {Array.from({ length: cfg.plateCols }, (_, c) => (
            <div key={c} className={`text-center text-[9px] font-mono ${usedCols.has(c) ? "text-foreground font-semibold" : "text-muted-foreground/40"}`}>{c + 1}</div>
          ))}
        </div>
        {/* 行：标准 96 孔板（8 行 A-H × 12 列），设备未启用的列灰显 */}
        {Array.from({ length: cfg.plateRows }, (_, r) => (
          <div key={r} className="grid gap-0.5 mb-0.5" style={{ gridTemplateColumns: colsTemplate }}>
            <div className={`text-[9px] font-mono flex items-center justify-center ${r >= cfg.rows ? "text-muted-foreground/40" : "text-muted-foreground"}`}>
              {String.fromCharCode(65 + r)}
            </div>
            {Array.from({ length: cfg.plateCols }, (_, c) => {
              // 设备未启用的孔（如 SIRO-16 仅前 2 列）：灰显不可用
              if (r >= cfg.rows || c >= cfg.cols) {
                return <div key={c} className="w-full h-10 rounded border border-dashed border-border/30 bg-muted/20" />;
              }
              const idx = r * cfg.cols + c;
              const sp = specimens[idx];
              const controlType = sp ? getControlType(sp) : null;
              const isOver = wellDragOver === idx;
              const isEmpty = !sp;
              return (
                <div
                  key={c}
                  title={sp ? `${controlType ? CONTROL_LABELS[controlType] : sp.patient} · ${sp.specimenId}` : "空"}
                  draggable={editable && !!sp}
                  onDragStart={() => sp && handleWellDragStart(idx)}
                  onDragOver={(e) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; if (wellDragOver !== idx) setWellDragOver(idx); }}
                  onDrop={(e) => { e.preventDefault(); const from = wellDragIndex.current; wellDragIndex.current = null; setWellDragOver(null); if (from !== null && from !== idx) onReorder?.(from, idx); }}
                  onDragEnd={handleWellDragEnd}
                  className={`w-full h-10 rounded flex items-center justify-center font-mono text-[10px] transition-all px-0.5 border ${
                    controlType
                      ? CONTROL_COLORS[controlType]
                      : sp
                      ? "bg-blue-50 border-blue-300 text-foreground"
                      : "bg-muted border border-dashed border-border/40"
                  } ${editable && sp ? "cursor-grab active:cursor-grabbing hover:ring-2 hover:ring-blue-300" : ""} ${editable && isEmpty ? "hover:border-primary/50 hover:bg-blue-50/20 dark:hover:bg-blue-900/20" : ""} ${isOver ? "ring-2 ring-blue-500 scale-110 z-10" : ""}`}
                >
                  <span className="truncate max-w-full text-center">{controlType ? controlType.charAt(0) : sp ? sp.specimenId : ""}</span>
                </div>
              );
            })}
          </div>
        ))}
        </div>
        );
      })()}
      <div className="flex gap-3 mt-1.5 text-[10px] text-muted-foreground">
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-blue-50 border border-blue-300 inline-block" />样本</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-orange-300 border border-orange-400 inline-block" />阳性质控</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-purple-300 border border-purple-400 inline-block" />阴性质控</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-slate-200 border border-slate-300 inline-block" />空白质控</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-muted border border-dashed border-border inline-block" />空孔</span>
      </div>
    </div>
  );
}

// ─── Review Modal ────────────────────────────────────────────────────────────

