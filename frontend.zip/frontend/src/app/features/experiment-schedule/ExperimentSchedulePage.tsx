import React, { useState, useCallback } from "react";
import {
  AlertTriangle, CheckCheck, CheckCircle2, ChevronRight, Plus, 
} from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { TableCard, TableCardHeader, TableCardFooter } from "@/app/components/shared/table-card";
import { ManualScheduleModal } from "./ManualScheduleModal";
import { getPreOrders, getPreOrderById, confirmPreOrder, deletePreOrder, updatePreOrder, type PreOrder, type ScheduleSpecimen, } from "@/app/lib/api";
import { type SIRODeviceType } from "@/app/lib/api";
import { usePagination } from "@/app/hooks/usePagination";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { fmtBeijing } from "@/app/lib/utils/time";
import { toast } from "sonner";
import { useConfirm } from "@/app/components/shared/ConfirmDialog";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { ReviewModal } from "./ReviewModal";
import { StatusBadge } from "./StatusBadge";
import { buildWellLayout } from "./schedule-page-types";
import { useExecutionMode } from "@/app/lib/execution-mode";

export function ExperimentSchedulePage() {
  const confirm = useConfirm();
  // 执行模式单源（手工模式：排单不下发 SIRO、创建即自动通过）
  const { mode: executionMode } = useExecutionMode();
  const isManual = executionMode === "manual";
  const [pendingOrders, setPendingOrders] = useState<PreOrder[]>([]);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [showCreate, setShowCreate] = useState(false);
  const [createDone, setCreateDone] = useState(false);
  // 待确认预排单：全量加载后前端分页（限制区域高度，与 uitest 优化设计一致）
  const [reviewTask, setReviewTask] = useState<PreOrder | null>(null);
  const [reviewReadonly, setReviewReadonly] = useState(false);
  const [editOrder, setEditOrder] = useState<PreOrder | null>(null);

  // Load pending orders (usually few, load all)
  const loadPending = async () => {
    const pending = await getPreOrders('pending', { page: 1, pageSize: 100 });
    setPendingOrders(pending);
  };

  const refreshOrders = async () => {
    await Promise.all([loadPending(), refreshConfirmed()]);
  };

  // Paginated confirmed orders (after pending review)
  const fetchConfirmed = useCallback(async (params: { page?: number; pageSize?: number; tabStatus?: string }) => {
    return getPreOrders('confirmed', { page: params.page, pageSize: params.pageSize });
  }, []);

  const {
    items: confirmedOrders,
    total: confirmedTotal,
    page: confirmedPage,
    pageSize: confirmedPageSize,
    setPage: setConfirmedPage,
    setPageSize: setConfirmedPageSize,
    refresh: refreshConfirmed,
  } = usePagination<PreOrder, { tabStatus: string }>({
    fetcher: fetchConfirmed,
    initialPageSize: 20,
    initialFilters: { tabStatus: "全部" },
  });

  React.useEffect(() => { void loadPending(); }, []);

  // 已确认排单 30s 自动刷新，跟随上位机执行状态（认领→运行中→完成）实时更新
  React.useEffect(() => {
    const timer = setInterval(() => { void refreshConfirmed(); }, 30_000);
    return () => clearInterval(timer);
  }, [refreshConfirmed]);

  const toggleExpand = (id: string) =>
    setExpanded((prev) => {
      const s = new Set(prev);
      s.has(id) ? s.delete(id) : s.add(id);
      return s;
    });

  const cancelTask = async (id: string) => {
    await deletePreOrder(id);
    setPendingOrders((prev) => prev.filter(t => t.id !== id));
  };

  const handleReviewConfirm = async (specimens: ScheduleSpecimen[], siroDevice: SIRODeviceType) => {
    if (!reviewTask) return;
    let result: Awaited<ReturnType<typeof confirmPreOrder>>;
    try {
      result = await confirmPreOrder(reviewTask.id);
    } catch (e: any) {
      // 后端校验/创建失败：透出真实错误，弹窗保持打开可修正后重试
      toast.error(e?.message || "排单确认失败，请稍后重试");
      return;
    }
    if (isManual) {
      // 手工模式：不下发中台，任务即手工实验单
      toast.success("排单已确认，手工实验单已生成");
    } else if (result.dispatch && !result.dispatch.ok) {
      toast.warning(`任务已生成，但投递 SIRO 中台失败${result.dispatch.error ? `：${result.dispatch.error}` : "（中台未连接）"}，可稍后在任务列表手动投递`);
    } else {
      toast.success("排单已确认，任务已投递 SIRO 中台");
    }
    setPendingOrders((prev) => prev.filter(t => t.id !== reviewTask.id));
    const confirmed: PreOrder = {
      ...reviewTask,
      status: 'confirmed',
      specimens,
      siroDevice,
    };
    setReviewTask(null);
    refreshConfirmed();
  };

  const handleReviewOpen = async (task: PreOrder) => {
    setReviewReadonly(false); // 审核入口：可编辑模式
    try {
      const detail = await getPreOrderById(task.id);
      setReviewTask(detail ?? task);
    } catch {
      setReviewTask(task);
    }
  };

  // 已确认排单编号点击：只读查看详情（ReviewModal readOnly）
  const handleViewOrder = async (order: PreOrder) => {
    setReviewReadonly(true);
    try {
      const detail = await getPreOrderById(order.id);
      setReviewTask(detail ?? order);
    } catch {
      setReviewTask(order);
    }
  };

  const handleAutoSave = async (specimens: (ScheduleSpecimen | undefined)[], siroDevice: SIRODeviceType) => {
    if (!reviewTask) return;
    const compactSpecs = specimens.filter((s): s is ScheduleSpecimen => !!s);
    // wellLayout 一并提交（含 barcode）：修复编辑后 well_layout 与 chip_lanes 失同步
    await updatePreOrder(reviewTask.id, {
      specimens: compactSpecs.map(s => ({ specimenId: s.specimenId })),
      wellLayout: buildWellLayout(specimens, siroDevice),
      siroDevice,
    });
    setPendingOrders((prev) => prev.map(t => t.id === reviewTask.id ? { ...t, specimens: compactSpecs, siroDevice } : t));
  };

  const handleEditOrderAutoSave = async (specimens: (ScheduleSpecimen | undefined)[], siroDevice: SIRODeviceType) => {
    if (!editOrder) return;
    await updatePreOrder(editOrder.id, {
      specimens: specimens.filter((s): s is ScheduleSpecimen => !!s).map(s => ({ specimenId: s.specimenId })),
      wellLayout: buildWellLayout(specimens, siroDevice),
      siroDevice,
    });
    refreshConfirmed();
  };

  const handleDeleteOrder = async (id: string) => {
    if (!await confirm({ title: '确认删除', message: '确认删除该排单？此操作不可撤销。', variant: 'danger' })) return;
    await deletePreOrder(id);
    refreshConfirmed();
  };

  const isTatUrgent = (tatDue: string) => {
    const today = new Date();
    const [m, d] = tatDue.split("-").map(Number);
    const due = new Date(today.getFullYear(), m - 1, d);
    return (due.getTime() - today.getTime()) / (1000 * 60 * 60 * 24) <= 2;
  };

  return (
    <div className="px-6 pb-6 pt-2 h-full flex flex-col space-y-5">
      {createDone && (
        <div className="flex items-center gap-2 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-lg px-4 py-3 text-sm text-emerald-700 dark:text-emerald-400">
          <CheckCircle2 size={15} />
          <span>排单创建成功，已加入排单列表。</span>
        </div>
      )}

      {/* ─── Section 1: 待确认预排单（上 50%）─── */}
      <section className="flex-1 min-h-0 flex flex-col">
        <TableCard className="flex-1 min-h-0">
          <TableCardHeader innerClassName="justify-start">
            <Button
              variant="outline" size="sm"
              className="text-[13px] text-primary border-primary/30 bg-transparent shadow-none hover:border-primary hover:bg-primary/5 hover:text-primary"
              onClick={() => { setShowCreate(true); setCreateDone(false); }}
            >
              <Plus size={12} />手动排单
            </Button>
          </TableCardHeader>

          {pendingOrders.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground text-sm flex flex-col items-center gap-3">
              <CheckCheck size={20} className="text-muted-foreground/40" />
              <p>暂无待确认的预排单任务</p>
            </div>
          ) : (
            <div className="flex-1 overflow-auto scrollbar-hide">
              <Table className="w-full text-sm">
                <TableHeader className="bg-muted/40 border-b border-border">
                  <TableRow>
                    <TableHead className="w-10 px-3 py-2.5" />
                    <TableHead className="w-12 px-3 py-2.5 text-left text-sm font-semibold text-foreground whitespace-nowrap">序号</TableHead>
                    {["实验项目", "类型", "样本数", "设备", "创建时间", "操作"].map((h) => (
                      <TableHead key={h} className="text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody className="divide-y divide-border">
                  {pendingOrders.map((task, idx) => {
                    const isOpen = expanded.has(task.id);
                    const urgent = isTatUrgent(task.tatDue);
                    return (
                      <React.Fragment key={task.id}>
                        <TableRow className="hover:bg-muted/20 transition-colors">
                          <TableCell className="px-3 py-3">
                            <button
                              onClick={() => toggleExpand(task.id)}
                              className="text-muted-foreground hover:text-foreground transition-colors shrink-0 p-0.5 rounded cursor-pointer"
                            >
                              <ChevronRight size={14} className={`transition-transform ${isOpen ? "rotate-90" : ""}`} />
                            </button>
                          </TableCell>
                          <TableCell className="px-3 py-3 text-sm text-muted-foreground font-mono">{idx + 1}</TableCell>
                          <TableCell className="px-4 py-3 font-medium">{task.project}</TableCell>
                          <TableCell className="px-4 py-3">
                            <div className="flex items-center gap-1 flex-wrap">
                              <span className="text-xs bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-400 px-1.5 py-0.5 rounded-full">系统预排单</span>
                              {urgent && (
                                <span className="text-xs bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400 px-1.5 py-0.5 rounded-full flex items-center gap-1 shrink-0">
                                  <AlertTriangle size={10} />临期
                                </span>
                              )}
                              {task.tags?.includes("scheduled") && (
                                <span className="text-xs bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-1.5 py-0.5 rounded-full shrink-0">定时任务</span>
                              )}
                              {task.tags?.includes("full_batch") && (
                                <span className="text-xs bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-1.5 py-0.5 rounded-full shrink-0">满批量</span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="px-4 py-3 font-mono">{task.specimens.length}</TableCell>
                          <TableCell className="px-4 py-3 text-muted-foreground">{task.siroDevice ?? "SIRO-48"}</TableCell>
                          <TableCell className="px-4 py-3 text-muted-foreground whitespace-nowrap">{fmtBeijing(task.createdAt)}</TableCell>
                          <TableCell className="px-4 py-3">
                            {/* 操作列统一为蓝色文字链接（参考样本中心：审核/取消） */}
                            <div className="flex gap-1">
                              <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70" onClick={() => { void handleReviewOpen(task); }}>审核</Button>
                              <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70" onClick={() => cancelTask(task.id)}>取消</Button>
                            </div>
                          </TableCell>
                        </TableRow>
                        {isOpen && (
                          <TableRow className="bg-muted/10">
                            <TableCell colSpan={10} className="px-4 py-2">
                              <div className="overflow-x-auto">
                                <Table className="w-full text-xs">
                                  <TableHeader>
                                    <TableRow>
                                      {["样本/样例编号", "样本来源", "患者", "样本类型", "产品编号", "TAT截止"].map((h) => (
                                        <TableHead key={h} className="text-left px-4 py-2 text-xs font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                                      ))}
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody className="divide-y divide-border">
                                    {task.specimens.map((sp) => (
                                      <TableRow key={sp.specimenId} className="hover:bg-muted/20">
                                        <TableCell className="px-4 py-2 text-xs font-mono text-primary">{sp.specimenId}</TableCell>
                                        {/* 样本来源：rowToPreOrder 从 web.samples.source 富化；Excel 导入链路可能为空 */}
                                        <TableCell className="px-4 py-2 text-xs text-muted-foreground">{sp.source || "—"}</TableCell>
                                        <TableCell className="px-4 py-2 text-xs">{sp.patient}</TableCell>
                                        <TableCell className="px-4 py-2 text-xs text-muted-foreground">{sp.sampleType}</TableCell>
                                        <TableCell className="px-4 py-2 text-xs">
                                          <span className="font-mono bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-1.5 py-0.5 rounded">{sp.productCode}</span>
                                        </TableCell>
                                        <TableCell className="px-4 py-2 text-xs text-muted-foreground">{sp.tat}</TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              </div>
                            </TableCell>
                          </TableRow>
                        )}
                      </React.Fragment>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}

        </TableCard>
      </section>

      {/* ─── Section 2: 排单列表（下 50%）─── */}
      <section className="flex-1 min-h-0 flex flex-col">
        <TableCard className="flex-1 min-h-0">
          <TableCardHeader>
            <div className="flex items-center gap-2 min-w-0">
              <h2 className="text-base font-semibold whitespace-nowrap shrink-0">排单列表</h2>
              {confirmedTotal > 0 && (
                <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full font-medium shrink-0">
                  {confirmedTotal} 条
                </span>
              )}
            </div>
          </TableCardHeader>
          <div className="flex-1 overflow-auto scrollbar-hide">
            <Table className="w-full text-sm">
              <TableHeader className="bg-muted/40 border-b border-border">
                <TableRow>
                  <TableHead className="w-12 px-3 py-2.5 text-left text-sm font-semibold text-foreground whitespace-nowrap">序号</TableHead>
                  {["排单编号", "实验项目", "实验设备", "样本数", "确认时间", "状态", "操作"].map((h) => (
                    <TableHead key={h} className="text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody className="divide-y divide-border">
                {confirmedOrders.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="px-4 py-12 text-center text-muted-foreground">暂无排单，审核通过后将出现在此处</TableCell>
                  </TableRow>
                ) : confirmedOrders.map((order, idx) => (
                  <TableRow key={order.id} className="hover:bg-muted/10 transition-colors">
                    <TableCell className="px-3 py-3 text-sm text-muted-foreground font-mono">{(confirmedPage - 1) * confirmedPageSize + idx + 1}</TableCell>
                    <TableCell className="px-4 py-3 font-mono text-sm text-primary cursor-pointer hover:underline" onClick={() => void handleViewOrder(order)}>{order.orderNo ?? '—'}</TableCell>
                    <TableCell className="px-4 py-3 font-medium">{order.project}</TableCell>
                    <TableCell className="px-4 py-3 text-muted-foreground">{order.siroDevice}</TableCell>
                    <TableCell className="px-4 py-3 font-mono">{order.sampleCount}</TableCell>
                    <TableCell className="px-4 py-3 text-muted-foreground whitespace-nowrap">{fmtBeijing(order.createdAt)}</TableCell>
                    <TableCell className="px-4 py-3">
                      {/* 认领状态：上位机认领（实验状态非空且非待启动）→ 已认领，否则待认领 */}
                      <StatusBadge status={order.status === 'cancelled' ? "准入失败" : (order.experimentStatus && order.experimentStatus !== '待启动') ? "已认领" : "待认领"} />
                    </TableCell>
                    <TableCell className="px-4 py-3">
                      {/* 操作列统一为蓝色文字链接（参考样本中心：编辑/删除） */}
                      <div className="flex gap-1">
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70" onClick={() => setEditOrder(order)}>编辑</Button>
                        <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70" onClick={() => handleDeleteOrder(order.id)}>删除</Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <TableCardFooter>
            <PaginationBar page={confirmedPage} pageSize={confirmedPageSize} total={confirmedTotal} onPageChange={setConfirmedPage} onPageSizeChange={setConfirmedPageSize} />
          </TableCardFooter>
        </TableCard>
      </section>

      {/* 手动排单弹窗 */}
      {showCreate && (
        <ManualScheduleModal
          onClose={() => setShowCreate(false)}
          onCreated={(created) => {
            void (async () => {
              try {
                await updatePreOrder(created.orderId, {
                  specimens: created.specimens.map(specimen => ({ specimenId: specimen.specimenId })),
                  wellLayout: created.wellLayout,
                  siroDevice: created.deviceType,
                  processNo: created.processNo,
                  project: created.project,
                });
                setShowCreate(false);
                // 手工模式：审核自动通过
                if (isManual) {
                  try {
                    await confirmPreOrder(created.orderId);
                    toast.success("手工实验单已生成，可到任务列表录入结果");
                  } catch (e: any) {
                    toast.warning(e?.message || "实验单已创建，但自动确认失败，请在待审列表手动确认");
                  }
                } else {
                  // 成功提示仅停留 3 秒后自动消失
                  setCreateDone(true);
                  setTimeout(() => setCreateDone(false), 3000);
                }
                await refreshOrders();
              } catch {
                toast.error("排单创建失败，请重试");
                setShowCreate(false);
              }
            })();
          }}
        />
      )}

      {/* 审核弹窗 */}
      {reviewTask && (
        <ReviewModal
          task={reviewTask}
          readOnly={reviewReadonly}
          onClose={() => setReviewTask(null)}
          onConfirm={handleReviewConfirm}
          onAutoSave={handleAutoSave}
        />
      )}

      {/* 编辑已确认排单弹窗 */}
      {editOrder && (
        <ReviewModal
          task={editOrder}
          onClose={() => setEditOrder(null)}
          onConfirm={() => setEditOrder(null)}
          onAutoSave={handleEditOrderAutoSave}
          mode="edit"
        />
      )}

    </div>
  );
}
