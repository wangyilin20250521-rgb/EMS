import { useState, useEffect, useRef } from "react";
import { CheckCircle2, Plus, XCircle } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { SIRO_DEVICE_OPTIONS, WELL_PLATE_CONFIG, type PreOrder, type ScheduleSpecimen, type SIRODeviceType } from "@/app/lib/api";
import { WellPlatePreview } from "./WellPlatePreview";
import { SampleSelectorModal } from "./SampleSelectorModal";
import { getControlType, getWellPosition, CONTROL_COLORS, CONTROL_LABELS } from "./schedule-page-types";
import type { ControlType } from "./schedule-page-types";
import { useExecutionMode } from "@/app/lib/execution-mode";

export function ReviewModal({
  task,
  onClose,
  onConfirm,
  onAutoSave,
  readOnly = false,
  mode = "review",
}: {
  task: PreOrder;
  onClose: () => void;
  onConfirm?: (specimens: ScheduleSpecimen[], siroDevice: SIRODeviceType) => void;
  onAutoSave?: (specimens: (ScheduleSpecimen | undefined)[], siroDevice: SIRODeviceType) => Promise<void> | void;
  readOnly?: boolean;
  mode?: "review" | "edit";
}) {
  // 手工模式无板位：裁剪孔板预览（清单/自动保存/确认流程不变）
  const { mode: executionMode } = useExecutionMode();
  const isManual = executionMode === "manual";
  const siroDevice: SIRODeviceType =
    (SIRO_DEVICE_OPTIONS as readonly string[]).includes(task.siroDevice ?? "")
      ? (task.siroDevice as SIRODeviceType)
      : "SIRO-48";
  // 孔位映射数组：下标 = row*cols+col（与手动排单向导 wells 同构，长度 = 设备总孔位）。
  // 从 well_layout（row/col 真相源）还原孔位 —— 修复 chip_lanes 紧凑顺序（按列填充后呈行优先外观）被当孔位渲染的问题；
  // 老排单无 well_layout 时按行优先顺序填充（历史行为回退）
  const [editSpecimens, setEditSpecimens] = useState<(ScheduleSpecimen | undefined)[]>(() => {
    const { total, cols } = WELL_PLATE_CONFIG[siroDevice];
    const slots: (ScheduleSpecimen | undefined)[] = new Array(total).fill(undefined);
    const layout = task.wellLayout ?? [];
    if (layout.length > 0) {
      for (const wl of layout) {
        if (wl.row == null || wl.col == null) continue;
        const idx = wl.row * cols + (wl.col - 1);
        if (idx < 0 || idx >= total) continue;
        if (wl.isControl && wl.controlType) {
          const ct = wl.controlType as ControlType;
          slots[idx] = { specimenId: `QC-${ct}`, sampleId: `QC-${ct}`, sampleType: CONTROL_LABELS[ct], productCode: "", patient: "", tat: "", controlType: ct };
        } else if (wl.specimenId) {
          const sp = task.specimens.find((s) => s.specimenId === wl.specimenId);
          slots[idx] = sp
            ? { ...sp, barcode: sp.barcode ?? wl.barcode }
            : { specimenId: wl.specimenId, sampleId: wl.specimenId, sampleType: "", productCode: "", patient: "", tat: "", barcode: wl.barcode };
        }
      }
      return slots;
    }
    task.specimens.forEach((sp, i) => { if (i < total) slots[i] = sp; });
    return slots;
  });
  const [showSelector, setShowSelector] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [saveFlash, setSaveFlash] = useState(false);

  // ─── Auto Save：样例发生变化时自动调用 ────────────────────────
  const compact = (arr: (ScheduleSpecimen | undefined)[]) => arr.filter((s): s is ScheduleSpecimen => !!s);
  const initialRef = useRef(JSON.stringify(task.specimens));
  useEffect(() => {
    if (!dirty || readOnly) return;
    const current = JSON.stringify(editSpecimens);
    if (current !== initialRef.current) {
      onAutoSave?.(editSpecimens, siroDevice);
      initialRef.current = current;
      setSaveFlash(true);
      const t = setTimeout(() => setSaveFlash(false), 1500);
      return () => clearTimeout(t);
    }
  }, [editSpecimens, dirty, readOnly, onAutoSave, siroDevice]);

  // 孔板拖拽：两格内容整格互换（与手动排单向导 handleDrop 同构；数组 = 板的完整映射）
  const handleWellReorder = (fromIdx: number, toIdx: number) => {
    setEditSpecimens((prev) => {
      const from = prev[fromIdx];
      if (!from) return prev;
      const next = [...prev];
      next[fromIdx] = next[toIdx];
      next[toIdx] = from;
      return next;
    });
    setDirty(true);
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl py-0">
        <div className="p-4 border-b border-border flex items-center justify-between bg-amber-50 dark:bg-amber-950/30">
          <div className="flex items-center gap-3">
            <div>
              <h3 className="font-semibold">{readOnly ? "查看排单" : mode === "edit" ? "编辑排单" : "审核预排单"}</h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                {task.project} · {readOnly ? "只读模式" : mode === "edit" ? "修改后自动保存" : "可拖拽孔位调整顺序，修改后自动保存"}
              </p>
            </div>
            {saveFlash && !readOnly && (
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full font-medium flex items-center gap-1">
                <CheckCircle2 size={10} />已自动保存
              </span>
            )}
          </div>
          <Button variant="ghost" size="icon-sm" onClick={onClose} aria-label="关闭" className="shrink-0">
            <XCircle size={18} />
          </Button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* 设备行 */}
          <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/10 px-3 py-2">
            <span className="text-xs font-semibold text-muted-foreground w-20 shrink-0">实验设备</span>
            <div className="text-sm font-medium text-foreground">{siroDevice}</div>
          </div>

          {/* 孔板预览（完整显示，不内部滚动） */}
          {!isManual && (
          <div className="rounded-xl border border-border bg-muted/10 p-3">
            <WellPlatePreview
              deviceType={siroDevice}
              specimens={editSpecimens}
              editable={!readOnly}
              onReorder={handleWellReorder}
            />
          </div>
          )}

          {/* 样本列表 */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-muted-foreground">样本清单（{compact(editSpecimens).length} 个）</p>
              {!readOnly && !isManual && (
                <p className="text-[11px] text-muted-foreground/70">在上方孔板图中拖拽可交换位置</p>
              )}
            </div>
            <div className="border border-border rounded-lg overflow-hidden min-h-64 max-h-80 overflow-y-auto">
              <Table className="w-full text-sm">
                <TableHeader className="bg-card sticky top-0 z-10 shadow-[0_1px_0_0_hsl(var(--border))]">
                  <TableRow>
                    {!readOnly && <TableHead className="w-7 px-3 py-2" />}
                    {["孔位号", "样本/样例编号", "样本类型", "检测项目", "Barcode"].map((h) => (
                      <TableHead key={h} className="text-left px-3 py-2 font-semibold text-foreground">{h}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody className="divide-y divide-border">
                  {editSpecimens.map((sp, idx) => {
                    if (!sp) return null;
                    const controlType = getControlType(sp);
                    return (
                      <TableRow key={`${sp.specimenId}-${idx}`} className="hover:bg-muted/10">
                        {!readOnly && (
                          <TableCell className="px-3 py-2 text-center">
                            <button
                              onClick={() => {
                                // 移除该孔位内容（孔位数组置空，后续样本孔位不变）
                                setEditSpecimens((prev) => { const n = [...prev]; n[idx] = undefined; return n; });
                                setDirty(true);
                              }}
                              className="text-muted-foreground hover:text-red-500 transition-colors cursor-pointer"
                            >
                              <XCircle size={12} />
                            </button>
                          </TableCell>
                        )}
                        <TableCell className="px-3 py-2 font-mono text-muted-foreground">{getWellPosition(idx, siroDevice)}</TableCell>
                        <TableCell className="px-3 py-2 font-mono text-primary">{sp.specimenId}</TableCell>
                        <TableCell className="px-3 py-2 text-muted-foreground">
                          {controlType ? (
                            <span className={`inline-flex rounded px-1.5 py-0.5 text-[11px] font-medium border ${CONTROL_COLORS[controlType]}`}>
                              {CONTROL_LABELS[controlType]}
                            </span>
                          ) : sp.sampleType}
                        </TableCell>
                        <TableCell className="px-3 py-2 text-muted-foreground">{sp.productCode || "—"}</TableCell>
                        <TableCell className="px-3 py-2 font-mono text-muted-foreground">{sp.barcode ?? "—"}</TableCell>
                      </TableRow>
                    );
                  })}
                  {!readOnly && (
                    <TableRow>
                      <TableCell colSpan={5} className="px-3 py-2 text-center">
                        <button
                          onClick={() => setShowSelector(true)}
                          className="text-xs text-primary hover:underline cursor-pointer font-medium flex items-center gap-1 mx-auto"
                        >
                          <Plus size={12} />新增样本
                        </button>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-border bg-muted/10 flex items-center justify-between">
          {readOnly ? (
            <>
              <span />
              <Button variant="ghost" onClick={onClose}>关闭</Button>
            </>
          ) : (
            <>
              <Button variant="ghost" onClick={onClose}>{mode === "edit" ? "关闭" : "取消"}</Button>
              <Button
                variant="default"
                onClick={async () => {
                  // 先等 autoSave 落库（避免确认/保存时后端还是旧孔位），再执行确认
                  await onAutoSave?.(editSpecimens, siroDevice);
                  // 样本关联不强制：未关联样本也允许审核通过/保存，继续排单去实验
                  const currentCompact = compact(editSpecimens);
                  onConfirm?.(currentCompact, siroDevice);
                }}
              >
                {mode === "edit" ? <><CheckCircle2 size={13} />保存</> : <><CheckCircle2 size={13} />审核通过，加入排单列表</>}
              </Button>
            </>
          )}
        </div>
      </Card>

      {showSelector && !readOnly && (
        <SampleSelectorModal
          onClose={() => setShowSelector(false)}
          existingIds={compact(editSpecimens).map((s) => s.specimenId)}
          project={task.project || ""}
          onSelect={(newSpecs) => {
            setEditSpecimens((prev) => {
              const next = [...prev];
              for (const sp of newSpecs) {
                // 孔位数组长度固定（= 设备总孔位）：只填空位，无空位忽略（板满）
                const emptyIdx = next.findIndex((s) => !s);
                if (emptyIdx !== -1) next[emptyIdx] = sp;
              }
              return next;
            });
            setShowSelector(false);
            setDirty(true);
          }}
        />
      )}
    </div>
  );
}

// ─── Status Badge ────────────────────────────────────────────────────────────

