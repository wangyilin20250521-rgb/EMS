import React, { useEffect, useState } from "react";
import { ArrowLeft, CheckCheck, CheckCircle2, FlaskConical, XCircle } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { createManualSchedule, getWorkflowRules, fetchSiroProcessList, WELL_PLATE_CONFIG, type SIRODeviceType, type WellPlateSlot } from "@/app/lib/api";
import type { ProcessItem, WellSlot } from "./schedule-types";
import { buildEmptyPlate, CONTROL_LABELS } from "./schedule-types";
import { Step1 } from "./Step1";
import { Step2 } from "./Step2";
import { Step3 } from "./Step3";

export function ManualScheduleModal({
  onClose,
  onCreated,
}: {
  onClose: () => void;
  onCreated: (order: {
    orderId: string;
    orderNo: string;
    project: string;
    processNo: string;
    deviceType: SIRODeviceType;
    sampleCount: number;
    wellLayout: WellPlateSlot[];
    specimens: Array<{
      specimenId: string;
      sampleId: string;
      sampleType: string;
      productCode: string;
      patient: string;
      tat: string;
      controlType?: "Positive" | "Negative" | "Blank";
    }>;
  }) => void;
}) {
  const [step, setStep] = useState<0 | 1 | 2>(0);
  // NIFTY/非 NIFTY 由项目自动推导（无需单独模式步骤）：NIFTY → 制备链路样本，其他 → 样本中心样本
  const [project, setProject]     = useState("");
  const mode: "nifty" | "normal" = project === "NIFTY" ? "nifty" : "normal";
  const [processNo, setProcessNo] = useState("");
  const [deviceType, setDeviceType] = useState<SIRODeviceType | null>(null);
  const [wells, setWells] = useState<WellSlot[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [processList, setProcessList] = useState<ProcessItem[]>([]);
  const [loadingProcesses, setLoadingProcesses] = useState(false);
  // 实验流程规则（workflow-rules）：项目配置 productLines 时，所选流程产品线不匹配给出软提示（不阻断）
  const [workflowRules, setWorkflowRules] = useState<Record<string, any>>({});

  useEffect(() => {
    getWorkflowRules().then(setWorkflowRules).catch(() => {});
  }, []);

  // 软提示：所选流程的产品线不在项目允许列表时提醒（逐步纠正流程编写规范，不阻止组合）
  const processWarning = (() => {
    if (!project || !processNo) return null;
    const allowed = workflowRules?.[project]?.productLines;
    if (!Array.isArray(allowed) || allowed.length === 0) return null;
    const sel = processList.find(p => p.process_no === processNo);
    const line = sel?.process_info?.product_line_code ?? sel?.product_line_code ?? "";
    if (!line) return null;
    return allowed.includes(line)
      ? null
      : `所选流程产品线（${line}）与项目（${project}）不匹配，请确认流程是否正确`;
  })();

  const fetchProcesses = async () => {
    if (!deviceType) return;
    setLoadingProcesses(true);
    try {
      const list = await fetchSiroProcessList(deviceType);
      setProcessList(Array.isArray(list) ? list : []);
    } catch {
      setProcessList([]);
    } finally {
      setLoadingProcesses(false);
    }
  };

  // 设备型号变化时重新拉取流程列表
  useEffect(() => {
    if (deviceType) {
      fetchProcesses();
    } else {
      setProcessList([]);
      setProcessNo("");
    }
  }, [deviceType]);

  const canProceedStep1 = !!project && !!processNo && !!deviceType;

  // 使用列选择（1-12 列中用户自选，数量 = 设备列数：SIRO-16 选 2 列、SIRO-48 选 6 列、SIRO-96 全 12 列）
  const [usedColumns, setUsedColumns] = useState<number[]>([]);

  const handleNextFromStep1 = () => {
    if (!canProceedStep1 || !deviceType) return;
    setWells(buildEmptyPlate(deviceType));
    // 默认使用前 N 列（SIRO-16: 1,2 / SIRO-48: 1-6 / SIRO-96: 1-12）
    setUsedColumns([...Array(WELL_PLATE_CONFIG[deviceType].cols).keys()]);
    setStep(1);
  };

  const handleConfirm = async () => {
    if (!deviceType) return;
    setSubmitting(true);
    const specimenIds = wells.filter((w) => w.specimenId).map((w) => w.specimenId!);
    const totalWells = wells.filter((w) => w.specimenId || w.isControl).length;
    const cols = WELL_PLATE_CONFIG[deviceType].cols;
    const wellLayout: WellPlateSlot[] = wells
      .filter((well) => well.specimenId || well.isControl)
      .map((well) => ({
        // 物理孔位：行 = 槽序号 / 列数，列 = 用户选择的使用列（indexOf 映射）
        row: Math.floor(well.index / cols),
        col: (usedColumns[well.index % cols] ?? well.index % cols) + 1,
        specimenId: well.specimenId ?? undefined,
        // barcode 随 well_layout 持久化（真相源）；质控孔无样例编号，不带 barcode
        barcode: well.specimenId ? well.barcode : undefined,
        isControl: well.isControl,
        controlType: well.controlType ?? undefined,
      }));
    try {
      const result = await createManualSchedule({
        project,
        processNo,
        deviceType,
        specimens: specimenIds.map(id => ({ specimenId: id })),
        totalWells,
        wellLayout,
      });
      if (result.success) {
        setDone(true);
        onCreated({
          orderId: result.orderId,
          orderNo: result.orderNo,
            project,
            processNo,
            deviceType,
            sampleCount: wells.filter((w) => w.specimenId || w.isControl).length,
            wellLayout,
            specimens: wells
              .filter((w) => w.specimenId || w.isControl)
              .map((w) => ({
                specimenId: w.isControl ? `QC-${w.controlType}` : w.specimenId!,
                sampleId: w.isControl ? `QC-${w.controlType}` : w.sampleId ?? w.specimenId!,
                sampleType: w.isControl ? CONTROL_LABELS[w.controlType!] : "样本",
                productCode: project,
                patient: w.isControl ? CONTROL_LABELS[w.controlType!] : w.sampleNo ?? "-",
                tat: "-",
                controlType: w.controlType ?? undefined,
              })),
        });
      }
    } finally {
      setSubmitting(false);
    }
  };

  const STEP_LABELS = ["选择参数", "孔板分配", "确认创建"];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      {/* Step2/Step3 宽度一致（860px），Step1 参数页保持紧凑 560px；
          高度提到视口上限（四周留 20px）：Step2 上下双板尽量同屏可见，无需滚动 */}
      <div
        className="bg-card rounded-xl shadow-2xl w-full flex flex-col"
        style={{ maxWidth: step >= 1 ? "860px" : "560px", maxHeight: "calc(100vh - 40px)" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-3">
            {step > 0 && !done && (
              <button
                onClick={() => setStep((s) => (s - 1) as 0 | 1 | 2)}
                className="flex items-center justify-center w-7 h-7 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer"
              >
                <ArrowLeft size={15} />
              </button>
            )}
            <h2 className="text-base font-semibold" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
              手动排单
            </h2>
          </div>
          <Button variant="ghost" size="icon-sm" onClick={onClose} aria-label="关闭" className="shrink-0">
            <XCircle size={18} />
          </Button>
        </div>

        {/* 步骤导航 */}
        {!done && (
          <div className="flex items-center px-6 py-3 border-b border-border shrink-0 bg-muted/10">
            {STEP_LABELS.map((label, i) => {
              const s = i + 1;
              const isActive = step + 1 === s;
              const isDone = step + 1 > s;
              return (
                <React.Fragment key={s}>
                  <div className={`flex items-center gap-2 ${s > 1 ? "" : ""}`}>
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                      isDone ? "bg-emerald-500 text-white" : isActive ? "bg-primary text-white" : "bg-muted text-muted-foreground"
                    }`}>
                      {isDone ? <CheckCheck size={11} /> : s}
                    </div>
                    <span className={`text-sm ${isActive ? "font-semibold text-foreground" : "text-muted-foreground"}`}>
                      {label}
                    </span>
                  </div>
                  {i < STEP_LABELS.length - 1 && (
                    <div className={`flex-1 h-px mx-3 ${step > s ? "bg-emerald-300" : "bg-border"}`} />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        )}

        {/* Body */}
        <div className="flex-1 overflow-y-auto">
          {done ? (
            <div className="flex flex-col items-center justify-center py-16 gap-4">
              <div className="w-16 h-16 rounded-full bg-emerald-50 dark:bg-emerald-950/40 flex items-center justify-center">
                <CheckCircle2 size={32} className="text-emerald-500" />
              </div>
              <p className="text-base font-semibold text-foreground">排单创建成功</p>
              <p className="text-sm text-muted-foreground">
                {project} · {deviceType} · {wells.filter((w) => w.specimenId).length} 个样本
              </p>
            </div>
          ) : step === 0 ? (
            <Step1
              project={project} setProject={setProject}
              deviceType={deviceType} setDeviceType={setDeviceType}
              processNo={processNo} setProcessNo={setProcessNo}
              processList={processList} loadingProcesses={loadingProcesses}
              processWarning={processWarning}
              onRefreshProcesses={fetchProcesses}
            />
          ) : step === 1 ? (
            // Step2 上下双板（样本分配 + Barcode 录入）：高度随内容自适应撑开，
            // 两块 96 孔板同屏可见；小屏由外层 body 滚动兜底
            <div className="flex">
              <Step2 mode={mode} deviceType={deviceType!} wells={wells} setWells={setWells} project={project} usedColumns={usedColumns} setUsedColumns={setUsedColumns} />
            </div>
          ) : (
            <Step3 project={project} processNo={processNo} deviceType={deviceType!} wells={wells} usedColumns={usedColumns} workflowSteps={workflowRules?.[project]?.steps} />
          )}
        </div>

        {/* Footer */}
        {!done && (
          <div className="px-6 py-3 border-t border-border shrink-0 flex items-center justify-between bg-muted/5">
            <Button variant="ghost" onClick={onClose}>取消</Button>
            <div className="flex gap-2">
              {step === 0 && (
                <Button
                  variant="default"
                  onClick={handleNextFromStep1}
                  className={!canProceedStep1 ? "opacity-50 cursor-not-allowed" : ""}
                >
                  下一步
                </Button>
              )}
              {step === 1 && (
                <Button variant="default" onClick={() => setStep(2)}>
                  下一步
                </Button>
              )}
              {step === 2 && (
                <Button variant="default" onClick={handleConfirm} className={submitting ? "opacity-70" : ""}>
                  {submitting ? (
                    <span className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <FlaskConical size={13} />
                  )}
                  {submitting ? "创建中..." : "确认创建"}
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
