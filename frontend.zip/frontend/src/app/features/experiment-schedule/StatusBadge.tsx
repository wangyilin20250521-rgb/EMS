
import { CheckCircle2, XCircle } from "lucide-react";

export function StatusBadge({ status }: { status: string }) {
  if (status === "待确认")
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-blue-50 dark:bg-blue-950/40 px-2 py-0.5 text-xs font-medium text-blue-700 dark:text-blue-400">
        <CheckCircle2 size={11} />待确认
      </span>
    );
  if (status === "准入失败")
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-red-50 dark:bg-red-950/40 px-2 py-0.5 text-xs font-medium text-red-600 dark:text-red-400">
        <XCircle size={11} />准入失败
      </span>
    );
  if (status === "已认领")
    return (
      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
        <CheckCircle2 size={11} />已认领
      </span>
    );
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 text-xs font-medium text-amber-700 dark:text-amber-400">
      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 dark:bg-amber-500 inline-block" />待认领
    </span>
  );
}

// ─── Main Page ───────────────────────────────────────────────────────────────

