import { useState, useEffect, } from "react";
import { Search, XCircle, AlertTriangle } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { getAvailableSpecimens, type AvailableSpecimensResult } from "@/app/lib/api";
import type { Specimen } from "./schedule-page-types";

export function SampleSelectorModal({
  onClose, onSelect, existingIds, project,
}: {
  onClose: () => void;
  onSelect: (specimens: Specimen[]) => void;
  existingIds: string[];
  project: string;
}) {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  // 非 NIFTY 视图筛选：已入库 / 待录入（批次概要仅查看，扫码占位行可排单）
  const [viewFilter, setViewFilter] = useState<"registered" | "pending">("registered");
  const [result, setResult] = useState<AvailableSpecimensResult>({ samples: [], pendingBatches: [], pendingSpecimens: [] });
  const isNifty = project === "NIFTY";

  useEffect(() => {
    // 按项目分流：NIFTY → 制备链路样本；非 NIFTY → 样本中心已入库样本 + 待录入批次/占位行
    getAvailableSpecimens(isNifty ? undefined : project || undefined).then(setResult);
    setViewFilter("registered");
  }, [project, isNifty]);

  const matchSearch = (id: string, patient: string) =>
    id.toLowerCase().includes(search.toLowerCase()) ||
    patient.toLowerCase().includes(search.toLowerCase());

  // 已入库样本（可排单）：后端 available 已排除终态（已完成/异常/草稿），NIFTY 制备链路样本
  // （待制备/已分血/待实验等）与非 NIFTY 样本中心样本均在此列，不再按状态二次过滤
  const registered = result.samples
    .filter((sp) => !existingIds.includes(sp.id))
    .filter((sp) => matchSearch(sp.id, sp.patient));
  // 扫码占位行（有条码无患者，待认领补全，可排单）
  const pendingSpecimens = result.pendingSpecimens
    .filter((sp) => !existingIds.includes(sp.id))
    .filter((sp) => matchSearch(sp.id, sp.sampleNo || sp.patient));
  // 待录入批次（批次级概要，仅查看，不可排单）
  const pendingBatches = result.pendingBatches.filter((b) =>
    b.batchNo.toLowerCase().includes(search.toLowerCase()) ||
    b.hospital.toLowerCase().includes(search.toLowerCase())
  );

  // 当前视图可勾选列表：已入库视图 = 已入库样本；待录入视图 = 扫码占位行
  const currentList = viewFilter === "registered" ? registered : pendingSpecimens;
  const allSelectable = [...registered, ...pendingSpecimens];

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[80vh] flex flex-col overflow-hidden shadow-2xl py-0">
        <div className="p-4 border-b border-border flex items-center justify-between bg-muted/30">
          <h3 className="font-semibold">选择待排单样本</h3>
          <Button variant="ghost" size="icon-sm" onClick={onClose} aria-label="关闭" className="shrink-0">
            <XCircle size={18} />
          </Button>
        </div>
        <div className="p-4">
          <div className="flex items-center gap-2">
            {/* 非 NIFTY：已入库 / 待录入 视图筛选 */}
            {!isNifty && (
              <Select value={viewFilter} onValueChange={(v) => setViewFilter(v as "registered" | "pending")}>
                <SelectTrigger className="w-36 h-9 text-xs shrink-0">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="registered">已入库</SelectItem>
                  <SelectItem value="pending">待录入</SelectItem>
                </SelectContent>
              </Select>
            )}
            <div className="relative flex-1">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                className="w-full pl-9 pr-4 py-2 text-sm border border-border rounded-md bg-card focus:outline-none focus:ring-2 focus:ring-ring"
                placeholder="搜索样本编号、患者姓名..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto border-t border-border">
          {viewFilter === "pending" && pendingBatches.length > 0 && (
            <div className="border-b border-border">
              <div className="px-4 py-2 bg-amber-50/60 text-[11px] text-amber-700 flex items-center gap-1.5">
                <AlertTriangle size={11} />以下批次已收样登记，样本尚未录入样本中心，请先录入后再排单
              </div>
              <Table className="w-full text-sm">
                <TableHeader className="bg-muted/40 sticky top-0 z-10">
                  <TableRow>
                    {["批次号", "医院", "申报管数", "收样日期", "状态"].map((h) => (
                      <TableHead key={h} className="px-4 py-2 text-left font-semibold text-foreground">{h}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody className="divide-y divide-border">
                  {pendingBatches.map((b) => (
                    <TableRow key={b.batchId} className="bg-muted/10 opacity-70">
                      <TableCell className="px-4 py-2.5 font-mono">{b.batchNo}</TableCell>
                      <TableCell className="px-4 py-2.5">{b.hospital}</TableCell>
                      <TableCell className="px-4 py-2.5">{b.tubeCount} 管</TableCell>
                      <TableCell className="px-4 py-2.5 text-muted-foreground">{b.receivedAt}</TableCell>
                      <TableCell className="px-4 py-2.5">
                        <span className="text-[10px] px-1.5 py-0.5 rounded-sm bg-amber-100 text-amber-700 font-medium">待录入</span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          <Table className="w-full text-sm">
            <TableHeader className="bg-muted/40 sticky top-0 z-10">
              <TableRow>
                <TableHead className="w-10 px-4 py-2 text-left">
                  <input
                    type="checkbox"
                    className="rounded"
                    checked={selected.size > 0 && selected.size === currentList.length}
                    onChange={() => {
                      if (selected.size === currentList.length) setSelected(new Set());
                      else setSelected(new Set(currentList.map((s) => s.id)));
                    }}
                  />
                </TableHead>
                {["样本编号", "患者", "样本类型", "收样日期"].map((h) => (
                  <TableHead key={h} className="px-4 py-2 text-left font-semibold text-foreground">{h}</TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-border">
              {currentList.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="px-4 py-10 text-center text-muted-foreground italic">
                    {viewFilter === "pending" ? "暂无待录入样本（扫码收样占位行可直接排单）" : "暂无可选样本"}
                  </TableCell>
                </TableRow>
              ) : (
                currentList.map((sp) => (
                  <TableRow key={sp.id} className="hover:bg-muted/20 cursor-pointer" onClick={() => toggleSelect(sp.id)}>
                    <TableCell className="px-4 py-2.5" onClick={(e) => e.stopPropagation()}>
                      <input type="checkbox" className="rounded" checked={selected.has(sp.id)} onChange={() => toggleSelect(sp.id)} />
                    </TableCell>
                    {/* NIFTY 显示样例编号（同一样本多个样例独立展示）；非 NIFTY 显示样本编号 */}
                    <TableCell className="px-4 py-2.5 font-mono text-primary">{isNifty ? sp.id : (sp.sampleNo || sp.id)}</TableCell>
                    <TableCell className="px-4 py-2.5 font-medium">
                      {sp.patient || <span className="text-muted-foreground/50 italic">待补全</span>}
                    </TableCell>
                    <TableCell className="px-4 py-2.5 text-muted-foreground">{sp.sampleType}</TableCell>
                    <TableCell className="px-4 py-2.5 text-muted-foreground">{sp.receivedAt}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        <div className="p-4 border-t border-border bg-muted/10 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">已选择 {selected.size} 个</span>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={onClose}>取消</Button>
            <Button
              variant="default" size="sm"
              onClick={() => {
                if (selected.size === 0) return;
                const specs = allSelectable.filter((s) => selected.has(s.id)).map((s) => ({
                  specimenId: s.id, sampleId: s.sampleId, sampleType: s.sampleType,
                  productCode: "WES-CL-V2", patient: s.patient, tat: "06-30",
                }));
                onSelect(specs);
              }}
              className={selected.size === 0 ? "opacity-50 cursor-not-allowed" : ""}
            >
              确认添加
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}

// ─── Plate Layout Rebuild ──────────────────────────────────────────────────────

/**
 * 从编辑中的扁平样本数组（数组下标 = 孔位 idx，与 WellPlatePreview 渲染同构）重建 well_layout，
 * 供 autoSave 与 chip_lanes 一并提交 —— 修复编辑排单（拖拽换孔/增删样本）后 well_layout 与 chip_lanes 失同步问题。
 * barcode 未定义时落 1（业务默认值，老数据安全回填）。
 */
