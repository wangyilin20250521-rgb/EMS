import { useEffect, useState } from "react";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { WELL_PLATE_CONFIG, type SIRODeviceType } from "@/app/lib/api";
import { getControlPlan, type ControlPlanItem } from "@/app/lib/api/schedule";
import { CONTROL_LABELS, CONTROL_COLORS } from "./schedule-types";
import type { WellSlot } from "./schedule-types";

export function Step3({
  project,
  processNo,
  deviceType,
  wells,
  usedColumns,
  workflowSteps,
}: {
  project: string;
  processNo: string;
  deviceType: SIRODeviceType;
  wells: WellSlot[];
  /** 使用列（与 Step2 一致：用户自选列，未选列灰显） */
  usedColumns: number[];
  /** 实验流程步骤（workflow-rules），按项目实时读取 */
  workflowSteps?: string[];
}) {
  const cfg = WELL_PLATE_CONFIG[deviceType];
  const specimens = wells.filter((w) => w.specimenId);
  const controls = wells.filter((w) => w.isControl);
  const sampleCount = specimens.length;
  const totalOccupied = wells.filter((w) => w.specimenId || w.isControl).length;

  // 质控品参考计划（control-rules）——样本数固定后抓取一次
  const [controlPlan, setControlPlan] = useState<ControlPlanItem[]>([]);
  const [planLoading, setPlanLoading] = useState(false);
  useEffect(() => {
    if (totalOccupied <= 0) { setControlPlan([]); return }
    setPlanLoading(true);
    getControlPlan(cfg.total, sampleCount)
      .then(r => setControlPlan(r.plan ?? []))
      .catch(() => setControlPlan([]))
      .finally(() => setPlanLoading(false));
    // sampleCount 在 第 2 步操作结束后固定，flow 稳定
  }, [sampleCount, cfg.total]);

  const CONTROL_NAME_MAP: Record<string, string> = {
    positiveControl: "阳性质控",
    negativeControl: "阴性质控",
    blankControl: "空白质控",
  };

  return (
    <div className="px-6 py-5 space-y-4">
      {/* 汇总信息 */}
      <div className="rounded-xl border border-border bg-muted/10 p-4 space-y-2">
        {[
          ["实验项目", project],
          ...(workflowSteps && workflowSteps.length > 0
            ? [["实验流程步骤", workflowSteps.join(" → ")]]
            : []),
          ["流程编号", processNo],
          ["设备型号", deviceType],
          ["孔板规格", `${cfg.cols === cfg.plateCols ? "96 孔板（8 行 × 12 列）" : `96 孔板 · 使用前 ${cfg.cols} 列（${cfg.total} 孔）`}`],
          ["样本数量", `${sampleCount} 个`],
          ["质控品数量", `${controls.length} 个`],
        ].map(([k, v]) => (
          <div key={k} className="flex items-center gap-3">
            <span className="text-xs text-muted-foreground w-24 shrink-0">{k}</span>
            <span className="text-sm font-medium text-foreground">{v}</span>
          </div>
        ))}
        {controlPlan.length > 0 && (
          <div className="border-t border-border/50 pt-2 mt-1">
            <p className="text-xs text-muted-foreground mb-1.5">质控品参考计划（按 control-rules 计算）</p>
            <div className="flex flex-wrap gap-2">
              {controlPlan.map((item, i) => (
                <span key={i} className="inline-flex items-center gap-1.5 text-xs bg-muted/60 rounded px-2 py-1">
                  <span className="font-medium">{CONTROL_NAME_MAP[item.control] ?? item.control}</span>
                  <span className="text-muted-foreground">{item.note}</span>
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 孔板只读预览（与 Step2 同款：外框网格 + 行列号 + 使用列灰显 + 列宽随条码自适应） */}
      <div>
        <p className="text-xs font-semibold text-muted-foreground mb-2">孔板布局预览</p>
        {(() => {
          const usedCols = new Set<number>();
          wells.forEach((w) => { if (w.specimenId || w.isControl) usedCols.add(usedColumns[w.index % cfg.cols] ?? w.index % cfg.cols); });
          const colWidth = (c: number) => {
            if (!usedCols.has(c)) return "2.25rem";
            let maxLen = 0;
            wells.forEach((w) => {
              const phys = usedColumns[w.index % cfg.cols] ?? w.index % cfg.cols;
              if ((w.specimenId || w.isControl) && phys === c && w.sampleNo) maxLen = Math.max(maxLen, w.sampleNo.length);
            });
            return `${Math.min(130, Math.max(36, maxLen * 7 + 10))}px`;
          };
          const colsTemplate = `20px ${Array.from({ length: cfg.plateCols }, (_, c) => colWidth(c)).join(" ")}`;
          return (
        <div className="border border-border rounded-lg overflow-hidden w-fit p-0.5 bg-card">
          <div className="grid gap-0.5 mb-0.5" style={{ gridTemplateColumns: colsTemplate }}>
            <div />
            {Array.from({ length: cfg.plateCols }, (_, c) => (
              <div key={c} className={`text-center text-[10px] font-mono ${usedColumns.includes(c) ? "text-foreground font-semibold" : "text-muted-foreground/40"}`}>
                {c + 1}
              </div>
            ))}
          </div>
          {Array.from({ length: cfg.plateRows }, (_, r) => (
            <div key={r} className="grid gap-0.5 mb-0.5" style={{ gridTemplateColumns: colsTemplate }}>
              <div className="text-center text-[10px] font-mono text-muted-foreground flex items-center justify-center">
                {String.fromCharCode(65 + r)}
              </div>
              {Array.from({ length: cfg.plateCols }, (_, c) => {
                if (r >= cfg.rows || !usedColumns.includes(c)) {
                  return <div key={c} className="w-full h-9 rounded border border-dashed border-border/30 bg-muted/20" />;
                }
                const idx = r * cfg.cols + usedColumns.indexOf(c);
                const slot = wells[idx];
                if (!slot) return <div key={c} className="w-full h-9 rounded border border-border/70" />;
                return (
                  <div
                    key={c}
                    title={slot.isControl ? CONTROL_LABELS[slot.controlType!] : (slot.sampleNo ?? slot.specimenId ?? "")}
                    className={`w-full h-9 rounded flex items-center justify-center font-mono text-[11px] px-0.5 border ${
                      slot.isControl
                        ? CONTROL_COLORS[slot.controlType!]
                        : slot.sampleNo || slot.specimenId
                          ? "bg-blue-50 border-blue-300 text-foreground"
                          : "border-border/70"
                    }`}
                  >
                    <span className="truncate max-w-full text-center">
                      {slot.isControl ? slot.controlType?.charAt(0) : (slot.sampleNo || "")}
                    </span>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
          );
        })()}
      </div>

      {/* 样本列表 */}
      {specimens.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-muted-foreground mb-2">样本清单</p>
          <div className="border border-border rounded-lg overflow-hidden max-h-40 overflow-y-auto">
            <Table className="w-full text-xs">
              <TableHeader className="bg-muted/40 sticky top-0">
                <TableRow>
                  <TableHead className="text-left px-3 py-2 font-semibold text-foreground">孔位</TableHead>
                  <TableHead className="text-left px-3 py-2 font-semibold text-foreground">样例编号</TableHead>
                  <TableHead className="text-left px-3 py-2 font-semibold text-foreground">Barcode</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody className="divide-y divide-border">
                {specimens.map((slot) => {
                  const row = String.fromCharCode(65 + Math.floor(slot.index / WELL_PLATE_CONFIG[deviceType].cols));
                  const col = (slot.index % WELL_PLATE_CONFIG[deviceType].cols) + 1;
                  return (
                    <TableRow key={slot.index} className="hover:bg-muted/10">
                      <TableCell className="px-3 py-1.5 font-mono text-muted-foreground">{row}{col}</TableCell>
                      <TableCell className="px-3 py-1.5 font-mono text-primary">{slot.sampleNo || slot.specimenId}</TableCell>
                      <TableCell className="px-3 py-1.5 font-mono text-foreground">{slot.barcode}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </div>
  );
}