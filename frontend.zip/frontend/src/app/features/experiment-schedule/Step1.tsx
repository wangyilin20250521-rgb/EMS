import { useEffect, } from "react";
import { RefreshCw, FlaskConical, AlertTriangle } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { PROJECT_OPTIONS, SIRO_DEVICE_OPTIONS, WELL_PLATE_CONFIG, type SIRODeviceType } from "@/app/lib/api";
import type { ProcessItem } from "./schedule-types";

export function Step1({
  project, setProject,
  deviceType, setDeviceType,
  processNo, setProcessNo,
  processList, loadingProcesses,
  processWarning,
  onRefreshProcesses,
}: {
  project: string; setProject: (v: string) => void;
  deviceType: SIRODeviceType | null; setDeviceType: (v: SIRODeviceType) => void;
  processNo: string; setProcessNo: (v: string) => void;
  processList: ProcessItem[]; loadingProcesses: boolean;
  /** 流程产品线与项目不匹配的软提示（workflow-rules productLines 配置，不阻断） */
  processWarning: string | null;
  onRefreshProcesses: () => void;
}) {
  const selectedProcess = processList.find(p => p.process_no === processNo);
  const processInfo: Record<string, any> = selectedProcess?.process_info ?? {};

  // 按项目过滤流程：project 为空/通用 匹配全部，否则精确匹配
  const filteredProcesses = processList.filter(p => {
    const proj = (p as any).project ?? (p.process_info?.project ?? '')
    return proj === '' || proj === '通用' || proj === project
  })
  // 切换项目后当前选中流程若不在新列表则清空
  useEffect(() => {
    const fp = processList.filter(p => {
      const proj = (p as any).project ?? (p.process_info?.project ?? '')
      return proj === '' || proj === '通用' || proj === project
    })
    if (processNo && !fp.some(p => p.process_no === processNo)) {
      setProcessNo('')
    }
  }, [project, processList, processNo, setProcessNo])

  return (
    <div className="px-6 py-5 space-y-5">
      {/* 设备型号 */}
      <div>
        <label className="text-xs font-semibold text-muted-foreground block mb-2">
          设备型号 <span className="text-red-500">*</span>
        </label>
        <div className="flex gap-3">
          {SIRO_DEVICE_OPTIONS.map((d) => {
            const cfg = WELL_PLATE_CONFIG[d];
            const isSelected = deviceType === d;
            return (
              <button
                key={d}
                onClick={() => { setDeviceType(d); setProcessNo(""); }}
                className={`flex-1 p-4 rounded-xl border-2 text-left transition-all cursor-pointer ${
                  isSelected
                    ? "border-primary bg-primary/5"
                    : "border-border bg-card hover:border-primary/40"
                }`}
              >
                <p className={`text-sm font-bold ${isSelected ? "text-primary" : "text-foreground"}`}>
                  {d}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {cfg.cols === cfg.plateCols ? "96 孔板（8 行 × 12 列）" : `96 孔板 · 使用前 ${cfg.cols} 列`}
                </p>
                <p className={`text-xs font-semibold mt-0.5 ${isSelected ? "text-primary" : "text-muted-foreground"}`}>
                  {cfg.total} 孔位
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* 实验项目：全部项目 chips 选择；NIFTY 内嵌图标徽章区分（需制备），样本池按项目自动分流 */}
      <div>
        <label className="text-xs font-semibold text-muted-foreground block mb-2">
          实验项目 <span className="text-red-500">*</span>
        </label>
        <div className="flex flex-wrap gap-2">
          {PROJECT_OPTIONS.map((p) => (
            <button
              key={p}
              onClick={() => setProject(p)}
              className={`px-3 py-1.5 rounded-lg border-2 text-sm font-medium transition-all cursor-pointer flex items-center gap-1 ${
                project === p
                  ? "border-primary bg-primary text-white"
                  : "border-border bg-card hover:border-primary/50 text-foreground"
              }`}
            >
              {p === "NIFTY" && <FlaskConical size={12} className={project === p ? "" : "text-primary"} />}
              {p}
            </button>
          ))}
        </div>
        {project === "NIFTY" && (
          <p className="text-xs text-amber-600 mt-2 flex items-center gap-1">
            <AlertTriangle size={11} className="shrink-0" />NIFTY 项目需先完成样本制备（分血）后，使用已制备样例排单
          </p>
        )}
      </div>

      {/* 流程选择 */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-semibold text-muted-foreground">
            流程选择 <span className="text-red-500">*</span>
          </label>
          <button
            onClick={onRefreshProcesses}
            disabled={loadingProcesses}
            className="text-xs text-primary hover:underline flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw size={11} className={loadingProcesses ? "animate-spin" : ""} />
            刷新
          </button>
        </div>
        {!deviceType ? (
          <p className="text-xs text-muted-foreground italic">请先选择设备型号</p>
        ) : loadingProcesses ? (
          <p className="text-xs text-muted-foreground">正在加载流程列表...</p>
        ) : (
          <>
            <Select onValueChange={v => setProcessNo(v)} value={processNo}>
  <SelectTrigger className="w-full border border-border rounded-md px-3 py-2 text-sm bg-card focus:outline-none focus:ring-2 focus:ring-ring"><SelectValue placeholder="请选择流程" /></SelectTrigger>
  <SelectContent>

              
              {filteredProcesses.map((p) => (
                <SelectItem key={p.process_no} value={p.process_no}>
                  {p.process_no}{p.process_name ? ` — ${p.process_name}` : ''}
                </SelectItem>
              ))}
            
  </SelectContent>
</Select>
            {!loadingProcesses && processList.length > 0 && filteredProcesses.length === 0 && (
              <p className="text-xs text-amber-600 mt-1">当前项目暂无匹配流程（流程的 project 字段不匹配）</p>
            )}
            {!loadingProcesses && processList.length === 0 && filteredProcesses.length === 0 && (
              <p className="text-xs text-amber-600 mt-1">当前设备型号暂无可用流程</p>
            )}

            {/* 流程产品线与项目不匹配软提示（不阻断，逐步纠正流程编写规范） */}
            {processWarning && (
              <p className="text-xs text-amber-600 mt-1 flex items-center gap-1">
                <AlertTriangle size={11} className="shrink-0" />{processWarning}
              </p>
            )}

            {/* 流程详情 */}
            {selectedProcess && (
              <div className="mt-3 rounded-lg border border-border bg-muted/10 p-3 text-xs space-y-2">
                <div>
                  <p className="text-[11px] text-muted-foreground">流程名称</p>
                  <p className="font-semibold text-foreground">{processInfo.process_name || selectedProcess.process_name || "—"}</p>
                </div>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
                  {[
                    ["产品线", processInfo.product_line_name || processInfo.product_line_code],
                    ["流程类型", processInfo.process_type],
                    ["设备类型", processInfo.device_type],
                    ["测序仪", processInfo.sequencer_type],
                    ["运行模式", processInfo.dev_mode],
                    ["当前版本", processInfo.current_version],
                    ["预计耗时", processInfo.estimated_duration_minutes ? `${processInfo.estimated_duration_minutes} 分钟` : null],
                    ["超时时间", processInfo.timeout_minutes ? `${processInfo.timeout_minutes} 分钟` : null],
                  ].filter(([, v]) => v != null).map(([label, value]) => (
                    <div key={label}>
                      <p className="text-[11px] text-muted-foreground">{label}</p>
                      <p className="text-foreground">{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

// ─── Step 2: Plate Assignment ──────────────────────────────────────────────────

