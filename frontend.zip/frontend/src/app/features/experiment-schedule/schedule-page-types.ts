import { WELL_PLATE_CONFIG, type SIRODeviceType, type WellPlateSlot, type ScheduleSpecimen } from "@/app/lib/api";

export type ControlType = "Positive" | "Negative" | "Blank";

export interface Specimen {
  specimenId: string; sampleId: string; sampleType: string;
  productCode: string; patient: string; tat: string;
  controlType?: ControlType;
}

export const CONTROL_LABELS: Record<ControlType, string> = {
  Positive: "阳性质控",
  Negative: "阴性质控",
  Blank: "空白质控",
};

export const CONTROL_COLORS: Record<ControlType, string> = {
  Positive: "bg-orange-300 border-orange-400 text-orange-900",
  Negative: "bg-purple-300 border-purple-400 text-purple-900",
  Blank: "bg-slate-200 border-slate-300 text-slate-700",
};

export const getControlType = (specimen: Specimen): ControlType | null => {
  if (specimen.controlType) return specimen.controlType;
  // sampleType 可能缺失（后端只返回 { specimenId } 时），兜底为空串避免崩溃
  const type = specimen.sampleType ?? "";
  if (type.includes("阳性") || specimen.specimenId.includes("POS")) return "Positive";
  if (type.includes("阴性") || specimen.specimenId.includes("NEG")) return "Negative";
  if (type.includes("空白") || specimen.specimenId.includes("BLANK")) return "Blank";
  return null;
};

export const getWellPosition = (index: number, deviceType: SIRODeviceType) => {
  const { cols } = WELL_PLATE_CONFIG[deviceType];
  const row = String.fromCharCode(65 + Math.floor(index / cols));
  const col = (index % cols) + 1;
  return `${row}${col}`;
};

// ─── Sample Selection Modal ─────────────────────────────────────────────────────


export function buildWellLayout(specimens: (ScheduleSpecimen | undefined)[], deviceType: SIRODeviceType): WellPlateSlot[] {
  const { cols } = WELL_PLATE_CONFIG[deviceType];
  const layout: WellPlateSlot[] = [];
  specimens.forEach((sp, i) => {
    if (!sp) return;
    const controlType = getControlType(sp);
    layout.push(
      controlType
        ? { row: Math.floor(i / cols), col: (i % cols) + 1, isControl: true, controlType }
        : { row: Math.floor(i / cols), col: (i % cols) + 1, specimenId: sp.specimenId, barcode: sp.barcode ?? 1 },
    );
  });
  return layout;
}

// ─── Plate Preview（支持拖拽交换孔位） ────────────────────────────────────────

