import React, { useEffect, useRef, useState } from "react";
import { AlertTriangle, X, } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { getAvailableSpecimens, WELL_PLATE_CONFIG, type AvailableSpecimen, type AvailableSpecimensResult, type SIRODeviceType, } from "@/app/lib/api";
import { toast } from "sonner";
import { CONTROL_LABELS, CONTROL_COLORS, } from "./schedule-types";
import type { ControlType, WellSlot } from "./schedule-types";

export function Step2({
  mode,
  deviceType,
  wells,
  setWells,
  project,
  usedColumns,
  setUsedColumns,
}: {
  mode: "nifty" | "normal";
  deviceType: SIRODeviceType;
  wells: WellSlot[];
  setWells: React.Dispatch<React.SetStateAction<WellSlot[]>>;
  project: string;
  /** 使用列（1-12 列中用户自选，数量 = 设备列数） */
  usedColumns: number[];
  setUsedColumns: React.Dispatch<React.SetStateAction<number[]>>;
}) {
  const cfg = WELL_PLATE_CONFIG[deviceType];
  const [search, setSearch] = useState("");
  const dragIdx = useRef<number | null>(null);
  // 非 NIFTY 视图筛选：已入库 / 待录入（批次概要仅查看，扫码占位行可排）
  const [viewFilter, setViewFilter] = useState<"registered" | "pending">("registered");
  const [allSpecimens, setAllSpecimens] = useState<AvailableSpecimensResult>({ samples: [], pendingBatches: [], pendingSpecimens: [] });

  useEffect(() => {
    // NIFTY 模式：制备链路样本（不传 project）；非 NIFTY：样本中心已入库样本 + 待录入批次/占位行（传 project）
    getAvailableSpecimens(mode === "nifty" ? undefined : project || undefined).then(setAllSpecimens);
    setViewFilter("registered");
  }, [mode, project]);

  const notOccupied = (sp: AvailableSpecimen) => !wells.some((w) => w.specimenId === sp.id);

  // 已入库样本（可排）：后端 available 已排除终态（已完成/异常/草稿），NIFTY 制备链路样本
  // （待制备/已分血/待实验等）与非 NIFTY 样本中心样本均在此列，不再按状态二次过滤；
  // project 为空的样本（上位机上报、样本中心未录入，无项目信息）始终显示
  const registered = allSpecimens.samples
    .filter((sp) => notOccupied(sp) && (!project || !sp.project || sp.project === project))
    .filter((sp) => sp.id.toLowerCase().includes(search.toLowerCase()) || sp.patient.toLowerCase().includes(search.toLowerCase()));
  // 扫码占位行（有条码无患者，可排）
  const pendingSpecimens = allSpecimens.pendingSpecimens
    .filter((sp) => notOccupied(sp))
    .filter((sp) => sp.id.toLowerCase().includes(search.toLowerCase()) || sp.sampleNo?.toLowerCase().includes(search.toLowerCase()));
  // 待录入批次（仅查看）
  const pendingBatches = allSpecimens.pendingBatches.filter((b) =>
    b.batchNo.toLowerCase().includes(search.toLowerCase()) || b.hospital.toLowerCase().includes(search.toLowerCase())
  );

  // 当前视图可排列表：已入库视图 = 已入库样本；待录入视图 = 扫码占位行
  const availableSpecimens = viewFilter === "registered" ? registered : pendingSpecimens;

  const occupiedCount = wells.filter((w) => w.specimenId || w.isControl).length;

  const handleWellClick = (idx: number) => {
    const slot = wells[idx];
    if (slot.specimenId || slot.isControl) {
      setWells((prev) =>
        prev.map((w) =>
          w.index === idx
            ? { ...w, specimenId: null, sampleNo: null, patient: null, sampleId: null, isControl: false, controlType: null, barcode: 1 }
            : w
        )
      );
    }
  };

  // 自动添加按列填充：先填满第 1 列（A1→B1→C1...→H1），再第 2 列（A2→B2...），依次类推
  const nextEmptyIndex = (ws: WellSlot[]): number | null => {
    for (let col = 0; col < cfg.cols; col++) {
      for (let row = 0; row < cfg.rows; row++) {
        const idx = row * cfg.cols + col;
        const slot = ws[idx];
        if (slot && !slot.specimenId && !slot.isControl) return idx;
      }
    }
    return null;
  };

  const handleSpecimenClick = (sp: { id: string; patient: string; sampleId: string; sampleNo?: string }) => {
    const idx = nextEmptyIndex(wells);
    if (idx === null) return;
    // NIFTY 制备链路显示样例编号（sp.id，同一样本多个样例各自独立）；非 NIFTY 1 样本 1 样例显示样本编号
    const displayNo = mode === "nifty" ? sp.id : (sp.sampleNo || sp.id);
    setWells((prev) =>
      prev.map((w) =>
        w.index === idx
          ? { ...w, specimenId: sp.id, sampleNo: displayNo, patient: sp.patient, sampleId: sp.sampleId, barcode: 1 }
          : w
      )
    );
  };

  const handleControlClick = (controlType: ControlType) => {
    const idx = nextEmptyIndex(wells);
    if (idx === null) return;
    setWells((prev) =>
      prev.map((w) =>
        w.index === idx
          ? { ...w, specimenId: null, patient: null, sampleId: null, isControl: true, controlType }
          : w
      )
    );
  };

  const handleDragStart = (idx: number) => {
    dragIdx.current = idx;
  };

  const handleDrop = (targetIdx: number) => {
    const srcIdx = dragIdx.current;
    if (srcIdx === null || srcIdx === targetIdx) return;
    setWells((prev) => {
      const next = [...prev];
      const src = { ...next[srcIdx] };
      const dst = { ...next[targetIdx] };
      // 整格内容互换（含 barcode：barcode 是样本的属性值，随样本走）
      next[srcIdx] = { ...src, specimenId: dst.specimenId, sampleNo: dst.sampleNo, patient: dst.patient, sampleId: dst.sampleId, isControl: dst.isControl, controlType: dst.controlType, barcode: dst.barcode };
      next[targetIdx] = { ...dst, specimenId: src.specimenId, sampleNo: src.sampleNo, patient: src.patient, sampleId: src.sampleId, isControl: src.isControl, controlType: src.controlType, barcode: src.barcode };
      return next;
    });
    dragIdx.current = null;
  };

  const isFull = occupiedCount >= cfg.total;

  // ── Barcode 录入板（下板）：输入文本草稿（blur 校验后写入 wells）──
  const [barcodeDrafts, setBarcodeDrafts] = useState<Record<number, string>>({});

  /** 1-1000 正整数校验；空输入不算非法态（blur 时归 1） */
  const isInvalidBarcode = (text: string) => {
    if (text === "") return false;
    const n = Number(text);
    return !Number.isInteger(n) || n < 1 || n > 1000;
  };

  const handleBarcodeChange = (idx: number, value: string) => {
    // 只接受数字，最多 4 位（1000）
    const digits = value.replace(/\D/g, "").slice(0, 4);
    setBarcodeDrafts((prev) => ({ ...prev, [idx]: digits }));
  };

  const handleBarcodeBlur = (idx: number) => {
    const text = barcodeDrafts[idx];
    if (text === undefined) return;
    setBarcodeDrafts((prev) => { const next = { ...prev }; delete next[idx]; return next; });
    const n = Number(text);
    const valid = text !== "" && Number.isInteger(n) && n >= 1 && n <= 1000;
    // 非法值归 1（业务默认值），不弹 toast 打断连续录入
    setWells((ws) => ws.map((w, i) => (i === idx ? { ...w, barcode: valid ? n : 1 } : w)));
  };

  const resetAllBarcodes = () => {
    setBarcodeDrafts({});
    setWells((ws) => ws.map((w) => (w.specimenId ? { ...w, barcode: 1 } : w)));
  };

  // 已录入条码的列自动放大：列宽按该列最长条码自适应（单行完整显示不截断），未使用列保持小格子 36px。
  // 上下两板共用同一 colsTemplate，保证 Barcode 板与样本板逐格对齐
  const usedCols = new Set<number>();
  wells.forEach((w) => { if (w.specimenId || w.isControl) usedCols.add(usedColumns[w.index % cfg.cols] ?? w.index % cfg.cols); });
  // 11px 等宽字体每字符约 6.6px，取 7px 保守；上限 130px 防极端长条码撑爆板宽
  const colWidth = (c: number) => {
    if (!usedCols.has(c)) return "2.25rem";
    let maxLen = 0;
    wells.forEach((w) => {
      const phys = usedColumns[w.index % cfg.cols] ?? w.index % cfg.cols;
      if ((w.specimenId || w.isControl) && phys === c && w.sampleNo) {
        maxLen = Math.max(maxLen, w.sampleNo.length);
      }
    });
    return `${Math.min(130, Math.max(36, maxLen * 7 + 10))}px`;
  };
  const colsTemplate = `20px ${Array.from({ length: cfg.plateCols }, (_, c) => colWidth(c)).join(" ")}`;

  // 切换使用列：启用/禁用（数量上限 = 设备列数）；列布局变化后清空已分配孔位（idx 映射改变）
  const toggleColumn = (c: number) => {
    setUsedColumns(prev => {
      if (prev.includes(c)) {
        if (prev.length <= 1) { toast.warning("至少保留 1 列"); return prev; }
        return prev.filter(x => x !== c);
      }
      if (prev.length >= cfg.cols) { toast.warning(`该设备最多使用 ${cfg.cols} 列`); return prev; }
      return [...prev, c].sort((a, b) => a - b);
    });
    setWells(prev => prev.map(w => ({ ...w, specimenId: null, sampleNo: null, patient: null, sampleId: null, isControl: false, controlType: null, barcode: 1 })));
    // 列布局变化后 idx 映射改变，清空 Barcode 草稿避免残留错位
    setBarcodeDrafts({});
  };

  return (
    <div className="flex h-full w-full overflow-hidden">
      {/* 左：孔板示意图 */}
      <div className="flex-1 px-5 py-2 overflow-y-auto">
        <div className="flex items-center justify-center gap-2 mb-2">
          <span className="text-sm font-semibold text-foreground">{deviceType} 孔板</span>
          <span className="text-xs text-muted-foreground">
            {occupiedCount} / {cfg.total} 孔已占用
          </span>
          {cfg.cols < cfg.plateCols && (
            <span className="text-[11px] text-muted-foreground/70">点击列号可更换使用列（{cfg.cols} 列）</span>
          )}
        </div>

        {/* 已录入条码的列自动放大：列宽按该列最长条码自适应（单行完整显示不截断），未使用列保持小格子 36px（计算见函数体 colsTemplate，与下板共用） */}
        {(() => (
        <>
        {/* 板子容器：外框 + 格子间细边框线，居中展示 */}
        <div className="border border-border rounded-lg overflow-hidden w-fit p-0.5 bg-card mx-auto">
        {/* 列号：点击切换使用列（最多 cfg.cols 列，默认前 N 列） */}
        <div
          className="grid gap-0.5 mb-0.5"
          style={{ gridTemplateColumns: colsTemplate }}
        >
          <div />
          {Array.from({ length: cfg.plateCols }, (_, c) => (
            <button
              key={c}
              type="button"
              onClick={() => toggleColumn(c)}
              title={usedColumns.includes(c) ? `第 ${c + 1} 列（点击停用）` : `第 ${c + 1} 列（点击启用）`}
              className={`text-center text-[10px] font-mono rounded transition-colors cursor-pointer ${usedColumns.includes(c) ? "text-foreground font-semibold" : "text-muted-foreground/40 hover:text-muted-foreground"}`}
            >
              {c + 1}
            </button>
          ))}
        </div>

        {/* 行：标准 96 孔板（8 行 A-H × 12 列 1-12），设备未启用的行列灰显不可用 */}
        {Array.from({ length: cfg.plateRows }, (_, r) => (
          <div
            key={r}
            className="grid gap-0.5 mb-0.5"
            style={{ gridTemplateColumns: colsTemplate }}
          >
            {/* 行号 */}
            <div className={`text-center text-[10px] font-mono flex items-center justify-center ${r >= cfg.rows ? "text-muted-foreground/40" : "text-muted-foreground"}`}>
              {String.fromCharCode(65 + r)}
            </div>
            {Array.from({ length: cfg.plateCols }, (_, c) => {
              // 用户未选用的列（不在 usedColumns）：灰显不可用，不参与分配
              if (r >= cfg.rows || !usedColumns.includes(c)) {
                return (
                  <div key={c} className="w-full h-9 rounded border border-dashed border-border/30 bg-muted/20" />
                );
              }
              const idx = r * cfg.cols + usedColumns.indexOf(c);
              const slot = wells[idx];
              if (!slot) return <div key={c} />;
              const hasContent = slot.specimenId || slot.isControl;
              return (
                <div
                  key={c}
                  className={`relative w-full h-9 rounded flex items-center justify-center font-mono transition-all select-none px-0.5
                    ${slot.isControl
                      ? (slot.controlType === "Positive"
                          ? "bg-orange-300 border border-orange-400 text-[9px]"
                          : slot.controlType === "Negative"
                          ? "bg-purple-300 border border-purple-400 text-[9px]"
                          : "bg-slate-200 border border-slate-300 text-[9px]")
                      : slot.specimenId
                      ? "bg-blue-50 border border-blue-300 text-foreground text-[11px]"
                      : "border border-border/70 hover:border-primary/50 hover:bg-blue-50/30"
                    }`}
                >
                  <div
                    draggable={!!hasContent}
                    onDragStart={() => handleDragStart(idx)}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={() => handleDrop(idx)}
                    onClick={() => handleWellClick(idx)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter" || event.key === " ") {
                        event.preventDefault();
                        handleWellClick(idx);
                      }
                    }}
                    role="button"
                    tabIndex={0}
                    aria-pressed={!!hasContent}
                    aria-label={`孔位 ${String.fromCharCode(65 + r)}${c + 1}，${slot.isControl ? CONTROL_LABELS[slot.controlType!] : slot.specimenId ? `已分配样例 ${slot.specimenId}` : "空孔位"}`}
                    title={
                      slot.isControl
                        ? CONTROL_LABELS[slot.controlType!]
                        : slot.sampleNo
                        ? slot.sampleNo
                        : "空孔位"
                    }
                    className="w-full h-full flex items-center justify-center cursor-pointer"
                  >
                    {/* 条码单行完整显示（列宽已按内容自适应，不截断） */}
                    <span className="max-w-full text-center px-0.5">
                      {slot.isControl
                        ? slot.controlType?.charAt(0)
                        : slot.sampleNo || ""}
                    </span>
                  </div>
                  {hasContent && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setWells(prev => prev.map((w, wi) => wi === idx ? { ...w, specimenId: null, sampleNo: null, patient: null, sampleId: null, isControl: false, controlType: null, barcode: 1 } : w));
                      }}
                      className="absolute -top-0.5 -right-0.5 text-red-500 hover:text-red-600 cursor-pointer"
                      title="移除此孔位内容"
                    >
                      <X size={16} strokeWidth={2.5} />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        ))}
        </div>
        </>
        ))()}

        {/* 图例 */}
        <div className="flex gap-4 mt-2 text-[11px] text-muted-foreground">
          <div className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-blue-50 border border-blue-300 inline-block" />样本</div>
          <div className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-orange-300 inline-block" />阳性对照</div>
          <div className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-purple-300 inline-block" />阴性对照</div>
          <div className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-slate-200 border border-slate-300 inline-block" />空白对照</div>
          <div className="flex items-center gap-1"><span className="w-3 h-3 rounded border-2 border-dashed border-border inline-block" />空</div>
        </div>

        {/* ── 下板：Barcode 录入（同一 wells/usedColumns 镜像，列宽与上板一致逐格对齐）── */}
        <div className="mt-4 pt-3 border-t border-border">
          <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-2 mb-3">
            {/* 左占位，保持标题与上板一样居中 */}
            <span />
            <div className="flex items-center gap-2 justify-self-center">
              <span className="text-sm font-semibold text-foreground">{deviceType} Barcode 分配</span>
              <span className="text-xs text-muted-foreground">
                已设置 {wells.filter((w) => w.specimenId && w.barcode >= 1 && w.barcode <= 1000).length} / {wells.filter((w) => w.specimenId).length} 个样本孔
              </span>
            </div>
            <button
              onClick={resetAllBarcodes}
              className="justify-self-end text-[11px] px-2 py-1 rounded border border-border text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer"
              title="所有样本孔 Barcode 重置为 1"
            >
              全部设为 1
            </button>
          </div>
          <div className="border border-border rounded-lg overflow-hidden w-fit p-0.5 bg-card mx-auto">
            {/* 列号：只读展示（不可点击切换使用列，避免清空孔位导致上下板失配） */}
            <div className="grid gap-0.5 mb-0.5" style={{ gridTemplateColumns: colsTemplate }}>
              <div />
              {Array.from({ length: cfg.plateCols }, (_, c) => (
                <div key={c} className={`text-center text-[10px] font-mono ${usedColumns.includes(c) ? "text-foreground font-semibold" : "text-muted-foreground/40"}`}>
                  {c + 1}
                </div>
              ))}
            </div>
            {/* 行 */}
            {Array.from({ length: cfg.plateRows }, (_, r) => (
              <div key={r} className="grid gap-0.5 mb-0.5" style={{ gridTemplateColumns: colsTemplate }}>
                <div className={`text-center text-[10px] font-mono flex items-center justify-center ${r >= cfg.rows ? "text-muted-foreground/40" : "text-muted-foreground"}`}>
                  {String.fromCharCode(65 + r)}
                </div>
                {Array.from({ length: cfg.plateCols }, (_, c) => {
                  // 未启用的列：灰显
                  if (r >= cfg.rows || !usedColumns.includes(c)) {
                    return <div key={c} className="w-full h-9 rounded border border-dashed border-border/30 bg-muted/20" />;
                  }
                  const idx = r * cfg.cols + usedColumns.indexOf(c);
                  const slot = wells[idx];
                  if (!slot) return <div key={c} />;
                  const pos = `${String.fromCharCode(65 + r)}${c + 1}`;
                  // 质控孔：仅展示，无 Barcode
                  if (slot.isControl) {
                    return (
                      <div
                        key={c}
                        title={CONTROL_LABELS[slot.controlType!]}
                        className={`w-full h-9 rounded flex items-center justify-center font-mono text-[9px] border ${
                          slot.controlType === "Positive"
                            ? "bg-orange-300 border-orange-400 text-orange-900"
                            : slot.controlType === "Negative"
                            ? "bg-purple-300 border-purple-400 text-purple-900"
                            : "bg-slate-200 border-slate-300 text-slate-700"
                        }`}
                      >
                        {slot.controlType?.charAt(0)}
                      </div>
                    );
                  }
                  // 空孔：灰显
                  if (!slot.specimenId) {
                    return <div key={c} className="w-full h-9 rounded border border-border/70" />;
                  }
                  // 样本孔：数字输入框（默认 1，1-1000 正整数，blur 校验非法归 1）
                  const draft = barcodeDrafts[idx];
                  const text = draft ?? String(slot.barcode);
                  const invalid = draft !== undefined && isInvalidBarcode(draft);
                  return (
                    <div key={c} className="w-full h-9 rounded bg-blue-50 border border-blue-300 flex items-center justify-center">
                      <input
                        type="text"
                        inputMode="numeric"
                        maxLength={4}
                        value={text}
                        onChange={(e) => handleBarcodeChange(idx, e.target.value)}
                        onBlur={() => handleBarcodeBlur(idx)}
                        title={slot.sampleNo ?? slot.specimenId}
                        aria-label={`孔位 ${pos} Barcode`}
                        className={`w-[80%] h-6 rounded text-center font-mono text-[11px] bg-card border focus:outline-none focus:ring-1 focus:ring-primary ${
                          invalid ? "border-red-400" : "border-blue-300"
                        }`}
                      />
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
          {/* 图例 */}
          <div className="flex gap-4 mt-1 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-blue-50 border border-blue-300 inline-block" />样本（输入 Barcode）</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-orange-300 border border-orange-400 inline-block" />质控（无 Barcode）</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-muted border border-dashed border-border inline-block" />空孔</span>
          </div>
        </div>
      </div>

      {/* 右：样本池 */}
      <div className="w-56 border-l border-border flex flex-col">
        <div className="px-3 py-3 border-b border-border bg-muted/20">
          <p className="text-xs font-semibold text-muted-foreground mb-2">对照样本</p>
          <div className="grid grid-cols-3 gap-1.5 mb-3">
            {(["Positive", "Negative", "Blank"] as ControlType[]).map((ct) => (
              <button
                key={ct}
                onClick={() => !isFull && handleControlClick(ct)}
                disabled={isFull}
                className={`px-1 py-1.5 rounded text-[10px] font-medium border text-center transition-all cursor-pointer ${
                  isFull
                    ? "opacity-40 cursor-not-allowed border-border bg-card text-muted-foreground"
                    : CONTROL_COLORS[ct] + " border-transparent"
                }`}
              >
                {CONTROL_LABELS[ct]}
              </button>
            ))}
          </div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold text-muted-foreground">可用样本</p>
            {/* 非 NIFTY：已入库 / 待录入 视图筛选 */}
            {mode !== "nifty" && (
              <Select value={viewFilter} onValueChange={(v) => setViewFilter(v as "registered" | "pending")}>
                <SelectTrigger className="w-20 h-6 text-[11px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="registered">已入库</SelectItem>
                  <SelectItem value="pending">待录入</SelectItem>
                </SelectContent>
              </Select>
            )}
          </div>
          <input
            className="w-full border border-border rounded px-2 py-1 text-xs bg-card focus:outline-none focus:ring-1 focus:ring-primary"
            placeholder="搜索..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex-1 overflow-y-auto">
          {isFull && (
            <div className="p-3 text-center text-xs text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/30">
              孔板已满
            </div>
          )}

          {/* 待录入视图：批次概要（仅查看，不可排） */}
          {viewFilter === "pending" && pendingBatches.length > 0 && (
            <div className="px-3 py-2 border-b border-border bg-amber-50/60">
              <p className="text-[10px] text-amber-700 flex items-center gap-1 mb-1.5">
                <AlertTriangle size={10} />已收样登记，样本尚未录入样本中心
              </p>
              {pendingBatches.map((b) => (
                <div key={b.batchId} className="text-[11px] text-muted-foreground py-1 border-b border-border/40 last:border-0">
                  <span className="font-mono text-foreground">{b.batchNo}</span>
                  <span className="ml-1.5">{b.hospital} · {b.tubeCount} 管</span>
                </div>
              ))}
            </div>
          )}

          {availableSpecimens.length === 0 && !isFull && (
            <div className="p-4 text-center text-xs text-muted-foreground italic">
              {viewFilter === "pending" ? "暂无待录入样本" : "暂无可用样本"}
            </div>
          )}
          {availableSpecimens.map((sp) => (
            <button
              key={sp.id}
              onClick={() => !isFull && handleSpecimenClick(sp)}
              disabled={isFull}
              className={`w-full text-left px-3 py-2.5 border-b border-border/50 transition-colors cursor-pointer ${
                isFull
                  ? "opacity-40 cursor-not-allowed"
                  : "hover:bg-blue-50 dark:hover:bg-blue-900/20"
              }`}
            >
              {/* NIFTY 显示样例编号（同一样本多个样例独立展示）；非 NIFTY 显示样本编号 */}
              <p className="text-[11px] font-mono text-primary">{mode === "nifty" ? sp.id : (sp.sampleNo || sp.id)}</p>
              {!sp.patient && <p className="text-[10px] text-muted-foreground/60 italic">待补全</p>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Step 3: Summary Confirmation ────────────────────────────────────────────────

