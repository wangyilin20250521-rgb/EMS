import { WELL_PLATE_CONFIG, type SIRODeviceType } from "@/app/lib/api";

export type ControlType = "Positive" | "Negative" | "Blank";

export interface WellSlot {
  index: number;
  specimenId: string | null;
  sampleNo: string | null;
  patient: string | null;
  sampleId: string | null;
  isControl: boolean;
  controlType: ControlType | null;
  /** 每孔 Barcode（1-1000 正整数，默认 1；质控孔无意义，保持 1） */
  barcode: number;
}

export const CONTROL_LABELS: Record<ControlType, string> = {
  Positive: "阳性对照",
  Negative: "阴性对照",
  Blank: "空白对照",
};
export const CONTROL_COLORS: Record<ControlType, string> = {
  Positive: "bg-orange-400 text-white",
  Negative: "bg-purple-400 text-white",
  Blank: "bg-slate-300 text-slate-700",
};

// ─── Build Empty Plate ─────────────────────────────────────────────────────────

export function buildEmptyPlate(deviceType: SIRODeviceType): WellSlot[] {
  const { total } = WELL_PLATE_CONFIG[deviceType];
  return Array.from({ length: total }, (_, i) => ({
    index: i,
    specimenId: null,
    sampleNo: null,
    patient: null,
    sampleId: null,
    isControl: false,
    controlType: null,
    barcode: 1,
  }));
}

export interface ProcessItem {
  process_no: string
  process_name?: string
  process_info?: Record<string, any>
  [key: string]: any
}

// ─── Step 1: Select Project + Device Type + Workflow（项目 chips 内嵌 NIFTY 区分） ───
