/**
 * 解决方案页纯函数层——「方案咨询」子 agent 的欢迎语、发送上下文拼装、会话 ID 派生。
 * 与文档归档 document-model 同模式：无状态无副作用，页面与编排 hook 共用。
 *
 * 边界（只读子 agent）：只回答本页方案（配置与"与通用基线的差异"）相关问题，
 * 业务操作类问题（排单/样本/设备等）由 AI 拒答并引导去「AI 助手」；
 * 差异上下文（方案 vs 通用基线 default）由 agent-server 每轮注入，前端不重复拼装。
 */

export interface SolutionChatMessage {
  id?: string
  role: "user" | "ai"
  text: string
  /**过程项（thinking/工具/来源行），与 stream-turn 引擎 TurnProcessItem 结构兼容 */
  process?: Array<{ id: string; type: "thinking" | "tool"; text: string }>
  streaming?: boolean
}

/**通用基线方案 id（与后端 profile-context BASE_PROFILE_ID 同源约定） */
export const BASE_PROFILE_ID = "default"

/** *方案咨询会话 ID：`solution-<方案id>`。
 * `solution-` 前缀由后端 session-mode 识别为 solution 模式（只读子 agent + 差异上下文注入 + 审计隔离落盘）；
 * 前缀后须为方案目录 id 原文——后端据此提取方案并比对 data/profiles/<id> 与 default。 */
export function buildSolutionSessionId(profileId: string): string {
  return `solution-${profileId}`
}

/**悬浮按钮文案（通用基线自身即"通用方案"，没有"与通用方案的差异"可比） */
export function diffButtonLabel(profileId: string): string {
  return profileId === BASE_PROFILE_ID ? "解释该方案的出厂配置" : "解释该方案与通用方案的差异"
}

/**悬浮按钮一键发送的问题（展示层与发送文本同源） */
export function diffQuestion(profileId: string): string {
  return profileId === BASE_PROFILE_ID
    ? "请解释这个方案的出厂配置分别是什么含义"
    : "请解释这个方案与通用方案的差异"
}

// ─── 固定提示词（WorkBuddy 式，悬浮输入框上方）───────────────────────────────

/**方案咨询固定提示词：label = 胶囊短文案，prompt = 实际发送问题；首条为动态差异问题
 * （即原「解释该方案…」按钮文案，收敛进提示词栏避免双入口） */
export function solutionPromptChips(profileId: string): Array<{ label: string; prompt: string }> {
  return [
    { label: diffButtonLabel(profileId), prompt: diffQuestion(profileId) },
    { label: "接口配置怎么设置", prompt: "这个方案的接口配置（HIS / OmicsOne / 测序）分别应该如何设置？" },
    { label: "切换影响哪些数据", prompt: "切换到这个方案后，哪些配置和数据会变化？切换前后需要注意什么？" },
    { label: "上线前准备事项", prompt: "新医院上线时，基于这个方案需要先确认或准备哪些事项？" },
  ]
}

/** *AI 助手（主 agent）「解决方案」入口卡的一键问句——
 * 主 agent 没有"当前浏览方案"上下文（那由 solution 子 agent 的会话 id 携带），
 * 故问句自带方案名与 id，并直接指明比对口径（sha256 判一致、差异细节读原文）。 */
export function mainAgentDiffPrompt(profile: { id: string; label: string }): string {
  return profile.id === BASE_PROFILE_ID
    ? `请解释通用方案 default（${profile.label}）的出厂配置构成：各规则文件的用途、基础配置与接口出厂初值，以及它作为所有项目方案派生基线的含义。`
    : `请对比解决方案「${profile.label}」（id: ${profile.id}）与通用方案 default 的出厂模板差异：基础配置/接口配置/初始账户/字典覆盖/初始设备逐项对照，规则文件是否一致按 rules 的 sha256 判定（不一致的读原文说明差异点），最后用表格给出结论并说明这些差异的影响。`
}

/**欢迎语（打开方案后的首条 AI 消息，说明能力边界与提问示例） */
export function makeSolutionWelcomeMessage(profileLabel: string, profileId: string): SolutionChatMessage {
  const isBase = profileId === BASE_PROFILE_ID
  const body = isBase
    ? `当前浏览的是通用基线「${profileLabel}」——它是所有项目方案的派生源头，本身没有「与通用方案的差异」。你可以问我这个方案的出厂配置含义与规则构成，也可以指定它与其它方案对照。`
    : `当前浏览方案「${profileLabel}」。默认与通用方案对照：基础配置/接口/账户/字典/设备逐项差异 + 规则文件内容差异；也可以指定它与其它任一方案对照（说出方案名称即可）。`
  return {
    role: "ai",
    text: `你好！我是本页的「方案咨询」助手，只解答解决方案相关问题（只读，不会修改任何配置）。\n\n${body}\n\n差异按出厂模板层比对；排单、样本、设备等业务操作请到「AI 助手」提问。`,
  }
}

/** *发送消息的上下文拼装（当前方案 + 回答要求 + 用户问题）——
 * 展示层仍显示用户原文，仅发送给后端的文本带上下文（方案差异上下文由服务端每轮注入）。 */
export function buildSolutionPrompt(profileLabel: string, profileId: string, text: string): string {
  return [
    `【当前方案】${profileLabel}（id: ${profileId}）`,
    ``,
    `回答要求: 只输出最终回答（结论先行，差异用表格逐项对照）；基于系统注入的方案差异上下文作答，涉及规则文件具体内容先读取原文；读不到就明说，不要编造。`,
    ``,
    `用户问题: ${text}`,
  ].join("\n")
}
