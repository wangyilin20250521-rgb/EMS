import { useEffect, useRef, useState } from "react"
import { ChevronDown, ChevronUp, MessageCircleQuestion } from "lucide-react"
import ReactMarkdown from "react-markdown"
import remarkGfm from "remark-gfm"

import { StreamingIndicator } from "@/app/components/shared/StreamingIndicator"
import { AIThinkingTrace } from "@/app/components/shared/AIThinkingTrace"
import { ChatComposer } from "@/app/components/shared/ChatComposer"
import { ChatPromptChips } from "@/app/components/shared/ChatPromptChips"
import { solutionPromptChips, type SolutionChatMessage } from "./solution-model"
import type { SolutionTarget } from "./useSolutionsChat"
import { isDelegationSeedId } from "@/app/hooks/useDelegationSeeds"

/**
 * 方案咨询面板（解决方案页底部）——消息区（展开后占满方案卡以下的全部空间，回答自卡片底部起排布；
 * 收起时只留输入条）。首次咨询：占位文字即默认问题，空输入 Enter/点发送直接发出；
 * 首次回答结束在其下方给推荐追问（Doubao 式，文档归档同款）。
 * 只读子 agent：只渲染正文与思考/工具轨迹，不渲染决策卡/提问卡/表单卡。
 */
export function SolutionsChatPanel({
  profile,
  messages,
  input,
  onInputChange,
  streaming,
  expanded,
  onToggleExpanded,
  onSend,
  onStop,
}: {
  profile: SolutionTarget | null
  messages: SolutionChatMessage[]
  input: string
  onInputChange: (value: string) => void
  streaming: boolean
  expanded: boolean
  onToggleExpanded: () => void
  onSend: (raw?: string) => void
  onStop: () => void
}) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const endRef = useRef<HTMLDivElement>(null)
  const [pinned, setPinned] = useState(true)

  // 首次咨询（会话内还没有任何用户提问，刷新内存即重置）与首次回答后的推荐追问
  const promptPool = profile ? solutionPromptChips(profile.id) : []
  const defaultQuestion = promptPool[0]?.prompt
  const followUpPrompts = promptPool.slice(1)
  const isFirstConsult = !messages.some(m => m.role === "user")
  const lastMsg = messages[messages.length - 1]
  const showFollowUps = !!profile && !streaming && expanded
    && messages.filter(m => m.role === "user").length === 1
    && lastMsg?.role === "ai" && !lastMsg.streaming

  // 贴底跟随 + 上滚暂停（与文档归档/策略管理同款交互）
  useEffect(() => {
    if (pinned) endRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages, pinned, expanded])

  const handleScroll = () => {
    const el = scrollRef.current
    if (!el) return
    setPinned(el.scrollHeight - el.scrollTop - el.clientHeight < 100)
  }

  /**已有提问的会话在收起后保留标题条（可再次展开）；未开始咨询时只显示输入条 */
  const asked = messages.some(m => m.role === "user")

  return (
    // 展开态：面板占满方案卡以下的空间（消息区随之上移，回答直接接在卡片底部）；收起态：只占底部一条。
    // 无底色差（与文档归档一致）：整个区域与页面背景同色，只有输入框自身是卡片
    <div className={expanded ? "flex-1 min-h-[180px] flex flex-col" : "shrink-0"}>
      {(expanded || asked) && (
        <div className={`border-b border-border/60 ${expanded ? "flex-1 min-h-0 flex flex-col" : ""}`}>
          <div className="px-4 py-1.5 flex items-center gap-2">
            <MessageCircleQuestion size={13} className="text-primary shrink-0" />
            <span className="text-[12px] font-medium text-muted-foreground shrink-0">方案咨询</span>
            <span className="hidden lg:inline text-[11px] text-muted-foreground/70 truncate">
              只读：只解答本页方案相关问题，业务操作请到「AI 助手」
            </span>
            <button
              onClick={onToggleExpanded}
              title={expanded ? "收起消息区" : "展开消息区"}
              className="ml-auto shrink-0 inline-flex items-center gap-1 px-1.5 py-1 rounded-md text-[12px] text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
            >
              {expanded ? <ChevronDown size={14} /> : <ChevronUp size={14} />}
            </button>
          </div>

          {expanded && (
            <div ref={scrollRef} onScroll={handleScroll} className="flex-1 min-h-0 overflow-y-auto px-4 pb-3 pt-1 space-y-5">
              {messages.map((m, i) => (
              // AI Native 平文形态（与文档归档一致）：AI 回复无卡片直接打字 + 浅色思考/工具轨迹行；
              // 用户消息右侧白底卡片
              <div key={m.id ?? i} className={`flex flex-col gap-1.5 ${m.role === "user" ? "items-end" : "items-start"}`}>
                {m.role === "user" ? (
                  <div className="flex flex-col items-end gap-1 max-w-[92%]">
                    {isDelegationSeedId(m.id) && (
                      <span className="text-[12px] text-muted-foreground">EMS 助手代问（委派记录）</span>
                    )}
                    <div className="px-3 py-2 rounded-2xl text-[14px] leading-relaxed bg-card border border-border text-foreground rounded-br-sm">
                      <p className="whitespace-pre-wrap">{m.text}</p>
                    </div>
                  </div>
                ) : (
                  <>
                    {(m.process?.length ?? 0) > 0 && (
                      <AIThinkingTrace items={m.process!} streaming={!!m.streaming} />
                    )}
                    <div className="w-full max-w-3xl text-[14px] leading-[1.9] space-y-3 text-foreground [&_li]:my-1">
                      {m.streaming ? (
                        // 流式期间轻量纯文本渲染（避免 ReactMarkdown 每次 delta 全量解析卡顿）；结束后一次性 markdown
                        <p className="whitespace-pre-wrap text-[14px] leading-[1.9]">{m.text}</p>
                      ) : (
                        <div className="space-y-3 [&_li]:my-1">
                          <ReactMarkdown
                            remarkPlugins={[remarkGfm]}
                            components={{
                              a: ({ children, ...props }) => <a {...props} target="_blank" rel="noreferrer" className="text-primary underline underline-offset-2" />,
                              code: ({ className, children, ...props }) => <code {...props} className={`${className ?? ""} rounded bg-muted px-1 py-0.5 font-mono text-[0.8125em]`} />,
                              table: ({ children }) => <div className="my-2 overflow-x-auto"><table className="w-full border-collapse text-left text-[14px]">{children}</table></div>,
                              th: ({ children }) => <th className="border border-border bg-muted px-2 py-1 font-semibold">{children}</th>,
                              td: ({ children }) => <td className="border border-border px-2 py-1">{children}</td>,
                            }}
                          >
                            {m.text}
                          </ReactMarkdown>
                        </div>
                      )}
                      {m.streaming && <StreamingIndicator text={m.text} process={m.process} />}
                    </div>
                  </>
                )}
              </div>
            ))}
              {/* 首次回答结束 → 结论下方给推荐追问（Doubao 式）。
               * 置于 endRef（自动滚动锚点）之前，保证出现时完整落在视口内 */}
              {showFollowUps && (
                <div className="pt-1">
                  <ChatPromptChips prompts={followUpPrompts} onPick={onSend} disabled={streaming} />
                </div>
              )}
              <div ref={endRef} />
            </div>
          )}
        </div>
      )}

      {/* Composer：自动增高，Enter 发送 / Shift+Enter 换行；首次咨询时占位文字即默认问题 */}
      <div className="px-4 pt-2.5 pb-3 shrink-0">
        <ChatComposer
          value={input}
          onChange={onInputChange}
          onSend={onSend}
          onStop={onStop}
          streaming={streaming}
          disabled={!profile}
          placeholder={!profile
            ? "暂无可用方案"
            : streaming
              ? "AI 正在回复..."
              : isFirstConsult && defaultQuestion
                ? defaultQuestion
                : `咨询「${profile?.label ?? ""}」的配置问题，例如：接口地址和通用方案有什么不同？`}
          phantomQuestion={profile && isFirstConsult ? defaultQuestion : undefined}
        />
      </div>
    </div>
  )
}
