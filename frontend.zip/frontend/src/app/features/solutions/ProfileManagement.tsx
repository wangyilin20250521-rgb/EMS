import { useCallback, useEffect, useState } from "react";
import {
  Building2, FileText, FlaskConical, Layers, Plug, RefreshCw, Save, Settings,
} from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { PanelSidebar } from "@/app/components/shared/PanelSidebar";
import { panelCardCls, panelIconCls } from "@/app/components/shared/panel-styles";
import { MarqueeText, CardTag } from "@/app/components/shared/MarqueeText";
import { Toggle } from "@/app/features/system-management/shared";
import { apiGet, apiPost, apiPut } from "@/app/lib/api";
import { toast } from "sonner";
import { SolutionsChatPanel } from "./SolutionsChatPanel";
import { useSolutionsChat } from "./useSolutionsChat";

/**
 * 解决方案（2026-09-18 三次收窄 + 底部 AI 咨询）：
 * - 面向部署交付：左侧方案列表，右侧 方案状态（名称/描述/一致性 + 一键切换）
 *   与两项"现场需要调整"的配置卡——基础配置（医院/科室/系统标题）、
 *   接口配置（HIS/OmicsOne/测序的启用与地址，现场一时定不下来）。
 * - 其余方案内容（策略规则 / 数据字典差异 / 初始设备 / 初始账户）属开发者已知项，
 *   随方案文件（data/profiles/<id>/profile.json + rules/）出厂配置，页面不再提供。
 * - 卡片抽屉编辑的是方案出厂模板，不影响当前运行系统；切换/重启后端后应用生效。
 * - 底部「方案咨询」：solution 模式只读子 agent（只比对方案 vs 通用基线的模板层差异），
 *   面板挂在页面层（不在方案详情 key 内），切换方案时各方案的对话线程互不干扰。
 */

interface RuntimeComparison { matches: boolean; runtimeOnly: string[]; profileOnly: string[]; differing: string[] }
interface ProfileSummary {
  id: string; label: string; description: string
  /**实验执行模式（siro|manual|hybrid，缺省 siro） */
  executionMode?: "siro" | "manual" | "hybrid"
  accounts: Array<{ username: string; displayName: string }>
  rulesFiles: number; runtime: RuntimeComparison
}
interface ProfilesPayload {
  selected: string
  applied: { id: string; hash: string; appliedAt: string; label?: string } | null
  profiles: ProfileSummary[]
}
interface Iface { enabled: boolean; ip: string; port: string }
interface DictItem { code: string; name: string; sort?: number; status?: string }
interface DeviceRow {
  id: string; device_type: string; name: string; model?: string; sn?: string; ip?: string
  port?: string; endpoint?: string; status?: string; location?: string; notes?: string
}
interface ProfileDetail {
  id: string; label: string; description: string
  /**实验执行模式（siro|manual|hybrid，缺省 siro） */
  executionMode?: "siro" | "manual" | "hybrid"
  /**下列段页面不展示，仅随接口配置保存原样回传（后端 PUT 为整份覆盖，防止误清空出厂模板） */
  accounts: Array<{ username: string; displayName: string; role?: string }>
  dictOverrides: Record<string, DictItem[]>
  devices: DeviceRow[]
  /**接口出厂初值；后端在 manifest 缺段时以运行态 KV 兜底 */
  interfaces: { his: Iface; omics: Iface; sequencing: Iface }
  interfacesInManifest?: boolean
  hospitalConfig: { hospitalName: string; departmentName: string; systemTitle: string } | null
  runtime: RuntimeComparison
}

/**执行模式中文名 */
const EXECUTION_MODE_LABELS: Record<string, string> = {
  siro: "SIRO 模式", manual: "手工模式", hybrid: "混合模式",
}

/**方案卡副行标签（hybrid 出双标签）。 */
const EXECUTION_MODE_TAGS: Record<string, string[]> = {
  siro: ["SIRO模式"],
  manual: ["手工模式"],
  hybrid: ["SIRO模式", "功能岛模式"],
}
const modeTagsOf = (p: ProfileSummary): string[] => EXECUTION_MODE_TAGS[p.executionMode ?? "siro"] ?? EXECUTION_MODE_TAGS.siro

/**方案卡图标（按档案 id 固定映射） */
const PROFILE_ICONS: Record<string, React.ElementType> = {
  default: Settings,
  zz1y: Building2,
  zz3y: Building2,
  "bgi-wh51": FlaskConical,
};

export function ProfileManagement() {
  const [payload, setPayload] = useState<ProfilesPayload | null>(null);
  const [browseId, setBrowseId] = useState<string | null>(null);
  const [switching, setSwitching] = useState<string | null>(null);

  const load = useCallback(() => {
    apiGet<ProfilesPayload>('/system/profiles').then(setPayload).catch(() => setPayload(null));
  }, []);
  useEffect(() => { load(); }, [load]);

  const switchTo = async (id: string, label: string) => {
    setSwitching(id);
    try {
      await apiPost('/system/profiles/switch', { id });
      toast.success(`已切换到方案「${label}」——重启后端服务后生效`);
      load();
    } catch (err: any) {
      toast.error(err?.message || "切换失败");
    } finally {
      setSwitching(null);
    }
  };

  const { selected, applied, profiles } = payload ?? { selected: "", applied: null, profiles: [] as ProfileSummary[] };
  const browse = profiles.find(p => p.id === browseId) ?? profiles.find(p => p.id === selected) ?? profiles[0];
  // 方案咨询（只读子 agent）：线程按方案 id 分桶，面板置于详情 key 之外 → 切换方案不打断/不串话
  const chat = useSolutionsChat({ profile: browse ? { id: browse.id, label: browse.label } : null });

  if (!payload) {
    return (
      <div className="h-full flex items-center justify-center text-sm text-muted-foreground">
        方案信息加载失败——请确认后端服务可用并以管理员身份登录。
      </div>
    );
  }

  const appliedStale = !!applied && applied.id !== selected;

  return (
    <div className="h-full flex overflow-hidden">
      {/* 左侧方案列表：单行标题（跑马灯）+ 执行模式灰标签副行 */}
      <PanelSidebar icon={Layers} title="方案" count={`共 ${profiles.length} 个`}>
        {profiles.map(p => {
          const Icon = PROFILE_ICONS[p.id] ?? Building2;
          const isBrowsed = p.id === browse?.id;
          return (
            <button
              key={p.id}
              type="button"
              onClick={() => setBrowseId(p.id)}
              aria-pressed={isBrowsed}
              className={panelCardCls({ active: isBrowsed })}
            >
              <span className={panelIconCls(isBrowsed)}>
                <Icon size={15} />
              </span>
              <span className="min-w-0 flex-1">
                <MarqueeText
                  text={p.label}
                  className={`text-[14px] font-medium leading-snug ${isBrowsed ? "text-primary" : "text-foreground"}`}
                />
                <span className="flex flex-wrap gap-1 mt-1">
                  {modeTagsOf(p).map(t => <CardTag key={t}>{t}</CardTag>)}
                </span>
              </span>
            </button>
          );
        })}
      </PanelSidebar>

      {/* 右侧：方案状态 + 现场需调整的两项配置 + 底部方案咨询 */}
      <div className="flex-1 min-w-0 flex flex-col min-h-0">
        {/* 咨询展开时方案内容回落到自然高度（窗口不足则自身滚动收缩），把下方空间让给对话 */}
        <div className={`min-h-0 overflow-y-auto ${chat.expanded ? "shrink" : "flex-1"}`}>
          <div className="px-6 pb-6 pt-2">
            {browse
              ? <ProfileDetailView key={browse.id} id={browse.id} payload={payload} switchTo={switchTo} switching={switching} />
              : <div className="py-12 text-center text-sm text-muted-foreground">暂无可用方案。</div>}
          </div>
        </div>

        <SolutionsChatPanel
          profile={browse ? { id: browse.id, label: browse.label } : null}
          messages={chat.messages}
          input={chat.input}
          onInputChange={chat.setInput}
          streaming={chat.streaming}
          expanded={chat.expanded}
          onToggleExpanded={chat.toggleExpanded}
          onSend={chat.send}
          onStop={chat.stopStream}
        />
      </div>
    </div>
  );
}

//─── 方案详情（状态 + 基础配置 / 接口配置） ───────────────────────────────────

type DrawerKind = "basic" | "ifaces" | null;

function ProfileDetailView({ id, payload, switchTo, switching }: {
  id: string;
  payload: ProfilesPayload;
  switchTo: (id: string, label: string) => Promise<void>;
  switching: string | null;
}) {
  const [detail, setDetail] = useState<ProfileDetail | null>(null);
  const [loadFailed, setLoadFailed] = useState(false);
  const [drawer, setDrawer] = useState<DrawerKind>(null);
  const [saving, setSaving] = useState(false);

  const isApplied = payload.applied?.id === id;
  const isSelected = payload.selected === id;
  const appliedStale = !!payload.applied && payload.applied.id !== payload.selected;
  const appliedLabel = payload.profiles.find(p => p.id === payload.applied?.id)?.label ?? payload.applied?.label ?? payload.applied?.id;

  const loadDetail = useCallback(() => {
    apiGet<ProfileDetail>(`/system/profiles/${id}`).then(setDetail).catch(() => setLoadFailed(true));
  }, [id]);
  useEffect(() => { loadDetail(); }, [loadDetail]);

  if (loadFailed || (detail && detail.id !== id)) {
    return (
      <div className="py-12 text-center text-sm text-muted-foreground">方案详情加载失败。</div>
    );
  }
  if (!detail) {
    return (
      <div className="flex items-center justify-center py-16 text-muted-foreground text-sm gap-2">
        <RefreshCw size={15} className="animate-spin" />加载方案详情中...
      </div>
    );
  }

  const saveManifest = async (section: Partial<Pick<ProfileDetail, "interfaces">>, successMsg: string) => {
    setSaving(true);
    try {
      await apiPut(`/system/profiles/${id}`, {
        label: detail.label,
        description: detail.description,
        // 隐藏段原样回传：后端 PUT 为整份覆盖，缺段会被写空
        accounts: detail.accounts.map(a => ({ ...a, password: "" })),
        dictOverrides: detail.dictOverrides,
        devices: detail.devices,
        interfaces: section.interfaces ?? detail.interfaces ?? undefined,
      });
      toast.success(successMsg);
      loadDetail();
      return true;
    } catch (err: any) {
      toast.error(err?.message || "保存失败");
      return false;
    } finally {
      setSaving(false);
    }
  };

  const saveHospitalConfig = async (cfg: NonNullable<ProfileDetail["hospitalConfig"]>) => {
    setSaving(true);
    try {
      await apiPut(`/system/profiles/${id}/hospital-config`, cfg);
      toast.success("基础配置已保存到方案模板（不影响当前运行系统）");
      loadDetail();
      return true;
    } catch (err: any) {
      toast.error(err?.message || "保存失败");
      return false;
    } finally {
      setSaving(false);
    }
  };

  const rt = detail.runtime;
  const mismatchCount = rt ? rt.differing.length + rt.runtimeOnly.length + rt.profileOnly.length : 0;
  const ifaceEnabled = [detail.interfaces?.his, detail.interfaces?.omics, detail.interfaces?.sequencing].filter(i => i?.enabled).length;

  const FUNC_CARDS: Array<{ kind: Exclude<DrawerKind, null>; icon: React.ElementType; title: string; desc: string; meta: string }> = [
    { kind: "basic", icon: FileText, title: "基础配置", desc: "医院名称 / 科室 / 系统标题", meta: detail.hospitalConfig?.hospitalName || "—" },
    { kind: "ifaces", icon: Plug, title: "接口配置", desc: "HIS / OmicsOne / 测序的启用与地址", meta: `${ifaceEnabled} / 3 项启用` },
  ];

  return (
    <div className="space-y-4">
      {/* 已切换未重启时才提示 */}
      {appliedStale && (
        <p className="text-[12px] text-amber-600">
          已切换为「{payload.profiles.find(p => p.id === payload.selected)?.label ?? payload.selected}」，重启后端后生效；当前运行态仍为「{appliedLabel}」。
        </p>
      )}

      {/* 头部（对齐设备管理右侧头部：标题 + 徽标 + 操作） */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-base font-semibold text-foreground flex items-center gap-2 flex-wrap">
            {detail.label}
            <span className="px-1.5 py-px rounded bg-muted text-[11px] font-mono font-normal text-muted-foreground">{detail.id}</span>
            {detail.executionMode && detail.executionMode !== "siro" && (
              <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${detail.executionMode === "manual" ? "bg-violet-50 text-violet-700 dark:bg-violet-950/40 dark:text-violet-300" : "bg-sky-50 text-sky-700 dark:bg-sky-950/40 dark:text-sky-300"}`}>
                {EXECUTION_MODE_LABELS[detail.executionMode] ?? detail.executionMode}
              </span>
            )}
            {isApplied && rt?.matches && <span className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700">与运行态一致</span>}
            {isApplied && rt && !rt.matches && <span className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-700">与运行态有差异（{mismatchCount} 个文件）</span>}
          </h1>
        </div>
        <div className="shrink-0 flex items-center gap-2">
          {!isSelected && (
            <Button size="sm" variant="outline" disabled={switching !== null} onClick={() => void switchTo(id, detail.label)}>
              {switching === id ? "切换中..." : "切换为此方案"}
            </Button>
          )}
        </div>
      </div>

      {/* 配置卡（一个内容一个卡片，对齐设备卡） */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {FUNC_CARDS.map(c => (
          <Card key={c.title}
            className="p-4 border-2 border-border transition-all hover:shadow-md cursor-pointer hover:border-primary/30"
            onClick={() => setDrawer(c.kind)}>
            <div className="flex items-start gap-3">
              <span className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300 flex items-center justify-center shrink-0"><c.icon size={15} /></span>
              <div className="min-w-0 flex-1">
                <p className="text-[14px] font-medium text-foreground">{c.title}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">{c.desc}</p>
              </div>
            </div>
            <p className="mt-3 pt-3 border-t border-border/60 text-[12px] font-mono text-muted-foreground truncate">{c.meta}</p>
          </Card>
        ))}
      </div>

      {drawer === "basic" && (
        <BasicConfigDrawer detail={detail} saving={saving} onClose={() => setDrawer(null)} onSave={saveHospitalConfig} />
      )}
      {drawer === "ifaces" && (
        <InterfacesDrawer detail={detail} saving={saving} onClose={() => setDrawer(null)} onSave={s => saveManifest({ interfaces: s }, "接口配置已保存到方案模板（不影响当前运行系统）")} />
      )}
    </div>
  );
}

//─── 抽屉壳（右侧滑出，与用户与角色编辑抽屉同款） ──────────────────────────────

function DrawerShell({ title, subtitle, onClose, children, footer, wide }: {
  title: string; subtitle?: string; onClose: () => void;
  children: React.ReactNode; footer?: React.ReactNode; wide?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/40" onClick={onClose}>
      <div className={`bg-card ${wide ? "w-[560px]" : "w-[480px]"} max-w-[92vw] h-full shadow-2xl flex flex-col`} onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-border shrink-0">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-base font-semibold">{title}</h2>
              {subtitle && <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{subtitle}</p>}
            </div>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground cursor-pointer text-lg">×</button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-4">{children}</div>
        {footer && <div className="px-6 py-4 border-t border-border shrink-0">{footer}</div>}
      </div>
    </div>
  );
}

//─── 基础配置抽屉（可编辑：rules/hospital-config.json 出厂模板） ───────────────

function BasicConfigDrawer({ detail, saving, onClose, onSave }: {
  detail: ProfileDetail; saving: boolean; onClose: () => void;
  onSave: (cfg: NonNullable<ProfileDetail["hospitalConfig"]>) => Promise<boolean>;
}) {
  const [draft, setDraft] = useState(
    detail.hospitalConfig ?? { hospitalName: "", departmentName: "", systemTitle: "" }
  );

  const submit = async () => {
    for (const [k, label] of [["hospitalName", "医院名称"], ["departmentName", "科室名称"], ["systemTitle", "系统标题"]] as const) {
      if (!draft[k].trim()) { toast.error(`${label}不能为空`); return; }
      if (draft[k].trim().length > 50) { toast.error(`${label}不能超过 50 字`); return; }
    }
    if (await onSave({ hospitalName: draft.hospitalName.trim(), departmentName: draft.departmentName.trim(), systemTitle: draft.systemTitle.trim() })) onClose();
  };

  return (
    <DrawerShell title="基础配置（出厂模板）" subtitle="医院名称 / 科室 / 系统标题，写入方案 rules/hospital-config.json；应用（重启）后生效" onClose={onClose}
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={submit} className={saving ? "opacity-50 pointer-events-none" : ""}><Save size={12} />{saving ? "保存中..." : "保存"}</Button>
        </div>
      }>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          {([
            { key: "hospitalName", label: "医院名称" },
            { key: "departmentName", label: "科室名称" },
          ] as const).map(f => (
            <div key={f.key}>
              <label className="text-xs font-medium mb-1 block">{f.label}<span className="text-red-500 ml-0.5">*</span></label>
              <input value={draft[f.key]} onChange={e => setDraft(p => ({ ...p, [f.key]: e.target.value }))}
                className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
          ))}
        </div>
        <div>
          <label className="text-xs font-medium mb-1 block">系统标题<span className="text-red-500 ml-0.5">*</span></label>
          <input value={draft.systemTitle} onChange={e => setDraft(p => ({ ...p, systemTitle: e.target.value }))}
            className="w-full border border-border rounded-md px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
      </div>
    </DrawerShell>
  );
}

//─── 接口配置抽屉（可编辑：HIS / OmicsOne / 测序 出厂初值） ────────────────────

const IFACE_SECTIONS: Array<{ key: "his" | "omics" | "sequencing"; title: string; hint: string }> = [
  { key: "his", title: "医院 HIS 接口", hint: "扫码收样提交前调用该接口复核样本条码" },
  { key: "omics", title: "OmicsOne 接口", hint: "样本中心新建入库登记按日期范围批量获取医院侧样本" },
  { key: "sequencing", title: "测序系统对接", hint: "实验任务完成后手动投递实验结果到第三方测序系统" },
];

function InterfacesDrawer({ detail, saving, onClose, onSave }: {
  detail: ProfileDetail; saving: boolean; onClose: () => void;
  onSave: (interfaces: { his: Iface; omics: Iface; sequencing: Iface }) => Promise<boolean>;
}) {
  const [draft, setDraft] = useState(() => {
    const base = detail.interfaces ?? { his: { enabled: false, ip: "", port: "" }, omics: { enabled: false, ip: "", port: "" }, sequencing: { enabled: false, ip: "", port: "" } };
    return { his: { ...base.his }, omics: { ...base.omics }, sequencing: { ...base.sequencing } };
  });

  const setField = (key: "his" | "omics" | "sequencing", field: keyof Iface, value: string | boolean) => {
    setDraft(prev => ({ ...prev, [key]: { ...prev[key], [field]: value } }));
  };

  const submit = async () => {
    for (const s of IFACE_SECTIONS) {
      const cfg = draft[s.key];
      if (cfg.enabled && (!cfg.ip.trim() || !cfg.port.trim())) { toast.error(`启用${s.title}时 IP 与端口不能为空`); return; }
    }
    if (await onSave({
      his: { enabled: draft.his.enabled, ip: draft.his.ip.trim(), port: draft.his.port.trim() },
      omics: { enabled: draft.omics.enabled, ip: draft.omics.ip.trim(), port: draft.omics.port.trim() },
      sequencing: { enabled: draft.sequencing.enabled, ip: draft.sequencing.ip.trim(), port: draft.sequencing.port.trim() },
    })) onClose();
  };

  return (
    <DrawerShell title="接口配置（出厂初值）" subtitle="保存到方案模板；应用（重启）时写入运行态接口配置。存量方案首次保存会把当前运行态值固化进模板" onClose={onClose}
      footer={
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>取消</Button>
          <Button onClick={submit} className={saving ? "opacity-50 pointer-events-none" : ""}><Save size={12} />{saving ? "保存中..." : "保存"}</Button>
        </div>
      }>
      {IFACE_SECTIONS.map(s => (
        <div key={s.key} className="border border-border rounded-lg p-3.5 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold">{s.title}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">{s.hint}</p>
            </div>
            <Toggle enabled={draft[s.key].enabled} onChange={() => setField(s.key, "enabled", !draft[s.key].enabled)} />
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="text-[11px] text-muted-foreground block mb-1">IP 地址</label>
              <input value={draft[s.key].ip} onChange={e => setField(s.key, "ip", e.target.value)} placeholder="如 192.168.1.100"
                className="w-full border border-border rounded-md px-2 py-1.5 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <div>
              <label className="text-[11px] text-muted-foreground block mb-1">端口</label>
              <input value={draft[s.key].port} onChange={e => setField(s.key, "port", e.target.value)} placeholder="如 8080"
                className="w-full border border-border rounded-md px-2 py-1.5 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
          </div>
        </div>
      ))}
      <p className="text-[11px] text-muted-foreground leading-relaxed">方案未声明接口段时应用不会改动运行态接口配置；一旦保存过本抽屉，之后每次应用（重启）都会以模板值覆盖运行态。</p>
    </DrawerShell>
  );
}
