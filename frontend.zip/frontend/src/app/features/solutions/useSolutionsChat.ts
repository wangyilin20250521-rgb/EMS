/**
 * 方案咨询聊天编排（仿 useDocumentChat，方案为维度）——每方案独立内存会话（刷新清空）；
 * SSE 流经共享 stream-turn 引擎合入末条 streaming 消息。
 * solution 模式为只读子 agent：无写操作确认卡/提问卡/表单卡，故无提案/表单状态机。
 * 会话 ID 用 `solution-<方案id>`（非随机）：服务端据此注入"方案 vs 通用基线"差异上下文。
 */

import { useEffect, useRef, useState } from "react"
import { streamChat } from "@/app/lib/utils/sse"
import { buildStreamCallbacks } from "@/app/lib/chat/stream-turn"
import { useDelegationSeeds } from "@/app/hooks/useDelegationSeeds"
import {
  buildSolutionPrompt,
  buildSolutionSessionId,
  diffQuestion,
  makeSolutionWelcomeMessage,
  type SolutionChatMessage,
} from "./solution-model"

export interface SolutionTarget { id: string; label: string }

export function useSolutionsChat({ profile }: { profile: SolutionTarget | null }) {
  const [chats, setChats] = useState<Record<string, SolutionChatMessage[]>>({})
  const [input, setInput] = useState("")
  const [streaming, setStreaming] = useState(false)
  /**消息区展开态：首次提问/一键差异时展开，收起后只留输入条 */
  const [expanded, setExpanded] = useState(false)
  const abortRef = useRef<AbortController | null>(null)

  const profileId = profile?.id ?? null
  const profileLabel = profile?.label ?? null
  // EMS 助手代办问答（原汁原味）：以普通 user/ai 消息对合入，位置 = 欢迎语之后、本面板会话之前
  const { seeds, clearSeeds } = useDelegationSeeds("solution", profileId)
  const messages: SolutionChatMessage[] = profileId
    ? [...(chats[profileId]?.slice(0, 1) ?? []), ...seeds, ...(chats[profileId]?.slice(1) ?? [])]
    : []

  // 每方案首条欢迎语（切换到该方案且其会话未初始化时写入；函数式更新防重复）
  useEffect(() => {
    if (!profileId || !profileLabel) return
    setChats(prev => prev[profileId] ? prev : { ...prev, [profileId]: [makeSolutionWelcomeMessage(profileLabel, profileId)] })
  }, [profileId, profileLabel])

  /**将增量合入指定方案的末条 streaming AI 消息（rAF 引擎的 apply 语义=全量覆盖） */
  const patchLast = (id: string, patch: Partial<SolutionChatMessage>) => {
    setChats(prev => {
      const msgs = prev[id] ?? []
      const last = msgs[msgs.length - 1]
      if (last?.role === "ai" && last.streaming) {
        return { ...prev, [id]: [...msgs.slice(0, -1), { ...last, ...patch }] }
      }
      return prev
    })
  }

  const appendErrorText = (id: string, msg: string) => {
    setChats(prev => {
      const msgs = prev[id] ?? []
      const last = msgs[msgs.length - 1]
      if (last?.role === "ai" && last.streaming) {
        return { ...prev, [id]: [...msgs.slice(0, -1), { ...last, text: last.text + `\n❌ ${msg}`, streaming: false }] }
      }
      return prev
    })
  }

  const finishStreaming = (id: string) => {
    abortRef.current = null
    setStreaming(false)
    patchLast(id, { streaming: false })
  }

  /**发送一条咨询（raw 非空 = 悬浮按钮等外部触发的一键提问，保留用户输入草稿） */
  const send = (raw?: string) => {
    if (!profile || streaming) return
    const text = (raw ?? input).trim()
    if (!text) return
    const { id: pid, label } = profile

    setChats(prev => {
      const thread = prev[pid] ?? [makeSolutionWelcomeMessage(label, pid)]
      return {
        ...prev,
        [pid]: [
          ...thread,
          { role: "user", text },
          { id: `sol-send-${Date.now()}`, role: "ai", text: "", process: [], streaming: true },
        ],
      }
    })
    setExpanded(true)
    if (raw === undefined) setInput("")
    setStreaming(true)

    if (abortRef.current) abortRef.current.abort()
    abortRef.current = streamChat(
      buildSolutionPrompt(label, pid, text),
      buildStreamCallbacks({
        idPrefix: `sol-${Date.now()}`,
        apply: (patch) => patchLast(pid, { text: patch.text, process: patch.process }),
        trackCharts: false, // 方案页消息模型无 charts 字段
        onDone: () => finishStreaming(pid),
        onError: (msg) => {
          appendErrorText(pid, msg)
          abortRef.current = null
          setStreaming(false)
        },
      }),
      { solution: true, sessionId: buildSolutionSessionId(pid) },
    )
  }

  /**一键差异（悬浮按钮）：直接发送当前方案的标准差异问题 */
  const askDiff = () => {
    if (!profile) return
    send(diffQuestion(profile.id))
  }

  /**停止生成：abort + 清 streaming 标志（防末条消息 spinner 残留） */
  const stopStream = () => {
    if (abortRef.current) {
      abortRef.current.abort()
      abortRef.current = null
    }
    setStreaming(false)
    if (profileId) patchLast(profileId, { streaming: false })
  }

  /**清理当前方案的咨询记录（重置为欢迎语；代办问答种子一并收起，重进该方案时重新合入） */
  const clearChat = () => {
    if (!profile) return
    if (abortRef.current) {
      abortRef.current.abort()
      abortRef.current = null
      setStreaming(false)
    }
    clearSeeds()
    setChats(prev => ({ ...prev, [profile.id]: [makeSolutionWelcomeMessage(profile.label, profile.id)] }))
  }

  return {
    messages,
    input,
    setInput,
    streaming,
    expanded,
    toggleExpanded: () => setExpanded(v => !v),
    send,
    askDiff,
    stopStream,
    clearChat,
  }
}
