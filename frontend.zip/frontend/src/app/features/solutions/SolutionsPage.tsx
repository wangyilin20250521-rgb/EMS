import { ProfileManagement } from "./ProfileManagement";

/**
 * 解决方案（2026-09-18 自系统设置独立，与系统设置并列；2026-09-18 二次收窄为纯只读切换页）：
 * 面向部署交付：左侧方案列表，右侧只展示方案状态 + 一键切换；方案内容（账户/设备/
 * 字典/接口/基础配置/规则）由开发者直接维护 data/profiles/<id>/，页面不提供编辑入口。
 * 数据维护在系统设置（操作运行态数据库）；数据字典在系统设置（平台通用设计）。
 */

export function SolutionsPage() {
  return <ProfileManagement />;
}
