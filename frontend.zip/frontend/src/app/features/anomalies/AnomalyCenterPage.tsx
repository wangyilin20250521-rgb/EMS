import { useCallback, useState } from "react";
import {
  ArrowLeft,
  Bot,
  Camera,
  CheckCheck,
  CheckCircle2,
  Download,
} from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { TableCard, TableCardHeader, TableCardFooter } from "@/app/components/shared/table-card";
import { LevelBadge } from "@/app/components/shared/status-badges";

import { getAnomalies, submitAnomalyResolution, exportAnomalies } from "@/app/lib/api";
import type { Anomaly, ResolutionType } from "@/app/lib/api";
import { useAuth } from "@/app/hooks/useAuth";
import { usePagination } from "@/app/hooks/usePagination";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { triggerFileDownload } from "@/app/lib/utils/download";
import { toast } from "sonner";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";

// ─── Status Badge（T014） ────────────────────────────────────────────────────

const ANOMALY_STATUS_COLOR: Record<string, { bg: string; text: string; dot: string }> = {
  "待处理":    { bg: "bg-red-50 dark:bg-red-950/40",         text: "text-red-700 dark:text-red-300",         dot: "bg-red-500"     },
  "待补样":    { bg: "bg-red-50 dark:bg-red-950/40",         text: "text-red-700 dark:text-red-300",         dot: "bg-red-500"     },
  "待通知":    { bg: "bg-red-50 dark:bg-red-950/40",         text: "text-red-700 dark:text-red-300",         dot: "bg-red-500"     },
  "待重做":    { bg: "bg-red-50 dark:bg-red-950/40",         text: "text-red-700 dark:text-red-300",         dot: "bg-red-500"     },
  "处理中":    { bg: "bg-amber-50 dark:bg-amber-950/40",     text: "text-amber-700 dark:text-amber-300",     dot: "bg-amber-500"   },
  "人工确认中":{ bg: "bg-amber-50 dark:bg-amber-950/40",     text: "text-amber-700 dark:text-amber-300",     dot: "bg-amber-500"   },
  "已解决":    { bg: "bg-emerald-50 dark:bg-emerald-950/40", text: "text-emerald-700 dark:text-emerald-300", dot: "bg-emerald-500" },
  "完成":      { bg: "bg-emerald-50 dark:bg-emerald-950/40", text: "text-emerald-700 dark:text-emerald-300", dot: "bg-emerald-500" },
  "已忽略":    { bg: "bg-gray-100 dark:bg-slate-800",        text: "text-gray-600 dark:text-slate-300",      dot: "bg-gray-400"    },
};

function AnomalyStatusBadge({ status }: { status: string }) {
  const s = ANOMALY_STATUS_COLOR[status] ?? { bg: "bg-gray-100", text: "text-gray-600", dot: "bg-gray-400" };
  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${s.bg} ${s.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
      {status}
    </span>
  );
}

function SourceBadge({ source }: { source: string }) {
  if (source === "rule") return <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-blue-50 text-blue-700">规则引擎</span>;
  if (source === "ai")   return <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-purple-50 text-purple-700">AI识别</span>;
  return <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-gray-100 text-gray-600">人工登记</span>;
}

// ─── Handling Panel（T015–T018） ─────────────────────────────────────────────

function AnomalyHandlePanel({
  anomaly,
  onBack,
  onSolve,
}: {
  anomaly: Anomaly;
  onBack: () => void;
  onSolve: (id: string, newStatus: string) => void;
}) {
  const { user } = useAuth();

  const [resolutionType, setResolutionType] = useState<ResolutionType>("reuse_original");
  const [content, setContent] = useState("");
  const [contentError, setContentError] = useState("");
  const [submitError, setSubmitError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const RESOLUTION_OPTIONS: Array<{ value: ResolutionType; label: string; desc: string }> = [
    { value: "reuse_original", label: "使用原样本重新实验", desc: "使用当前原样本重新执行实验流程" },
    { value: "reuse_backup", label: "使用备份样例重新实验", desc: "使用备份样例重新执行实验流程" },
    { value: "manual_accept", label: "人工判定可接受", desc: "人工认定此异常可接受，需填写判定理由" },
    { value: "concession", label: "让步接收", desc: "异常轻微不影响结果，让步放行该样本继续实验，需填写理由" },
    { value: "custom", label: "自定义处理", desc: "填写具体处理方案后提交" },
  ];

  // T017: 校验 + 提交
  const handleSubmit = async () => {
    if (submitting) return; // 防重入：提交中忽略重复点击
    // 需要填写理由/方案的类型（样本与任务异常统一）：自定义处理 / 人工判定必填；让步接收不强制（想通过就通过）
    const needsContent = resolutionType === "custom" || resolutionType === "manual_accept";
    if (needsContent && !content.trim()) {
      setContentError(resolutionType === "manual_accept" ? "请填写判定理由" : "请填写处理方案");
      return;
    }
    setContentError("");
    setSubmitError("");
    setSubmitting(true);
    try {
      const res = await submitAnomalyResolution({
        anomalyId: anomaly.id,
        type: resolutionType,
        content: content.trim() || undefined,
        operator: user?.displayName || user?.username || "当前用户",
      });
      if (res.success) {
        // T018: 审计埋点 + 状态更新
        onSolve(anomaly.id, res.newAnomalyStatus);
        onBack();
      }
    } catch (error) {
      const status = typeof error === "object" && error !== null && "status" in error
        ? (error as { status?: number }).status
        : undefined;
      setSubmitError(
        status === 404
          ? "处理方案提交失败：后端尚未实现异常处置接口"
          : error instanceof Error
            ? error.message
            : "处理方案提交失败，请稍后重试",
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="p-6 overflow-y-auto h-full space-y-5">
      {/* 标题 */}
      <div className="flex flex-col md:flex-row md:items-center gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            title="返回上一页"
            className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer shrink-0"
          >
            <ArrowLeft size={16} />
          </button>
          <h1 className="text-xl font-semibold" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
            异常处理：{anomaly.id}
          </h1>
        </div>
        <div className="flex gap-2">
          <LevelBadge level={anomaly.level} />
          <AnomalyStatusBadge status={anomaly.status} />
          <SourceBadge source={anomaly.source} />
        </div>
      </div>

      {/* 基本信息 */}
      <Card className="p-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div><span className="text-muted-foreground">异常类型:</span><span className="font-medium ml-2">{anomaly.type}</span></div>
          <div><span className="text-muted-foreground">异常描述:</span><span className="font-medium ml-2">{anomaly.desc}</span></div>
          <div><span className="text-muted-foreground">关联对象:</span><span className="font-mono text-sm text-foreground ml-2">{anomaly.related}</span></div>
          <div><span className="text-muted-foreground">登记时间:</span><span className="font-medium ml-2">{anomaly.time}</span></div>
        </div>
      </Card>

      {/* 来源特定上下文 */}
      {anomaly.source === "rule" && (
        <Card className="p-5 border-blue-200 bg-blue-50/40">
          <div className="flex items-center gap-2 mb-3">
            <Bot size={14} className="text-blue-600" />
            <h3 className="text-sm font-semibold text-blue-800">触发规则 + AI建议</h3>
          </div>
          <div className="text-sm text-blue-800 space-y-1.5">
            <p><span className="font-medium">触发规则:</span> QC浓度 &lt; 20 ng/µL → 自动创建异常</p>
            <p><span className="font-medium">AI建议:</span> 使用备份样例重新执行文库构建步骤</p>
          </div>
        </Card>
      )}

      {anomaly.source === "ai" && (
        <Card className="p-5 border-purple-200 bg-purple-50/30">
          <div className="flex items-center gap-2 mb-3">
            <Bot size={14} className="text-purple-600" />
            <h3 className="text-sm font-semibold text-purple-800">AI 分析结果</h3>
            <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">置信度 62%</span>
          </div>
          <p className="text-sm text-purple-800 mb-3">AI分析：姓名栏存在歧义，无法高置信度识别</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="bg-purple-100/50 rounded p-2">
              <p className="text-muted-foreground mb-1">原始识别</p>
              <p className="font-medium">王 五 → 王五 / 王伍（歧义）</p>
            </div>
            <div className="bg-purple-100/50 rounded p-2">
              <p className="text-muted-foreground mb-1">医院记录</p>
              <p className="font-medium">HIS: 王五（匹配度 82%）</p>
            </div>
          </div>
        </Card>
      )}

      {anomaly.source === "manual" && (
        <Card className="p-5">
          <h3 className="text-sm font-semibold mb-3">照片 / 现场证明</h3>
          <div className="w-full h-28 bg-muted/40 rounded-lg border-2 border-dashed border-border flex items-center justify-center text-muted-foreground text-sm">
            <Camera size={16} className="mr-2" />点击查看现场照片
          </div>
          <p className="text-xs text-muted-foreground mt-2">{anomaly.desc}</p>
        </Card>
      )}

      {/* T015–T017: 统一处理方案区域 */}
      <Card className="p-5">
        <h3 className="text-sm font-semibold mb-4">处理方案</h3>

        <div className="space-y-2 mb-4" role="radiogroup" aria-label="选择异常处理方案">
          {RESOLUTION_OPTIONS.map((opt) => (
          <label
            key={opt.value}
            className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
              resolutionType === opt.value
                ? "border-primary bg-primary/5"
                : "border-border hover:bg-muted/30"
            }`}
          >
            <input
              type="radio"
              name={`resolution-${anomaly.id}`}
              value={opt.value}
              checked={resolutionType === opt.value}
              aria-describedby={`resolution-description-${anomaly.id}-${opt.value}`}
              onChange={() => {
                setResolutionType(opt.value);
                setContent("");
                setContentError("");
              }}
              className="mt-0.5 accent-primary shrink-0"
            />
            <div>
              <p className={`text-sm font-medium ${resolutionType === opt.value ? "text-primary" : "text-foreground"}`}>
                {opt.label}
              </p>
              <p id={`resolution-description-${anomaly.id}-${opt.value}`} className="text-xs text-muted-foreground mt-0.5">{opt.desc}</p>
            </div>
          </label>
          ))}
        </div>

        {(resolutionType === "custom" || resolutionType === "manual_accept" || resolutionType === "concession") && (
          <div className="mb-4">
            <label className="text-xs text-muted-foreground block mb-1">
              {resolutionType === "manual_accept" ? "人工判定理由" : resolutionType === "concession" ? "让步接收理由（选填）" : "处理方案"}
              {resolutionType !== "concession" && <span className="text-red-500 ml-0.5">*</span>}
            </label>
            <textarea
              className={`w-full border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring bg-card resize-none ${
                contentError ? "border-red-300 bg-red-50/30" : "border-border"
              }`}
              rows={3}
              placeholder={
                resolutionType === "manual_accept" ? "请填写人工判定理由..."
                : resolutionType === "concession" ? "可填写让步接收理由（不填也可直接提交）..."
                : "请填写处理方案..."
              }
              value={content}
              onChange={(e) => {
                setContent(e.target.value);
                if (e.target.value.trim()) setContentError("");
              }}
            />
            {contentError && <p className="mt-1 text-xs text-red-600">{contentError}</p>}
          </div>
        )}
        {submitError && <p className="mb-4 text-xs text-red-600">{submitError}</p>}

        {/* T017: 统一提交按钮 */}
        <div className="flex items-center gap-3">
          <Button
            variant="default"
            onClick={handleSubmit}
          >
            {submitting ? (
              <span className="inline-block w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <CheckCheck size={12} />
            )}
            {submitting ? "提交中..." : "提交"}
          </Button>
          <Button variant="ghost" onClick={onBack}>取消</Button>
        </div>
      </Card>
    </div>
  );
}

// ─── Main Page ───────────────────────────────────────────────────────────────

export function AnomalyCenterPage() {
  const [tab, setTab] = useState<"样本" | "实验任务">("样本");
  const [handling, setHandling] = useState<string | null>(null);
  const [resolvedMap, setResolvedMap] = useState<Record<string, string>>({});
  const [sampleFilter, setSampleFilter] = useState("未解决");
  const [taskFilter, setTaskFilter] = useState("未解决");
  const [exporting, setExporting] = useState(false);

  const handleExport = async () => {
    setExporting(true);
    try {
      const res = await exportAnomalies({ category: tab === '样本' ? 'sample' : 'task' });
      if (res.success) triggerFileDownload(res.downloadUrl, res.filename || `异常中心_${new Date().toISOString().slice(0, 10)}.xlsx`);
    } catch { toast.error('导出失败，请稍后重试'); } finally {
      setExporting(false);
    }
  };

  const fetchAnomalies = useCallback(async (params: { page?: number; pageSize?: number }) => {
    const result = await getAnomalies({ page: params.page, pageSize: params.pageSize });
    if (!result.ok) throw new Error(result.error.message);
    return result.data;
  }, []);

  const {
    items: anomalies,
    total,
    page,
    pageSize,
    setPage,
    setPageSize,
  } = usePagination<Anomaly>({
    fetcher: fetchAnomalies,
    initialPageSize: 20,
  });

  const sampleFilterOpts = ["未解决", "全部", "收样异常", "样本异常", "AI识别异常", "收样核对"];
  const taskFilterOpts   = ["未解决", "全部", "实验异常", "设备异常", "质控失败"];

  const isResolved = (anomaly: Anomaly) =>
    ["已解决", "完成", "已忽略"].includes(resolvedMap[anomaly.id] ?? anomaly.status);

  const sampleAnomalies = anomalies.filter((anomaly) => anomaly.category === "sample");
  const taskAnomalies = anomalies.filter((anomaly) => anomaly.category === "task");
  const pendingSample = sampleAnomalies.filter((anomaly) => !isResolved(anomaly)).length;
  const pendingTask = taskAnomalies.filter((anomaly) => !isResolved(anomaly)).length;

  const handleSolve = (id: string, newStatus: string) => {
    setResolvedMap((prev) => ({ ...prev, [id]: newStatus }));
  };

  if (handling) {
    const anomaly = anomalies.find((item) => item.id === handling);
    if (!anomaly) return null;
    return (
      <AnomalyHandlePanel
        anomaly={anomaly}
        onBack={() => setHandling(null)}
        onSolve={handleSolve}
      />
    );
  }

  const filteredSamples = sampleAnomalies
    .filter((anomaly) => sampleFilter === "全部" ? true : sampleFilter === "未解决" ? !isResolved(anomaly) : anomaly.type === sampleFilter)
    .sort((a, b) => b.time.localeCompare(a.time));
  const filteredTasks = taskAnomalies
    .filter((anomaly) => taskFilter === "全部" ? true : taskFilter === "未解决" ? !isResolved(anomaly) : anomaly.type === taskFilter)
    .sort((a, b) => b.time.localeCompare(a.time));

  return (
    <div className="px-6 pb-6 pt-2 h-full flex flex-col space-y-5">
      <div className="flex-1 flex flex-col min-h-0">
        <TableCard>
          <TableCardHeader>
            {/* 左：Tab 切换（pill 式）+ 当前 Tab 的状态筛选 chips */}
            <div className="flex items-center gap-3 min-w-0">
              {/* EMS 蓝边框切换器：白底蓝描边容器 + 选中项主色蓝填充 */}
              <div className="flex items-center gap-1 p-1 rounded-lg border border-primary/40 bg-card shrink-0">
                {([
                  { key: "样本" as const,     label: "异常样本",     count: pendingSample },
                  { key: "实验任务" as const,  label: "异常实验任务", count: pendingTask  },
                ]).map((t) => (
                  <button
                    key={t.key}
                    onClick={() => setTab(t.key)}
                    className={`flex items-center gap-1.5 px-3 py-1 text-sm rounded-md transition-colors font-medium cursor-pointer ${
                      tab === t.key
                        ? "bg-primary text-white shadow-sm"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {t.label}
                    {t.count > 0 && (
                      <span className="bg-red-500 text-white text-xs font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                        {t.count}
                      </span>
                    )}
                  </button>
                ))}
              </div>
              {/* 当前 Tab 的状态筛选：下拉框（简洁，替代原平铺 chips） */}
              <Select value={tab === "样本" ? sampleFilter : taskFilter} onValueChange={(v) => (tab === "样本" ? setSampleFilter(v) : setTaskFilter(v))}>
                <SelectTrigger size="sm" className="w-28 h-8 px-2.5 text-sm border border-border rounded-md bg-card shrink-0">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(tab === "样本" ? sampleFilterOpts : taskFilterOpts).map(f => (
                    <SelectItem key={f} value={f}>{f}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {/* 右：EMS 统计块（收样登记同款：数字 font-mono 突出）+ 导出 */}
            <div className="flex items-center gap-2.5 text-sm text-muted-foreground whitespace-nowrap shrink-0">
              <span>异常样本 <span className="font-semibold font-mono text-foreground">{pendingSample}</span></span>
              <span className="text-border">·</span>
              <span>实验任务 <span className="font-semibold font-mono text-foreground">{pendingTask}</span></span>
              <span className="text-border">·</span>
              <span>待处理 <span className="font-semibold font-mono text-primary">{pendingSample + pendingTask}</span></span>
              <Button variant="outline" size="sm" className={`ml-1 ${exporting ? "opacity-50 pointer-events-none" : ""}`} onClick={() => { if (!exporting) handleExport(); }}>{exporting ? "导出中..." : <><Download size={12} />导出数据</>}</Button>
            </div>
          </TableCardHeader>

          {/* 内容区：当前 Tab 的表格 */}
          <div className="flex-1 overflow-auto scrollbar-hide">
            {tab === "样本" ? (
                <Table className="w-full text-sm">
                  <TableHeader className="bg-muted/40 border-b border-border sticky top-0 z-10 backdrop-blur-sm">
                    <TableRow>
                      {["序号", "编号", "类型", "来源", "关联样本", "患者", "检测项目", "异常描述", "等级", "状态", "时间", "操作"].map((h) => (
                        <TableHead key={h} className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody className="divide-y divide-border">
                    {filteredSamples.map((a, idx) => {
                      const currentStatus = resolvedMap[a.id] ?? a.status;
                      const resolved = isResolved(a);
                      return (
                        <TableRow key={a.id} className={`hover:bg-muted/20 transition-colors ${resolved ? "opacity-50" : ""}`}>
                          <TableCell className="px-3 py-3 text-sm text-muted-foreground font-mono">{(page - 1) * pageSize + idx + 1}</TableCell>
                          <TableCell className="px-3 py-3">
                            <button type="button" title="查看异常详情" onClick={() => setHandling(a.id)} className="font-mono text-sm text-primary hover:underline cursor-pointer">{a.id}</button>
                          </TableCell>
                          <TableCell className="px-3 py-3 font-medium text-sm whitespace-nowrap">{a.type}</TableCell>
                          <TableCell className="px-3 py-3"><SourceBadge source={a.source ?? "manual"} /></TableCell>
                          <TableCell className="px-3 py-3 text-sm text-foreground whitespace-nowrap">{a.related}</TableCell>
                          <TableCell className="px-3 py-3 text-sm whitespace-nowrap">{a.patient}</TableCell>
                          <TableCell className="px-3 py-3 text-sm text-muted-foreground whitespace-nowrap">{a.project}</TableCell>
                          <TableCell className="px-3 py-3 text-muted-foreground text-sm min-w-[180px] max-w-[240px] truncate">{a.desc}</TableCell>
                          <TableCell className="px-3 py-3"><LevelBadge level={a.level} /></TableCell>
                          <TableCell className="px-3 py-3"><AnomalyStatusBadge status={currentStatus} /></TableCell>
                          <TableCell className="px-3 py-3 text-sm text-muted-foreground whitespace-nowrap">{a.time}</TableCell>
                          <TableCell className="px-3 py-3" onClick={e => e.stopPropagation()}>
                            {!resolved
                              ? <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70 px-1" onClick={() => setHandling(a.id)}>处理</Button>
                              : <span className="text-xs text-emerald-600 flex items-center gap-1"><CheckCircle2 size={11} />已解决</span>
                            }
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
                ) : (
                <Table className="w-full text-sm">
                  <TableHeader className="bg-muted/40 border-b border-border sticky top-0 z-10 backdrop-blur-sm">
                    <TableRow>
                      {["序号", "编号", "类型", "来源", "关联任务", "检测项目", "设备", "异常步骤", "异常描述", "等级", "状态", "时间", "操作"].map((h) => (
                        <TableHead key={h} className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody className="divide-y divide-border">
                    {filteredTasks.map((a, idx) => {
                      const currentStatus = resolvedMap[a.id] ?? a.status;
                      const resolved = isResolved(a);
                      return (
                        <TableRow key={a.id} className={`hover:bg-muted/20 transition-colors ${resolved ? "opacity-50" : ""}`}>
                          <TableCell className="px-3 py-3 text-sm text-muted-foreground font-mono">{(page - 1) * pageSize + idx + 1}</TableCell>
                          <TableCell className="px-3 py-3">
                            <button type="button" title="查看异常详情" onClick={() => setHandling(a.id)} className="font-mono text-sm text-primary hover:underline cursor-pointer">{a.id}</button>
                          </TableCell>
                          <TableCell className="px-3 py-3 font-medium text-sm whitespace-nowrap">{a.type}</TableCell>
                          <TableCell className="px-3 py-3"><SourceBadge source={a.source ?? "rule"} /></TableCell>
                          <TableCell className="px-3 py-3 text-sm text-foreground whitespace-nowrap">{a.related}</TableCell>
                          <TableCell className="px-3 py-3 text-sm text-muted-foreground whitespace-nowrap">{a.project}</TableCell>
                          <TableCell className="px-3 py-3 text-sm text-muted-foreground whitespace-nowrap">{a.device}</TableCell>
                          <TableCell className="px-3 py-3">
                            <span className="text-xs bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded whitespace-nowrap">{a.step}</span>
                          </TableCell>
                          <TableCell className="px-3 py-3 text-muted-foreground text-sm min-w-[180px] max-w-[240px] truncate">{a.desc}</TableCell>
                          <TableCell className="px-3 py-3"><LevelBadge level={a.level} /></TableCell>
                          <TableCell className="px-3 py-3"><AnomalyStatusBadge status={currentStatus} /></TableCell>
                          <TableCell className="px-3 py-3 text-sm text-muted-foreground whitespace-nowrap">{a.time}</TableCell>
                          <TableCell className="px-3 py-3" onClick={e => e.stopPropagation()}>
                            {!resolved
                              ? <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70 px-1" onClick={() => setHandling(a.id)}>处理</Button>
                              : <span className="text-xs text-emerald-600 flex items-center gap-1"><CheckCircle2 size={11} />已解决</span>
                            }
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
                )}
          </div>

          <TableCardFooter>
            <PaginationBar page={page} pageSize={pageSize} total={total} onPageChange={setPage} onPageSizeChange={setPageSize} />
          </TableCardFooter>
        </TableCard>
      </div>
    </div>
  );
}
