import { useCallback, useEffect, useState } from "react";
import {
  Search,
  Grid3X3,
  FlaskConical,
  XCircle,
  MapPin,
  Calendar,
  AlertCircle,
  Edit,
  PackagePlus,
} from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { RegisterProductModal } from "./RegisterProductModal";
import { useConfirm } from "@/app/components/shared/ConfirmDialog";

import { destroyProduct, updateProduct, getProducts, type Product, type ProductUpdate } from "@/app/lib/api";
import { usePagination } from "@/app/hooks/usePagination";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";

export function ProductManagementPage() {
  const confirm = useConfirm();
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [editMode, setEditMode] = useState(false);
  const [draft, setDraft] = useState<ProductUpdate>({ storageCondition: "", expiryDate: "", notes: "" });
  const [message, setMessage] = useState("");
  const [showRegister, setShowRegister] = useState(false);

  const fetchProducts = useCallback(async (params: { page?: number; pageSize?: number; type?: string; status?: string; q?: string }) => {
    return getProducts({ page: params.page, pageSize: params.pageSize, type: params.type, status: params.status, q: params.q ?? "" });
  }, []);

  const {
    items: products,
    total,
    page,
    pageSize,
    setPage,
    setPageSize,
    setFilters,
    refresh,
  } = usePagination<Product, { type: string; status: string; q: string }>({
    fetcher: fetchProducts,
    initialPageSize: 15,
    initialFilters: { type: 'all', status: 'all', q: '' },
  });

  const handleFilterTypeChange = (val: string) => { setFilterType(val); };
  const handleFilterStatusChange = (val: string) => { setFilterStatus(val); };

  // 搜索/类型/状态 → 服务端查询(300ms 防抖;usePagination 自动回第 1 页)
  useEffect(() => {
    const t = setTimeout(() => setFilters({ type: filterType, status: filterStatus, q: searchQuery.trim() }), 300);
    return () => clearTimeout(t);
  }, [searchQuery, filterType, filterStatus, setFilters]);

  const beginEditing = () => {
    if (!selectedProduct) return;
    setDraft({ storageCondition: selectedProduct.storageCondition, expiryDate: selectedProduct.expiryDate, notes: selectedProduct.notes });
    setEditMode(true);
    setMessage("");
  };

  const saveProduct = async () => {
    if (!selectedProduct || !draft.storageCondition.trim() || !draft.expiryDate) {
      setMessage("请填写存储条件和有效期。");
      return;
    }
    const before = selectedProduct;
    const result = await updateProduct(selectedProduct.id, draft);
    if (!result.success) return;
    const updated = { ...selectedProduct, ...draft };
    setSelectedProduct(updated);
    setEditMode(false);
    setMessage("参数已保存。");
    refresh();
  };

  const handleDestroy = async (product: Product) => {
    if (!(await confirm({ title: "确认销毁", message: `确认销毁产物 ${product.id}？此操作不可恢复。`, variant: "danger" }))) return;
    const result = await destroyProduct(product.id, "");
    if (!result.success) return;
    const updated = { ...product, status: "已销毁" as const };
    if (selectedProduct?.id === updated.id) setSelectedProduct(updated);
    setMessage("产物已销毁。");
    refresh();
  };

  return (
    // 2026-09-01 重构：单大卡片模式（参考收样中心/样本中心）——取消独立标题条与统计小卡片，
    // 操作按钮与筛选统一收纳进大卡片信息栏
    <div className="px-6 pb-6 pt-2 h-full flex flex-col">
      <Card className="flex flex-col flex-1 overflow-hidden py-0 gap-0">
        <div className="px-4 pt-3 pb-3.5 border-b border-border">
          <div className="flex items-center justify-between gap-3">
            {/* 左：操作按钮 */}
            <div className="flex items-center gap-2.5 shrink-0">
              <Button variant="default" size="sm" onClick={() => setShowRegister(true)}>
                <PackagePlus size={12} />登记产物
              </Button>

            </div>
            {/* 右：筛选 */}
            <div className="flex items-center gap-2.5 shrink-0">
              <Select value={filterType} onValueChange={handleFilterTypeChange}>
                <SelectTrigger size="sm" className="w-auto h-8 px-2.5 text-xs border border-border rounded-md bg-card">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[
                    { id: 'all', label: '全部产物' },
                    { id: 'nucleic', label: '核酸产物' },
                    { id: 'library', label: '建库产物' },
                    { id: 'pooling', label: 'Pooling产物' },
                  ].map(t => <SelectItem key={t.id} value={t.id}>{t.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={filterStatus} onValueChange={handleFilterStatusChange}>
                <SelectTrigger size="sm" className="w-auto h-8 px-2.5 text-xs border border-border rounded-md bg-card">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem>
                  <SelectItem value="正常">在库</SelectItem>
                  <SelectItem value="已销毁">已销毁</SelectItem>
                </SelectContent>
              </Select>
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="搜索产物/样本/任务编号..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-44 pl-8 pr-3 h-8 text-xs border border-border rounded-md bg-card focus:outline-none focus:ring-1 focus:ring-primary outline-none"
                />
              </div>
            </div>
          </div>
        </div>

          <div className="overflow-auto flex-1">
            <Table className="w-full text-left text-sm border-collapse">
              <TableHeader>
                <TableRow className="bg-muted/30 border-b border-border sticky top-0">
                  <TableHead className="px-4 py-3 text-sm font-semibold text-foreground w-14">序号</TableHead>
                  <TableHead className="px-4 py-3 text-sm font-semibold text-foreground">产物编号</TableHead>
                  <TableHead className="px-4 py-3 text-sm font-semibold text-foreground">类型</TableHead>
                  <TableHead className="px-4 py-3 text-sm font-semibold text-foreground">关联对象</TableHead>
                  <TableHead className="px-4 py-3 text-sm font-semibold text-foreground">任务编号</TableHead>
                  <TableHead className="px-4 py-3 text-sm font-semibold text-foreground">浓度</TableHead>
                  <TableHead className="px-4 py-3 text-sm font-semibold text-foreground">板号-孔位</TableHead>
                  <TableHead className="px-4 py-3 text-sm font-semibold text-foreground">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody className="divide-y divide-border">
                {products.map((p, idx) => (
                  <TableRow key={p.id}
                    className={`transition-colors ${selectedProduct?.id === p.id ? 'bg-primary/5' : ''}`}
                  >
                    <TableCell className="px-4 py-3 text-muted-foreground font-mono text-xs">{(page - 1) * pageSize + idx + 1}</TableCell>
                    <TableCell className="px-4 py-3">
                      <button
                        type="button"
                        title="查看产物详情"
                        onClick={() => setSelectedProduct(p)}
                        className="font-mono text-sm text-primary font-medium hover:underline cursor-pointer"
                      >
                        {p.id}
                      </button>
                    </TableCell>
                    <TableCell className="px-4 py-3">
                      <div className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-medium border ${
                        p.type === 'nucleic' ? 'bg-blue-50 text-blue-700 border-blue-100' :
                        p.type === 'library' ? 'bg-purple-50 text-purple-700 border-purple-100' :
                        'bg-emerald-50 text-emerald-700 border-emerald-100'
                      }`}>
                        <span>{p.icon}</span>
                        {p.typeName}
                      </div>
                    </TableCell>
                    <TableCell className="px-4 py-3">
                      <div className="flex flex-col items-start whitespace-nowrap">
                        <span className="font-medium text-foreground">{p.relatedId}</span>
                        <span className="text-[10px] text-muted-foreground">{p.relatedName}</span>
                      </div>
                    </TableCell>
                    <TableCell className="px-4 py-3">
                      <span className="text-muted-foreground whitespace-nowrap">{p.taskId}</span>
                    </TableCell>
                    <TableCell className="px-4 py-3">
                      <span className="font-medium text-foreground whitespace-nowrap">{p.concentration}</span>
                      <span className="text-[10px] text-muted-foreground ml-1 whitespace-nowrap">{p.unit}</span>
                    </TableCell>
                    <TableCell className="px-4 py-3 text-muted-foreground">
                      <div className="flex items-center gap-1.5 text-sm whitespace-nowrap">
                        <Grid3X3 className="w-3 h-3 text-muted-foreground/50" />
                        {p.plateNo}
                        <span className="text-border">|</span>
                        <span className="font-medium text-foreground">{p.wellPos}</span>
                      </div>
                    </TableCell>
                    <TableCell className="px-4 py-3">
                      {p.status === "已销毁" ? (
                        <span className="text-sm text-muted-foreground">已销毁</span>
                      ) : (
                        /* 操作列统一为蓝色文字链接（参考样本中心：编辑/删除） */
                        <div className="inline-flex items-center gap-1 justify-start">
                          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70" onClick={(event) => { event.stopPropagation(); setSelectedProduct(p); }}>编辑</Button>
                          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70" onClick={() => handleDestroy(p)}>删除</Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
              {/* 空行填充 */}
              {products.length < pageSize && (
                <TableBody>
                  {Array.from({ length: pageSize - products.length }).map((_, i) => (
                    <TableRow key={`empty-${i}`} className="h-[49px] border-0"><TableCell colSpan={8}>&nbsp;</TableCell></TableRow>
                  ))}
                </TableBody>
              )}
            </Table>
            {products.length === 0 && (
              <div className="py-12 flex flex-col items-center justify-center text-muted-foreground/40">
                <FlaskConical className="w-10 h-10 mb-2 opacity-20" />
                <p className="text-sm">暂无符合条件的产物记录</p>
              </div>
            )}
          </div>
          <div className="px-4 py-3 border-t border-border shrink-0">
            <PaginationBar page={page} pageSize={pageSize} total={total} onPageChange={setPage} onPageSizeChange={setPageSize} />
          </div>
        </Card>

        {/* 登记产物弹窗（手动补录入口） */}
        {showRegister && (
          <RegisterProductModal
            onClose={() => setShowRegister(false)}
            onSaved={refresh}
          />
        )}

        {/* Side Panel（2026-09-01：加宽至 480px + 遮罩聚焦，参考样本中心抽屉观感） */}
        {selectedProduct && (
          <>
            {/* 遮罩：主页变暗，视线聚焦卡片；点击遮罩关闭 */}
            <div className="fixed inset-0 z-30 bg-black/40" onClick={() => setSelectedProduct(null)} />
            <div className="fixed inset-y-0 right-0 w-[480px] max-w-[90vw] bg-card shadow-2xl z-40 flex flex-col border-l border-border animate-in slide-in-from-right-4 duration-300">
            <div className="px-5 py-4 border-b border-border flex items-center justify-between bg-muted/20 shrink-0">
              <div className="flex items-center gap-2">
                <span className="text-lg">{selectedProduct.icon}</span>
                <h3 className="text-sm font-semibold text-foreground">产物详情</h3>
              </div>
              <button 
                onClick={() => setSelectedProduct(null)}
                className="p-1 hover:bg-muted rounded transition-colors text-muted-foreground cursor-pointer"
              >
                <XCircle size={16} />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-5 space-y-6 text-[13px]">
              <div className="space-y-3">
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                  基本关联
                </p>
                <div className="bg-muted/30 rounded-xl p-3 border border-border space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">产物编号</span>
                    <span className="font-mono text-xs">{selectedProduct.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{selectedProduct.type === 'pooling' ? 'Pooling ID' : '关联样本'}</span>
                    <span className="font-medium">{selectedProduct.relatedId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">任务编号</span>
                    <span className="font-mono">{selectedProduct.taskId}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  实测数据
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-muted/30 rounded-xl p-3 border border-border">
                    <p className="text-[10px] text-muted-foreground mb-1">浓度</p>
                    <p className="font-bold">{selectedProduct.concentration} <span className="text-[10px] font-normal">{selectedProduct.unit}</span></p>
                  </div>
                  <div className="bg-muted/30 rounded-xl p-3 border border-border">
                    <p className="text-[10px] text-muted-foreground mb-1">体积</p>
                    <p className="font-bold">{selectedProduct.volume} <span className="text-[10px] font-normal">µL</span></p>
                  </div>
                  <div className="bg-muted/30 rounded-xl p-3 border border-border col-span-2 flex justify-between items-center">
                    <div>
                      <p className="text-[10px] text-muted-foreground mb-1">总量</p>
                      <p className="font-bold">{selectedProduct.total} <span className="text-[10px] font-normal">{selectedProduct.type === 'nucleic' ? 'ng' : 'fmol'}</span></p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] text-muted-foreground mb-1">板孔</p>
                      <p className="font-bold">{selectedProduct.plateNo}-{selectedProduct.wellPos}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                  仓储与效期
                </p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 p-3 bg-card border border-border rounded-xl">
                    <MapPin className="w-3.5 h-3.5 text-primary" />
                    <span className="flex-1 text-xs truncate">{editMode ? <input value={draft.storageCondition} onChange={(event) => setDraft((current) => ({ ...current, storageCondition: event.target.value }))} placeholder="存储条件" className="w-full border border-border rounded px-2 py-1" /> : `${selectedProduct.location} · ${selectedProduct.storageCondition}`}</span>
                    {!editMode && <button className="text-primary text-[10px] font-bold hover:underline cursor-pointer">转移</button>}
                  </div>
                  <div className="flex items-center gap-2 p-3 bg-card border border-border rounded-xl">
                    <Calendar className="w-3.5 h-3.5 text-rose-500" />
                    <span className="flex-1 text-xs">{editMode ? <input type="date" value={draft.expiryDate} onChange={(event) => setDraft((current) => ({ ...current, expiryDate: event.target.value }))} className="w-full border border-border rounded px-2 py-1" /> : selectedProduct.expiryDate}</span>
                    <span className="text-[10px] text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-100">提前{selectedProduct.remindDays}天告警</span>
                  </div>
                  <div className="p-3 bg-card border border-border rounded-xl"><label className="block text-[10px] text-muted-foreground mb-1">备注</label>{editMode ? <input value={draft.notes} onChange={(event) => setDraft((current) => ({ ...current, notes: event.target.value }))} placeholder="填写备注" className="w-full border border-border rounded px-2 py-1 text-xs" /> : <p className="text-xs text-foreground">{selectedProduct.notes || "—"}</p>}</div>
                </div>
              </div>

              {message && <p role="status" className="text-xs text-emerald-700">{message}</p>}

            </div>
            <div className="shrink-0 p-5 pt-4 border-t border-border flex flex-col gap-2 bg-card">
              {editMode ? (
                <div className="flex gap-2">
                  <Button variant="ghost" className="flex-1 text-xs h-9" onClick={() => { setEditMode(false); setMessage(""); }}>取消</Button>
                  <Button variant="default" className="flex-1 text-xs h-9" onClick={saveProduct}>保存</Button>
                </div>
              ) : (
                <Button variant="plain" className="w-full text-xs h-9" onClick={beginEditing}>
                  <Edit className="w-3.5 h-3.5 mr-2" />修改参数
                </Button>
              )}
              {/* 2026-09-01：EMS 蓝字样式（确认弹窗仍走 danger 确认） */}
              <Button variant="ghost" className="w-full text-xs h-9 text-primary hover:text-primary/70" onClick={() => handleDestroy(selectedProduct)}>
                <AlertCircle className="w-3.5 h-3.5 mr-2" />
                立即销毁
              </Button>
            </div>
          </div>
          </>
        )}
    </div>
  );
}
