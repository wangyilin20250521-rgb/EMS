import { useState } from "react";
import { PackagePlus, XCircle } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { createProduct, type ProductType } from "@/app/lib/api/products";
import { toast } from "sonner";

/** 产物类型选项（业务核心为建库文库，核酸/Pooling 为扩展） */
const TYPE_OPTIONS: { value: ProductType; label: string }[] = [
  { value: "library", label: "文库（建库产物）" },
  { value: "nucleic", label: "核酸" },
  { value: "pooling", label: "Pool样本" },
];

const FIELD_LABEL = "text-xs font-medium text-muted-foreground mb-1 block";
const FIELD_GRID = "grid grid-cols-2 gap-3";

/**
 * 登记产物弹窗：建库实验完成 → 文库信息入库（POST /products）。
 * taskId 由任务详情页自动绑定传入，只读展示。
 */
export function RegisterProductModal({
  taskId,
  onClose,
  onSaved,
}: {
  /** 任务详情页登记时自动绑定；产物页手动补录时为空（可手填） */
  taskId?: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [type, setType] = useState<ProductType>("library");
  const [manualTaskId, setManualTaskId] = useState(taskId ?? "");
  const [concentration, setConcentration] = useState("");
  const [unit, setUnit] = useState("ng/μL");
  const [volume, setVolume] = useState("");
  const [plateNo, setPlateNo] = useState("");
  const [wellPos, setWellPos] = useState("");
  const [location, setLocation] = useState("");
  const [storageCondition, setStorageCondition] = useState("-20°C");
  const [expiryDate, setExpiryDate] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    setSaving(true);
    try {
      await createProduct({
        type,
        taskId: manualTaskId || undefined,
        concentration: concentration || undefined,
        unit: unit || undefined,
        volume: volume || undefined,
        plateNo: plateNo || undefined,
        wellPos: wellPos || undefined,
        location: location || undefined,
        storageCondition: storageCondition || undefined,
        expiryDate: expiryDate || undefined,
        notes: notes || undefined,
      });
      toast.success("产物已登记入库");
      onSaved();
      onClose();
    } catch (e: any) {
      toast.error(e?.message || "登记失败，请稍后重试");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-card rounded-2xl shadow-2xl w-full max-w-[560px] flex flex-col max-h-[85vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header：标题 + 任务编号 + 关闭 */}
        <div className="flex items-center justify-between gap-3 px-6 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <span className="flex items-center justify-center text-primary shrink-0">
              <PackagePlus size={16} />
            </span>
            <h2 className="text-base font-semibold truncate">登记产物</h2>
            {taskId && (
              <span className="text-xs font-mono text-muted-foreground shrink-0 bg-muted/40 px-2 py-0.5 rounded">
                任务 {taskId}
              </span>
            )}
          </div>
          <Button variant="ghost" size="icon-sm" onClick={onClose} aria-label="关闭" className="shrink-0">
            <XCircle size={18} />
          </Button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
          {/* 任务编号（产物页手动补录时可填） */}
          {!taskId && (
            <div>
              <label className={FIELD_LABEL}>任务编号</label>
              <Input value={manualTaskId} onChange={(e) => setManualTaskId(e.target.value)} placeholder="如 T-20260826-001（选填）" />
            </div>
          )}

          {/* 产物类型 */}
          <div>
            <label className={`${FIELD_LABEL}`}>产物类型 <span className="text-red-500">*</span></label>
            <Select value={type} onValueChange={(v) => setType(v as ProductType)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TYPE_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 浓度 / 体积 */}
          <div className={FIELD_GRID}>
            <div>
              <label className={FIELD_LABEL}>浓度</label>
              <div className="flex gap-2">
                <Input value={concentration} onChange={(e) => setConcentration(e.target.value)} placeholder="如 50" />
                <Select value={unit} onValueChange={setUnit}>
                  <SelectTrigger className="w-24 shrink-0">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {["ng/μL", "ng/mL", "μg/μL"].map((u) => (
                      <SelectItem key={u} value={u}>{u}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <label className={FIELD_LABEL}>体积（μL）</label>
              <Input value={volume} onChange={(e) => setVolume(e.target.value)} placeholder="如 20" />
            </div>
          </div>

          {/* 板号 / 孔位 */}
          <div className={FIELD_GRID}>
            <div>
              <label className={FIELD_LABEL}>板号</label>
              <Input value={plateNo} onChange={(e) => setPlateNo(e.target.value)} placeholder="如 P-01" />
            </div>
            <div>
              <label className={FIELD_LABEL}>孔位</label>
              <Input value={wellPos} onChange={(e) => setWellPos(e.target.value)} placeholder="如 A01" />
            </div>
          </div>

          {/* 存放位置 / 存储条件 */}
          <div className={FIELD_GRID}>
            <div>
              <label className={FIELD_LABEL}>存放位置</label>
              <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="如 冷库A" />
            </div>
            <div>
              <label className={FIELD_LABEL}>存储条件</label>
              <Input value={storageCondition} onChange={(e) => setStorageCondition(e.target.value)} placeholder="如 -20°C" />
            </div>
          </div>

          {/* 有效期 */}
          <div>
            <label className={FIELD_LABEL}>有效期</label>
            <Input type="date" value={expiryDate} onChange={(e) => setExpiryDate(e.target.value)} />
          </div>

          {/* 备注 */}
          <div>
            <label className={FIELD_LABEL}>备注</label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="选填" />
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-border flex justify-end gap-2 shrink-0">
          <Button variant="ghost" size="sm" onClick={onClose}>取消</Button>
          <Button variant="default" size="sm" onClick={handleSubmit} disabled={saving}>
            {saving ? "登记中..." : "登记入库"}
          </Button>
        </div>
      </div>
    </div>
  );
}
