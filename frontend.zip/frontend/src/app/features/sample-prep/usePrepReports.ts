import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  ackPrepReport,
  applyPrepReport,
  autoCreatePrepTask,
  getHostReports,
  submitToExperiment,
  type HostSeparationReport,
  type SamplePrepRecord,
} from "@/app/lib/api";
import { buildHostReportMap, hasOpenPrepTaskForReport, isPrepReportApplyTarget } from "./prep-task-model";

// ─── 上位机分血回执轮询与决策 Hook ────────────────────────────────────────────
// 页面级无条件挂载：立即轮询一次、之后每 10s 拉取回执；发现新回执弹预览，
// 接受（应用/自动创建/自动提交）与忽略（持久化 + 拒绝 ACK）的编排集中在此。

export interface UsePrepReportsOptions {
  /** 当前页任务数组（弹窗资格与接受目标匹配都用它） */
  records: SamplePrepRecord[];
  /** 列表刷新回调（接受/忽略决策后触发，不 await） */
  refresh: () => void;
}

export interface UsePrepReportsResult {
  /** 每台上位机最新回执（biz_host_id → 完整上报；被忽略的回执不展示） */
  hostReportMap: Map<string, HostSeparationReport>;
  /** 待确认回执（弹窗展示；null = 无） */
  pendingReport: HostSeparationReport | null;
  /** 应用回执中 */
  applyingReport: boolean;
  /** 确认接受：应用目标任务 → （自动模式）自动创建 → 记已处理 → 关窗 → 刷新 → 回传 ACK（不 await） */
  handleApplyReport: () => Promise<void>;
  /** 取消（忽略）：持久化忽略 + 回传拒绝 ACK，不再提示 */
  handleIgnoreReport: () => void;
}

export function usePrepReports(options: UsePrepReportsOptions): UsePrepReportsResult {
  const { records, refresh } = options;
  const [hostReports, setHostReports] = useState<HostSeparationReport[]>([]);
  const [pendingReport, setPendingReport] = useState<HostSeparationReport | null>(null);
  // 决策持久化：确认/取消过的回执不再弹窗（切换模块或刷新后仍生效）
  const [handledReportIds, setHandledReportIds] = useState<Set<string>>(() => {
    try { return new Set(JSON.parse(localStorage.getItem("prep-handled-reports") || "[]")); } catch { return new Set(); }
  });
  const [ignoredReportIds, setIgnoredReportIds] = useState<Set<string>>(() => {
    try { return new Set(JSON.parse(localStorage.getItem("prep-ignored-reports") || "[]")); } catch { return new Set(); }
  });
  const [applyingReport, setApplyingReport] = useState(false);

  // 轮询上位机分血完成回执：发现新回执（有匹配的未完成任务）→ 弹窗提示，确认后应用
  // in-flight 防重：同一回执的自动创建请求未返回前不重复发起（handledReportIds 异步更新存在窗口）
  const inflightReports = useRef<Set<string>>(new Set());
  useEffect(() => {
    let cancelled = false;
    const tick = () => {
      getHostReports()
        .then(list => {
          if (cancelled) return;
          setHostReports(list);
          for (const r of list) {
            // 已接受(accepted)的回执属历史记录,只作卡片底部信息展示,不再弹确认预览
            if (!r.report_id || r.accept_status === "accepted" || handledReportIds.has(r.report_id) || inflightReports.current.has(r.report_id)) continue;
            // 收到上报 → 弹预览弹窗（先过目，确认后才应用/创建/提交）
            { setPendingReport(r); break; }
          }
        })
        .catch(() => { /* 忽略 */ });
    };
    tick();
    const timer = setInterval(tick, 10000);
    return () => { cancelled = true; clearInterval(timer); };
  }, [records, handledReportIds]);

  // Decision record persistence
  const markHandled = (id: string) => {
    setHandledReportIds(prev => {
      const next = new Set(prev); next.add(id);
      try { localStorage.setItem("prep-handled-reports", JSON.stringify([...next])); } catch { /* ignore */ }
      return next;
    });
  };
  const markIgnored = (id: string) => {
    setIgnoredReportIds(prev => {
      const next = new Set(prev); next.add(id);
      try { localStorage.setItem("prep-ignored-reports", JSON.stringify([...next])); } catch { /* ignore */ }
      return next;
    });
  };

  // 每台上位机的最新回执（biz_host_id → 完整上报，含分血明细；被忽略的回执不展示）
  const hostReportMap = buildHostReportMap(hostReports, ignoredReportIds);

  // 确认收到回执：应用到匹配的未完成任务（逐行比对、样例填充）。
  // 自动模式 = 确认后全链自动：无匹配任务时自动创建 → ack 回传上位机 → 自动提交到实验（不再弹第二个确认）
  const handleApplyReport = async () => {
    if (!pendingReport) return;
    const r = pendingReport;
    setApplyingReport(true);
    try {
      const targets = records.filter(t => isPrepReportApplyTarget(t, r));
      for (const t of targets) {
        await applyPrepReport(t.id);
      }
      // 无匹配任务：信息唯一来源 = 上位机，确认即自动创建制备任务
      let autoTaskId = "";
      if (targets.length === 0) {
        const res = await autoCreatePrepTask(r.report_id);
        if (!res.noNew && !res.already && res.created > 0) autoTaskId = res.taskId;
      }
      markHandled(r.report_id);
      setPendingReport(null);
      refresh();
      // 决策回传上位机：已接受（自动/非自动模式一致）
      ackPrepReport(r.report_id, "accepted").catch(() => { /* 上位机离线时忽略 */ });
      // 确认后自动提交到实验（样例进入待实验，可排单）
      const submitId = targets.length > 0 ? targets[0].id : autoTaskId;
      if (submitId) {
        try {
          await submitToExperiment(submitId);
          toast.success(`已接收上报并自动确认（${r.host_name || r.device_id || "上位机"}），样例已进入实验链路`);
        } catch {
          toast.warning("已接收上报，但自动提交实验失败，可手动在列表确认提交");
        }
        refresh();
      } else {
        toast.success("已接收上报（样本已被其它任务占用或重复，未创建新任务）");
      }
    } catch (e) {
      toast.error((e as { message?: string })?.message || "回执应用失败");
    } finally {
      setApplyingReport(false);
    }
  };

  // 忽略回执：不接受、不应用、不再提示（回执数据不再展示），并回传上位机"未接受"
  const handleIgnoreReport = () => {
    if (!pendingReport) return;
    markHandled(pendingReport.report_id);
    markIgnored(pendingReport.report_id);
    setPendingReport(null);
    ackPrepReport(pendingReport.report_id, "rejected").catch(() => { /* 上位机离线时忽略 */ });
    toast.info("已忽略该上位机上报，并已回传未接受通知");
  };

  return { hostReportMap, pendingReport, applyingReport, handleApplyReport, handleIgnoreReport };
}
