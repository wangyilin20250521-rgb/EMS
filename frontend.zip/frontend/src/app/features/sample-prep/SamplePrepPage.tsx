import { useCallback, useEffect, useState } from "react";
import { CheckCircle2, Plus } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { TableCard, TableCardHeader, TableCardFooter } from "@/app/components/shared/table-card";

import { getSamplePrepRecords, submitToExperiment, manualPassPrepSample, releasePrepTask, type SamplePrepRecord } from "@/app/lib/api";
import { usePagination } from "@/app/hooks/usePagination";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { useConfirm } from "@/app/components/shared/ConfirmDialog";
import { toast } from "sonner";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { usePrepTaskCreation } from "./usePrepTaskCreation";
import { usePrepReports } from "./usePrepReports";
import { PrepTaskRow } from "./PrepTaskRow";
import { PrepReportDialog } from "./PrepReportDialog";
import { CreatePrepTaskModal } from "./CreatePrepTaskModal";

// ─── 样本制备页 ───────────────────────────────────────────────────────────────
// 拆分后页面只保留：表格骨架与分页、日期筛选、行级动作（确认完成制备/释放/人工通过/
// 设备跳转）、自动化模式确认弹窗，以及两个页面级 hook（创建弹窗编排 / 回执轮询决策）的
// 挂载与传参。行渲染在 PrepTaskRow，两个弹窗为独立组件。

export function SamplePrepPage() {
  const confirm = useConfirm();
  const [expandedTask, setExpandedTask] = useState<string | null>("SP20260624-001");
  const [dateFilter, setDateFilter] = useState("全部");
  const [confirmingTaskId, setConfirmingTaskId] = useState<string | null>(null);
  // 自动化模式（2026-08-25）：上位机上报自动创建制备任务；关闭后恢复手动入口
  const [autoConfirm, setAutoConfirm] = useState<{ taskId: string; reportId: string; hostName: string; created: number; skipped: number } | null>(null);
  const [autoSubmitting, setAutoSubmitting] = useState(false);

  useEffect(() => {
  }, []);

  const fetchRecords = useCallback(async (params: { page?: number; pageSize?: number; dateFilter?: string }) => {
    return getSamplePrepRecords({ dateFilter: params.dateFilter, page: params.page, pageSize: params.pageSize });
  }, []);

  const {
    items: records,
    total,
    page,
    pageSize,
    loading,
    setPage,
    setPageSize,
    setFilters,
    refresh,
  } = usePagination<SamplePrepRecord, { dateFilter: string }>({
    fetcher: fetchRecords,
    initialPageSize: 20,
    initialFilters: { dateFilter: "全部" },
  });

  // 两个页面级 hook 无条件挂载：创建弹窗编排 与 回执轮询/决策（打开弹窗只是渲染结果）
  const taskCreation = usePrepTaskCreation({ refresh });
  const { hostReportMap, pendingReport, applyingReport, handleApplyReport, handleIgnoreReport } = usePrepReports({ records, refresh });

  const handleDateFilterChange = (val: string) => {
    setDateFilter(val);
    setFilters({ dateFilter: val });
  };

  const handleConfirmPrep = async (taskId: string) => {
    setConfirmingTaskId(taskId);
    try {
      const res = await submitToExperiment(taskId);
      toast.success(res.message || "制备完成确认成功");
      refresh();
    } catch (e) {
      toast.error((e as { message?: string })?.message || "确认失败");
    } finally {
      setConfirmingTaskId(null);
    }
  };

  const handleReleaseTask = async (taskId: string) => {
    if (!(await confirm({ title: "确认释放", message: `确认释放任务 ${taskId}？释放后其样本编号解绑，可重新创建任务。`, variant: "danger" }))) return;
    try {
      const res = await releasePrepTask(taskId);
      toast.success(res.message || "任务已释放");
      refresh();
    } catch (e) {
      toast.error((e as { message?: string })?.message || "释放失败");
    }
  };

  // 人工通过：复核不一致时人工检查后标记通过（成功才刷新列表）
  const handleManualPass = (taskId: string, sampleId: string) => {
    manualPassPrepSample(taskId, sampleId)
      .then(() => refresh())
      .catch((e) => toast.error((e as { message?: string })?.message || "操作失败"));
  };

  // 设备详情跳转：从设备显示值解析 SN 后切到设备页（stopPropagation 由 PrepTaskRow 内部处理）
  const handleOpenDevice = (task: SamplePrepRecord) => {
    const sn = (task.device || '').match(/SN:\s*([^）]+)/)?.[1]?.trim();
    if (sn) sessionStorage.setItem('open_device_sn', sn);
    window.location.hash = '#/devices';
  };

  // 自动化模式：自动创建任务后用户阅读确认 → 提交实验进入下一步
  const handleAutoConfirmSubmit = async () => {
    if (!autoConfirm) return;
    setAutoSubmitting(true);
    try {
      const res = await submitToExperiment(autoConfirm.taskId);
      toast.success(res.message || "制备完成确认成功");
      setAutoConfirm(null);
      refresh();
    } catch (e) {
      toast.error((e as { message?: string })?.message || "确认失败");
    } finally {
      setAutoSubmitting(false);
    }
  };

  return (
    <div className="px-6 pb-6 pt-2 h-full flex flex-col space-y-5">
      <div className="flex-1 flex flex-col min-h-0">
        <TableCard>
          <TableCardHeader>
              <div className="flex items-center gap-2">
                {/* 场景3：手动登记制备结果入口常驻（开关仅控制 SIRO 上报自动链路） */}
                <Button variant="outline" size="sm" className="text-[13px] text-primary border-primary/30 bg-transparent shadow-none hover:border-primary hover:bg-primary/5 hover:text-primary" onClick={taskCreation.openCreateModal}>
                  <Plus size={12} />新建任务
                </Button>
              </div>
              {/* 日期筛选 */}
              <div className="flex items-center gap-1 p-0.5 bg-muted rounded-lg">
                {["全部", "今日", "近3日", "近7日"].map((opt) => (
                  <button
                    key={opt}
                    onClick={() => handleDateFilterChange(opt)}
                    className={`px-3 py-1 text-xs rounded-md transition-colors font-medium cursor-pointer ${
                      dateFilter === opt
                        ? "bg-background text-foreground shadow-sm"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
          </TableCardHeader>

          {/* 表格区 */}
          <div className="flex-1 overflow-auto scrollbar-hide">
            <Table className="w-full text-sm">
              <TableHeader className="bg-muted/40 border-b border-border sticky top-0 z-10 backdrop-blur-sm">
                <TableRow>
                  <TableHead className="w-10 px-3 py-2.5" />
                  <TableHead className="w-12 px-3 py-2.5 text-left text-sm font-semibold text-foreground whitespace-nowrap">序号</TableHead>
                  {["任务编号", "执行时间", "样本数量", "样本来源", "设备", "状态", "操作"].map(h => (
                    <TableHead key={h} className="text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading && Array.from({ length: 3 }).map((_, index) => (
                  <TableRow key={index}>
                    <TableCell colSpan={9} className="px-4 py-4">
                      <div className="h-6 bg-muted rounded animate-pulse" />
                    </TableCell>
                  </TableRow>
                ))}

                {!loading && records.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={9} className="py-16 text-center text-sm text-muted-foreground">当前筛选条件下没有制备记录</TableCell>
                  </TableRow>
                )}

                {!loading && records.map((task, idx) => (
                  <PrepTaskRow
                    key={task.id}
                    task={task}
                    rowNo={(page - 1) * pageSize + idx + 1}
                    expanded={expandedTask === task.id}
                    report={task.hostId ? hostReportMap.get(task.hostId) : undefined}
                    confirming={confirmingTaskId === task.id}
                    onToggleExpand={() => setExpandedTask(expandedTask === task.id ? null : task.id)}
                    onOpenDevice={handleOpenDevice}
                    onRelease={handleReleaseTask}
                    onConfirmPrep={handleConfirmPrep}
                    onManualPass={handleManualPass}
                  />
                ))}
              </TableBody>
            </Table>
          </div>

          {/* 底部分页栏（卡片内） */}
          {!loading && records.length > 0 && (
            <TableCardFooter>
              <PaginationBar page={page} pageSize={pageSize} total={total} onPageChange={setPage} onPageSizeChange={setPageSize} />
            </TableCardFooter>
          )}
        </TableCard>
      </div>

      {/* 上位机回执到达弹窗 */}
      {pendingReport && (
        <PrepReportDialog
          report={pendingReport}
          applying={applyingReport}
          onAccept={handleApplyReport}
          onIgnore={handleIgnoreReport}
        />
      )}

      {/* 自动化模式：自动创建制备任务确认弹窗 */}
      {autoConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-card rounded-2xl shadow-2xl w-full max-w-md p-5 space-y-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 size={20} className="text-emerald-600" />
              <h3 className="text-base font-semibold">已自动创建制备任务</h3>
            </div>
            <div className="space-y-2 text-sm">
              <p>
                <span className="text-muted-foreground">上位机：</span>
                <span className="font-medium">{autoConfirm.hostName || "未知设备"}</span>
              </p>
              <p>
                <span className="text-muted-foreground">任务编号：</span>
                <span className="font-mono font-medium">{autoConfirm.taskId}</span>
              </p>
              <p>
                <span className="text-muted-foreground">样本数量：</span>
                <span className="font-medium text-foreground">{autoConfirm.created} 份</span>
                {autoConfirm.skipped > 0 && <span className="text-xs text-amber-600 ml-2">（跳过 {autoConfirm.skipped} 份已被其它任务占用）</span>}
              </p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                上位机分血上报已自动生成制备任务，样例以上位机上报结果为准。请阅读确认后提交进入下一步（排单/实验）。
              </p>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setAutoConfirm(null)}>稍后处理</Button>
              <Button variant="default" onClick={handleAutoConfirmSubmit} className={autoSubmitting ? "opacity-50 pointer-events-none" : ""}>
                {autoSubmitting ? "提交中..." : "确认提交"}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Create Prep Task Modal */}
      <CreatePrepTaskModal
        open={taskCreation.showCreateModal}
        dupWarning={taskCreation.dupWarning}
        creating={taskCreation.createLoading}
        onClose={taskCreation.closeCreateModal}
        onImportFile={taskCreation.handleImportFile}
        onDownloadTemplate={taskCreation.handleDownloadTemplate}
        onClearImport={taskCreation.handleClearImport}
        onCreate={taskCreation.handleCreate}
      />
    </div>
  );
}
