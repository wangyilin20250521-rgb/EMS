import type { HostSeparationReport, SamplePrepRecord } from "@/app/lib/api";
import type { createPrepTask } from "@/app/lib/api";
import type { PrepImportRow } from "@/app/lib/utils/prep-import";

// ─── 样本制备任务页纯函数模型 ─────────────────────────────────────────────────
// 从 SamplePrepPage 拆分出的可复用纯逻辑：回执索引、三套独立资格判断
// （弹窗轮询资格 / 回执应用目标 / 任务行"已上报待确认"提示，三者条件不同不可合并）、
// 任务行派生值、创建任务载荷映射。不含 React 状态与副作用。

/** createPrepTask 入参类型（复用 API 既有定义，不重复声明） */
export type PrepCreateTaskPayload = Parameters<typeof createPrepTask>[0];

/** 任务编号是否为上位机上报自动创建（PREP-AUTO- 前缀） */
export function isPrepAutoTaskId(taskId: string): boolean {
  return taskId.startsWith("PREP-AUTO-");
}

/** 任务记录创建时间是否不晚于回执上报时间（兼容 "yyyy-MM-dd HH:mm:ss" 字符串解析） */
function isTaskTimeBeforeReport(taskTime: string | undefined, reportTime: string): boolean {
  return new Date(String(taskTime || "").replace(" ", "T")).getTime() <= new Date(reportTime).getTime();
}

/** 每台上位机的最新回执（biz_host_id → 完整上报，含分血明细；被忽略的回执不展示） */
export function buildHostReportMap(
  reports: HostSeparationReport[],
  ignoredReportIds: Set<string>,
): Map<string, HostSeparationReport> {
  const map = new Map<string, HostSeparationReport>();
  for (const r of reports) {
    if (!r.biz_host_id || ignoredReportIds.has(r.report_id)) continue;
    if (!map.has(r.biz_host_id)) map.set(r.biz_host_id, r);
  }
  return map;
}

/**
 * 轮询弹窗资格：当前页存在设备归属匹配、且未完成/未释放、创建时间不晚于回执的任务。
 * 注意：不含样本复核条件，与 isPrepReportApplyTarget 不同（不可合并）。
 */
export function hasOpenPrepTaskForReport(records: SamplePrepRecord[], report: HostSeparationReport): boolean {
  return records.some(t =>
    t.hostId === report.biz_host_id &&
    t.syncStatus !== "待实验" && t.syncStatus !== "已释放" &&
    isTaskTimeBeforeReport(t.time, report.report_time)
  );
}

/**
 * 回执应用目标：设备归属匹配、未完成/未释放、创建时间不晚于回执，
 * 且存在内嵌样本、全部样本待复核（比弹窗资格多两条样本条件，不可合并）。
 */
export function isPrepReportApplyTarget(task: SamplePrepRecord, report: HostSeparationReport): boolean {
  return task.hostId === report.biz_host_id &&
    task.syncStatus !== "待实验" && task.syncStatus !== "已释放" &&
    isTaskTimeBeforeReport(task.time, report.report_time) &&
    task.samples.some(s => s.embedded) &&
    task.samples.every(s => (s.reviewStatus ?? "pending") === "pending");
}

/** 任务行派生状态（表格主行与展开区渲染用） */
export interface PrepTaskRowDerived {
  /** 是否上位机上报自动创建（PREP-AUTO- 前缀） */
  isAuto: boolean;
  /** 回执是否在任务创建之后（自动任务由回执创建，只需存在回执） */
  reportedAfterCreate: boolean;
  /** 是否展示"已上报待确认"徽标（未完成/未释放且已有有效回执） */
  showReportHint: boolean;
  /** 已关联样本中心样本数 */
  linkedCount: number;
  /** 未关联（内嵌）样本数 */
  embeddedCount: number;
}

/** 任务行派生值：自动任务判定、回执时序、行提示与关联计数 */
export function derivePrepTaskRowState(
  task: SamplePrepRecord,
  report: HostSeparationReport | undefined,
): PrepTaskRowDerived {
  const isAuto = isPrepAutoTaskId(task.id);
  // 自动任务（PREP-AUTO）由回执创建：无需时间比较（创建时间必然晚于回执落库）；
  // 手动任务需回执晚于任务创建才算有效上报
  const reportedAfterCreate = isAuto ? !!report : !!(report && isTaskTimeBeforeReport(task.time, report.report_time));
  return {
    isAuto,
    reportedAfterCreate,
    showReportHint: !!(reportedAfterCreate && task.syncStatus !== "待实验" && task.syncStatus !== "已释放"),
    linkedCount: task.samples.filter(s => s.linked).length,
    embeddedCount: task.embeddedCount ?? task.samples.filter(s => !s.linked).length,
  };
}

/**
 * 创建任务载荷映射。
 * Excel 导入分支内嵌样本：batchSeq 取模板内部编号 sampleId，sampleNo 保持条码，不可混换。
 */
export function buildPrepCreatePayload(input: {
  taskId: string;
  deviceNo: string;
  hostId: string;
  project: string;
  importedRows: PrepImportRow[];
}): PrepCreateTaskPayload {
  return {
    taskId: input.taskId,
    deviceNo: input.deviceNo,
    hostId: input.hostId || undefined,
    source: "import",
    project: input.project,
    importedSamples: input.importedRows.map(r => ({
      batchSeq: r.sampleId,
      sampleNo: r.sampleNo,
      type: r.type,
      patient: r.patient,
      gender: r.gender,
      age: r.age,
      // 场景3 手工登记：随创建录入的样例（EP 条码）；非空时后端置 reviewStatus=matched
      specimens: r.specimens ?? [],
    })),
  };
}
