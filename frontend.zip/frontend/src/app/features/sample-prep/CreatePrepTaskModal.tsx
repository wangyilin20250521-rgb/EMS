import { useRef } from "react"
import { X, Upload } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { usePrepCreateStore } from "./prep-create-store";
import type { PrepDuplicateWarningItem } from "./usePrepTaskCreation";

// ─── 登记制备结果弹窗（纯 UI，场景3） ─────────────────────────────────────────
// 从 SamplePrepTaskPage 拆出：展示表单与候选数据，编排逻辑在 usePrepTaskCreation。
// 单一 Excel 路径：上传结果表后 EMS 按样本编号自动匹配样本中心（命中即关联，未命中仅随任务走），
// 无"关联批次 / 未关联"选择项。关闭仅隐藏（open=false 返回 null），store 草稿保留。

export interface CreatePrepTaskModalProps {
  /** 弹窗是否可见 */
  open: boolean;
  /** 占用警告（样本编号已被未完成任务占用，阻止创建） */
  dupWarning: PrepDuplicateWarningItem[];
  /** 创建提交中 */
  creating: boolean;
  /** 关闭弹窗 */
  onClose: () => void;
  /** 选择 Excel 样本信息表 */
  onImportFile: (file: File) => void;
  /** 下载登记模板 */
  onDownloadTemplate: () => void;
  /** 清空已解析数据 */
  onClearImport: () => void;
  /** 提交登记 */
  onCreate: () => void;
}

export function CreatePrepTaskModal({
  open,
  dupWarning,
  creating,
  onClose,
  onImportFile,
  onDownloadTemplate,
  onClearImport,
  onCreate,
}: CreatePrepTaskModalProps) {
  // 表单状态在 zustand store（与页面 hook 共享同一实例）
  const store = usePrepCreateStore();
  const fileRef = useRef<HTMLInputElement>(null);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-card rounded-2xl shadow-2xl w-[720px] max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
          <h2 className="text-base font-semibold">登记制备结果</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1 rounded"><X size={18} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* 占用提示（阻止创建，需先释放占用任务） */}
          {dupWarning.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 text-xs text-amber-700 space-y-1">
              <p className="font-medium">
                ⚠ {dupWarning.length} 个样本编号已被未完成任务占用（{dupWarning[0].taskId}{dupWarning.length > 1 ? ` 等 ${new Set(dupWarning.map(d => d.taskId)).size} 个任务` : ""}）：
              </p>
              <p className="font-mono break-all">
                {dupWarning.slice(0, 5).map(d => d.sampleNo).join("、")}{dupWarning.length > 5 ? " …" : ""}
              </p>
              <p>请先到任务卡片对占用任务点「释放任务」，再重新创建。</p>
            </div>
          )}

          {/* Excel 结果表（唯一样本来源；大上传按钮与样本中心导入同款） */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-3">
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={store.parsing}
                className="flex flex-col items-center justify-center gap-1.5 h-24 rounded-xl border-2 border-primary bg-primary/5 hover:bg-primary/10 transition-all cursor-pointer disabled:opacity-60"
              >
                {store.parsing ? (
                  <span className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Upload size={20} className="text-primary" />
                )}
                <span className="text-sm font-medium text-primary">{store.parsing ? "解析中..." : "上传制备结果表"}</span>
                {store.importedRows.length > 0 ? (
                  <span className="text-[10px] text-emerald-600 truncate max-w-full px-2">已解析 {store.importedRows.length} 行（点击更换）</span>
                ) : (
                  <span className="text-[10px] text-muted-foreground">支持 .xlsx .xls</span>
                )}
              </button>
            </div>
            <input
              ref={fileRef}
              type="file"
              accept=".xlsx,.xls"
              className="hidden"
              onChange={e => { const f = e.target.files?.[0]; if (f) onImportFile(f); e.target.value = ""; }}
            />
            {store.importedRows.length > 0 && (
              <div className="border border-border rounded-lg overflow-hidden">
                <div className="px-3 py-2 bg-muted/40 border-b border-border text-xs font-semibold text-muted-foreground flex items-center justify-between">
                  <span>共 {store.importedRows.length} 行 · 检测项目：{store.project || "—"}</span>
                  <button type="button" className="text-muted-foreground hover:text-red-600 font-normal cursor-pointer"
                    onClick={onClearImport}>清空</button>
                </div>
                <div className="max-h-56 overflow-y-auto">
                  <Table className="w-full text-xs">
                    <TableHeader className="bg-muted/20 sticky top-0">
                      <TableRow>{["样本编号", "样本类型", "患者姓名", "性别", "年龄", "样例"].map(h => (
                        <TableHead key={h} className="text-left px-2.5 py-1.5 font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                      ))}</TableRow>
                    </TableHeader>
                    <TableBody className="divide-y divide-border">
                      {store.importedRows.map((r, i) => (
                        <TableRow key={i} className="hover:bg-muted/20">
                          <TableCell className="px-2.5 py-1.5 font-mono">{r.sampleNo}</TableCell>
                          <TableCell className="px-2.5 py-1.5">{r.type}</TableCell>
                          <TableCell className="px-2.5 py-1.5">{r.patient || "—"}</TableCell>
                          <TableCell className="px-2.5 py-1.5">{r.gender || "—"}</TableCell>
                          <TableCell className="px-2.5 py-1.5">{r.age || "—"}</TableCell>
                          <TableCell className="px-2.5 py-1.5 font-mono">{r.specimens.length > 0 ? r.specimens.join("、") : "—"}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}
          </div>

        </div>
        {/* 底部信息栏：左下载模板链接 / 右取消 + 登记按钮（与样本中心导入同款） */}
        <div className="px-6 py-4 border-t border-border flex items-center justify-between gap-2 shrink-0">
          <button
            type="button"
            onClick={onDownloadTemplate}
            className="text-xs text-primary hover:underline cursor-pointer"
          >
            下载模板
          </button>
          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={onClose}>取消</Button>
            <Button variant="default" onClick={onCreate} disabled={dupWarning.length > 0}
              className={creating || dupWarning.length > 0 ? "opacity-50 pointer-events-none" : ""}>
              {dupWarning.length > 0 ? "需先释放占用任务" : creating ? "登记中..." : "登记制备结果"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
