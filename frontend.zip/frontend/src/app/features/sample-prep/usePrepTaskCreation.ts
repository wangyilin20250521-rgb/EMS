import { useState } from "react";
import { toast } from "sonner";
import {
  checkPrepDuplicates,
  createPrepTask,
  downloadPrepImportTemplate,
} from "@/app/lib/api";
import { parsePrepImportFile } from "@/app/lib/utils/prep-import";
import { usePrepCreateStore } from "./prep-create-store";

// ─── 登记制备结果弹窗编排 Hook（场景3） ──────────────────────────────────────
// 单一 Excel 路径：上传制备结果表 → EMS 按样本编号自动匹配样本中心（命中即关联，未命中仅随任务走）。
// 无批次选择、无来源切换；整卡可点式入口常驻，开关仅控制 SIRO 上报自动链路。

/** 占用提示项（样本编号已被未完成任务占用；复用 checkPrepDuplicates 返回元素类型） */
export type PrepDuplicateWarningItem = Awaited<ReturnType<typeof checkPrepDuplicates>>["duplicates"][number];

export interface UsePrepTaskCreationOptions {
  /** 创建成功后触发列表刷新（不 await，避免阻塞关窗） */
  refresh: () => void;
}

export interface UsePrepTaskCreationResult {
  /** 弹窗是否可见 */
  showCreateModal: boolean;
  /** 占用警告（样本编号已被未完成任务占用，阻止创建） */
  dupWarning: PrepDuplicateWarningItem[];
  /** 创建提交中 */
  createLoading: boolean;
  /** 打开弹窗：重置草稿并加载设备候选 */
  openCreateModal: () => void;
  /** 关闭弹窗：仅隐藏，不清理 store */
  closeCreateModal: () => void;
  /** 解析 Excel 样本信息表（复用 prep-import：解析 + 项目一致性校验 + 查重） */
  handleImportFile: (file: File) => Promise<void>;
  /** 下载登记模板 */
  handleDownloadTemplate: () => Promise<void>;
  /** 清空已解析数据与占用警告 */
  handleClearImport: () => void;
  /** 提交登记（成功：提示 → 触发刷新 → 关窗；失败留窗） */
  handleCreate: () => Promise<void>;
}

export function usePrepTaskCreation(options: UsePrepTaskCreationOptions): UsePrepTaskCreationResult {
  const { refresh } = options;
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createLoading, setLoading] = useState(false);
  const [dupWarning, setDupWarning] = useState<PrepDuplicateWarningItem[]>([]);

  // Create-modal user state lives in the zustand store (survives close/reopen)
  const createStore = usePrepCreateStore();

  const openCreateModal = () => {
    createStore.reset();
    createStore.setTaskId(`PREP-${Date.now()}`);
    setDupWarning([]);
    setShowCreateModal(true);
  };

  const closeCreateModal = () => {
    setShowCreateModal(false);
  };

  const handleImportFile = async (file: File) => {
    createStore.setParsing(true);
    try {
      const rows = await parsePrepImportFile(file);
      // 检测项目来自模板填写：未填写或混杂时直接阻止导入
      const projects = [...new Set(rows.map(r => r.project).filter(Boolean))];
      if (projects.length === 0) {
        createStore.setImportedRows([]);
        createStore.setProject("");
        toast.error("样本信息表未填写检测项目，请填写后重新导入");
        return;
      }
      if (projects.length > 1) {
        createStore.setImportedRows([]);
        createStore.setProject("");
        toast.error(`样本信息表检测项目不一致（${projects.join("、")}），请统一后重新导入`);
        return;
      }
      createStore.setImportedRows(rows);
      createStore.setProject(projects[0]);
      const specimenRows = rows.filter(r => r.specimens.length > 0).length;
      toast.success(`解析成功，共 ${rows.length} 行（检测项目：${projects[0]}${specimenRows > 0 ? `，${specimenRows} 行含样例` : ""}）`);
      // 重复测试提示：检查这些样本编号是否已在未完成任务中
      checkPrepDuplicates(rows.map(r => r.sampleNo))
        .then(res => setDupWarning(res.duplicates ?? []))
        .catch(() => setDupWarning([]));
    } catch (e) {
      createStore.setImportedRows([]);
      toast.error((e as { message?: string })?.message || "文件解析失败");
    } finally {
      createStore.setParsing(false);
    }
  };

  const handleDownloadTemplate = async () => {
    try {
      await downloadPrepImportTemplate();
    } catch (e) {
      toast.error((e as { message?: string })?.message || "模板下载失败");
    }
  };

  const handleClearImport = () => {
    createStore.setImportedRows([]);
    createStore.setProject("");
    setDupWarning([]);
  };

  const handleCreate = async () => {
    const { importedRows, project } = createStore;
    if (importedRows.length === 0) { toast.error("请先上传并解析制备结果表"); return; }
    if (!project) { toast.error("样本信息表未填写检测项目"); return; }
    setLoading(true);
    try {
      const res = await createPrepTask({
        source: "import",
        taskId: createStore.taskId,
        project,
        importedSamples: importedRows,
      });
      const linkedCount = (res as any).linkedCount ?? 0;
      toast.success(`制备结果已登记：任务 ${res.taskId}（${importedRows.length} 份样本，其中 ${linkedCount} 份关联样本中心）`);
      refresh();
      setShowCreateModal(false);
    } catch (e) {
      toast.error((e as { message?: string })?.message || "登记失败");
    } finally {
      setLoading(false);
    }
  };

  return {
    showCreateModal,
    dupWarning,
    createLoading,
    openCreateModal,
    closeCreateModal,
    handleImportFile,
    handleDownloadTemplate,
    handleClearImport,
    handleCreate,
  };
}
