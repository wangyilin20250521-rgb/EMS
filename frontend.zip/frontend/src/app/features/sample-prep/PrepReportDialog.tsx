import { CheckCircle2 } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { fmtBeijing } from "@/app/lib/utils/time";
import type { HostSeparationReport } from "@/app/lib/api";

// ─── 上位机分血回执确认弹窗（纯 UI） ──────────────────────────────────────────
// 从 SamplePrepPage 拆出：收到上报后的预览确认（确认接受 / 取消忽略）。
// 接受与忽略的编排逻辑在 usePrepReports。

export interface PrepReportDialogProps {
  /** 待确认的上位机回执 */
  report: HostSeparationReport;
  /** 应用中（应用期间按钮禁用） */
  applying: boolean;
  /** 确认接受：应用回执 / 自动创建并回传 ACK */
  onAccept: () => void;
  /** 取消：持久化忽略并回传拒绝 ACK */
  onIgnore: () => void;
}

export function PrepReportDialog({ report, applying, onAccept, onIgnore }: PrepReportDialogProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="bg-card rounded-2xl shadow-2xl w-full max-w-md p-5 space-y-4">
        <div className="flex items-center gap-2">
          <CheckCircle2 size={20} className="text-emerald-600" />
          <h3 className="text-base font-semibold">
            收到「{report.host_name || report.device_id || "上位机"}（SN: {report.biz_host_id}）」的上位机上报信息
          </h3>
        </div>
        <div className="space-y-1.5 text-xs text-muted-foreground">
          <p>
            <span className="font-medium text-foreground">分血方法：</span>
            {report.report_payload?.method_name || "—"}（{report.report_payload?.method_id || ""}）
          </p>
          <p>
            <span className="font-medium text-foreground">样本数量：</span>
            {report.report_payload?.sample_count ?? 0} 份 · 复核 {(report.report_payload?.review_records ?? []).length} 项
          </p>
          <p>
            <span className="font-medium text-foreground">上报时间：</span>
            {fmtBeijing(report.report_time)}
          </p>
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onIgnore}>取消</Button>
          <Button variant="default" onClick={onAccept} className={applying ? "opacity-50 pointer-events-none" : ""}>
            {applying ? "应用中..." : "确认接受"}
          </Button>
        </div>
      </div>
    </div>
  );
}
