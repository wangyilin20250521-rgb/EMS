import { Fragment } from "react";
import { ChevronDown } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { fmtBeijing } from "@/app/lib/utils/time";
import type { HostSeparationReport, SamplePrepRecord } from "@/app/lib/api";
import { derivePrepTaskRowState } from "./prep-task-model";

// ─── 制备任务表格行（主行 + 展开复核区） ──────────────────────────────────────
// 从 SamplePrepPage 拆出：保持原表格结构、事件冒泡控制（stopPropagation）与设备跳转入口。
// 行内派生值（自动任务/回执时序/提示/关联计数）由 prep-task-model 纯函数计算。

export interface PrepTaskRowProps {
  /** 任务记录 */
  task: SamplePrepRecord;
  /** 列表序号（页面按分页计算） */
  rowNo: number;
  /** 是否展开 */
  expanded: boolean;
  /** 该任务对应上位机回执（按设备归属匹配，可为空） */
  report?: HostSeparationReport;
  /** 该任务"确认完成制备"提交中 */
  confirming: boolean;
  /** 展开/收起 */
  onToggleExpand: () => void;
  /** 设备详情跳转（SN 解析与路由跳转由页面处理） */
  onOpenDevice: (task: SamplePrepRecord) => void;
  /** 释放任务（页面负责二次确认） */
  onRelease: (taskId: string) => void;
  /** 确认完成制备（提交到实验） */
  onConfirmPrep: (taskId: string) => void;
  /** 复核不一致时标记人工通过 */
  onManualPass: (taskId: string, sampleId: string) => void;
}

export function PrepTaskRow({
  task,
  rowNo,
  expanded,
  report,
  confirming,
  onToggleExpand,
  onOpenDevice,
  onRelease,
  onConfirmPrep,
  onManualPass,
}: PrepTaskRowProps) {
  const { isAuto, reportedAfterCreate, showReportHint, linkedCount, embeddedCount } = derivePrepTaskRowState(task, report);
  return (
    <Fragment>
      <TableRow className={`border-b border-border hover:bg-muted/20 transition-colors cursor-pointer ${expanded ? "bg-muted/30" : ""}`} onClick={onToggleExpand}>
        <TableCell className="px-3 py-3">
          <button
            onClick={onToggleExpand}
            className="text-muted-foreground hover:text-foreground transition-colors p-0.5 rounded cursor-pointer"
            title={expanded ? "收起" : "展开"}
          >
            <ChevronDown size={14} className={`transition-transform ${expanded ? "rotate-180" : ""}`} />
          </button>
        </TableCell>
        <TableCell className="px-3 py-3.5 text-sm text-muted-foreground font-mono">{rowNo}</TableCell>
        <TableCell className="px-4 py-3">
          <p className="font-mono text-sm text-primary truncate max-w-[180px]" title={task.id}>{task.id}</p>
        </TableCell>
        <TableCell className="px-4 py-3.5 whitespace-nowrap">{fmtBeijing(task.time)}</TableCell>
        <TableCell className="px-4 py-3.5 font-mono">{task.sampleCount} 管</TableCell>
        <TableCell className="px-4 py-3.5 whitespace-nowrap">
          <span className="text-emerald-600">{linkedCount} 已关联</span>
          {embeddedCount > 0 && <span className="text-purple-600"> / {embeddedCount} 未关联</span>}
        </TableCell>
        <TableCell className="px-4 py-3">
          <div className="flex items-center gap-1.5">
            <span className="font-mono truncate max-w-[130px] block" title={task.device}>
              {task.device ? task.device.split("（")[0] : "—"}
            </span>
            {task.device && (
              <button
                onClick={(e) => { e.stopPropagation(); onOpenDevice(task); }}
                className="text-xs text-primary hover:text-primary/70 cursor-pointer shrink-0"
              >
                详情
              </button>
            )}
          </div>
        </TableCell>
        <TableCell className="px-4 py-3.5 whitespace-nowrap">
          {task.syncStatus === '待实验' ? (
            <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 text-[10px] font-medium">已完成制备</span>
          ) : task.syncStatus === '已释放' ? (
            <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-500 text-[10px] font-medium">已释放</span>
          ) : showReportHint ? (
            <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-medium">已上报待确认</span>
          ) : (
            <span className="px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 text-[10px] font-medium">待分血</span>
          )}
        </TableCell>
        <TableCell className="px-4 py-3.5 whitespace-nowrap">
          {task.syncStatus === '已释放' ? (
            <span className="text-xs text-muted-foreground">已释放</span>
          ) : task.syncStatus === '待实验' ? (
            <span className="text-xs text-muted-foreground/50 cursor-not-allowed" title="已完成制备，样本已进入下游，无法释放">释放任务</span>
          ) : (
            <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-600/70" onClick={(e) => { e.stopPropagation(); onRelease(task.id); }}>释放任务</Button>
          )}
        </TableCell>
      </TableRow>

      {/* Expanded: 样本比对复核表 + 底部回执信息与确认动作（表格展开行） */}
      {expanded && (
        <TableRow className="bg-muted/10">
          <TableCell colSpan={9} className="px-0 py-0">
            <div className="border-t border-border">
              {isAuto ? (
                <div className="overflow-x-auto">
                  <Table className="w-full text-sm">
                    <TableHeader className="bg-muted/40 sticky top-0 z-10 backdrop-blur-sm">
                      <TableRow>
                        {["样本编号", "样例编号", "患者", "项目", "样本类型", "关联状态"].map(h => (
                          <TableHead key={h} className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody className="divide-y divide-border">
                      {task.samples.map((s) => (
                        <TableRow key={s.sampleId} className="hover:bg-muted/20">
                          <TableCell className="px-3 py-2.5 font-mono text-sm">{s.sampleNo || s.sampleId}</TableCell>
                          <TableCell className="px-3 py-2.5">
                            {s.specimens.length > 0 ? (
                              <div className="flex items-center gap-1 flex-wrap">
                                {s.specimens.map(sp => <span key={sp} className="font-mono text-[11px] bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded">{sp}</span>)}
                              </div>
                            ) : (
                              <span className="text-xs text-muted-foreground">—</span>
                            )}
                          </TableCell>
                          <TableCell className="px-3 py-2.5 text-sm">{s.patient || "—"}</TableCell>
                          <TableCell className="px-3 py-2.5 text-sm">{s.project || "—"}</TableCell>
                          <TableCell className="px-3 py-2.5 text-sm">{s.type || "—"}</TableCell>
                          <TableCell className="px-3 py-2.5">
                            {s.linked ? (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-emerald-50 text-emerald-700">已关联样本中心</span>
                            ) : (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-slate-100 text-slate-500">未关联</span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table className="w-full text-sm">
                    <TableHeader className="bg-muted/40 sticky top-0 z-10 backdrop-blur-sm">
                      <TableRow>
                        <TableHead className="text-left px-2 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap w-6">#</TableHead>
                        <TableHead className="text-left px-2 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap w-36">样本编号</TableHead>
                        <TableHead className="text-center px-0.5 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap w-8">对照</TableHead>
                        <TableHead className="text-left px-2 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap w-36">上位机条码</TableHead>
                        <TableHead className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">患者</TableHead>
                        <TableHead className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">项目</TableHead>
                        <TableHead className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">来源</TableHead>
                        <TableHead className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">样例编号</TableHead>
                        <TableHead className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">复核状态</TableHead>
                        <TableHead className="text-left px-3 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">操作</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody className="divide-y divide-border">
                      {task.samples.map((s, i) => {
                        const rs = s.reviewStatus ?? "pending";
                        return (
                          <TableRow key={s.sampleId} className={`hover:bg-muted/20 transition-colors ${rs === "mismatch" ? "bg-amber-50/60" : ""}`}>
                            <TableCell className="px-2 py-2.5 text-sm text-muted-foreground">{i + 1}</TableCell>
                            <TableCell className="px-2 py-2.5">
                              <span className="font-mono text-xs">{s.sampleNo || s.sampleId}</span>
                            </TableCell>
                            <TableCell className="px-0.5 py-2.5 text-center">
                              {rs === "matched" && <span className="text-emerald-600 font-bold">⇄</span>}
                              {rs === "mismatch" && <span className="text-amber-600 font-bold">≠</span>}
                              {rs !== "matched" && rs !== "mismatch" && <span className="text-slate-300">—</span>}
                            </TableCell>
                            <TableCell className="px-2 py-2.5 text-sm font-mono">
                              {rs === "mismatch" ? (
                                <span className="text-amber-600 font-medium">未匹配</span>
                              ) : rs === "matched" ? (
                                <span className="text-emerald-700">{s.scannedBarcode || "—"}</span>
                              ) : (
                                <span className="text-muted-foreground">—</span>
                              )}
                            </TableCell>
                            <TableCell className="px-4 py-2.5 text-sm">{s.patient || "—"}</TableCell>
                            <TableCell className="px-4 py-2.5 text-sm">{s.project || "—"}</TableCell>
                            <TableCell className="px-4 py-2.5">
                              <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${s.linked ? "bg-emerald-50 text-emerald-700" : "bg-purple-50 text-purple-700"}`}>
                                {s.linked ? "样本中心" : "未关联"}
                              </span>
                            </TableCell>
                            <TableCell className="px-4 py-2.5">
                              {s.specimens.length > 0 ? (
                                <div className="flex items-center gap-1 flex-wrap">
                                  {s.specimens.map(sp => (
                                    <span key={sp} className="font-mono text-[11px] bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded">{sp}</span>
                                  ))}
                                </div>
                              ) : (
                                <span className="text-xs text-muted-foreground">—</span>
                              )}
                            </TableCell>
                            <TableCell className="px-4 py-2.5">
                              {rs === "matched" ? (
                                <span className="text-xs text-emerald-600 font-medium">✔ 匹配</span>
                              ) : rs === "mismatch" ? (
                                <span className="text-xs text-amber-600 font-medium">⚠ 不一致</span>
                              ) : rs === "skipped" ? (
                                <span className="text-xs text-slate-500 font-medium">跳过复核</span>
                              ) : rs === "manualPassed" ? (
                                <span className="text-xs text-blue-600 font-medium">✔ 人工通过</span>
                              ) : (
                                <span className="text-xs text-muted-foreground">待回执</span>
                              )}
                            </TableCell>
                            <TableCell className="px-4 py-2.5">
                              {rs === "mismatch" && (
                                <button
                                  onClick={() => onManualPass(task.id, s.sampleId)}
                                  className="px-2 py-0.5 rounded bg-emerald-600 text-white text-[11px] hover:bg-emerald-700 cursor-pointer"
                                >
                                  标记通过
                                </button>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>

            {/* 底部信息栏（展开行内）：左=上位机上报信息，右=确认动作 */}
            <div className="px-5 py-2.5 bg-muted/20 border-t border-border flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              {report && reportedAfterCreate ? (
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-emerald-700">
                  <span className="font-semibold">
                    分血回执：{report.report_payload?.method_name || "—"}（{report.report_payload?.method_id || ""}）
                  </span>
                  <span>样本 {report.report_payload?.sample_count ?? 0} 份</span>
                  <span>复核 {(report.report_payload?.review_records ?? []).length} 项</span>
                  <span>上报时间 {fmtBeijing(report.report_time)}</span>
                  <span>SN: {report.biz_host_id}</span>
                </div>
              ) : isAuto ? (
                // 自动模式：任务由回执创建，展开即有上报，无"无回执"状态
                <span />
              ) : (
                // 非自动模式：先创建任务、等待上位机上报期间的空档状态
                <span className="text-xs text-muted-foreground">尚未收到上位机分血完成回执</span>
              )}
              <div className="shrink-0">
                {task.syncStatus !== '待实验' && task.syncStatus !== '已释放' && (
                  showReportHint ? (
                    <Button variant="default" size="sm" onClick={() => onConfirmPrep(task.id)} className={confirming ? "opacity-50 pointer-events-none" : ""}>
                      {confirming ? "确认中..." : "确认完成制备"}
                    </Button>
                  ) : (
                    <Button variant="outline" size="sm" className="opacity-50 pointer-events-none cursor-not-allowed" title="需上位机分血完成并上报后才能确认">
                      待上位机上报
                    </Button>
                  )
                )}
              </div>
            </div>
          </TableCell>
        </TableRow>
      )}
    </Fragment>
  );
}
