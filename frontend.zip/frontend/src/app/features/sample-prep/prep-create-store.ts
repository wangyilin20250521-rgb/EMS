import { create } from "zustand"
import type { PrepImportRow } from "@/app/lib/utils/prep-import"

// ─── Sample Prep Create Modal Store（内存态） ──────────────────────────────────
// Modal state for "登记制备结果"（场景3：单一 Excel 路径，样本中心自动匹配）。
// Parsed rows survive dialog interactions within the session (zustand memory).

interface PrepCreateStore {
  taskId: string
  importedRows: PrepImportRow[]
  parsing: boolean
  /** 导入分支：整批统一的检测项目（来自模板填写） */
  project: string
  deviceNo: string
  /** 分血上位机 biz_host_id（注册表命中时自动带出；手动填写设备号时为空） */
  hostId: string
  setTaskId: (taskId: string) => void
  setImportedRows: (rows: PrepImportRow[]) => void
  setParsing: (parsing: boolean) => void
  setProject: (project: string) => void
  setDeviceNo: (deviceNo: string) => void
  setHostId: (hostId: string) => void
  /** Reset all modal state — called when opening the modal */
  reset: () => void
}

const initialState = {
  taskId: "",
  importedRows: [] as PrepImportRow[],
  parsing: false,
  project: "",
  deviceNo: "",
  hostId: "",
}

export const usePrepCreateStore = create<PrepCreateStore>((set) => ({
  ...initialState,
  setTaskId: (taskId) => set({ taskId }),
  setImportedRows: (importedRows) => set({ importedRows }),
  setParsing: (parsing) => set({ parsing }),
  setProject: (project) => set({ project }),
  setDeviceNo: (deviceNo) => set({ deviceNo }),
  setHostId: (hostId) => set({ hostId }),
  reset: () => set({ ...initialState }),
}))
