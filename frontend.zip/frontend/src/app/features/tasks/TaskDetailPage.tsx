import { useEffect, useState } from "react";
import {
  ArrowLeft,
  CheckCheck,
  Download,
  PackagePlus,
  Send,
  X,
} from "lucide-react";
import { RegisterProductModal } from "@/app/features/products/RegisterProductModal";
import { ExperimentDataPanel } from "@/app/features/tasks/ExperimentDataPanel";
import { ManualResultEntryPanel } from "@/app/features/tasks/ManualResultEntryPanel";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { SampleStatusBadge } from "@/app/components/shared/status-badges";

import { getTaskDetail, pauseTask, resumeTask, terminateTask, WELL_PLATE_CONFIG, exportTaskSamples, deliverSequencing, type TaskDetail } from "@/app/lib/api";
import { getWorkflowRules } from "@/app/lib/api/strategy";
import { fetchSiroTaskStatus, sendHostCommand, type SiroTaskStatus } from "@/app/lib/api/siro";
import { useExecutionMode } from "@/app/lib/execution-mode";
import { fmtBeijing } from "@/app/lib/utils/time";
import { toast } from "sonner";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";

/** 上位机上报的中台任务状态 → 中文展示映射 */
const SIRO_STATUS_MAP: Record<string, { label: string; className: string }> = {
  READY: { label: "待认领", className: "bg-slate-100 text-slate-600" },
  IDLE: { label: "空闲", className: "bg-slate-100 text-slate-600" },
  RUNNING: { label: "运行中", className: "bg-blue-50 text-blue-700" },
  PAUSED: { label: "已暂停", className: "bg-amber-50 text-amber-700" },
  COMPLETED: { label: "已完成", className: "bg-emerald-50 text-emerald-700" },
  FAILED: { label: "失败", className: "bg-red-50 text-red-700" },
  STOPPED: { label: "已停止", className: "bg-slate-100 text-slate-600" },
};

import { useConfirm } from "@/app/components/shared/ConfirmDialog";

export function TaskDetailPage({ taskId, onBack }: { taskId: string; onBack: () => void }) {
  const confirm = useConfirm();
  const { mode: executionMode } = useExecutionMode();
  // 手工模式：执行区为录入面板，无 SIRO 中台交互
  const isManual = executionMode === "manual";
  const [detail, setDetail] = useState<TaskDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showLog, setShowLog] = useState(false);
  const [showRegisterProduct, setShowRegisterProduct] = useState(false);
  const [siroStatus, setSiroStatus] = useState<SiroTaskStatus | null>(null);
  const [workflowSteps, setWorkflowSteps] = useState<string[]>([]);

  // 轮询 SIRO 中台上报的任务状态（手工模式无中台任务）
  useEffect(() => {
    if (!detail || isManual) return;
    let cancelled = false;
    const tick = () => {
      fetchSiroTaskStatus(detail.id)
        .then(s => { if (!cancelled && s) setSiroStatus(s); })
        .catch(() => { /* 中台未连接时忽略 */ });
    };
    tick();
    const timer = setInterval(tick, 5000);
    return () => { cancelled = true; clearInterval(timer); };
  }, [detail?.id, isManual]);

  useEffect(() => {
    if (!detail?.project) { setWorkflowSteps([]); return }
    getWorkflowRules()
      .then(r => setWorkflowSteps(r?.[detail.project as string]?.steps ?? []))
      .catch(() => setWorkflowSteps([]))
  }, [detail?.project])

  useEffect(() => {
    setLoading(true);
    setError(null);
    getTaskDetail(taskId)
      .then(setDetail)
      .catch((err) => setError(err?.message || '加载任务详情失败'))
      .finally(() => setLoading(false));
  }, [taskId]);

  if (loading) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <p className="text-sm text-muted-foreground">加载中...</p>
      </div>
    );
  }

  if (error || !detail) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <p className="text-sm text-destructive">{error || '任务不存在'}</p>
      </div>
    );
  }

  const plateConfig = WELL_PLATE_CONFIG[detail.device as keyof typeof WELL_PLATE_CONFIG] || WELL_PLATE_CONFIG["SIRO-48"];
  // 标准 96 孔板（12 行 × 8 列）；设备未启用的行（如 SIRO-16 第 3~12 行）灰显
  const plateRows = Array.from({ length: plateConfig.plateRows }, (_, i) => String.fromCharCode(65 + i));
  const plateCols = Array.from({ length: plateConfig.plateCols }, (_, i) => i + 1);

  // 孔板布局：优先用排单时保存的 wellLayout（含孔位与质控），旧任务回退 chipLanes 扁平列表
  const wellMap = new Map<string, { label: string; isControl: boolean }>();
  const wellLayoutArr = Array.isArray(detail.wellLayout) ? detail.wellLayout : null;
  if (wellLayoutArr && wellLayoutArr.length > 0) {
    for (const slot of wellLayoutArr) {
      const key = `${String.fromCharCode(65 + slot.row)}${slot.col}`;
      if (slot.isControl) {
        wellMap.set(key, { label: slot.controlType === "Positive" ? "P" : slot.controlType === "Negative" ? "N" : "B", isControl: true });
      } else if (slot.specimenId) {
        wellMap.set(key, { label: slot.specimenId, isControl: false });
      }
    }
  } else {
    const lanes: any[] = Array.isArray(detail.chipLanes) ? detail.chipLanes
      : typeof detail.chipLanes === 'string' ? JSON.parse(detail.chipLanes || '[]') : [];
    lanes.forEach((lane, idx) => {
      if (!lane) return;
      const rowIdx = Math.floor(idx / plateConfig.cols);
      const colIdx = idx % plateConfig.cols;
      const row = String.fromCharCode(65 + rowIdx);
      const col = colIdx + 1;
      const sampleId = typeof lane === 'string' ? lane : (lane.specimenId || lane.sampleId || '');
      if (sampleId) wellMap.set(`${row}${col}`, { label: sampleId, isControl: false });
    });
  }

  return (
    <div className="p-6 overflow-y-auto h-full space-y-5">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            title="返回上一页"
            className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors cursor-pointer shrink-0"
          >
            <ArrowLeft size={16} />
          </button>
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-semibold" style={{ fontFamily: "'DM Mono', monospace" }}>{detail.id}</h1>
            <SampleStatusBadge status={detail.status} />
          </div>
        </div>
        <div className="flex gap-2">
          {/* 登记产物：任务列表均为建库实验（experiment），完成后登记文库产物入库 */}
          <Button variant="outline" size="sm" onClick={() => setShowRegisterProduct(true)}>
            <PackagePlus size={12} />登记产物
          </Button>
          {!isManual && <Button variant="outline" onClick={() => setShowLog(true)}>查看SIRO日志</Button>}
          <Button variant="outline" onClick={() => {
            exportTaskSamples(detail.id)
              .then(() => toast.success("样本结果已导出"))
              .catch((e: any) => toast.error(e?.message || "导出失败，请稍后重试"));
          }}><Download size={12} />导出样本结果</Button>
          {(detail.status === "完成" || detail.status === "失败") && (
            <Button variant="outline" size="sm" onClick={async () => {
              if (!(await confirm({ title: "确认投递", message: `确认将任务 ${detail.id} 的实验结果投递到测序系统？` }))) return
              try {
                const r = await deliverSequencing(detail.id)
                toast.success(`投递成功（样本 ${r.sampleCount ?? 0} 条）`)
              } catch (e: any) {
                toast.error(e?.message || "投递失败")
              }
            }}><Send size={12} />投递测序</Button>
          )}
          {detail.status === "运行中" && !isManual && (
            <>
              <Button
                variant="outline"
                className="text-yellow-700 dark:text-yellow-300 bg-yellow-50 dark:bg-yellow-950/40 border-yellow-300 dark:border-yellow-700 hover:bg-yellow-100 dark:hover:bg-yellow-950/60"
                onClick={async () => {
                  if (await confirm({ title: "确认暂停", message: `确认暂停任务 ${detail.id}？暂停后可继续执行。` })) {
                    // 先下发上位机控制指令，成功后再同步 EMS 状态
                    sendHostCommand(detail.id, "pause")
                      .then(() => pauseTask(detail.id))
                      .then(() => getTaskDetail(taskId).then(setDetail))
                      .catch((e: any) => toast.error(e?.message || "暂停失败"));
                  }
                }}
              >
                暂停任务
              </Button>
              <Button
                variant="outline"
                className="text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950/40 border-red-300 dark:border-red-700 hover:bg-red-100 dark:hover:bg-red-950/60"
                onClick={async () => {
                  if (await confirm({ title: "确认终止", message: `确认终止任务 ${detail.id}？此操作不可撤销。`, variant: "danger" })) {
                    sendHostCommand(detail.id, "stop")
                      .then(() => terminateTask(detail.id))
                      .then(() => getTaskDetail(taskId).then(setDetail))
                      .catch((e: any) => toast.error(e?.message || "终止失败"));
                  }
                }}
              >
                终止任务
              </Button>
            </>
          )}
          {detail.status === "已暂停" && !isManual && (
            <Button
              variant="outline"
              className="text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-700 hover:bg-emerald-100 dark:hover:bg-emerald-950/60"
              onClick={async () => {
                if (await confirm({ title: "确认恢复", message: `确认恢复任务 ${detail.id}？` })) {
                  sendHostCommand(detail.id, "resume")
                    .then(() => resumeTask(detail.id))
                    .then(() => getTaskDetail(taskId).then(setDetail))
                    .catch((e: any) => toast.error(e?.message || "恢复失败"));
                }
              }}
            >
              恢复任务
            </Button>
          )}
        </div>
      </div>

      {/* 基本信息卡片 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
        {[
          ["检测项目", detail.project],
          ["样本数量", `${detail.sampleCount} 个`],
          ["使用设备", detail.device],
          ["预计完成", detail.estDone],
        ].map(([k, v]) => (
          <Card key={k} className="p-3">
            <p className="text-xs text-muted-foreground">{k}</p>
            <p className="font-semibold mt-0.5">{v}</p>
          </Card>
        ))}
      </div>

      {/* 实验流程步骤（按项目实时读取 workflow-rules） */}
      {workflowSteps.length > 0 && (
        <Card className="p-3">
          <div className="flex items-center gap-2 text-sm flex-wrap">
            <p className="text-xs text-muted-foreground shrink-0">实验流程步骤</p>
            <div className="flex items-center gap-1.5 flex-wrap">
              {workflowSteps.map((step, i) => (
                <span key={i} className="inline-flex items-center gap-1">
                  <span className="text-sm font-medium text-foreground">{step}</span>
                  {i < workflowSteps.length - 1 && <span className="text-muted-foreground/40 text-xs">→</span>}
                </span>
              ))}
            </div>
          </div>
        </Card>
      )}

      {/* 孔板布局（手工模式无板位） */}
      {!isManual && (
      <Card className="p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">{plateConfig.total}孔板布局</h3>
          <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-[3px] bg-blue-100 border border-blue-300 inline-block" />样本</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-[3px] bg-orange-100 border border-orange-300 inline-block" />质控</span>
            <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-[3px] bg-gray-100 border border-gray-200 inline-block" />空位</span>
          </div>
        </div>
        <div className="overflow-x-auto pb-2">
          <div className="inline-block min-w-max">
            {/* 孔位宽度：孔多（12 列）用小格，孔少（≤8 列）用大格，保证长编号可显示 */}
            <div className="flex items-center gap-1 mb-1">
              <div className="w-7 shrink-0" />
              {plateCols.map(c => (
                <div key={c} className={`${plateConfig.cols > 8 ? "w-16" : "w-24"} shrink-0 text-center text-[10px] text-muted-foreground font-medium`}>{c}</div>
              ))}
            </div>
            {plateRows.map((row) => {
              // 设备未启用的行（标准板中超出设备有效区）：灰显不可用
              const rowDisabled = row.charCodeAt(0) - 65 >= plateConfig.rows;
              return (
              <div key={row} className="flex items-center gap-1 mb-1">
                <div className={`w-7 shrink-0 text-[10px] font-medium ${rowDisabled ? "text-muted-foreground/40" : "text-muted-foreground"}`}>{row}</div>
                {plateCols.map((c) => {
                  // 设备未启用的列（如 SIRO-16 的 9-12 列）同样灰显
                  const disabled = rowDisabled || c > plateConfig.cols;
                  const key = `${row}${c}`;
                  const cell = wellMap.get(key);
                  const filled = !!cell;
                  return (
                    <div
                      key={c}
                      className={`${plateConfig.plateCols > 8 ? "w-16" : "w-24"} h-12 rounded-md shrink-0 flex items-center justify-center text-center px-1 py-1 text-[10px] leading-tight font-mono font-medium border break-all ${
                        disabled
                          ? "bg-muted/20 border-dashed border-border/30 text-muted-foreground/30"
                          : cell?.isControl
                            ? "bg-orange-100 border-orange-300 text-orange-700"
                            : filled
                              ? "bg-blue-50 border-blue-300 text-blue-700 hover:bg-blue-100"
                              : "bg-gray-50 border-gray-200 text-gray-300 hover:bg-gray-100"
                      }`}
                      title={disabled ? "未启用" : (cell?.label ?? `${row}${c} 空位`)}
                    >
                      {disabled ? "·" : (filled ? cell!.label.replace('S-', '') : "·")}
                    </div>
                  );
                })}
              </div>
              );
            })}
          </div>
        </div>
      </Card>
      )}

      {/* 执行区：手工=录入面板，设备=只读回传面板 */}
      {detail.taskType === "experiment" && (
        isManual
          ? <ManualResultEntryPanel taskId={detail.id} taskStatus={detail.status} />
          : <ExperimentDataPanel taskId={detail.id} />
      )}

      {/* SIRO 中台任务状态（上位机上报） */}
      {!isManual && siroStatus && (
        <Card className="p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold mb-3">SIRO 中台任务状态</h3>
            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${SIRO_STATUS_MAP[siroStatus.status]?.className ?? "bg-slate-100 text-slate-600"}`}>
              {SIRO_STATUS_MAP[siroStatus.status]?.label ?? siroStatus.status}
            </span>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            <div>
              <p className="text-muted-foreground mb-0.5">当前步骤</p>
              <p className="font-medium">
                {siroStatus.current_step || "—"}
                {siroStatus.current_step_status ? `（${siroStatus.current_step_status}）` : ""}
              </p>
            </div>
            <div>
              <p className="text-muted-foreground mb-0.5">认领设备</p>
              <p className="font-medium">{siroStatus.biz_host_id || "未认领"}</p>
            </div>
            <div>
              <p className="text-muted-foreground mb-0.5">认领时间</p>
              <p className="font-medium">{siroStatus.claim_time ? fmtBeijing(siroStatus.claim_time) : "—"}</p>
            </div>
            <div>
              <p className="text-muted-foreground mb-0.5">执行进度</p>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
                  <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${siroStatus.progress || 0}%` }} />
                </div>
                <span className="font-mono">{siroStatus.progress || 0}%</span>
              </div>
            </div>
          </div>
          {siroStatus.status_reason && (
            <p className="mt-2 text-xs text-red-600">异常信息：{siroStatus.status_reason}</p>
          )}
        </Card>
      )}

      {/* 步骤时间线（上位机上报） */}
      {siroStatus && siroStatus.steps.length > 0 && (
        <Card className="p-4">
          <h3 className="text-sm font-semibold mb-3">步骤时间线</h3>
          <div className="flex flex-wrap gap-1.5">
            {siroStatus.steps.map(st => (
              <span key={st.stepNo} className={`px-2 py-1 rounded text-[11px] font-mono ${
                st.status === "COMPLETED" ? "bg-emerald-50 text-emerald-700" :
                st.status === "FAILED" ? "bg-red-50 text-red-700" :
                st.status === "RUNNING" ? "bg-blue-50 text-blue-700" :
                "bg-slate-100 text-slate-600"
              }`}>
                {st.stepNo} · {st.status}
              </span>
            ))}
          </div>
        </Card>
      )}

      {/* 样本结果表（上位机上报 sample_nos 解析） */}
      {siroStatus && siroStatus.samples.length > 0 && (
        <Card className="overflow-hidden py-0">
          <div className="px-4 py-2.5 border-b border-border">
            <h3 className="text-sm font-semibold">样本结果</h3>
          </div>
          <div className="overflow-x-auto">
            <Table className="w-full text-xs">
              <TableHeader className="bg-muted/40">
                <TableRow>
                  {["样本编号", "产品", "类型", "前处理板位", "建库板位", "杂洗板位", "上机板位", "提取QC", "提取信号", "建库QC", "建库信号", "杂洗QC", "杂洗信号", "上机QC", "上机信号", "DNA取样体积", "子文库体积", "PoolingID", "HybridizationID", "BarcodeID", "INDEX", "UMI"].map(h => (
                    <TableHead key={h} className="text-left px-2.5 py-2 font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody className="divide-y divide-border">
                {siroStatus.samples.map(s => (
                  <TableRow key={s.experimentSampleId || s.sampleNo} className="hover:bg-muted/20">
                    <TableCell className="px-2.5 py-2 font-mono text-primary whitespace-nowrap">{s.sampleNo || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 whitespace-nowrap">{s.testName || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 whitespace-nowrap">{s.sampleType || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.preptreatmentPlate || s.preptreatmentWell ? `${s.preptreatmentPlate || "—"}-${s.preptreatmentWell || "—"}` : "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.libprepPlate || s.libprepWell ? `${s.libprepPlate || "—"}-${s.libprepWell || "—"}` : "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.hybridPlate || s.hybridWell ? `${s.hybridPlate || "—"}-${s.hybridWell || "—"}` : "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.seqprepPlate || s.seqprepWell ? `${s.seqprepPlate || "—"}-${s.seqprepWell || "—"}` : "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.extractionQC || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.extractionSignal || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.libprepQC || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.libprepSignal || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.hybridQC || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.hybridSignal || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.seqprepQC || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.seqprepSignal || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.dnaSamplingVolume || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.libraryVolume || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.poolingID || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.hybridizationID || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.barcodeID || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.index || "—"}</TableCell>
                    <TableCell className="px-2.5 py-2 font-mono whitespace-nowrap">{s.umi || "—"}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* 实验任务完成后的操作区域 (备份与条码) */}
      {detail.status === "完成" && (
        <Card className="p-4 bg-blue-50/30 border-blue-200">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-blue-700">
              <CheckCheck size={18} className="text-blue-500" />
              <div>
                <p className="text-sm font-semibold">任务已完成</p>
                <p className="text-xs text-blue-600/80">您可以进行样本备份及条码打印操作</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">打印条码</Button>
              <Button variant="default" size="sm" className="shadow-sm"><CheckCheck size={12} />完成备份</Button>
            </div>
          </div>
        </Card>
      )}

      {/* 登记产物弹窗（建库实验完成 → 文库入库） */}
      {showRegisterProduct && (
        <RegisterProductModal
          taskId={detail.id}
          onClose={() => setShowRegisterProduct(false)}
          onSaved={() => {}}
        />
      )}

      {/* SIRO 日志弹窗（上位机经中台存库的上报日志） */}
      {showLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="bg-card rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col overflow-hidden">
            <div className="px-5 py-4 border-b border-border flex items-center justify-between shrink-0">
              <h2 className="text-sm font-semibold">SIRO 中台日志（上位机上报）</h2>
              <button onClick={() => setShowLog(false)} className="p-1 hover:bg-muted rounded text-muted-foreground cursor-pointer"><X size={16} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {(siroStatus?.logs?.length ?? 0) === 0 ? (
                <p className="text-center text-xs text-muted-foreground py-8">暂无日志</p>
              ) : (
                siroStatus!.logs.map(l => (
                  <div key={l.log_id} className="border border-border rounded-lg p-3 text-xs">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-1.5 py-0.5 rounded bg-muted text-muted-foreground font-mono">{l.log_type}</span>
                      {l.step_name && <span className="text-primary font-medium">{l.step_name}</span>}
                      <span className="ml-auto text-muted-foreground">{l.log_time ? fmtBeijing(l.log_time) : ""}</span>
                    </div>
                    <p className="text-foreground/80 break-all">{l.log_content}</p>
                  </div>
                ))
              )}
            </div>
            <div className="px-5 py-3 border-t border-border flex justify-end shrink-0">
              <Button variant="default" onClick={() => setShowLog(false)} className="px-4 py-2 text-xs rounded-lg bg-primary text-white cursor-pointer font-medium">关闭</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
