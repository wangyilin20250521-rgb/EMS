import { useEffect, useMemo, useRef, useState } from "react"
import { CheckCheck, Download, Save, Upload } from "lucide-react"
import { Button } from "@/app/components/ui/button"
import { Card } from "@/app/components/ui/card"
import {
  MANUAL_RESULT_FIELDS, completeManualExperiment, downloadManualResultTemplate,
  getTaskExperimentData, importManualExperimentData, saveManualExperimentData,
  type TaskExperimentData,
} from "@/app/lib/api"
import { useAuth } from "@/app/hooks/useAuth"
import { useConfirm } from "@/app/components/shared/ConfirmDialog"
import { toast } from "sonner"

/**
 * 手工结果录入面板（manual 模式任务详情执行区，替代 SIRO 只读面板）：
 * 字段复刻建库段、写同一张 specimen_results；录入即生效，异常只提醒；
 * 进度按已录入样本占比（0 → 100%）。
 */
export function ManualResultEntryPanel({ taskId, taskStatus }: { taskId: string; taskStatus: string }) {
  const confirm = useConfirm()
  const { user } = useAuth()
  const fileRef = useRef<HTMLInputElement>(null)
  const [data, setData] = useState<TaskExperimentData | null>(null)
  /**草稿：sampleNo → 字段键 → 输入值 */
  const [drafts, setDrafts] = useState<Record<string, Record<string, string>>>({})
  const [warnings, setWarnings] = useState<string[]>([])
  const [saving, setSaving] = useState(false)
  const completed = taskStatus === "完成" || taskStatus === "失败" || taskStatus === "已终止"

  useEffect(() => {
    getTaskExperimentData(taskId).then(setData).catch(() => setData(null))
  }, [taskId])

  /**行 = 任务样本名册；名册缺失（旧任务）回退已保存结果行 */
  const rows = useMemo(() => {
    if (data?.samples?.length) return data.samples.map(s => ({ sampleNo: s.sampleNo, patient: s.patient }))
    return (data?.specimens ?? []).map(s => ({ sampleNo: s.specimenId, patient: s.patient }))
  }, [data])

  /**已保存结果（specimenId = 样本编号），预填草稿初值 */
  const savedBySampleNo = useMemo(() => {
    const m = new Map<string, Record<string, string>>()
    for (const sp of data?.specimens ?? []) {
      const vals: Record<string, string> = {}
      for (const f of MANUAL_RESULT_FIELDS) {
        const v = sp.experimentData?.[f.key]
        if (v !== undefined && v !== null && String(v) !== "") vals[f.key] = String(v)
      }
      if (Object.keys(vals).length > 0) m.set(sp.specimenId, vals)
    }
    return m
  }, [data])

  useEffect(() => {
    // 已保存结果回填（本地草稿优先，避免覆盖正在编辑的内容）
    setDrafts(prev => {
      const next = { ...prev }
      for (const [sampleNo, vals] of savedBySampleNo) {
        if (!next[sampleNo]) next[sampleNo] = { ...vals }
      }
      return next
    })
  }, [savedBySampleNo])

  const setField = (sampleNo: string, key: string, value: string) => {
    setDrafts(prev => ({ ...prev, [sampleNo]: { ...(prev[sampleNo] ?? {}), [key]: value } }))
  }

  const enteredCount = rows.filter(r => {
    const d = drafts[r.sampleNo]
    return d && MANUAL_RESULT_FIELDS.some(f => (d[f.key] ?? "").trim() !== "")
  }).length
  const progress = rows.length > 0 ? Math.min(100, Math.round((enteredCount / rows.length) * 100)) : 0

  const applyResult = (r: { saved: number; skipped?: Array<{ sampleNo: string; reason: string }>; warnings?: string[] }) => {
    const lines = [...(r.warnings ?? [])]
    for (const s of r.skipped ?? []) lines.push(`${s.sampleNo}：${s.reason}`)
    setWarnings(lines)
    if ((r.skipped?.length ?? 0) > 0) toast.warning(`已保存 ${r.saved} 行，${r.skipped!.length} 行被跳过（见提醒）`)
    else toast.success(`已保存 ${r.saved} 行`)
    getTaskExperimentData(taskId).then(setData).catch(() => { /* 保持现状 */ })
  }

  const save = async () => {
    const payload = rows
      .map(r => ({ sampleNo: r.sampleNo, values: drafts[r.sampleNo] ?? {} }))
      .filter(r => MANUAL_RESULT_FIELDS.some(f => (r.values[f.key] ?? "").trim() !== ""))
    if (payload.length === 0) { toast.warning("没有可保存的录入（先填写浓度等字段）"); return }
    setSaving(true)
    try {
      applyResult(await saveManualExperimentData(taskId, payload, user?.username ?? ""))
    } catch (e: any) {
      toast.error(e?.message || "保存失败")
    } finally {
      setSaving(false)
    }
  }

  const importExcel = async (file: File) => {
    setSaving(true)
    try {
      applyResult(await importManualExperimentData(taskId, file, user?.username ?? ""))
    } catch (e: any) {
      toast.error(e?.message || "导入失败")
    } finally {
      setSaving(false)
      if (fileRef.current) fileRef.current.value = ""
    }
  }

  const complete = async () => {
    if (!(await confirm({
      title: "确认完成实验",
      message: `确认完成实验 ${taskId}？任务将置为「完成」，随后可投递测序。`,
    }))) return
    try {
      const r = await completeManualExperiment(taskId)
      toast.success(`实验已完成（已录入结果 ${r.enteredResults} 条）`)
    } catch (e: any) {
      toast.error(e?.message || "操作失败")
    }
  }

  return (
    <Card className="p-5 space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h3 className="text-sm font-semibold">手工实验结果录入</h3>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            录入即生效（重复录入自动覆盖）；编号等明显错误系统会提醒但不阻断
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={() => downloadManualResultTemplate(taskId).catch((e: any) => toast.error(e?.message || "模板下载失败"))}>
            <Download size={12} />下载模板
          </Button>
          <Button variant="outline" size="sm" disabled={saving || completed} onClick={() => fileRef.current?.click()}>
            <Upload size={12} />导入 Excel
          </Button>
          <input
            ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden"
            onChange={(e) => { const f = e.target.files?.[0]; if (f) void importExcel(f) }}
          />
          <Button variant="outline" size="sm" disabled={saving || completed} onClick={save}>
            <Save size={12} />{saving ? "保存中..." : "保存录入"}
          </Button>
          {!completed && (
            <Button variant="default" size="sm" onClick={complete}>
              <CheckCheck size={12} />完成实验
            </Button>
          )}
        </div>
      </div>

      {/* 进度（手工模式 0 → 100% 两点式：填完即完成，与设备模式同一进度条视觉） */}
      <div>
        <div className="flex items-center justify-between text-[11px] text-muted-foreground mb-1">
          <span>录入进度（{enteredCount}/{rows.length}）</span>
          <span className="font-mono">{progress}%</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${progress}%` }} />
        </div>
      </div>

      {warnings.length > 0 && (
        <div className="rounded-lg border border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/40 px-3 py-2 space-y-1">
          {warnings.map((w, i) => (
            <p key={i} className="text-[12px] text-amber-700 dark:text-amber-300">⚠ {w}</p>
          ))}
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-left text-[13px]">
          <thead>
            <tr className="bg-muted/40">
              <th className="border border-border px-2 py-1.5 font-semibold whitespace-nowrap">样本编号</th>
              <th className="border border-border px-2 py-1.5 font-semibold whitespace-nowrap">患者</th>
              {MANUAL_RESULT_FIELDS.map(f => (
                <th key={f.key} className="border border-border px-2 py-1.5 font-semibold whitespace-nowrap">
                  {f.label}{f.required && <span className="text-red-500 ml-0.5">*</span>}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.sampleNo} className="hover:bg-muted/10">
                <td className="border border-border px-2 py-1 font-mono text-[12px] whitespace-nowrap">{r.sampleNo}</td>
                <td className="border border-border px-2 py-1 text-muted-foreground whitespace-nowrap">{r.patient || "—"}</td>
                {MANUAL_RESULT_FIELDS.map(f => (
                  <td key={f.key} className="border border-border px-1 py-1">
                    <input
                      value={drafts[r.sampleNo]?.[f.key] ?? ""}
                      disabled={completed}
                      onChange={(e) => setField(r.sampleNo, f.key, e.target.value)}
                      placeholder={f.key === "qcWord" ? "合格/不合格" : f.type === "number" ? "数值" : ""}
                      className={`w-24 px-1.5 py-1 text-[12px] rounded border border-border bg-card focus:outline-none focus:ring-2 focus:ring-ring ${f.type === "number" ? "font-mono" : ""}`}
                    />
                  </td>
                ))}
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={2 + MANUAL_RESULT_FIELDS.length} className="text-center text-muted-foreground py-8">任务暂无样本名册</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </Card>
  )
}
