import React, { useEffect, useState } from "react";
import { ChevronDown, ChevronRight, FlaskConical } from "lucide-react";
import { Card } from "@/app/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { getTaskExperimentData, type TaskExperimentSpecimen } from "@/app/lib/api";

/**
 * 实验结果数据面板(只读,任务详情内嵌)
 * 数据源: GET /tasks/:id/experiment-data → specimen_results.experiment_data 全量 JSONB。
 * 2026-09 去测序化后:载荷为建库段数据(文库浓度/荧光/子文库体积/质控),系统流程到建库结束,
 * 测序/报告键(Z 值/风险/检出结论/Q30 等)不再进入系统(见 demo-seed 解析裁剪)。标签字典为
 * 自建扩展映射(Excel 列名搬运,见 demo-seed profile),未知键回退显示原始键名。
 */

/** 扩展检测键 → 中文标签(键名与 scripts/demo-seed profile 列映射一致) */
const KEY_LABELS: Record<string, string> = {
  // 上位机契约键(有真实值者)
  SampleNo: "样本编号",
  TestName: "检测项目",
  BarcodeID: "Barcode ID",
  // 流程/质控
  qcWord: "样本质控",
  qcFailReason: "质控失败原因",
  validDataM: "有效数据量(M)",
  gcPct: "GC(%)",
  mapRatePct: "比对率(%)",
  dupRatePct: "重复率(%)",
  q20Pct: "Q20(%)",
  q30Pct: "Q30(%)",
  fetalConcPct: "胎儿浓度(%)",
  abnormalChrCount: "异常染色体数",
  dupFlag: "标示是否为重复样",
  // 检出结论
  test13: "Test(chr13)",
  test18: "Test(chr18)",
  test21: "Test(chr21)",
  testSexChr: "Test(性染色体)",
  testOtherAuto: "Test(其它常染色体)",
  testDup: "Test(缺失重复)",
  disease: "疾病",
  dupGe10M: "≥10M(缺失重复)",
  otherDup: "其他缺失重复",
  sexChrHint: "性染色体异常提示",
  clinicalRawResult: "临床原始结果",
  halos1Result: "halos1 结果",
  detectCount: "检测次数",
  supplement: "补充",
  batchQC: "是否批间质评",
  // 检测数值
  conc13Pct: "13浓度(%)",
  conc18Pct: "18浓度(%)",
  conc21Pct: "21浓度(%)",
  risk13: "13风险值",
  risk18: "18风险值",
  risk21: "21风险值",
  sexChrDiff: "性染色体浓度差",
  xConc: "X染色体浓度",
  yConc: "Y染色体浓度",
  // 建库/上机
  libConc: "建库产物浓度",
  libFluo: "建库产物荧光值",
  libConcNg: "文库浓度(ng/μl)",
  subLibVolume: "子文库体积",
  mixLibWaterVol: "混合文库补水体积",
  dnbConc: "DNB浓度",
  serialNo: "GenSIRO 序列号",
  deviceSwVersion: "SIRO 软件版本",
  middleSwVersion: "中台软件版本",
  runDate: "实验日期",
  sampleCategory: "样本类别",
  productCategory: "产品大类",
  technicalRoute: "技术路线",
  roundLabel: "实验轮次",
  pkgLine: "产品线",
  pkgCode: "产品套餐编号",
  chipId: "芯片号",
  laneId: "Lane ID",
  // 21 号染色体专用总结(阳性病例高亮列)
  z13: "Z(chr13)",
  z18: "Z(chr18)",
  z21: "Z(chr21)",
};

/** Z(chrN) 自动标签:zChr1~zChr22 / zChrX */
function labelOf(key: string): string {
  if (KEY_LABELS[key]) return KEY_LABELS[key];
  const m = /^zChr(\d+|X)$/.exec(key);
  if (m) return `Z(chr${m[1]})`;
  return key;
}

/** 摘要列(每样例一行展示的关键指标;2026-09 去测序化后为建库段/质控键) */
const SUMMARY_KEYS = ["qcWord", "libConc", "libFluo", "subLibVolume"];

/** 详情展示顺序:结论/风险 → 数值 → 质控 → 流程/元数据,未知键收尾 */
const DETAIL_ORDER: string[] = [
  "qcWord", "qcFailReason", "clinicalRawResult", "halos1Result", "detectCount",
  "test13", "test18", "test21", "testSexChr", "testOtherAuto", "testDup",
  "disease", "dupGe10M", "otherDup", "sexChrHint", "abnormalChrCount",
  "z13", "z18", "z21",
  "conc13Pct", "conc18Pct", "conc21Pct",
  "risk13", "risk18", "risk21",
  "fetalConcPct", "sexChrDiff", "xConc", "yConc",
  "validDataM", "gcPct", "mapRatePct", "dupRatePct", "q20Pct", "q30Pct",
  "libConc", "libFluo", "libConcNg", "subLibVolume", "mixLibWaterVol", "dnbConc",
  "dupFlag", "batchQC", "supplement",
  "SampleNo", "TestName", "BarcodeID",
  "serialNo", "deviceSwVersion", "middleSwVersion", "productCategory",
  "technicalRoute", "roundLabel", "sampleCategory", "pkgLine", "pkgCode",
];

/** 按详情顺序 + 未知键(字母序)排列 */
function orderedEntries(data: Record<string, string>): Array<[string, string]> {
  const known = DETAIL_ORDER.filter((k) => data[k] !== undefined && data[k] !== "").map((k) => [k, data[k]] as [string, string]);
  const used = new Set(DETAIL_ORDER);
  const unknown = Object.entries(data)
    .filter(([k, v]) => !used.has(k) && v !== "" && v !== "-")
    .sort(([a], [b]) => a.localeCompare(b));
  return [...known, ...unknown];
}

export function ExperimentDataPanel({ taskId }: { taskId: string }) {
  const [specimens, setSpecimens] = useState<TaskExperimentSpecimen[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    getTaskExperimentData(taskId)
      .then((d) => { if (!cancelled) setSpecimens(d.specimens); })
      .catch((e: Error) => { if (!cancelled) setError(e?.message || "加载实验结果失败"); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [taskId]);

  return (
    <Card className="overflow-hidden py-0 gap-0">
      {/* 卡片头(表格卡片标准模式:不用 CardHeader) */}
      <div className="px-4 pt-3 pb-3.5 border-b border-border flex items-center justify-between">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <FlaskConical size={14} className="text-primary" />
          实验结果数据
        </h3>
        <span className="text-xs text-muted-foreground">
          {specimens.length > 0 ? `${specimens.length} 例样例 · 数值为上位机真实上报` : ""}
        </span>
      </div>

      {loading ? (
        <p className="px-4 py-6 text-center text-xs text-muted-foreground">加载中...</p>
      ) : error ? (
        <p className="px-4 py-6 text-center text-xs text-destructive">{error}</p>
      ) : specimens.length === 0 ? (
        <p className="px-4 py-6 text-center text-xs text-muted-foreground">
          暂无实验数据(本任务未关联样例级结果)
        </p>
      ) : (
        <div className="flex-1 overflow-auto scrollbar-hide">
          <Table className="w-full text-xs">
            <TableHeader className="bg-muted/40">
              <TableRow>
                <TableHead className="text-left px-3 py-2 font-semibold text-foreground whitespace-nowrap">样例编号</TableHead>
                <TableHead className="text-left px-3 py-2 font-semibold text-foreground whitespace-nowrap">受检者</TableHead>
                {SUMMARY_KEYS.map((k) => (
                  <TableHead key={k} className="text-left px-3 py-2 font-semibold text-foreground whitespace-nowrap">{labelOf(k)}</TableHead>
                ))}
                <TableHead className="text-left px-3 py-2 font-semibold text-foreground whitespace-nowrap">详情</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-border">
              {specimens.map((s) => {
                const d = s.experimentData ?? {};
                const expanded = expandedId === s.specimenId;
                return (
                  <React.Fragment key={s.specimenId}>
                    <TableRow className="hover:bg-muted/20">
                      <TableCell className="px-3 py-2 font-mono text-primary whitespace-nowrap">{s.specimenId}</TableCell>
                      <TableCell className="px-3 py-2 whitespace-nowrap">{s.patient || "—"}</TableCell>
                      {SUMMARY_KEYS.map((k) => (
                        <TableCell key={k} className="px-3 py-2 whitespace-nowrap">
                          {d[k] || "—"}
                        </TableCell>
                      ))}
                      <TableCell className="px-3 py-2 whitespace-nowrap">
                        <button
                          onClick={() => setExpandedId(expanded ? null : s.specimenId)}
                          className="inline-flex items-center gap-1 text-primary hover:underline cursor-pointer text-xs"
                        >
                          {expanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                          {expanded ? "收起" : "查看全部"}
                        </button>
                      </TableCell>
                    </TableRow>
                    {expanded && (
                      <TableRow className="bg-muted/10">
                        <TableCell colSpan={SUMMARY_KEYS.length + 4} className="px-4 py-3">
                          <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-6 gap-y-1.5 text-xs">
                            {orderedEntries(d).map(([k, v]) => (
                              <div key={k} className="flex justify-between gap-3 border-b border-border/40 pb-1">
                                <span className="text-muted-foreground shrink-0">{labelOf(k)}</span>
                                <span className="font-mono text-right break-all">
                                  {v}
                                </span>
                              </div>
                            ))}
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </React.Fragment>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </Card>
  );
}
