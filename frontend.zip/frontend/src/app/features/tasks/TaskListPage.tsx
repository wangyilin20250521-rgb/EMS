import { useCallback, useEffect, useRef, useState } from "react";
import {
  Filter,
  Search,
  X,
} from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { TableCard, TableCardHeader, TableCardFooter } from "@/app/components/shared/table-card";

import { getTasks, pauseTask, resumeTask, terminateTask, deliverSequencing, getSequencingConfig, PROJECT_OPTIONS, type Task, type TaskStatus } from "@/app/lib/api";
import { sendHostCommand } from "@/app/lib/api/siro";
import { toast } from "sonner";
import { TaskDetailPage } from "./TaskDetailPage";
import { usePagination } from "@/app/hooks/usePagination";
import { PaginationBar } from "@/app/components/shared/PaginationBar";
import { fmtBeijing } from "@/app/lib/utils/time";
import { TASK_STATUSES } from "@/app/lib/api/types";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/app/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/app/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/app/components/ui/dialog";

type StatusTab = "全部" | TaskStatus;
const STATUS_TABS: StatusTab[] = ["全部", ...TASK_STATUSES];
const OWNER_OPTIONS = ["王丽", "张明", "李强"];

interface AdvancedFilter {
  projects: string[];
  owner: string;
  startDate: string;
  endDate: string;
}

const EMPTY_ADVANCED_FILTER: AdvancedFilter = { projects: [], owner: "", startDate: "", endDate: "" };

function TaskStatusBadge({ status }: { status: TaskStatus }) {
  const colors: Record<TaskStatus, string> = {
    "就绪": "bg-gray-100 text-gray-600 dark:bg-slate-800 dark:text-slate-300",
    "运行中": "bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300",
    "待启动": "bg-gray-100 text-gray-600 dark:bg-slate-800 dark:text-slate-300",
    "已暂停": "bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300",
    "已终止": "bg-zinc-100 text-zinc-700 dark:bg-zinc-900/40 dark:text-zinc-300",
    "完成": "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300",
    "失败": "bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-300",
  };
  return <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${colors[status]}`}><span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />{status}</span>;
}

function TaskAdvancedFilterPanel({ value, onChange, onClose }: { value: AdvancedFilter; onChange: (filter: AdvancedFilter) => void; onClose: () => void }) {
  const toggleProject = (project: string) => onChange({ ...value, projects: value.projects.includes(project) ? value.projects.filter((item) => item !== project) : [...value.projects, project] });

  return (
    <Card className="p-4 shadow-lg space-y-4">
      <div className="flex items-center justify-between"><h2 className="text-sm font-semibold">高级筛选</h2><button onClick={onClose} className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-muted" aria-label="关闭高级筛选"><X size={14} /></button></div>
      <div><p className="text-xs font-medium text-muted-foreground mb-2">实验项目</p><div className="flex flex-wrap gap-1.5">{PROJECT_OPTIONS.map((project) => <label key={project} className="inline-flex items-center gap-1.5 text-xs text-muted-foreground cursor-pointer"><input type="checkbox" checked={value.projects.includes(project)} onChange={() => toggleProject(project)} className="rounded accent-primary" />{project}</label>)}</div></div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3"><div><label className="text-xs font-medium text-muted-foreground block mb-1">负责人</label><Select onValueChange={v => onChange({ ...value, owner: v })} value={value.owner}>
  <SelectTrigger className="w-full border border-border rounded-md px-2 py-1.5 text-xs bg-input-background"><SelectValue placeholder="全部" /></SelectTrigger>
  <SelectContent>
{OWNER_OPTIONS.map((owner) => <SelectItem key={owner} value={owner}>{owner}</SelectItem>)}
  </SelectContent>
</Select></div><div><label className="text-xs font-medium text-muted-foreground block mb-1">创建开始</label><input type="date" value={value.startDate} onChange={(event) => onChange({ ...value, startDate: event.target.value })} className="w-full border border-border rounded-md px-2 py-1.5 text-xs bg-input-background" /></div><div><label className="text-xs font-medium text-muted-foreground block mb-1">创建结束</label><input type="date" value={value.endDate} onChange={(event) => onChange({ ...value, endDate: event.target.value })} className="w-full border border-border rounded-md px-2 py-1.5 text-xs bg-input-background" /></div></div>
      <div className="flex justify-end gap-2 pt-1 border-t border-border"><Button variant="ghost" size="sm" onClick={() => onChange(EMPTY_ADVANCED_FILTER)}>重置</Button><Button variant="default" size="sm" onClick={onClose}>搜索</Button></div>
    </Card>
  );
}

function taskCreatedDate(task: Task) {
  return fmtBeijing(task.createdAt).split(" ")[0]
}

/** 任务耗时（完成时间 - 创建时间；无完成时间时按当前时间估算） */
function taskDuration(task: Task): string {
  const end = task.updatedAt ? new Date(task.updatedAt).getTime() : Date.now();
  const start = new Date(task.createdAt).getTime();
  const ms = Math.max(0, end - start);
  const hours = Math.floor(ms / 3600000);
  const mins = Math.floor((ms % 3600000) / 60000);
  if (hours > 0) return `${hours}小时${mins}分`;
  if (mins > 0) return `${mins}分钟`;
  return `${Math.max(1, Math.round(ms / 1000))}秒`;
}

/** 已完成任务的弹窗通知（已通知集合持久化到 localStorage，跨刷新/跨页面不重复弹） */
const COMPLETED_NOTIFIED_KEY = "mlims_task_completed_notified";

function InfoRow({ label, value, mono }: { label: string; value: string | number; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-xs text-muted-foreground shrink-0">{label}</span>
      <span className={`text-sm font-medium text-foreground text-right ${mono ? "font-mono" : ""}`}>{value}</span>
    </div>
  );
}

import { useConfirm } from "@/app/components/shared/ConfirmDialog";

export function TaskListPage() {
  const confirm = useConfirm();
  const [detail, setDetail] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [statusTab, setStatusTab] = useState<StatusTab>("全部");
  const [showAdvancedFilter, setShowAdvancedFilter] = useState(false);
  const [advancedFilter, setAdvancedFilter] = useState<AdvancedFilter>(EMPTY_ADVANCED_FILTER);

  // ── Task Completion Auto Popup（2026-08-28）：状态由上位机上报，轮询检测"非完成 → 完成" ──
  const [completionQueue, setCompletionQueue] = useState<Task[]>([]);
  const [notified] = useState<Set<string>>(
    () => new Set<string>(JSON.parse(localStorage.getItem(COMPLETED_NOTIFIED_KEY) ?? "[]"))
  );
  const firstRunRef = useRef(true);

  useEffect(() => {
    let cancelled = false;
    const checkCompleted = async () => {
      try {
        const completed = await getTasks({ status: "完成", pageSize: 100 });
        if (firstRunRef.current) {
          // 初次挂载只建立基线（不弹窗）；刷新页面时 localStorage 已有记录，正常对比
          firstRunRef.current = false;
          completed.forEach((t) => notified.add(t.id));
          localStorage.setItem(COMPLETED_NOTIFIED_KEY, JSON.stringify([...notified]));
          return;
        }
        const fresh = completed.filter((t) => !notified.has(t.id));
        if (fresh.length > 0) {
          fresh.forEach((t) => notified.add(t.id));
          localStorage.setItem(COMPLETED_NOTIFIED_KEY, JSON.stringify([...notified]));
          if (!cancelled) setCompletionQueue((prev) => [...prev, ...fresh]);
        }
      } catch { /* 轮询失败静默，下轮重试 */ }
    };
    void checkCompleted();
    const timer = setInterval(() => void checkCompleted(), 10000);
    return () => { cancelled = true; clearInterval(timer); };
  }, []);

  const currentCompletion = completionQueue[0] ?? null;

  // 测序对接启用状态（解决方案→接口配置）：未启用时置灰「投递测序」，避免点击后才收到报错
  const [seqEnabled, setSeqEnabled] = useState<boolean | null>(null);
  useEffect(() => {
    let cancelled = false;
    getSequencingConfig()
      .then(cfg => { if (!cancelled) setSeqEnabled(cfg.enabled === true) })
      .catch(() => { if (!cancelled) setSeqEnabled(false) });
    return () => { cancelled = true };
  }, []);

  const fetchTasksData = useCallback(async (params: { page?: number; pageSize?: number; status?: string }) => {
    return getTasks({ page: params.page, pageSize: params.pageSize, status: params.status !== '全部' ? params.status : undefined });
  }, []);

  const {
    items: pagedTasks,
    total,
    page,
    pageSize,
    setPage,
    setPageSize,
    refresh,
  } = usePagination<Task, { status?: string }>({
    fetcher: fetchTasksData,
    initialPageSize: 20,
    initialFilters: { status: '全部' },
  });

  // 10 秒轮询刷新：中台状态同步回任务后，列表状态实时更新
  useEffect(() => {
    const timer = setInterval(() => refresh(), 10000);
    return () => clearInterval(timer);
  }, [refresh]);

  // Tab 切换时更新筛选并回到第1页
  const handleStatusTabChange = (status: StatusTab) => {
    setStatusTab(status);
    setPage(1);
  };

  const displayedTasks = pagedTasks.filter((task) => {
    if (search && !task.id.toLowerCase().includes(search.toLowerCase())) return false;
    if (statusTab !== "全部" && task.status !== statusTab) return false;
    if (advancedFilter.projects.length > 0 && !advancedFilter.projects.includes(task.project)) return false;
    if (advancedFilter.owner && task.owner !== advancedFilter.owner) return false;
    const createdDate = taskCreatedDate(task);
    if (advancedFilter.startDate && createdDate < advancedFilter.startDate) return false;
    if (advancedFilter.endDate && createdDate > advancedFilter.endDate) return false;
    return true;
  });

  const hasAdvancedFilter = advancedFilter.projects.length > 0 || advancedFilter.owner !== "" || advancedFilter.startDate !== "" || advancedFilter.endDate !== "";

  if (detail) {
    return <TaskDetailPage taskId={detail} onBack={() => setDetail(null)} />;
  }

  return (
    <div className="h-full flex flex-col overflow-hidden px-6 pb-6 pt-2 space-y-5">
      <TableCard className="flex-1 min-h-0">
        <TableCardHeader innerClassName="justify-end">
              <Select value={statusTab} onValueChange={(v) => handleStatusTabChange(v as StatusTab)}>
                <SelectTrigger size="sm" className="w-auto h-8 px-2.5 text-xs border border-border rounded-md bg-card">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_TABS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
              <div className="relative">
                <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input value={search} onChange={(event) => setSearch(event.target.value)}
                  className="w-44 pl-8 pr-3 h-8 text-xs border border-border rounded-md bg-card focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="搜索任务编号..." />
              </div>
              <Button variant="outline" size="sm" className="text-xs" onClick={() => setShowAdvancedFilter((current) => !current)}><Filter size={12} />高级筛选{hasAdvancedFilter && <span className="w-1.5 h-1.5 rounded-full bg-primary" />}</Button>
        </TableCardHeader>
        {showAdvancedFilter && <TaskAdvancedFilterPanel value={advancedFilter} onChange={setAdvancedFilter} onClose={() => setShowAdvancedFilter(false)} />}

        <div className="flex-1 overflow-y-auto">
          <div className="overflow-x-auto">
            <Table className="w-full text-sm">
              <TableHeader className="bg-muted/40 border-b border-border sticky top-0 z-10">
                <TableRow>
                  <TableHead className="w-12 px-3 py-2.5 text-left text-sm font-semibold text-foreground whitespace-nowrap">序号</TableHead>
                  {["任务编号", "检测项目", "样本数", "关联样例数", "设备", "状态", "当前阶段", "创建时间", "预估完成", "操作", "详情"].map(h => (
                    <TableHead key={h} className="text-left px-4 py-2.5 text-sm font-semibold text-foreground whitespace-nowrap">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody className="divide-y divide-border">
                {displayedTasks.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={12} className="px-4 py-12 text-center text-sm text-muted-foreground">暂无符合条件的实验任务</TableCell>
                  </TableRow>
                ) : displayedTasks.map((task, idx) => (
                  <TableRow key={task.id} className="hover:bg-muted/20 transition-colors">
                    {/* 序号列（跨页连续编号） */}
                    <TableCell className="px-3 py-3 text-sm text-muted-foreground font-mono">{(page - 1) * pageSize + idx + 1}</TableCell>
                    <TableCell className="px-4 py-3">
                      <button
                        type="button"
                        title="查看任务详情"
                        onClick={() => setDetail(task.id)}
                        className="font-mono text-sm text-primary hover:underline cursor-pointer"
                      >
                        {task.id}
                      </button>
                    </TableCell>
                    <TableCell className="px-4 py-3 font-medium whitespace-nowrap">{task.project}</TableCell>
                    <TableCell className="px-4 py-3 text-center font-mono text-sm">{task.sampleCount}</TableCell>
                    <TableCell className="px-4 py-3 text-center font-mono text-sm">{task.specimenCount}</TableCell>
                    <TableCell className="px-4 py-3 text-muted-foreground text-sm">{task.device}</TableCell>
                    <TableCell className="px-4 py-3"><TaskStatusBadge status={task.status} /></TableCell>
                    <TableCell className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">{task.currentStage || "—"}</TableCell>
                    <TableCell className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">{fmtBeijing(task.createdAt)}</TableCell>
                    <TableCell className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">{fmtBeijing(task.estDone)}</TableCell>
                    <TableCell className="px-4 py-3">
                      <div className="flex gap-1 items-center" onClick={e => e.stopPropagation()}>
                        {task.status === "已暂停" ? (
                          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70"
                            onClick={async () => { if (await confirm({ title: "确认恢复", message: `确认恢复任务 ${task.id}？` })) sendHostCommand(task.id, "resume").then(() => resumeTask(task.id)).then(() => refresh()).catch((e: any) => toast.error(e?.message || "恢复失败")); }}>恢复</Button>
                        ) : task.status !== "已终止" && task.status !== "完成" && task.status !== "失败" ? (
                          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70"
                            onClick={async () => { if (await confirm({ title: "确认暂停", message: `确认暂停任务 ${task.id}？` })) sendHostCommand(task.id, "pause").then(() => pauseTask(task.id)).then(() => refresh()).catch((e: any) => toast.error(e?.message || "暂停失败")); }}>暂停</Button>
                        ) : null}
                        {task.status !== "已终止" && task.status !== "完成" && task.status !== "失败" && (
                          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70"
                            onClick={async () => { if (await confirm({ title: "确认终止", message: `确认终止任务 ${task.id}？此操作不可撤销。`, variant: "danger" })) sendHostCommand(task.id, "stop").then(() => terminateTask(task.id)).then(() => refresh()).catch((e: any) => toast.error(e?.message || "终止失败")); }}>终止</Button>
                        )}
                        {(task.status === "完成" || task.status === "失败") && (
                          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70 disabled:text-muted-foreground/50 disabled:cursor-not-allowed"
                            disabled={seqEnabled === false}
                            title={seqEnabled === false ? "测序对接未启用，请在 解决方案→接口配置 开启" : undefined}
                            onClick={async () => {
                              if (!(await confirm({ title: "确认投递", message: `确认将任务 ${task.id} 的实验结果投递到测序系统？` }))) return
                              try {
                                const r = await deliverSequencing(task.id)
                                toast.success(`投递成功（样本 ${r.sampleCount ?? 0} 条）`)
                              } catch (e: any) {
                                toast.error(e?.message || "投递失败")
                              } finally { refresh() }
                            }}>投递测序</Button>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="px-4 py-3">
                      <Button variant="ghost" size="sm" className="text-primary hover:text-primary/70" onClick={() => setDetail(task.id)}>详情</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
        <TableCardFooter>
          <PaginationBar page={page} pageSize={pageSize} total={total} onPageChange={setPage} onPageSizeChange={setPageSize} />
        </TableCardFooter>
      </TableCard>

      {/* 任务完成弹窗（上位机上报状态 → 轮询检测 → 自动弹出结果摘要） */}
      <Dialog
        open={completionQueue.length > 0}
        onOpenChange={(open) => { if (!open) setCompletionQueue((prev) => prev.slice(1)); }}
      >
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <span className="w-2 h-2 rounded-full bg-chart-2" />
              任务已完成
            </DialogTitle>
            <DialogDescription>
              任务已由实验设备上报完成，结果摘要如下。
            </DialogDescription>
          </DialogHeader>
          {currentCompletion && (
            <div className="space-y-2.5 py-1">
              <InfoRow label="任务编号" value={currentCompletion.id} mono />
              <InfoRow label="检测项目" value={currentCompletion.project} />
              <InfoRow label="样本数" value={currentCompletion.sampleCount} />
              <InfoRow label="设备" value={currentCompletion.device || "—"} />
              <InfoRow
                label="完成时间"
                value={currentCompletion.updatedAt ? fmtBeijing(currentCompletion.updatedAt) : "—"}
              />
              <InfoRow label="耗时" value={taskDuration(currentCompletion)} />
            </div>
          )}
          <DialogFooter>
            <Button size="sm" onClick={() => setCompletionQueue((prev) => prev.slice(1))}>知道了</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
