/**
 * 文档「AI 智能介绍」状态机：idle → typing（基础信息打字机）→ ai（AI 简报流式）→ done。
 * - 基础信息（元数据/签名/章节结构）是确定性文本，纯前端逐字打出，无需等待 AI；
 * - 打字完成后自动发起 document 模式独立会话，请求 AI 两三句简报（流式即天然打字感）；
 * - 切换文档 / 重复点击时重置并中止进行中的请求。
 */

import { useEffect, useMemo, useRef, useState } from "react"
import type { KbDocDetail } from "@/app/lib/api"
import { streamChat } from "@/app/lib/utils/sse"
import { buildStreamCallbacks } from "@/app/lib/chat/stream-turn"
import { buildDocBasicsText, buildDocIntroPrompt, buildDocSessionId } from "./document-model"

export type DocIntroPhase = "idle" | "typing" | "ai" | "done"

/** 打字机节奏：每 tick 2 字（中文阅读节奏 + ~150-250 字基础信息 ≈ 1.5-2 秒） */
const TYPE_TICK_MS = 16
const TYPE_CHARS_PER_TICK = 2

export function useDocIntro(doc: KbDocDetail | null) {
  const [phase, setPhase] = useState<DocIntroPhase>("idle")
  const [typed, setTyped] = useState("")
  const [aiText, setAiText] = useState("")
  const [aiError, setAiError] = useState("")
  const abortRef = useRef<AbortController | null>(null)
  const sessionRef = useRef<string | null>(null)

  const basics = useMemo(() => (doc ? buildDocBasicsText(doc) : ""), [doc])

  // 切换文档：重置全部状态并中止进行中的请求
  useEffect(() => {
    abortRef.current?.abort()
    abortRef.current = null
    sessionRef.current = null
    setPhase("idle")
    setTyped("")
    setAiText("")
    setAiError("")
  }, [doc?.docId])

  // 打字机：phase=typing 时逐字揭示基础信息；打完后转入 AI 简报
  useEffect(() => {
    if (phase !== "typing" || !basics) return
    let i = 0
    const timer = setInterval(() => {
      i = Math.min(i + TYPE_CHARS_PER_TICK, basics.length)
      setTyped(basics.slice(0, i))
      if (i >= basics.length) {
        clearInterval(timer)
        setPhase("ai")
      }
    }, TYPE_TICK_MS)
    return () => clearInterval(timer)
  }, [phase, basics])

  // AI 简报：打字完成自动触发；独立会话（doc- 前缀 → document 模式，审计隔离）
  useEffect(() => {
    if (phase !== "ai" || !doc || !sessionRef.current) return
    setAiText("")
    setAiError("")
    const controller = streamChat(
      buildDocIntroPrompt(doc),
      buildStreamCallbacks({
        idPrefix: "doc-intro",
        apply: (patch) => setAiText(patch.text),
        trackCharts: false,
        onDone: () => setPhase("done"),
        onError: (msg) => {
          setAiError(msg)
          setPhase("done")
        },
      }),
      { document: true, sessionId: sessionRef.current },
    )
    abortRef.current = controller
    return () => controller.abort()
  }, [phase, doc])

  /** 开始（或重新开始）介绍：新会话、状态重置 */
  const start = () => {
    if (!doc) return
    abortRef.current?.abort()
    abortRef.current = null
    sessionRef.current = buildDocSessionId(doc.docId)
    setTyped("")
    setAiText("")
    setAiError("")
    setPhase("typing")
  }

  return {
    phase,
    typed,
    aiText,
    aiError,
    start,
    /** 是否已进入介绍流程（控制详情区展开） */
    isActive: phase !== "idle",
  }
}
