import { useEffect, useRef, useState } from "react"
import { BookOpen, FileText } from "lucide-react"

import { getKbDocument, getKbDocuments, type KbDocDetail, type KbDocSummary } from "@/app/lib/api/documents"

import { PanelSidebar } from "@/app/components/shared/PanelSidebar"
import { MarqueeText, CardTag } from "@/app/components/shared/MarqueeText"
import { panelCardCls, panelIconCls } from "@/app/components/shared/panel-styles"
import { DocChatPanel } from "./DocChatPanel"
import { DocDetailHeader } from "./DocDetailHeader"
import { useDocumentChat } from "./useDocumentChat"

/**
 * 文档归档页（2026-09-16 开放）——左侧文档卡片列表（大面积卡片），右侧文档详情
 * （极简头部 + 「AI 智能介绍」打字机）与「AI 咨询」面板（document 模式）。
 * 列表展示全部文档（2026-09-21 去掉"精选/显示全部"折叠，10 份全部平铺，侧栏计数同步简化）。
 */
export function DocumentsPage() {
  const [docs, setDocs] = useState<KbDocSummary[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [activeDocId, setActiveDocId] = useState<string | null>(null)
  const [detail, setDetail] = useState<KbDocDetail | null>(null)

  const chat = useDocumentChat({ activeDoc: detail })

  // 文档列表（首次加载）
  useEffect(() => {
    let alive = true
    getKbDocuments()
      .then(list => { if (alive) { setDocs(list); setLoading(false) } })
      .catch(() => { if (alive) { setError("文档列表加载失败，请稍后重试"); setLoading(false) } })
    return () => { alive = false }
  }, [])

  // 选中卡片 → 拉取详情
  useEffect(() => {
    if (!activeDocId) return
    let alive = true
    getKbDocument(activeDocId)
      .then(d => { if (alive) setDetail(d) })
      .catch(() => { /* 保持当前详情 */ })
    return () => { alive = false }
  }, [activeDocId])

  // ── 聊天滚动：贴底跟随 + 上滚暂停（与策略管理同款交互） ──
  const chatScrollRef = useRef<HTMLDivElement>(null)
  const chatEndRef = useRef<HTMLDivElement>(null)
  const chatInputRef = useRef<HTMLTextAreaElement>(null)
  const [chatPinnedToBottom, setChatPinnedToBottom] = useState(true)
  const handleChatScroll = () => {
    const el = chatScrollRef.current
    if (!el) return
    setChatPinnedToBottom(el.scrollHeight - el.scrollTop - el.clientHeight < 100)
  }
  useEffect(() => {
    if (chatPinnedToBottom) chatEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [chat.messages, chatPinnedToBottom])

  return (
    <div className="h-full flex min-h-0">
      {/* ── 左：文档卡片列表 ── */}
      <PanelSidebar
        icon={BookOpen}
        title="实验文档归档"
        count={loading ? "加载中…" : `共 ${docs.length} 份`}
      >
        {error && <p className="text-[14px] text-red-500 px-1 py-2">{error}</p>}
        {docs.map(d => (
          <DocCard
            key={d.docId}
            doc={d}
            active={d.docId === activeDocId}
            onClick={() => {
              setActiveDocId(d.docId)
              setTimeout(() => chatInputRef.current?.focus(), 50)
            }}
          />
        ))}
        {!loading && !error && docs.length === 0 && (
          <p className="text-[14px] text-muted-foreground px-1 py-2">知识库暂无文档</p>
        )}
      </PanelSidebar>

      {/* ── 右：详情 + AI 咨询 ── */}
      <div className="flex-1 flex flex-col min-w-0 min-h-0">
        {detail ? (
          <>
            <DocDetailHeader doc={detail} />
            <DocChatPanel
              docTitle={detail.title}
              messages={chat.messages}
              input={chat.input}
              onInputChange={chat.setInput}
              streaming={chat.streaming}
              onSend={chat.handleSend}
              onStop={chat.stopStream}
              scrollRef={chatScrollRef}
              endRef={chatEndRef}
              inputRef={chatInputRef}
              onScroll={handleChatScroll}
            />
          </>
        ) : (
          <DocChatPanel
            docTitle={null}
            messages={[]}
            input=""
            onInputChange={() => {}}
            streaming={false}
            onSend={() => {}}
            onStop={() => {}}
            scrollRef={chatScrollRef}
            endRef={chatEndRef}
            inputRef={chatInputRef}
            onScroll={() => {}}
          />
        )}
      </div>
    </div>
  )
}

/** 文档卡片：单行标题（悬浮跑马灯）+ 产品/平台灰标签副行。 */
function DocCard({ doc, active, onClick }: { doc: KbDocSummary; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={panelCardCls({ active })}>
      <div className={panelIconCls(active)}>
        <FileText size={15} />
      </div>
      <div className="min-w-0 flex-1">
        <MarqueeText
          text={doc.title}
          className={`text-[14px] font-medium leading-snug ${active ? "text-primary" : "text-foreground"}`}
        />
        {/* 副行标签：产品/平台（灰色小标签，与设备/解决方案侧边栏副行同层结构） */}
        {(doc.product || doc.platform) && (
          <div className="flex flex-wrap gap-1 mt-1">
            {doc.product && <CardTag>{doc.product}</CardTag>}
            {doc.platform && <CardTag>{doc.platform}</CardTag>}
          </div>
        )}
      </div>
    </button>
  )
}
