/**
 * 文档咨询聊天编排（仿 useStrategyChat 简化版）——每文档独立内存会话（刷新清空，
 * 与策略管理一致）；SSE 流经共享 stream-turn 引擎合入末条 streaming 消息。
 * document 模式不涉及写操作确认/提问卡，故无提案/表单状态机。
 */

import { useEffect, useRef, useState } from "react"
import type { KbDocDetail } from "@/app/lib/api"
import { streamChat } from "@/app/lib/utils/sse"
import { buildStreamCallbacks } from "@/app/lib/chat/stream-turn"
import { useDelegationSeeds } from "@/app/hooks/useDelegationSeeds"
import { buildDocSessionId, buildDocumentPrompt, makeDocWelcomeMessage, type DocChatMessage } from "./document-model"

export function useDocumentChat({ activeDoc }: { activeDoc: KbDocDetail | null }) {
  const [chats, setChats] = useState<Record<string, DocChatMessage[]>>({})
  const [input, setInput] = useState("")
  const [streaming, setStreaming] = useState(false)
  const abortRef = useRef<AbortController | null>(null)
  const sessionIds = useRef<Record<string, string>>({})

  const docId = activeDoc?.docId ?? null
  // EMS 助手代办问答（原汁原味）：以普通 user/ai 消息对合入，位置 = 欢迎语之后、本面板会话之前
  const { seeds, clearSeeds } = useDelegationSeeds("document", docId)
  const messages: DocChatMessage[] = docId
    ? [...(chats[docId]?.slice(0, 1) ?? []), ...seeds, ...(chats[docId]?.slice(1) ?? [])]
    : []

  // 每文档首条欢迎语（只在该文档会话未初始化时写入；函数式更新防重复）
  useEffect(() => {
    if (activeDoc && !chats[activeDoc.docId]) {
      setChats(prev => prev[activeDoc.docId] ? prev : { ...prev, [activeDoc.docId]: [makeDocWelcomeMessage(activeDoc)] })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeDoc])

  /** 将增量合入指定文档的末条 streaming AI 消息（rAF 引擎的 apply 语义=全量覆盖） */
  const patchLast = (id: string, patch: Partial<DocChatMessage>) => {
    setChats(prev => {
      const msgs = prev[id] ?? []
      const last = msgs[msgs.length - 1]
      if (last?.role === "ai" && last.streaming) {
        return { ...prev, [id]: [...msgs.slice(0, -1), { ...last, ...patch }] }
      }
      return prev
    })
  }

  const appendErrorText = (id: string, msg: string) => {
    setChats(prev => {
      const msgs = prev[id] ?? []
      const last = msgs[msgs.length - 1]
      if (last?.role === "ai" && last.streaming) {
        return { ...prev, [id]: [...msgs.slice(0, -1), { ...last, text: last.text + `\n❌ ${msg}`, streaming: false }] }
      }
      return prev
    })
  }

  const finishStreaming = (id: string) => {
    abortRef.current = null
    setStreaming(false)
    patchLast(id, { streaming: false })
  }

  const handleSend = (raw?: string) => {
    const text = (raw ?? input).trim()
    if (!text || streaming || !activeDoc) return
    const id = activeDoc.docId

    const promptText = buildDocumentPrompt(activeDoc, text)
    setChats(prev => ({
      ...prev,
      [id]: [
        ...(prev[id] ?? []),
        { role: "user", text },
        { id: `doc-send-${Date.now()}`, role: "ai", text: "", process: [], streaming: true },
      ],
    }))
    if (raw === undefined) setInput("")
    setStreaming(true)

    if (abortRef.current) abortRef.current.abort()
    if (!sessionIds.current[id]) sessionIds.current[id] = buildDocSessionId(id)
    abortRef.current = streamChat(
      promptText,
      buildStreamCallbacks({
        idPrefix: `doc-${Date.now()}`,
        apply: (patch) => patchLast(id, { text: patch.text, process: patch.process }),
        trackCharts: false, // 文档页消息模型无 charts 字段
        onDone: () => finishStreaming(id),
        onError: (msg) => {
          appendErrorText(id, msg)
          abortRef.current = null
          setStreaming(false)
        },
      }),
      { document: true, sessionId: sessionIds.current[id] },
    )
  }

  /** 停止生成：abort + 清 streaming 标志（防末条消息 spinner 残留） */
  const stopStream = () => {
    if (abortRef.current) {
      abortRef.current.abort()
      abortRef.current = null
    }
    setStreaming(false)
    if (docId) patchLast(docId, { streaming: false })
  }

  /** 清理当前文档对话（重置为欢迎语；代办问答种子一并收起，重选该文档时重新合入） */
  const clearChat = () => {
    if (!activeDoc) return
    if (abortRef.current) {
      abortRef.current.abort()
      abortRef.current = null
      setStreaming(false)
    }
    clearSeeds()
    setChats(prev => ({ ...prev, [activeDoc.docId]: [makeDocWelcomeMessage(activeDoc)] }))
  }

  return {
    messages,
    input,
    setInput,
    streaming,
    handleSend,
    stopStream,
    clearChat,
  }
}
