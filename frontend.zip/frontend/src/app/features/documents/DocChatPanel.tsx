import type { RefObject } from "react"
import { Bot } from "lucide-react"
import ReactMarkdown from "react-markdown"
import remarkGfm from "remark-gfm"

import { ChatComposer } from "@/app/components/shared/ChatComposer"
import { ChatPromptChips } from "@/app/components/shared/ChatPromptChips"
import { StreamingIndicator } from "@/app/components/shared/StreamingIndicator"
import { AIThinkingTrace } from "@/app/components/shared/AIThinkingTrace"
import { DOCUMENT_PROMPT_CHIPS, type DocChatMessage } from "./document-model"
import { isDelegationSeedId } from "@/app/hooks/useDelegationSeeds"

/**首次咨询的默认问题 = 词条池第 1 条；回答末尾的推荐 = 其余词条 */
const DEFAULT_QUESTION = DOCUMENT_PROMPT_CHIPS[0].prompt
const FOLLOW_UP_PROMPTS = DOCUMENT_PROMPT_CHIPS.slice(1)

/**
 * 文档咨询聊天面板——消息流（流式纯文本 / 结束 markdown 一次性渲染）、
 * 输入区与操作栏只负责渲染与回调上抛；状态与 SSE 编排由 useDocumentChat 持有。
 * 与策略管理面板的差异：document 模式无写操作确认卡/提问卡，故不渲染决策卡。
 */
export function DocChatPanel({
  docTitle,
  messages,
  input,
  onInputChange,
  streaming,
  onSend,
  onStop,
  scrollRef,
  endRef,
  inputRef,
  onScroll,
}: {
  docTitle: string | null
  messages: DocChatMessage[]
  input: string
  onInputChange: (value: string) => void
  streaming: boolean
  onSend: (raw?: string) => void
  onStop: () => void
  scrollRef: RefObject<HTMLDivElement | null>
  endRef: RefObject<HTMLDivElement | null>
  inputRef: RefObject<HTMLTextAreaElement | null>
  onScroll: () => void
}) {
  // 首次咨询（会话内还没有任何用户提问，刷新内存即重置）：占位文字即默认问题，
  // 空输入直接 Enter/点发送即可发出；首次回答结束后在其下方给推荐追问
  const isFirstConsult = !messages.some(m => m.role === "user")
  const lastMsg = messages[messages.length - 1]
  const showFollowUps = !!docTitle && !streaming
    && messages.filter(m => m.role === "user").length === 1
    && lastMsg?.role === "ai" && !lastMsg.streaming

  return (
    <div className="flex-1 flex flex-col min-h-0">
      {/* Action bar */}
      <div className="px-4 py-2 border-b border-border flex items-center gap-2 shrink-0 bg-card/30">
        <span className="text-[14px] font-medium text-muted-foreground">AI 咨询</span>
      </div>

      {/* Messages */}
      <div ref={scrollRef} onScroll={onScroll} className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
        {!docTitle ? (
          <div className="flex items-center justify-center h-full text-center">
            <div className="space-y-3">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                <Bot size={26} className="text-blue-600 dark:text-blue-400" />
              </div>
              <p className="text-[14px] font-medium text-muted-foreground">点击左侧文档卡片开始咨询</p>
              <p className="text-[14px] text-muted-foreground">对话记录仅保存在内存中，刷新页面后自动清空</p>
            </div>
          </div>
        ) : (
          messages.map((m, i) => (
            // 2026-09-17 AI Native 平文形态：AI 回复无卡片直接打字 + 浅色思考/工具轨迹行（完成后自动收起）；
            // 用户消息保持右侧白底卡片
            <div key={m.id ?? i} className={`flex flex-col gap-1.5 ${m.role === "user" ? "items-end" : "items-start"}`}>
              {m.role === "user" ? (
                <div className="flex flex-col items-end gap-1 max-w-[92%]">
                  {isDelegationSeedId(m.id) && (
                    <span className="text-[12px] text-muted-foreground">EMS 助手代问（委派记录）</span>
                  )}
                  <div className="px-3 py-2 rounded-2xl text-[14px] leading-relaxed bg-card border border-border text-foreground rounded-br-sm">
                    <p className="whitespace-pre-wrap">{m.text}</p>
                  </div>
                </div>
              ) : (
                <>
                  {(m.process?.length ?? 0) > 0 && (
                    <AIThinkingTrace items={m.process!} streaming={!!m.streaming} />
                  )}
                  {/* 行距 1.9 + 段落/列表间距（2026-09-17 用户反馈：行距偏密；preflight 清零了 markdown 段落边距，需显式补回） */}
                  <div className="w-full max-w-3xl text-[14px] leading-[1.9] space-y-3 text-foreground [&_li]:my-1">
                    {m.streaming ? (
                      // 流式期间轻量纯文本渲染（避免 ReactMarkdown 每次 delta 全量解析卡顿）；结束后一次性 markdown
                      <p className="whitespace-pre-wrap text-[14px] leading-[1.9]">{m.text}</p>
                    ) : (
                      <div className="doc-chat-markdown space-y-3 [&_li]:my-1">
                        <ReactMarkdown
                          remarkPlugins={[remarkGfm]}
                          components={{
                            a: ({ children, ...props }) => <a {...props} target="_blank" rel="noreferrer" className="text-primary underline underline-offset-2" />,
                            code: ({ className, children, ...props }) => <code {...props} className={`${className ?? ""} rounded bg-muted px-1 py-0.5 font-mono text-[0.8125em]`} />,
                            table: ({ children }) => <div className="my-2 overflow-x-auto"><table className="w-full border-collapse text-left text-[14px]">{children}</table></div>,
                            th: ({ children }) => <th className="border border-border bg-muted px-2 py-1 font-semibold">{children}</th>,
                            td: ({ children }) => <td className="border border-border px-2 py-1">{children}</td>,
                          }}
                        >
                          {m.text}
                        </ReactMarkdown>
                      </div>
                    )}
                    {m.streaming && <StreamingIndicator text={m.text} process={m.process} />}
                  </div>
                </>
              )}
            </div>
          ))
        )}
        {/* 首次回答结束 → 结论下方给推荐追问（Doubao 式；用户追问一次后消失）。
         * 置于 endRef（自动滚动锚点）之前，保证出现时完整落在视口内 */}
        {showFollowUps && (
          <div className="pt-1">
            <ChatPromptChips prompts={FOLLOW_UP_PROMPTS} onPick={onSend} disabled={streaming} />
          </div>
        )}
        <div ref={endRef} />
      </div>

      {/* Input（composer：自动增高 + 内嵌工具栏；首次咨询时占位文字即默认问题，空输入可直接发送） */}
      <div className="px-4 py-3 shrink-0">
        <ChatComposer
          inputRef={inputRef}
          value={input}
          onChange={onInputChange}
          onSend={onSend}
          onStop={onStop}
          streaming={streaming}
          disabled={!docTitle}
          placeholder={!docTitle
            ? "请先点击左侧文档卡片"
            : streaming
              ? "AI 正在回复..."
              : isFirstConsult ? DEFAULT_QUESTION : "针对这份文档提问，例如：核心测试结论是什么？"}
          phantomQuestion={docTitle && isFirstConsult ? DEFAULT_QUESTION : undefined}
        />
      </div>
    </div>
  )
}
