import { RotateCcw, Sparkles } from "lucide-react"

import type { KbDocDetail } from "@/app/lib/api"
import { useDocIntro } from "./useDocIntro"

/**
 * 文档详情头（2026-09-16 用户反馈重构）——默认态保持极简：标题 + 徽标 + 「AI 智能介绍」按钮，
 * 不再静态铺开介绍/章节（文字多会失去高级感）。点击按钮后：
 *   ① 确定性基础信息（元数据/签名/章节结构）以打字机逐字展示（无需 AI 理解，即时）；
 *   ② 打完后自动请求 AI 两三句简报（流式渲染，即天然打字感）。
 */
export function DocDetailHeader({ doc }: { doc: KbDocDetail }) {
  const intro = useDocIntro(doc)
  const typing = intro.phase === "typing"
  const aiStreaming = intro.phase === "ai"

  return (
    <div className="shrink-0 border-b border-border bg-card/40 max-h-[46%] overflow-y-auto">
      <div className="px-5 py-4 space-y-3">
        {/* 极简头部：标题 + 徽标 + 介绍按钮 */}
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <h1 className="text-[14px] font-semibold text-foreground leading-snug">{doc.title}</h1>
            <div className="flex flex-wrap items-center gap-1.5 mt-2">
              {doc.product && <span className="text-[14px] px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300 font-medium">{doc.product}</span>}
              {doc.platform && <span className="text-[14px] px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 dark:bg-purple-950/40 dark:text-purple-300 font-medium">{doc.platform}</span>}
              <span className={`text-[14px] px-2 py-0.5 rounded-md font-medium ${doc.docType.includes("SOP") ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300" : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300"}`}>{doc.docType || "文档"}</span>
              {doc.conclusion && <span className="text-[14px] px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 font-medium">结论：{doc.conclusion}</span>}
            </div>
          </div>
          <button
            onClick={intro.start}
            className="shrink-0 inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-primary/90 text-white text-[14px] font-medium hover:bg-primary transition-colors cursor-pointer shadow-sm shadow-primary/20"
          >
            {intro.isActive ? <RotateCcw size={13} /> : <Sparkles size={13} />}
            {intro.phase === "done" ? "重新介绍" : intro.isActive ? "重新播放" : "AI 智能介绍"}
          </button>
        </div>

        {/* 智能介绍区：打字机基础信息 + AI 简报 */}
        {intro.isActive && (
          <div className="rounded-xl border border-border bg-background/80 px-4 py-3.5 space-y-3 shadow-sm">
            <pre className="whitespace-pre-wrap break-words font-sans text-[14px] leading-relaxed text-foreground/85 m-0">
              {intro.typed}
              {typing && <span className="inline-block w-[7px] h-[13px] bg-primary/70 animate-pulse align-middle ml-0.5 rounded-[1px]" />}
            </pre>

            {(aiStreaming || intro.phase === "done") && (
              <div className="border-t border-dashed border-border pt-3">
                <p className="text-[14px] font-medium text-muted-foreground mb-1.5 flex items-center gap-1.5">
                  <Sparkles size={11} className="text-primary" />AI 简报
                </p>
                <p className="text-[14px] leading-relaxed text-foreground/90 whitespace-pre-wrap">
                  {intro.aiText}
                  {aiStreaming && <span className="inline-block w-[7px] h-[13px] bg-primary/70 animate-pulse align-middle ml-0.5 rounded-[1px]" />}
                  {intro.aiError && <span className="text-red-500">生成失败：{intro.aiError}（可点击「重新介绍」重试）</span>}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
