/**
 * 文档归档页纯函数层——欢迎语、发送上下文拼装、会话 ID 派生。
 * 全部无状态无副作用，页面与编排 hook 共用（与策略管理 strategy-model 同模式）。
 */

import type { KbDocDetail, KbDocSummary } from "@/app/lib/api"

export interface DocChatMessage {
  id?: string
  role: "user" | "ai"
  text: string
  /**过程项（thinking/工具/来源行），与 stream-turn 引擎 TurnProcessItem 结构兼容 */
  process?: Array<{ id: string; type: "thinking" | "tool"; text: string }>
  streaming?: boolean
}

/** *文档会话 ID：`doc-<短哈希>-<随机>`。
 * `doc-` 前缀由后端 session-mode 识别为 document 模式（独立提示词 + 审计隔离落盘）；
 * 短哈希让同文档会话可读，随机后缀保证每用户每页独立（内存态会话，刷新即新）。 */
export function buildDocSessionId(docId: string): string {
  let h = 0
  for (let i = 0; i < docId.length; i++) h = (Math.imul(31, h) + docId.charCodeAt(i)) | 0
  return `doc-${Math.abs(h).toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

/**欢迎语（选中文档后的首条 AI 消息） */
export function makeDocWelcomeMessage(doc: KbDocDetail): DocChatMessage {
  const meta = [doc.product, doc.platform, doc.docType].filter(Boolean).join(" · ")
  return {
    role: "ai",
    text: `你好！当前文档《${doc.title}》（${meta}，共 ${doc.sections.length} 章节${doc.conclusion ? `，结论：${doc.conclusion}` : ""}）。\n\n你可以问我这份文档的核心内容、章节构成与测试结论，也可以让我做跨文档对比或按 SOP 指导操作步骤。涉及文档内容的问题我会先检索知识库再回答，并标注来源。`,
  }
}

/** *发送消息的上下文拼装（当前文档信息 + 回答要求 + 用户问题）——
 * 展示层仍显示用户原文（前端消息列表自行维护），仅发送给后端的文本带上下文。 */
export function buildDocumentPrompt(doc: KbDocDetail, text: string): string {
  return [
    `【当前文档】《${doc.title}》（docId: ${doc.docId}）`,
    `文档信息: ${[doc.product, doc.platform, doc.docType].filter(Boolean).join(" · ")}${doc.conclusion ? `；测试结论: ${doc.conclusion}` : ""}；章节数: ${doc.sections.length}`,
    ``,
    `回答要求: 只输出面向业务人员的最终回答；涉及文档内容必须先检索知识库（kbName 传 "SOP知识库"）并保留来源标注；检索不到就明说，不要编造。`,
    ``,
    `用户问题: ${text}`,
  ].join("\n")
}

// ─── 固定提示词（WorkBuddy 式，悬浮输入框上方；SOP 与测试报告通用）────────────

/**文档咨询固定提示词：label = 胶囊短文案，prompt = 实际发送问题 */
export const DOCUMENT_PROMPT_CHIPS: ReadonlyArray<{ label: string; prompt: string }> = [
  { label: "总结核心内容", prompt: "请总结这份文档的核心内容" },
  { label: "关键步骤与参数", prompt: "这份文档涉及哪些关键实验步骤与参数？" },
  { label: "适用样本与项目", prompt: "这份文档适用于哪些样本类型和检测项目？" },
  { label: "注意事项与风险", prompt: "按照这份文档操作，有哪些注意事项或风险点？" },
]

// ─── 精选展示（2026-09-16 用户反馈：SOP 为主、实验报告只留经典示范）───────────

/** 经典测试报告规则（产品 × 平台，每组合取第一份）——列表默认只展示"全部 SOP + 精选报告"，
 * "显示全部"切换可展开完整目录；SOP 永远优先置顶。 */
export const FEATURED_REPORT_KEYS: ReadonlyArray<{ product: string; platform: string }> = [
  { product: "NIFTY", platform: "GenSIRO-16" },
  { product: "CNVseq", platform: "GenSIRO-48" },
  { product: "PMseq-DNA", platform: "GenSIRO-48" },
  { product: "PTseq-TB", platform: "GenSIRO-48" },
]

export function curateFeaturedDocs(docs: KbDocSummary[]): KbDocSummary[] {
  const sops = docs.filter((d) => d.docType.includes("SOP"))
  const reports = FEATURED_REPORT_KEYS
    .map((k) => docs.find((d) => d.product === k.product && d.platform === k.platform && !d.docType.includes("SOP")))
    .filter((d): d is KbDocSummary => !!d)
  const seen = new Set<string>()
  return [...sops, ...reports].filter((d) => {
    if (seen.has(d.docId)) return false
    seen.add(d.docId)
    return true
  })
}

/** AI 智能介绍的基础信息打字文本——确定性内容（元数据/签名/章节结构），纯前端逐字打出，
 * 无需 AI 理解；AI 简介随后流式补充（两三句）。 */
export function buildDocBasicsText(doc: KbDocDetail): string {
  const lines: string[] = []
  lines.push(`《${doc.title}》`)
  lines.push("")
  const meta: string[] = []
  if (doc.docType) meta.push(`类型 ${doc.docType}`)
  if (doc.product) meta.push(`产品 ${doc.product}`)
  if (doc.platform) meta.push(`平台 ${doc.platform}`)
  if (meta.length) lines.push(meta.join("　·　"))
  if (doc.conclusion) lines.push(`测试结论 ${doc.conclusion}`)
  const signers = [
    doc.authors.length ? `编制 ${doc.authors.join("、")}` : "",
    doc.reviewers.length ? `审核 ${doc.reviewers.join("、")}` : "",
    doc.approvers.length ? `批准 ${doc.approvers.join("、")}` : "",
  ].filter(Boolean)
  if (signers.length) lines.push(signers.join("　·　"))
  if (doc.equipment) lines.push(`设备 ${doc.equipment}`)
  lines.push("")
  lines.push(`章节结构（共 ${doc.sections.length} 节）`)
  doc.sections.forEach((s, i) => lines.push(`${String(i + 1).padStart(2, "0")}　${s}`))
  return lines.join("\n")
}

/** AI 初步介绍的发送指令（独立会话；两三句、80 字内、无列表无来源行） */
export function buildDocIntroPrompt(doc: KbDocDetail): string {
  return [
    `【当前文档】《${doc.title}》（docId: ${doc.docId}）`,
    `文档信息: ${[doc.product, doc.platform, doc.docType].filter(Boolean).join(" · ")}${doc.conclusion ? `；测试结论: ${doc.conclusion}` : ""}`,
    ``,
    `请用两三句话（80 字以内）简要介绍这份文档的核心作用与主要内容，帮助用户快速了解它。直接输出介绍文字：不要标题、不要列表、不要来源标注行。`,
  ].join("\n")
}
