import React, { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router'
import { useAuth } from '@/app/hooks/useAuth'
import { loginSchema } from '@/app/lib/validation'
import { Button } from '@/app/components/ui/button'
import { Input } from '@/app/components/ui/input'
import { Card, CardContent, CardHeader } from '@/app/components/ui/card'
import { useConfirm } from '@/app/components/shared/ConfirmDialog'
import { getApiConfig } from '@/app/lib/api/config'
import { ChevronDown } from 'lucide-react'
import labelFull from '@/assets/icons/label-full.png'
import userIcon from '@/assets/icons/user.png'
import passwordIcon from '@/assets/icons/password.png'
import bgImage from '@/assets/ems-bg-light.png'

// 预设快捷登录账号：默认 admin，登录页挂载时从后端 /auth/presets 拉取
// （admin + 当前医院档案的初始账户；2026-09-17 档案化后随档案动态变化）
const FALLBACK_PRESET_ACCOUNTS: Record<string, { password: string; label: string }> = {
  admin: { password: 'admin123', label: '管理员' },
}

export function LoginPage() {
  const { login, isAuthenticated } = useAuth()
  const navigate = useNavigate()
  const confirm = useConfirm()
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('admin123')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [showUserList, setShowUserList] = useState(false)
  const [presetAccounts, setPresetAccounts] = useState(FALLBACK_PRESET_ACCOUNTS)
  const userListRef = useRef<HTMLDivElement>(null)

  // 拉取快捷登录账户（admin + 当前档案初始账户）
  useEffect(() => {
    fetch(`${getApiConfig().baseUrl}/auth/presets`).then(r => r.json()).then(d => {
      if (Array.isArray(d.data) && d.data.length > 0) {
        setPresetAccounts(Object.fromEntries(d.data.map((a: { username: string; password: string; label: string }) => [a.username, { password: a.password, label: a.label }])))
      }
    }).catch(() => { /* 后端不可用时保留回退 */ })
  }, [])

  // 点击外部关闭账号下拉
  useEffect(() => {
    if (!showUserList) return
    const handleMouseDown = (e: MouseEvent) => {
      if (userListRef.current && !userListRef.current.contains(e.target as Node)) {
        setShowUserList(false)
      }
    }
    document.addEventListener('mousedown', handleMouseDown)
    return () => document.removeEventListener('mousedown', handleMouseDown)
  }, [showUserList])

  const selectPresetUser = (name: string) => {
    const preset = presetAccounts[name]
    if (!preset) return
    setUsername(name)
    setPassword(preset.password)
    setError('')
    setShowUserList(false)
  }

  useEffect(() => {
    if (isAuthenticated) {
      navigate('/', { replace: true })
    }
  }, [isAuthenticated, navigate])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    const validation = loginSchema.safeParse({ username, password })
    if (!validation.success) {
      setError(validation.error.issues[0]?.message ?? '输入有误')
      return
    }

    setLoading(true)
    const result = await login({ username, password })
    setLoading(false)

    if (result.success) return

    // 账号已有用户在线（code "1"）→ 弹确认：顶下线 or 取消登录
    if (result.code === '1') {
      const onlineIp = (result.details as { data?: { onlineIp?: string } })?.data?.onlineIp ?? '未知'
      const ok = await confirm({
        title: '该账号已有用户在线',
        message: `账号 ${username} 正在被另一个 IP（${onlineIp}）使用。\n顶下线并登录？`,
        confirmText: '顶下线并登录',
        cancelText: '取消登录',
      })
      if (!ok) return
      setLoading(true)
      const forceResult = await login({ username, password, force: true })
      setLoading(false)
      if (!forceResult.success) setError(forceResult.error ?? '登录失败')
      return
    }

    setError(result.error ?? '登录失败')
  }

  return (
    <div className="relative min-h-screen bg-cover bg-center flex items-center justify-end" style={{ backgroundImage: `url(${bgImage})` }}>
      {/* 登录框：450×520px，右对齐，左侧为背景图 */}
      <Card className="w-[450px] h-[520px] mr-[120px] rounded-2xl shadow-2xl bg-card/60 backdrop-blur-sm border-border/50">
        <CardHeader className="text-center pt-12 pb-6">
          <img src={labelFull} alt="EMS" className="mx-auto mb-4 h-28 object-contain" />
        </CardHeader>
        <CardContent className="px-12">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div ref={userListRef}>
              <div className="flex items-center gap-2">
                <img src={userIcon} alt="" className="w-5 h-5 shrink-0 object-contain" />
                <div className="relative flex-1">
                  <Input
                    id="username"
                    type="text"
                    placeholder="请输入用户名"
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value)
                      setError('')
                    }}
                    onFocus={() => setShowUserList(true)}
                    autoComplete="username"
                    className="w-full h-[40px] pr-10 text-base rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => setShowUserList((v) => !v)}
                    aria-label="选择账号"
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                  >
                    <ChevronDown size={16} className={`transition-transform ${showUserList ? "rotate-180" : ""}`} />
                  </button>
                </div>
              </div>
              {/* 账号下拉：预设账号始终同时显示（不随输入过滤），当前匹配项高亮 */}
              {showUserList && (
                <div className="absolute z-10 w-full mt-2 bg-card border border-border rounded-lg shadow-lg overflow-hidden">
                  {Object.entries(presetAccounts).map(([name, acc]) => (
                    <button
                      key={name}
                      type="button"
                      onClick={() => selectPresetUser(name)}
                      className={`w-full flex items-center justify-between px-4 py-3 text-sm hover:bg-muted cursor-pointer ${
                        username === name ? "bg-primary/5" : ""
                      }`}
                    >
                      <span className="font-medium">{acc.label}</span>
                      <span className="font-mono text-xs text-muted-foreground">{name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="flex items-center gap-2">
              <img src={passwordIcon} alt="" className="w-5 h-5 shrink-0 object-contain" />
              <Input
                id="password"
                type="password"
                placeholder="请输入密码"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                className="flex-1 h-[40px] text-base rounded-lg"
              />
            </div>
            {error && (
              <p className="text-sm text-destructive">{error}</p>
            )}
            <Button type="submit" className="w-full h-[40px] mt-4 text-base font-medium rounded-lg bg-primary/70! hover:bg-primary/90! text-primary-foreground!" disabled={loading}>
              {loading ? '登录中...' : '登录'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
