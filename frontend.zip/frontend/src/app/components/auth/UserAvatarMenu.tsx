import { useNavigate } from 'react-router'
import { useAuth } from '../../hooks/useAuth'
import { User, LogOut, UserCircle } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu'

/**
 * User avatar dropdown menu shown in the TopBar.
 * Options: 个人信息, 退出登录
 */
export function UserAvatarMenu() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  if (!user) return null

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-1.5 pl-2 border-l border-border hover:opacity-80 transition-opacity cursor-pointer outline-none">
          <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center">
            <User size={13} className="text-white" />
          </div>
          <span className="text-sm text-foreground font-medium hidden sm:inline">{user.displayName}</span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-40">
        <DropdownMenuItem onClick={() => navigate('/user-info')}>
          <UserCircle size={14} className="mr-2" />
          个人信息
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={logout} className="text-destructive focus:text-destructive">
          <LogOut size={14} className="mr-2" />
          退出登录
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
