import React, { useState } from 'react'
import { useAuth } from '../../hooks/useAuth'
import { changePasswordSchema } from '../../lib/validation'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Label } from '../ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card'
import { User, Mail, Phone, Shield, KeyRound } from 'lucide-react'

export function UserInfoPage() {
  const { user, changePassword } = useAuth()
  const [showPasswordForm, setShowPasswordForm] = useState(false)
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [loading, setLoading] = useState(false)

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSuccess('')

    const validation = changePasswordSchema.safeParse({ currentPassword, newPassword, confirmPassword })
    if (!validation.success) {
      setError(validation.error.issues[0]?.message ?? '输入有误')
      return
    }

    setLoading(true)
    const result = await changePassword({ currentPassword, newPassword, confirmPassword })
    setLoading(false)

    if (result.success) {
      setSuccess('密码修改成功')
      setCurrentPassword('')
      setNewPassword('')
      setConfirmPassword('')
      setShowPasswordForm(false)
    } else {
      setError(result.error ?? '密码修改失败')
    }
  }

  if (!user) return null

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6 overflow-y-auto h-full">
      <h1 className="text-xl font-semibold text-foreground">个人信息</h1>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">基本信息</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-full bg-primary flex items-center justify-center">
              <User size={24} className="text-white" />
            </div>
            <div>
              <p className="font-medium text-foreground">{user.displayName}</p>
              <p className="text-sm text-muted-foreground">@{user.username}</p>
            </div>
          </div>

          <div className="grid gap-3 pt-2">
            <div className="flex items-center gap-2 text-sm">
              <Shield size={14} className="text-muted-foreground" />
              <span className="text-muted-foreground">角色：</span>
              <span className="text-foreground">{user.role}</span>
            </div>
            {user.email && (
              <div className="flex items-center gap-2 text-sm">
                <Mail size={14} className="text-muted-foreground" />
                <span className="text-muted-foreground">邮箱：</span>
                <span className="text-foreground">{user.email}</span>
              </div>
            )}
            {user.phone && (
              <div className="flex items-center gap-2 text-sm">
                <Phone size={14} className="text-muted-foreground" />
                <span className="text-muted-foreground">电话：</span>
                <span className="text-foreground">{user.phone}</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">安全设置</CardTitle>
          {!showPasswordForm && (
            <Button variant="outline" size="sm" onClick={() => setShowPasswordForm(true)}>
              <KeyRound size={14} className="mr-1" />
              修改密码
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {success && <p className="text-sm text-green-600 mb-3">{success}</p>}
          {showPasswordForm && (
            <form onSubmit={handleChangePassword} className="space-y-4 max-w-sm">
              <div className="space-y-2">
                <Label htmlFor="current-pwd">当前密码</Label>
                <Input
                  id="current-pwd"
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-pwd">新密码</Label>
                <Input
                  id="new-pwd"
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-pwd">确认新密码</Label>
                <Input
                  id="confirm-pwd"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </div>
              {error && <p className="text-sm text-destructive">{error}</p>}
              <div className="flex gap-2">
                <Button type="submit" disabled={loading}>
                  {loading ? '提交中...' : '确认修改'}
                </Button>
                <Button type="button" variant="ghost" onClick={() => { setShowPasswordForm(false); setError('') }}>
                  取消
                </Button>
              </div>
            </form>
          )}
          {!showPasswordForm && !success && (
            <p className="text-sm text-muted-foreground">点击"修改密码"按钮可以更改您的登录密码。</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
