

/**
 * 样本/任务状态徽章（业务组件，收编自原 EMSComponents）。
 * 色板源自设计稿状态映射，新增状态时在此补充。
 */
export function SampleStatusBadge({ status }: { status: string }) {
  const map: Record<string, { bg: string; text: string; dot: string }> = {
    // Specimen Statuses（蓝色系随 Omics 换肤：bg-primary-light-9/text-primary-active/dot-primary，亮暗自动适配）
    "待实验":   { bg: "bg-gray-100", text: "text-gray-600",   dot: "bg-gray-400" },
    "实验中":   { bg: "bg-primary-light-9", text: "text-primary-active", dot: "bg-primary" },
    "实验完成": { bg: "bg-emerald-50",text: "text-emerald-700",dot: "bg-emerald-500" },
    "实验失败": { bg: "bg-red-50",   text: "text-red-700",    dot: "bg-red-500" },
    "待测序":   { bg: "bg-amber-50", text: "text-amber-700",  dot: "bg-amber-500" },
    "实验异常": { bg: "bg-orange-50",text: "text-orange-700", dot: "bg-orange-500" },

    // Sample / Other Statuses
    "已收样":   { bg: "bg-slate-100",text: "text-slate-600",  dot: "bg-slate-400" },
    "已到样":   { bg: "bg-gray-100", text: "text-gray-600",   dot: "bg-gray-400" },
    "已培养":   { bg: "bg-cyan-50",  text: "text-cyan-700",   dot: "bg-cyan-500" },
    "已分血":   { bg: "bg-primary-light-9", text: "text-primary-active", dot: "bg-primary" },
    "培养中":   { bg: "bg-cyan-50",  text: "text-cyan-700",   dot: "bg-cyan-500" },
    "培养完成": { bg: "bg-emerald-50",text: "text-emerald-700",dot: "bg-emerald-500" },
    "需培养":   { bg: "bg-purple-50", text: "text-purple-700", dot: "bg-purple-500" },
    "已备份":   { bg: "bg-slate-100",text: "text-slate-500",  dot: "bg-slate-300" },
    "QC中":     { bg: "bg-amber-50", text: "text-amber-700",  dot: "bg-amber-500" },
    "待启动":   { bg: "bg-gray-100", text: "text-gray-600",   dot: "bg-gray-400" },
    "就绪":     { bg: "bg-gray-100", text: "text-gray-600",   dot: "bg-gray-400" },
    "完成":     { bg: "bg-emerald-50",text: "text-emerald-700",dot: "bg-emerald-500" },
    "已完成":   { bg: "bg-emerald-50",text: "text-emerald-700",dot: "bg-emerald-500" },
    "异常":     { bg: "bg-red-50",   text: "text-red-700",    dot: "bg-red-500" },

    // SIRO Host-Reported Experiment Task Status（siro-server STATUS_TO_EMS 映射）
    "运行中":   { bg: "bg-primary-light-9", text: "text-primary-active", dot: "bg-primary" },
    "已暂停":   { bg: "bg-amber-50", text: "text-amber-700",  dot: "bg-amber-500" },
    "失败":     { bg: "bg-red-50",   text: "text-red-700",    dot: "bg-red-500" },
    "已终止":   { bg: "bg-slate-100",text: "text-slate-600",  dot: "bg-slate-400" },

    // Schedule Claim Status（上位机认领后 → 已认领）
    "待认领":   { bg: "bg-amber-50", text: "text-amber-700",  dot: "bg-amber-500" },
    "已认领":   { bg: "bg-emerald-50",text: "text-emerald-700",dot: "bg-emerald-500" },
  };
  const s = map[status] ?? { bg: "bg-gray-100", text: "text-gray-600", dot: "bg-gray-400" };
  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${s.bg} ${s.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
      {status}
    </span>
  );
}

export function LevelBadge({ level }: { level: string }) {
  if (level === "高") return <span className="inline-flex px-2 py-0.5 rounded text-xs font-medium bg-red-50 text-red-700">高</span>;
  if (level === "中") return <span className="inline-flex px-2 py-0.5 rounded text-xs font-medium bg-amber-50 text-amber-700">中</span>;
  return <span className="inline-flex px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-600">低</span>;
}
