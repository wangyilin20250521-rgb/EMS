import type { ReactNode } from "react";
import { AlertCircle, ArrowUpDown, Clock3 } from "lucide-react";

export interface DataTableColumn<T> {
  key: string;
  title: string;
  sortable?: boolean;
  align?: "left" | "center" | "right";
  width?: string;
  /** 编号规范：font-mono text-xs */
  mono?: boolean;
  /** 主键蓝色链接样式 */
  link?: boolean;
  ellipsis?: boolean;
  render?: (row: T) => ReactNode;
}

export interface DataTableProps<T> {
  columns: DataTableColumn<T>[];
  rows: T[];
  rowKey: (row: T) => string;
  /** 序号列 */
  indexColumn?: boolean;
  /** 行警示图标：normal 无图标 / warning 琥珀 / overdue 红 */
  warnIcon?: (row: T) => "normal" | "warning" | "overdue";
  /** 整行点击（跳详情等） */
  onRowClick?: (row: T) => void;
  emptyText?: string;
  /** 空行占位填充至 N 行（保持卡片高度稳定） */
  fillEmptyTo?: number;
  loading?: boolean;
}

const ALIGN_CLASSES: Record<NonNullable<DataTableColumn<unknown>["align"]>, string> = {
  left: "text-left",
  center: "text-center",
  right: "text-right",
};

function WarnIcon({ flag }: { flag: "normal" | "warning" | "overdue" }) {
  if (flag === "overdue") return <Clock3 size={13} className="text-red-500 shrink-0" aria-label="超期" />;
  if (flag === "warning") return <AlertCircle size={13} className="text-amber-500 shrink-0" aria-label="异常" />;
  return null;
}

/**
 * 配置化数据表格通用模式：列配置（sortable/align/mono/link/ellipsis/render）、
 * 序号列、行警示图标、空状态、整行点击。首页与后续列表页共用。
 */
export function DataTable<T>({
  columns,
  rows,
  rowKey,
  indexColumn = false,
  warnIcon,
  onRowClick,
  emptyText = "暂无数据",
  fillEmptyTo = 0,
  loading = false,
}: DataTableProps<T>) {
  const fillerCount = Math.max(0, fillEmptyTo - rows.length);

  return (
    <div className="w-full overflow-x-auto">
      <table className="w-full text-xs border-collapse">
        <thead>
          <tr className="bg-muted/50">
            {indexColumn && (
              <th className="px-3 py-2 text-left font-medium text-muted-foreground whitespace-nowrap w-10">#</th>
            )}
            {warnIcon && <th className="px-1 py-2 w-6" aria-label="警示" />}
            {columns.map(col => (
              <th
                key={col.key}
                style={col.width ? { width: col.width } : undefined}
                className={`px-3 py-2 font-medium text-muted-foreground whitespace-nowrap ${ALIGN_CLASSES[col.align ?? "left"]}`}
              >
                <span className="inline-flex items-center gap-1">
                  {col.title}
                  {col.sortable && <ArrowUpDown size={11} className="opacity-50" aria-hidden />}
                </span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, idx) => {
            const flag = warnIcon?.(row) ?? "normal";
            return (
              <tr
                key={rowKey(row)}
                onClick={onRowClick ? () => onRowClick(row) : undefined}
                className={`border-b border-border/60 last:border-b-0 transition-colors ${
                  onRowClick ? "cursor-pointer hover:bg-primary/5" : "hover:bg-muted/30"
                }`}
              >
                {indexColumn && (
                  <td className="px-3 py-2.5 text-muted-foreground tabular-nums">{idx + 1}</td>
                )}
                {warnIcon && (
                  <td className="px-1 py-2.5">
                    <WarnIcon flag={flag} />
                  </td>
                )}
                {columns.map(col => {
                  const content = col.render ? col.render(row) : (row as Record<string, unknown>)[col.key];
                  return (
                    <td
                      key={col.key}
                      className={`px-3 py-2.5 text-foreground ${ALIGN_CLASSES[col.align ?? "left"]} ${
                        col.mono ? "font-mono text-xs" : ""
                      } ${col.link ? "text-primary hover:underline" : ""} ${
                        col.ellipsis ? "max-w-40 truncate" : ""
                      }`}
                      title={col.ellipsis && typeof content === "string" ? content : undefined}
                    >
                      {content as ReactNode}
                    </td>
                  );
                })}
              </tr>
            );
          })}
          {rows.length === 0 && !loading && (
            <tr>
              <td
                colSpan={columns.length + (indexColumn ? 1 : 0) + (warnIcon ? 1 : 0)}
                className="px-3 py-8 text-center text-muted-foreground"
              >
                {emptyText}
              </td>
            </tr>
          )}
          {fillerCount > 0 &&
            Array.from({ length: fillerCount }, (_, i) => (
              <tr key={`filler-${i}`} className="border-b border-border/60 last:border-b-0">
                {indexColumn && <td className="px-3 py-2.5">&nbsp;</td>}
                {warnIcon && <td className="px-1 py-2.5" />}
                {columns.map(col => (
                  <td key={col.key} className="px-3 py-2.5">
                    &nbsp;
                  </td>
                ))}
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}
