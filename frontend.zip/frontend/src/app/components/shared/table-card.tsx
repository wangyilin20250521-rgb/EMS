import type { ReactNode } from "react";
import { Card } from "@/app/components/ui/card";
import { cn } from "@/app/components/ui/utils";

/**
 * 表格卡片标准壳（2026-08-28 定稿，全站单卡片页面统一引用，页面不再各自画样式）：
 * 页面仅一个大卡片 = 顶部信息栏 + 内容区（表格等）+ 底部信息栏（分页等），
 * 高度参数（pt-3 / h-8 行高 / pb-3.5 / pb-3.5 底栏）全部锁死在此，任何页面渲染一致。
 */
export function TableCard({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <Card className={cn("overflow-hidden flex flex-col h-full gap-0 py-0", className)}>
      {children}
    </Card>
  );
}

/** 顶部信息栏：px-4 pt-3 pb-3.5 + 内层 h-8 行（行高锁定）；右侧居中等用 innerClassName 覆盖 */
export function TableCardHeader({
  className,
  innerClassName,
  children,
}: { className?: string; innerClassName?: string; children: ReactNode }) {
  return (
    <div className={cn("px-4 pt-3 pb-3.5 border-b border-border", className)}>
      <div className={cn("flex items-center justify-between gap-3 h-8", innerClassName)}>{children}</div>
    </div>
  );
}

/** 底部信息栏（分页等）：px-4 py-2 border-t */
export function TableCardFooter({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <div className={cn("px-4 py-2 border-t border-border shrink-0", className)}>
      {children}
    </div>
  );
}
