import { useState, useCallback, createContext, useContext, type ReactNode } from 'react'
import { AlertTriangle } from 'lucide-react'
import { Button } from "../ui/button";


interface ConfirmOptions {
  title: string
  message: string
  confirmText?: string
  cancelText?: string
  variant?: 'default' | 'danger'
}

interface ConfirmContextValue {
  confirm: (options: ConfirmOptions) => Promise<boolean>
}

const ConfirmContext = createContext<ConfirmContextValue | null>(null)

export function ConfirmProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<{
    open: boolean
    options: ConfirmOptions | null
    resolve: ((value: boolean) => void) | null
  }>({ open: false, options: null, resolve: null })

  const confirm = useCallback((options: ConfirmOptions): Promise<boolean> => {
    return new Promise((resolve) => {
      setState({ open: true, options, resolve })
    })
  }, [])

  const handleConfirm = () => {
    state.resolve?.(true)
    setState({ open: false, options: null, resolve: null })
  }

  const handleCancel = () => {
    state.resolve?.(false)
    setState({ open: false, options: null, resolve: null })
  }

  return (
    <ConfirmContext.Provider value={{ confirm }}>
      {children}
      {state.open && state.options && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[60] p-4">
          <div className="bg-card rounded-[12px] shadow-2xl w-[500px] max-w-[calc(100vw-2rem)] h-[206px] flex flex-col overflow-hidden">
            <div className="flex items-start gap-3 px-6 pt-6 flex-1">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                state.options.variant === 'danger' ? 'bg-red-100' : 'bg-blue-100'
              }`}>
                <AlertTriangle size={20} className={
                  state.options.variant === 'danger' ? 'text-red-600' : 'text-blue-600'
                } />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-semibold text-foreground">{state.options.title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{state.options.message}</p>
              </div>
            </div>
            <div className="flex justify-end gap-2 px-6 pb-5">
              <Button variant="ghost" onClick={handleCancel}>
                {state.options.cancelText ?? '取消'}
              </Button>
              <Button
                variant={state.options.variant === 'danger' ? 'destructive' : 'default'}
                onClick={handleConfirm}
              >
                {state.options.confirmText ?? '确认'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </ConfirmContext.Provider>
  )
}

export function useConfirm() {
  const context = useContext(ConfirmContext)
  if (!context) {
    throw new Error('useConfirm must be used within ConfirmProvider')
  }
  return context.confirm
}
