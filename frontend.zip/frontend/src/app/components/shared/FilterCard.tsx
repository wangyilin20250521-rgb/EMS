import type { ReactNode } from "react";
import { Calendar, ChevronDown, ChevronUp, Filter, RotateCcw, Search } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card } from "@/app/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/app/components/ui/popover";

/** 通用头部筛选卡片：支持折叠，查询显式触发请求，重置清空条件并重载 */
export function FilterCard({
  active,
  collapsed,
  onToggleCollapse,
  onQuery,
  onReset,
  children,
}: {
  /** 是否有已填写的筛选条件（显示"已启用"徽标） */
  active: boolean;
  collapsed: boolean;
  onToggleCollapse: () => void;
  onQuery: () => void;
  onReset: () => void;
  /** 筛选字段区，渲染在统一的 6 列栅格内 */
  children: ReactNode;
}) {
  return (
    <Card className="py-0 gap-0 overflow-hidden">
      <div className="flex items-center justify-between gap-3 px-4 py-2.5">
        <div className="flex items-center gap-2 shrink-0">
          <Filter size={13} className="text-primary" />
          <span className="text-sm font-semibold">筛选</span>
          {active && (
            <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">已启用</span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" className="text-xs" onClick={onToggleCollapse}>
            {collapsed ? <ChevronDown size={12} /> : <ChevronUp size={12} />}
            {collapsed ? "展开" : "折叠"}
          </Button>
          <Button variant="default" size="sm" className="text-xs" onClick={onQuery}>
            <Search size={12} />查询
          </Button>
          <Button variant="outline" size="sm" className="text-xs" onClick={onReset}>
            <RotateCcw size={12} />重置
          </Button>
        </div>
      </div>

      {!collapsed && (
        <div className="border-t border-border px-4 py-3">
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-x-3 gap-y-2.5">{children}</div>
        </div>
      )}
    </Card>
  );
}

/** 多选下拉：Popover + checkbox 列表 */
export function FilterMultiSelect({
  placeholder,
  options,
  value,
  onChange,
}: {
  placeholder: string;
  options: readonly string[];
  value: string[];
  onChange: (v: string[]) => void;
}) {
  const toggle = (item: string) =>
    onChange(value.includes(item) ? value.filter((x) => x !== item) : [...value, item]);
  const display =
    value.length === 0 ? placeholder : value.length <= 2 ? value.join("、") : `已选 ${value.length} 项`;
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="w-full h-8 flex items-center justify-between gap-1 px-2.5 text-sm border border-border rounded-md bg-white hover:bg-muted/30 transition-colors cursor-pointer"
        >
          <span className={`truncate ${value.length === 0 ? "text-muted-foreground/70" : "text-foreground"}`}>{display}</span>
          <ChevronDown size={12} className="text-muted-foreground shrink-0" />
        </button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-48 p-1 max-h-56 overflow-y-auto">
        {value.length > 0 && (
          <button
            onClick={() => onChange([])}
            className="w-full text-left px-2 py-1.5 text-sm text-muted-foreground hover:bg-muted/40 rounded cursor-pointer"
          >
            清空已选
          </button>
        )}
        {options.map((o) => (
          <label
            key={o}
            className="flex items-center gap-2 px-2 py-1.5 text-sm rounded hover:bg-muted/40 cursor-pointer"
          >
            <input
              type="checkbox"
              checked={value.includes(o)}
              onChange={() => toggle(o)}
              className="rounded"
            />
            {o}
          </label>
        ))}
      </PopoverContent>
    </Popover>
  );
}

/** 日期筛选输入框：date 原生不支持 placeholder，空值时以 text 展示占位，聚焦后切换为 date */
export function FilterDateInput({
  placeholder,
  value,
  onChange,
}: {
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="relative flex-1">
      <Calendar size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
      <input
        type={value ? "date" : "text"}
        placeholder={placeholder}
        onFocus={(e) => (e.currentTarget.type = "date")}
        onBlur={(e) => { if (!e.currentTarget.value) e.currentTarget.type = "text"; }}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-8 pl-8 pr-2.5 border border-border rounded-md text-sm bg-input-background focus:outline-none focus:ring-2 focus:ring-ring"
      />
    </div>
  );
}
