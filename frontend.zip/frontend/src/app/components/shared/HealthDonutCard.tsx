import { Cell, Pie, PieChart, ResponsiveContainer } from "recharts";
import { HeartPulse, ShieldAlert } from "lucide-react";

export interface HealthDonutCardProps {
  online: number;
  total: number;
  /** 离线告警阈值，默认 0（任何离线即横幅） */
  warnOfflineThreshold?: number;
}

/**
 * 运行健康环图卡：在线占比环图 + 健康徽章 + 离线超阈值警示横幅。
 * 颜色经 CSS 变量传入，浅/暗双主题自动适配。
 */
export function HealthDonutCard({ online, total, warnOfflineThreshold = 0 }: HealthDonutCardProps) {
  const offline = Math.max(0, total - online);
  const healthy = offline <= 0;
  const showBanner = offline > warnOfflineThreshold;
  const ratio = total > 0 ? online / total : 1;
  const ratioText = `${Math.round(ratio * 100)}%`;

  const data = [
    { name: "在线", value: Math.max(online, total === 0 ? 1 : 0) },
    ...(offline > 0 ? [{ name: "离线", value: offline }] : []),
  ];

  return (
    <div className="flex items-center gap-4 h-full">
      <div className="relative w-28 h-28 shrink-0">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              nameKey="name"
              innerRadius={38}
              outerRadius={52}
              paddingAngle={offline > 0 ? 3 : 0}
              startAngle={90}
              endAngle={-270}
              stroke="none"
            >
              <Cell fill="var(--chart-1, #25b865)" />
              {offline > 0 && <Cell fill="var(--chart-5, #f53f3f)" />}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        {/* 中心总计 */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-lg font-bold text-foreground tabular-nums leading-none" style={{ fontFamily: "'DM Mono', monospace" }}>
            {ratioText}
          </span>
          <span className="text-[10px] text-muted-foreground mt-0.5">在线率</span>
        </div>
      </div>

      <div className="flex-1 min-w-0 space-y-2">
        {/* 健康徽章 */}
        <span
          className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium ${
            healthy
              ? "bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400"
              : "bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400"
          }`}
        >
          {healthy ? <HeartPulse size={13} /> : <ShieldAlert size={13} />}
          {healthy ? "健康" : "警告"}
        </span>
        <p className="text-xs text-muted-foreground">
          在线 <span className="font-medium text-foreground tabular-nums">{online}</span> / 共{" "}
          <span className="font-medium text-foreground tabular-nums">{total}</span> 台设备
        </p>
        {showBanner && (
          <p className="text-[11px] text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/30 rounded-md px-2 py-1">
            {offline} 台设备离线，请检查连接
          </p>
        )}
      </div>
    </div>
  );
}
