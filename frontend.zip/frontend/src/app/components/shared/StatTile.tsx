import { IconAsset } from "./IconAsset";

export type StatTileTone = "blue" | "teal" | "green" | "amber" | "orange" | "violet" | "red";

/** 色语 → 渐变类名映射（全页共享，集中于此处避免风格分叉） */
export const STAT_TILE_TONE_CLASSES: Record<StatTileTone, string> = {
  blue: "from-blue-50 to-blue-100 text-blue-700 dark:from-blue-950/60 dark:to-blue-900/40 dark:text-blue-300",
  teal: "from-teal-50 to-teal-100 text-teal-700 dark:from-teal-950/60 dark:to-teal-900/40 dark:text-teal-300",
  green:
    "from-emerald-50 to-emerald-100 text-emerald-700 dark:from-emerald-950/60 dark:to-emerald-900/40 dark:text-emerald-300",
  amber:
    "from-amber-50 to-amber-100 text-amber-700 dark:from-amber-950/60 dark:to-amber-900/40 dark:text-amber-300",
  orange:
    "from-orange-50 to-orange-100 text-orange-700 dark:from-orange-950/60 dark:to-orange-900/40 dark:text-orange-300",
  violet:
    "from-violet-50 to-violet-100 text-violet-700 dark:from-violet-950/60 dark:to-violet-900/40 dark:text-violet-300",
  red:
    "from-red-50 to-red-100 text-red-700 dark:from-red-950/60 dark:to-red-900/40 dark:text-red-300",
};

export interface StatTileProps {
  label: string;
  value: number;
  tone: StatTileTone;
  /** 产品图标资产名（icons 资产集），缺省不显示图标 */
  iconAsset?: string;
  onClick?: () => void;
}

/**
 * 渐变流程指标瓷砖：色块 + 阶段名 + 大数字 + 右下角大背景图标（复刻 OmicsOne 首页
 * 待处理样本量卡 icon-item 观感：图标铺底、文字叠上、数字加大），点击跳转
 */
export function StatTile({ label, value, tone, iconAsset, onClick }: StatTileProps) {
  const toneClasses = STAT_TILE_TONE_CLASSES[tone];
  return (
    <button
      type="button"
      onClick={onClick}
      className={`relative w-full overflow-hidden rounded-xl border border-border/60 bg-gradient-to-br p-4 text-left transition-all hover:shadow-md hover:-translate-y-0.5 cursor-pointer ${toneClasses}`}
    >
      {/* 右下角大背景图标（低透明度铺底，不拦截点击） */}
      {iconAsset && (
        <div className="absolute -bottom-3 -right-3 opacity-30 pointer-events-none select-none" aria-hidden>
          <IconAsset name={iconAsset} size={84} />
        </div>
      )}
      <div className="relative min-w-0">
        <p className="text-sm font-medium opacity-80">{label}</p>
        <p className="mt-1.5 text-4xl font-bold tabular-nums leading-none" style={{ fontFamily: "'DM Mono', monospace" }}>
          {value}
        </p>
      </div>
    </button>
  );
}
