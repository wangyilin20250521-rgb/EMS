/**
 * 固定提示词快捷条（WorkBuddy 式）——悬浮在对话输入框上方的一组提示词按钮，
 * 点击即发送对应问题（不打断输入草稿）。文档归档 / 解决方案 / 策略管理共用。
 */
export function ChatPromptChips({
  prompts,
  onPick,
  disabled,
}: {
  /**label = 胶囊展示文案（短），prompt = 实际发送的问题（完整） */
  prompts: ReadonlyArray<{ label: string; prompt: string }>
  onPick: (prompt: string) => void
  /**流式回复中禁用（防并发提问） */
  disabled?: boolean
}) {
  if (prompts.length === 0) return null
  return (
    <div className="flex flex-wrap gap-1.5">
      {prompts.map(p => (
        <button
          key={p.label}
          type="button"
          title={p.prompt}
          disabled={disabled}
          onClick={() => onPick(p.prompt)}
          className="inline-flex items-center max-w-full px-2.5 py-1.5 rounded-md border border-border bg-card text-[12px] text-muted-foreground hover:text-primary hover:border-primary/40 hover:bg-primary/5 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:text-muted-foreground disabled:hover:border-border disabled:hover:bg-card"
        >
          <span className="truncate">{p.label}</span>
        </button>
      ))}
    </div>
  )
}
