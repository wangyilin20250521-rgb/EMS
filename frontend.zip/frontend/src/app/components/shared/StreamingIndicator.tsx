import { Loader2, Wrench } from "lucide-react";

/**
 * AI 流式输出"工作中"状态指示器（2026-09 优化）— 阶段感知的小转圈：
 * - 思考阶段（有 process 且最后一项是 thinking、正文为空）→ "⟳ 思考中"
 * - 工具执行阶段（最后一项是 tool）→ "⟳ 执行中"（带工具图标）
 * - 正文输出阶段 → 只转圈（内容在流动，无需文案，避免布局跳动）
 * Agent 在推理/工具/等待响应期间持续显示转圈，用户不会误以为卡死。
 */

export function StreamingIndicator({
  text,
  process,
}: {
  text?: string;
  process?: Array<{ type: "thinking" | "tool" }>;
}) {
  const last = process?.[process.length - 1];
  const state = last?.type === "tool" ? "tool" : text ? "output" : "thinking";

  return (
    <span className="inline-flex items-center gap-1 ml-1 align-middle text-muted-foreground">
      <Loader2 size={13} className="animate-spin" />
      {state === "tool" && (
        <span className="inline-flex items-center gap-1 text-[14px]">
          <Wrench size={11} />
          执行中
        </span>
      )}
      {state === "thinking" && <span className="text-[14px]">思考中</span>}
    </span>
  );
}
