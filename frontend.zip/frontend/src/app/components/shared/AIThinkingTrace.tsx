import { useEffect, useRef, useState } from "react";
import { ChevronDown, ChevronRight, Loader2, Wrench } from "lucide-react";

/**
 * AI 思考/工具轨迹（AI Native 平文形态，2026-09-17）——三个聊天 surface 共用：
 * - 流式期间：正文旁以浅色非粗体小字实时滚动工具/思考行（最近 3 行，更早折叠为"+N"），
 *   thinking 内容对用户不可读、只显示进行中状态（沿用 2026-09 优化口径）；
 * - 完成瞬间：自动收起为一行"已思考并查询 N 项 ▸"（对齐 ChatGPT/Claude 的折叠摘要形态），
 *   点击可展开完整轨迹（工具结果保留 pre 明细），再点收起；
 * - 历史恢复的消息没有 process 数据 → 不渲染，天然只显示最终结论。
 * 交互卡（决策卡/提问卡/表单卡等）不归本组件管，由各页面按事件类型另行渲染。
 */
export interface AIThinkingTraceItem {
  id: string;
  type: "thinking" | "tool";
  text: string;
  /** 结构化工具名（tool 项专有）：展示文本已中文化，原名挂 title 供 hover 查看 */
  toolName?: string;
}

const STREAM_VISIBLE_ROWS = 3;

export function AIThinkingTrace({
  items,
  streaming,
}: {
  items: AIThinkingTraceItem[];
  streaming: boolean;
}) {
  // 流式期间默认展开（实时可见）；streaming → false 的瞬间自动收起；
  // 之后完全交给用户手动展开/收起，不再自动跳
  const [expanded, setExpanded] = useState(true);
  const prevStreaming = useRef(streaming);
  useEffect(() => {
    if (prevStreaming.current && !streaming) setExpanded(false);
    prevStreaming.current = streaming;
  }, [streaming]);

  if (items.length === 0) return null;

  // 完成后收起态：一行摘要
  if (!expanded) {
    return (
      <button
        type="button"
        onClick={() => setExpanded(true)}
        className="inline-flex items-center gap-1 text-[13px] text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
      >
        <ChevronRight size={13} className="shrink-0" />
        <span>已思考并查询 {items.length} 项</span>
      </button>
    );
  }

  const visible = streaming ? items.slice(-STREAM_VISIBLE_ROWS) : items;
  const hiddenCount = items.length - visible.length;

  return (
    // min-w-0 + w-full：给 truncate 行一个有界宽度，长工具结果不撑破消息容器（防横向滚动条）
    <div className="min-w-0 w-full space-y-1">
      {streaming && hiddenCount > 0 && (
        <p className="text-[13px] text-muted-foreground/60">… 更早 {hiddenCount} 项</p>
      )}
      {visible.map((item) => (
        <div key={item.id} className="flex items-start gap-1.5 text-[13px] text-muted-foreground">
          {item.type === "tool" ? (
            <Wrench size={12} className="mt-0.5 shrink-0" />
          ) : streaming ? (
            <Loader2 size={12} className="mt-0.5 shrink-0 animate-spin" />
          ) : (
            <Wrench size={12} className="mt-0.5 shrink-0 opacity-50" />
          )}
          {item.type === "tool" ? (
            // 流式期间一行截断（浅色行的"轻"感）；完成后展开态保留完整结果；title 显示英文原名
            <span title={item.toolName} className={`min-w-0 ${streaming ? "truncate" : "whitespace-pre-wrap break-words font-mono leading-5"}`}>
              {item.text}
            </span>
          ) : streaming ? (
            <span>思考中…</span>
          ) : (
            <p className="whitespace-pre-wrap leading-5 max-h-32 overflow-auto">{item.text}</p>
          )}
        </div>
      ))}
      {!streaming && items.length > 0 && (
        <button
          type="button"
          onClick={() => setExpanded(false)}
          className="inline-flex items-center gap-1 text-[13px] text-muted-foreground/70 hover:text-foreground transition-colors cursor-pointer"
        >
          <ChevronDown size={13} className="shrink-0 rotate-180" />
          <span>收起</span>
        </button>
      )}
    </div>
  );
}
