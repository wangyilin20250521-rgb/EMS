import type { ReactNode } from "react";
import { SquareDashed } from "lucide-react";
import ai from "@/assets/icons/ai.png";
import alert from "@/assets/icons/alert.png";
import consumerables from "@/assets/icons/consumerables.png";
import dashboard from "@/assets/icons/dashboard.png";
import device from "@/assets/icons/device.png";
import document from "@/assets/icons/document.png";
import products from "@/assets/icons/products.png";
import register from "@/assets/icons/register.png";
import samplePrep from "@/assets/icons/sample_prep.png";
import samples from "@/assets/icons/samples.png";
import schedule from "@/assets/icons/schedule.png";
import sequencer from "@/assets/icons/sequencer.png";
import settings from "@/assets/icons/settings.png";
import solutions from "@/assets/icons/solutions.png";
import strategy from "@/assets/icons/strategy.png";
import taskList from "@/assets/icons/task-list.png";

/** 产品图标资产集（src/assets/icons/）按名称映射，进入 Vite 构建图（哈希/压缩/桌面打包可用） */
const ICON_MODULES: Record<string, string> = {
  ai,
  alert,
  consumerables,
  dashboard,
  device,
  document,
  products,
  register,
  sample_prep: samplePrep,
  samples,
  schedule,
  sequencer,
  settings,
  solutions,
  strategy,
  "task-list": taskList,
};

export interface IconAssetProps {
  name: string;
  size?: number;
  /** 覆盖渲染宽度（默认等于 size） */
  imgWidth?: number;
  /** 覆盖渲染高度（默认等于 size） */
  imgHeight?: number;
  className?: string;
  /** 资产缺失回退（默认 lucide 线性图标） */
  fallback?: ReactNode;
}

/** 产品图标资产组件：按名称加载 PNG，缺失时回退 lucide 线性图标 */
export function IconAsset({ name, size = 24, imgWidth, imgHeight, className = "", fallback }: IconAssetProps) {
  const src = ICON_MODULES[name];
  const w = imgWidth ?? size;
  const h = imgHeight ?? size;
  if (!src) {
    return fallback ? <>{fallback}</> : <SquareDashed size={size} className={className} />;
  }
  return (
    <img
      src={src}
      width={w}
      height={h}
      alt=""
      draggable={false}
      className={`shrink-0 select-none ${className}`}
      style={{ width: w, height: h, objectFit: "contain" }}
    />
  );
}
