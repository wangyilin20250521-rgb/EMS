import { useEffect, useRef, useState } from "react"

/**
 * 单行标题跑马灯：静止省略号，悬浮滚动展示全文（不溢出则静止）。
 * 裁剪与位移必须父子分层——truncate 挂在位移元素自身时，裁剪窗口随位移平移，隐藏文本永远露不出来。
 */
export function MarqueeText({ text, className = "" }: { text: string; className?: string }) {
  const boxRef = useRef<HTMLDivElement>(null)
  const textRef = useRef<HTMLSpanElement>(null)
  const [marquee, setMarquee] = useState({ dist: 0, dur: 0 })

  // 测量溢出量：滚动距离 = 文本宽 - 容器宽；时长按 25px/s 估算（下限 3s），不溢出则不动画
  useEffect(() => {
    const box = boxRef.current
    const node = textRef.current
    if (!box || !node) return
    const measure = () => {
      const dist = Math.max(0, node.scrollWidth - box.clientWidth)
      setMarquee({ dist, dur: dist > 0 ? Math.max(3, Math.round(dist / 25)) : 0 })
    }
    measure()
    window.addEventListener("resize", measure)
    return () => window.removeEventListener("resize", measure)
  }, [text])

  return (
    <div ref={boxRef} className="doc-title-marquee overflow-hidden">
      <span
        ref={textRef}
        className={`doc-title-marquee-text ${className}`}
        style={marquee.dist > 0 ? ({ "--marquee-x": `-${marquee.dist}px`, "--marquee-dur": `${marquee.dur}s` } as React.CSSProperties) : undefined}
      >
        {text}
      </span>
    </div>
  )
}

/** 卡面副行灰色标签（产品/平台/模式/分类等）：纯灰配色，无彩色，暗色模式随主题自适应 */
export function CardTag({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center rounded bg-muted px-1.5 py-px text-[11px] text-muted-foreground">
      {children}
    </span>
  )
}
