import { AlertTriangle } from "lucide-react";
import { cn } from "@/app/components/ui/utils";

export interface AlertPanelCardProps {
  warning: number;
  overdue: number;
  onWarningClick?: () => void;
  onOverdueClick?: () => void;
  /** 覆盖容器高度（默认 h-full 撑满；与明细列表同卡时传 "h-auto shrink-0"） */
  className?: string;
}

/**
 * 双色面板预警卡：左"预警"/右"超期"双面板计数 + 中间警示插画位。
 * 零状态（两者皆 0）呈平静视觉，无红色警示氛围。
 */
export function AlertPanelCard({ warning, overdue, onWarningClick, onOverdueClick, className = "" }: AlertPanelCardProps) {
  const calm = warning === 0 && overdue === 0;
  return (
    <div className={cn("flex items-stretch gap-3 h-full", className)}>
      {/* 左面板：预警 */}
      <button
        type="button"
        onClick={onWarningClick}
        disabled={!onWarningClick}
        className={`flex-1 rounded-xl border p-4 text-left transition-all ${
          warning > 0
            ? "border-amber-200 bg-amber-50 hover:shadow-sm dark:border-amber-900/50 dark:bg-amber-950/30"
            : "border-border bg-muted/30"
        } ${onWarningClick ? "cursor-pointer" : "cursor-default"}`}
      >
        <p className={`text-xs font-medium ${warning > 0 ? "text-amber-600 dark:text-amber-400" : "text-muted-foreground"}`}>
          预警
        </p>
        <p
          className={`mt-2 text-3xl font-bold tabular-nums ${
            warning > 0 ? "text-amber-600 dark:text-amber-400" : "text-muted-foreground"
          }`}
          style={{ fontFamily: "'DM Mono', monospace" }}
        >
          {warning}
        </p>
        <p className="mt-1 text-[11px] text-muted-foreground">TAT 即将超期</p>
      </button>

      {/* 中间：警示插画位 */}
      <div className="flex items-center justify-center px-1">
        <div
          className={`w-12 h-12 rounded-full flex items-center justify-center ${
            calm ? "bg-muted text-muted-foreground/60" : "bg-amber-100 text-amber-500 dark:bg-amber-900/40"
          }`}
        >
          <AlertTriangle size={22} />
        </div>
      </div>

      {/* 右面板：超期 */}
      <button
        type="button"
        onClick={onOverdueClick}
        disabled={!onOverdueClick}
        className={`flex-1 rounded-xl border p-4 text-left transition-all ${
          overdue > 0
            ? "border-red-200 bg-red-50 hover:shadow-sm dark:border-red-900/50 dark:bg-red-950/30"
            : "border-border bg-muted/30"
        } ${onOverdueClick ? "cursor-pointer" : "cursor-default"}`}
      >
        <p className={`text-xs font-medium ${overdue > 0 ? "text-red-600 dark:text-red-400" : "text-muted-foreground"}`}>
          超期
        </p>
        <p
          className={`mt-2 text-3xl font-bold tabular-nums ${
            overdue > 0 ? "text-red-600 dark:text-red-400" : "text-muted-foreground"
          }`}
          style={{ fontFamily: "'DM Mono', monospace" }}
        >
          {overdue}
        </p>
        <p className="mt-1 text-[11px] text-muted-foreground">TAT 已超期</p>
      </button>
    </div>
  );
}
