import type { ReactNode } from "react"

/** react-markdown <pre> 子节点的纯文本提取（递归展开元素/数组/片段） */
export function markdownChildrenText(node: ReactNode): string {
  if (node === null || node === undefined || typeof node === "boolean") return ""
  if (typeof node === "string" || typeof node === "number") return String(node)
  if (Array.isArray(node)) return node.map(markdownChildrenText).join("")
  if (typeof node === "object" && "props" in (node as unknown as Record<string, unknown>)) {
    return markdownChildrenText((node as { props: { children?: ReactNode } }).props?.children)
  }
  return ""
}

/** *markdown 代码块守卫：LLM 偶发输出空代码围栏（```lang\n``` 或回复结尾的未闭合空围栏），
 * 会渲染成一块 44px 的空灰底框（2026-09-22 策略决策卡实测）。内容为空时整块不渲染；
 * 围栏内有真实内容（含空行）时按原样式渲染，不影响正常代码块展示。 */
export function MarkdownPre({ className, children }: { className?: string; children?: ReactNode }) {
  if (!markdownChildrenText(children).trim()) return null
  return <pre className={className}>{children}</pre>
}
