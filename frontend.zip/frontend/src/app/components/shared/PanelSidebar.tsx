import type { ReactNode } from "react";

/**
 * 模块内左侧列表栏统一规格（2026-09-18 五模块统一：AI 助手 / 设备管理 / 文档归档 / 策略管理 / 解决方案）：
 * - 固定 280px（w-80）；窄屏 <1024px 整栏隐藏，仅保留右侧内容区（hidden lg:flex）；
 * - 结构统一：固定头部（主色图标 + 14px 标题 + 计数 + 右侧操作位）+ 独立滚动的卡片列表（p-3 space-y-2）；
 * - 卡片外观走 panel-styles.ts 的 panelCardCls / panelIconCls，五个模块不再各维护一套类名，避免风格再次漂移。
 * 注意：卡面类名函数而非包装组件——AI 助手入口卡需要被 Radix Trigger asChild 克隆、
 * 规则卡内部有嵌套按钮，包装组件会引入 ref/Slot 语义问题。
 */
export function PanelSidebar({
  icon: Icon,
  title,
  count,
  action,
  children,
}: {
  icon: React.ElementType;
  title: string;
  count?: ReactNode;
  action?: ReactNode;
  children: ReactNode;
}) {
  return (
    <aside className="w-80 shrink-0 border-r border-border bg-card flex-col min-h-0 hidden lg:flex">
      {/* 固定 h-12（42px）：有操作按钮（新对话 / 新建规则）与无操作按钮的模块头部高度完全一致 */}
      <div className="px-4 h-12 border-b border-border shrink-0 flex items-center justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2">
          <Icon size={15} className="shrink-0 text-primary" />
          <h2 className="text-[14px] font-semibold text-foreground truncate">{title}</h2>
          {count != null && count !== "" && (
            <span className="shrink-0 text-[14px] font-normal text-muted-foreground">· {count}</span>
          )}
        </div>
        {action}
      </div>
      <div className="flex-1 overflow-y-auto p-3 space-y-2">{children}</div>
    </aside>
  );
}
