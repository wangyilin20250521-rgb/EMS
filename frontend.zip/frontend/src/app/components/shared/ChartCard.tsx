import type { ReactNode } from "react";

export interface ChartCardProps {
  title: string;
  /** 头部小图标（卡片头部规范：小图标 + 标题） */
  icon?: ReactNode;
  /** 图表类型切换等动作槽（渲染在头部右侧） */
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
}

/**
 * 图表卡通用模式：统一卡片头部规范（小图标 + 标题 + 动作槽）与圆角/边框/阴影。
 * 首页与后续页面的所有数据卡片均以此拼装，保证全页一致。
 */
export function ChartCard({ title, icon, actions, children, className = "" }: ChartCardProps) {
  return (
    <section
      className={`rounded-card border border-border bg-card shadow-card flex flex-col overflow-hidden ${className}`}
    >
      <header className="flex items-center gap-2 px-4 pt-4 pb-3">
        {icon && <span className="flex items-center justify-center text-primary shrink-0">{icon}</span>}
        <h3 className="text-sm font-semibold text-foreground flex-1 min-w-0 truncate">{title}</h3>
        {actions && <div className="flex items-center gap-1 shrink-0">{actions}</div>}
      </header>
      <div className="flex-1 px-4 pb-4 min-h-0 overflow-hidden flex flex-col">{children}</div>
    </section>
  );
}
