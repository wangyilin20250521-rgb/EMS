/**
 * 模块内左侧列表栏的卡片样式（与 PanelSidebar 同属一套统一规格）：
 * 单独成模块而非与组件同文件——同文件混导出组件与函数会让 Vite Fast Refresh 失效。
 */

/** 列表卡外框（选中 = 主色描边 + 淡底；停用 = 整卡降透明；悬停 = 主色描边 + 轻阴影） */
export function panelCardCls({ active = false, disabled = false }: { active?: boolean; disabled?: boolean } = {}): string {
  const base = "group relative flex w-full min-h-[84px] items-center gap-3 p-3 rounded-xl border transition-all text-left cursor-pointer";
  if (active) return `${base} border-primary/60 bg-primary/5 shadow-sm`;
  if (disabled) return `${base} border-border/50 bg-muted/20 opacity-55`;
  return `${base} border-border bg-card hover:border-primary/30 hover:shadow-sm`;
}

/** 卡片左侧 8×8 图标块（灰底 → 选中 / 悬停主色） */
export function panelIconCls(active = false): string {
  return `w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
    active
      ? "bg-primary/10 text-primary"
      : "bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300 group-hover:bg-primary/10 group-hover:text-primary"
  }`;
}
