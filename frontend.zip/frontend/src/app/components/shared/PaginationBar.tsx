import React, { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";

interface PaginationBarProps {
  page: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
  onPageSizeChange?: (size: number) => void;
  pageSizeOptions?: number[];
}

const DEFAULT_PAGE_SIZE_OPTIONS = [10, 15, 20, 30, 50, 100];

/**
 * 分页通用模式（OmicsOne 换肤版，research R6）：
 * props API 不变，布局改整行右对齐单串"共X条 | N条/页 | 页码 | 前往N页"，
 * 活跃页方形蓝底；全系统使用方零成本切换。
 */
export function PaginationBar({
  page,
  pageSize,
  total,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = DEFAULT_PAGE_SIZE_OPTIONS,
}: PaginationBarProps) {
  const [jumpValue, setJumpValue] = useState("");

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  const handleJump = () => {
    const p = parseInt(jumpValue);
    if (!isNaN(p) && p >= 1 && p <= totalPages) {
      onPageChange(p);
      setJumpValue("");
    }
  };

  const handleJumpKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleJump();
  };

  // Generate page number list, up to 7 slots (with ellipsis)
  const getPageNumbers = (): (number | "ellipsis")[] => {
    if (totalPages <= 7) {
      return Array.from({ length: totalPages }, (_, i) => i + 1);
    }
    const pages: (number | "ellipsis")[] = [1];
    if (page > 3) pages.push("ellipsis");
    const rangeStart = Math.max(2, page - 1);
    const rangeEnd = Math.min(totalPages - 1, page + 1);
    for (let i = rangeStart; i <= rangeEnd; i++) pages.push(i);
    if (page < totalPages - 2) pages.push("ellipsis");
    pages.push(totalPages);
    return pages;
  };

  return (
    <div className="flex items-center justify-end gap-3 px-2 py-1.5 text-xs text-muted-foreground flex-wrap">
      {/* 共 X 条 */}
      <span className="whitespace-nowrap">
        共 <span className="font-medium text-foreground">{total}</span> 条
      </span>

      {/* N 条/页 */}
      {onPageSizeChange && (
        <div className="flex items-center gap-1 shrink-0">
          <Select onValueChange={v => onPageSizeChange(Number(v))} value={String(pageSize)}>
            <SelectTrigger className="w-auto h-7 px-1.5 text-xs border border-border rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring cursor-pointer">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {pageSizeOptions.map(opt => (
                <SelectItem key={opt} value={String(opt)}>
                  {opt}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <span className="whitespace-nowrap">条/页</span>
        </div>
      )}

      {/* 页码（上一页 / 数字 / 下一页） */}
      <div className="flex items-center gap-0.5">
        <button
          onClick={() => onPageChange(page - 1)}
          disabled={page === 1}
          className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
          title="上一页"
        >
          <ChevronLeft size={14} />
        </button>

        {getPageNumbers().map((p, i) =>
          p === "ellipsis" ? (
            <span key={`ellipsis-${i}`} className="px-1 text-muted-foreground/60 select-none">
              …
            </span>
          ) : (
            <button
              key={p}
              onClick={() => onPageChange(p)}
              className={`min-w-7 h-7 px-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                p === page
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
            >
              {p}
            </button>
          ),
        )}

        <button
          onClick={() => onPageChange(page + 1)}
          disabled={page >= totalPages}
          className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
          title="下一页"
        >
          <ChevronRight size={14} />
        </button>
      </div>

      {/* 前往 N 页 */}
      <div className="flex items-center gap-1">
        <span className="whitespace-nowrap">前往</span>
        <input
          type="text"
          value={jumpValue}
          onChange={e => setJumpValue(e.target.value.replace(/\D/g, ""))}
          onKeyDown={handleJumpKeyDown}
          onBlur={handleJump}
          placeholder={`${page}`}
          aria-label="前往页码"
          className="w-11 h-7 px-1.5 text-xs text-center border border-border rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        />
        <span className="whitespace-nowrap">页</span>
      </div>
    </div>
  );
}
