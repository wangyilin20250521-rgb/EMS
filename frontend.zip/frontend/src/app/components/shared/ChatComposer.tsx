import { useEffect, useRef, type ChangeEvent, type KeyboardEvent, type ReactNode, type RefObject } from "react"
import { FileText, Image as ImageIcon, Paperclip, Send, Square, X } from "lucide-react"

/**文本行高（px）与上下内边距（py-2.5 ×2）——maxHeight 换算用 */
const LINE_HEIGHT = 22
const PADDING_Y = 20

/**附件 chip 数据（uploadAttachment 的返回 + 上传中占位） */
export interface ComposerAttachment {
  id: string
  name: string
  kind: string
  /**上传中（尚无 id，发送禁用） */
  uploading?: boolean
}

/** *聊天输入区（composer，通用设计）：自动增高的多行输入框 + 内嵌工具栏。
 * - 空态 1 行；随内容自动长高到 maxLines（默认 5）行封顶，之后内部滚动隐藏后面的行；
 * - Enter 发送 / Shift+Enter 换行；中文输入法组词回车（isComposing）不触发发送；
 * - 容器整体一个圆角边框，textarea 无边框内嵌；底部工具栏左侧是 leftActions 插槽
 *   （清理/快捷操作等既有按钮统一收进来），右侧是发送/停止按钮——
 *   后续"上传附件 / 模型选择 / 思考开关"等控制项加进 leftActions 即可，布局不用再动。
 */
export function ChatComposer({
  value,
  onChange,
  onSend,
  onStop,
  streaming = false,
  disabled = false,
  placeholder,
  phantomQuestion,
  inputRef,
  leftActions,
  maxLines = 5,
  containerClassName = "",
  attachments,
  onRemoveAttachment,
  onFilesSelected,
  accept = ".xlsx,.xls,.csv,.txt,.json,.md,.png,.jpg,.jpeg,.webp,.bmp",
  fileInputRef,
}: {
  value: string
  onChange: (value: string) => void
  /**raw 参数：输入为空但有 phantomQuestion 时，composer 会把默认问题作为 raw 传入 */
  onSend: (raw?: string) => void
  /**流式生成时的停止回调；不传则流式期间仅禁用发送按钮 */
  onStop?: () => void
  streaming?: boolean
  disabled?: boolean
  placeholder?: string
  /**首次咨询的默认问题（与占位文字同文）：空输入时 Enter/发送按钮直接发送它，Tab 仅填充；
   * 有输入文字时不生效。用尽（非首次）后传 undefined 恢复常规行为 */
  phantomQuestion?: string
  /**外部持有的 ref（面板聚焦/清空输入用）；组件内部同时用它做自适应测高 */
  inputRef?: RefObject<HTMLTextAreaElement | null>
  /**底部工具栏左侧插槽：本模块的辅助控制按钮 */
  leftActions?: ReactNode
  maxLines?: number
  containerClassName?: string
  /**待发送的附件 chips（容器顶部一行）；传入即启用上传按钮 */
  attachments?: ComposerAttachment[]
  onRemoveAttachment?: (id: string) => void
  /**选择文件回调（上传由调用方负责，完成后更新 attachments） */
  onFilesSelected?: (files: File[]) => void
  /**文件选择器 accept */
  accept?: string
  /**外部持有的文件选择 input ref（重置表单用，可选） */
  fileInputRef?: RefObject<HTMLInputElement | null>
}) {
  const innerRef = useRef<HTMLTextAreaElement | null>(null)
  const localFileRef = useRef<HTMLInputElement | null>(null)
  const maxHeight = maxLines * LINE_HEIGHT + PADDING_Y
  const hasAttachments = !!attachments?.length
  /**有上传中的附件 → 发送禁用（等上传完成再发） */
  const uploadingFile = !!attachments?.some(a => a.uploading)

  // 内容变化 → 重测高度：先置 auto 拿 scrollHeight，再夹到 maxHeight（超出后内部滚动）
  const resize = () => {
    const el = innerRef.current
    if (!el) return
    el.style.height = "auto"
    el.style.height = `${Math.min(el.scrollHeight, maxHeight)}px`
  }
  useEffect(resize, [value])

  const hasText = !!value.trim()
  const canSend = !streaming && !disabled && !uploadingFile && (hasText || !!phantomQuestion)
  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault()
      if (canSend) onSend(hasText ? undefined : phantomQuestion)
      return
    }
    // Tab 仅填充默认问题（不直接发送，用户可改后再发）；有输入文字时保持浏览器默认焦点行为
    if (e.key === "Tab" && !hasText && phantomQuestion && !streaming && !disabled) {
      e.preventDefault()
      onChange(phantomQuestion)
    }
  }

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? [])
    if (files.length > 0 && onFilesSelected) onFilesSelected(files)
    e.target.value = "" // 允许重复选择同一文件
  }

  return (
    <div
      className={`rounded-2xl border border-border bg-card focus-within:ring-2 focus-within:ring-primary/50 focus-within:border-primary/40 transition-shadow ${disabled ? "opacity-60" : ""} ${containerClassName}`}
    >
      {/* 附件 chips（待发送） */}
      {hasAttachments && (
        <div className="flex flex-wrap gap-1.5 px-3 pt-2.5">
          {attachments!.map(a => (
            <span
              key={a.id}
              className={`inline-flex items-center gap-1.5 max-w-[240px] px-2 py-1 rounded-lg border text-[12px] ${a.uploading ? "border-dashed border-border text-muted-foreground" : "border-border bg-muted/40 text-foreground/90"}`}
              title={a.name}
            >
              {a.kind === "image" ? <ImageIcon size={12} className="shrink-0" /> : <FileText size={12} className="shrink-0" />}
              <span className="truncate">{a.uploading ? `上传中… ${a.name}` : a.name}</span>
              {onRemoveAttachment && !a.uploading && (
                <button
                  onClick={() => onRemoveAttachment(a.id)}
                  title="移除附件"
                  className="text-muted-foreground hover:text-red-500 transition-colors cursor-pointer shrink-0"
                >
                  <X size={11} />
                </button>
              )}
            </span>
          ))}
        </div>
      )}
      <textarea
        // 同时喂给内部测高与外部 ref（面板聚焦/程序化清空）
        ref={el => {
          innerRef.current = el
          if (inputRef) inputRef.current = el
        }}
        rows={1}
        value={value}
        onChange={e => onChange(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        disabled={disabled}
        className="w-full resize-none bg-transparent px-4 pt-2.5 pb-1 text-[14px] leading-[22px] focus:outline-none placeholder:text-muted-foreground/70 overflow-y-auto"
        style={{ maxHeight }}
      />
      <div className="flex items-center gap-1 px-2.5 pb-2 pt-0.5">
        {/* 附件上传按钮（传入 onFilesSelected 即启用） */}
        {onFilesSelected && (
          <>
            <input
              ref={el => {
                localFileRef.current = el
                if (fileInputRef) fileInputRef.current = el
              }}
              type="file"
              accept={accept}
              multiple
              className="hidden"
              onChange={handleFileChange}
            />
            <button
              onClick={() => localFileRef.current?.click()}
              disabled={disabled || streaming}
              title="上传附件（Excel/CSV/文本/图片）——AI 会先读取内容再处理"
              className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/5 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
            >
              <Paperclip size={15} />
            </button>
          </>
        )}
        {/* 左侧辅助控制插槽 */}
        {leftActions && <div className="flex items-center gap-1 min-w-0">{leftActions}</div>}
        {streaming && onStop ? (
          <button
            onClick={onStop}
            title="停止生成"
            className="ml-auto w-9 h-9 rounded-xl border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors cursor-pointer shrink-0"
          >
            <Square size={14} className="fill-current" />
          </button>
        ) : (
          <button
            onClick={() => onSend(hasText ? undefined : phantomQuestion)}
            disabled={!canSend}
            title={hasText || !phantomQuestion ? "发送" : `发送推荐问题：${phantomQuestion}`}
            aria-label="发送消息"
            className="ml-auto w-9 h-9 rounded-xl border border-primary bg-transparent text-primary flex items-center justify-center hover:bg-primary/10 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
          >
            <Send size={15} />
          </button>
        )}
      </div>
    </div>
  )
}
