import * as React from "react";

import { cn } from "@/app/components/ui/utils";

/**
 * 页面标题栏（收编自原 EMSComponents.PageHeader，样式保持一致）。
 * breadcrumb 保留入参以兼容旧调用方，暂不渲染。
 */
function PageHeader({
  title,
  breadcrumb,
  actions,
  className,
}: React.ComponentProps<"div"> & {
  title: string;
  breadcrumb?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div
      data-slot="page-header"
      className={cn("flex items-center justify-between", className)}
    >
      <h1
        className="text-xl font-semibold text-foreground"
        style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
      >
        {title}
      </h1>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

export { PageHeader };
