import { RouterProvider } from "react-router";
import { Toaster } from "./components/ui/sonner";
import { ApiProvider } from "./lib/api";
import { PlatformProvider } from "./lib/platform";
import { AuthProvider } from "./hooks/useAuth";
import { ConfirmProvider } from "./components/shared/ConfirmDialog";
import { router } from "./routes";

function App() {
  return (
    <PlatformProvider>
      <ApiProvider>
        <AuthProvider>
          <ConfirmProvider>
            <RouterProvider router={router} />
            <Toaster position="top-center" richColors />
          </ConfirmProvider>
        </AuthProvider>
      </ApiProvider>
    </PlatformProvider>
  );
}

export default App;
