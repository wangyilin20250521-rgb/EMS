import { useEffect, useState } from "react"
import { getSystemConfig } from "@/app/lib/api"

/**
 * 实验执行模式单源（siro|manual|hybrid）：设备页过滤/任务执行区/排单守卫都从这里读。
 * 数据源 GET /system/config；会话内只拉一次，取不到回退 siro（零行为变化）。
 */

export type ExecutionMode = "siro" | "manual" | "hybrid"

export interface ExecutionModeState {
  mode: ExecutionMode
  /**当前模式允许注册的实验执行设备类型（SIRO/功能岛/虚拟设备；测序仪/AGV/冰箱不受限） */
  allowedExperimentDeviceTypes: string[]
}

let cache: ExecutionModeState | null = null
let inflight: Promise<ExecutionModeState> | null = null

const FALLBACK: ExecutionModeState = { mode: "siro", allowedExperimentDeviceTypes: ["SIRO"] }

export async function loadExecutionMode(): Promise<ExecutionModeState> {
  if (cache) return cache
  inflight ??= getSystemConfig()
    .then((cfg) => {
      const mode: ExecutionMode =
        cfg.executionMode === "manual" || cfg.executionMode === "hybrid" ? cfg.executionMode : "siro"
      cache = {
        mode,
        allowedExperimentDeviceTypes:
          Array.isArray(cfg.allowedExperimentDeviceTypes) && cfg.allowedExperimentDeviceTypes.length > 0
            ? cfg.allowedExperimentDeviceTypes
            : FALLBACK.allowedExperimentDeviceTypes,
      }
      return cache
    })
    .catch(() => FALLBACK)
    .finally(() => { inflight = null })
  return inflight
}

export function useExecutionMode(): ExecutionModeState & { loading: boolean } {
  const [state, setState] = useState<ExecutionModeState>(cache ?? FALLBACK)
  const [loading, setLoading] = useState(!cache)
  useEffect(() => {
    let alive = true
    loadExecutionMode().then((s) => {
      if (alive) { setState(s); setLoading(false) }
    })
    return () => { alive = false }
  }, [])
  return { ...state, loading }
}
