import type { ViewId } from "./api";

/** 角色可见视图白名单；未配置的角色（如管理员）不受限 */
export const ROLE_VIEW_LIMITS: Record<string, ViewId[]> = {
  "操作员": ["sample-prep", "experiment-schedule", "task-list", "devices", "documents"],
};

/** 路由守卫豁免视图（登录后必达，如个人中心），不要求在白名单中 */
export const GUARD_EXEMPT_VIEWS: ViewId[] = ["user-info"];

/** 角色是否可见某视图（无白名单配置的角色恒放行） */
export function isViewAllowed(role: string | undefined, view: ViewId): boolean {
  const limits = role ? ROLE_VIEW_LIMITS[role] : undefined;
  return limits === undefined || limits.includes(view);
}
