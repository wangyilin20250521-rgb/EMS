import type { Device, Sequencer } from '../api/types'

/** Available devices for task assignment */
export const DEVICES: Device[] = [
  { id: 'DEV-001', name: 'MGISEQ-2000 #1', model: 'MGISEQ-2000', status: '空闲' },
  { id: 'DEV-002', name: 'MGISEQ-2000 #2', model: 'MGISEQ-2000', status: '运行中' },
  { id: 'DEV-003', name: 'DNBSEQ-T7 #1', model: 'DNBSEQ-T7', status: '空闲' },
]

/** Available sequencers with lane configuration */
export const SEQUENCERS: Sequencer[] = [
  { id: 'SEQ-001', name: 'MGISEQ-2000 #1', model: 'MGISEQ-2000', laneCount: 2, status: '空闲' },
  { id: 'SEQ-002', name: 'MGISEQ-2000 #2', model: 'MGISEQ-2000', laneCount: 2, status: '运行中' },
  { id: 'SEQ-003', name: 'DNBSEQ-T7 #1', model: 'DNBSEQ-T7', laneCount: 4, status: '空闲' },
]

/** Predefined plate types */
export const PLATE_TYPE_OPTIONS = ['96孔PCR板', '384孔PCR板', '96孔深孔板'] as const

/** Execution mode options shown after selecting a task order */
export const EXECUTION_MODES = ['全流程', '仅提取', '提取+建库', '选择性loading'] as const
export type ExecutionMode = (typeof EXECUTION_MODES)[number]
