import type { UnpackFormState } from '../api/types'

// ─── Business Option Constants（所有模块统一数据源，后端字典刷新前的静态兜底） ────

/** 检测项目 */
export const PROJECT_OPTIONS = ["NIFTY", "WES", "CNVseq", "CMA", "WGS", "遗传病Panel", "其他"] as const;

/** 样本来源 */
export const SOURCE_OPTIONS = ["本院", "外院"] as const;

/** 来源医院 */
export const HOSPITAL_OPTIONS = ["本院", "吉安妇保院", "九江妇保院", "南昌大学附属医院"] as const;

/** 样本类型 */
export const SAMPLE_TYPE_OPTIONS = ["血液", "羊水", "组织", "外周血", "全血", "DNA", "肌肉组织", "流产组织", "绒毛", "脐血"] as const;

/** 产品套餐后缀（与检测项目联动生成选项：{检测项目}{后缀}，如 NIFTY标准套餐 / NIFTY升级套餐；手动填写/收样登记共用） */
export const PACKAGE_SUFFIXES = ["标准套餐", "升级套餐", "Plus套餐"] as const;

/** SIRO 设备型号 */
export const SIRO_DEVICE_OPTIONS = ["SIRO-16", "SIRO-48", "SIRO-96"] as const;

/** 测序仪型号（下拉选择，不允许手动输入） */
export const SEQUENCER_MODELS = ["DNBSEQ-G99", "MGISEQ-200", "MGISEQ-2000", "DNBSEQ-E25"] as const;

/** 功能岛类型（下拉选择，不允许手动输入） */
export const ISLAND_TYPES = ["试剂岛", "裂解岛", "提取岛", "qPCR岛", "建库岛"] as const;

/** 收样登记日期筛选选项 */
/** 收样登记日期筛选（与后端 /sample-reception/date-filters 对齐，作离线兜底） */
export const UNPACK_DATE_FILTERS = ["全部", "今日", "近3日", "近7日", "近30日"];

/** 收样登记可选产品 */
export const UNPACK_AVAILABLE_PRODUCTS: readonly string[] = PROJECT_OPTIONS;

/** 新建收样登记表单模板（真实值在组件内覆盖） */
export const UNPACK_DEFAULT_FORM: UnpackFormState = {
  hospital: "本院",
  source: "本院",
  receiveTime: "",
  receiver: "",
  actualTubes: 0,
  actualPapers: 0,
  remark: "",
  products: [],
};

/** 样本状态 → 时间线节点的映射 */
export const STATUS_TO_TIMELINE_LABEL: Record<string, string> = {
  "已收样": "已收样",
  "已培养": "已培养",
  "培养中": "已培养",
  "培养完成": "已培养",
  "已分血": "已分血",
  "实验中": "实验中",
  "已完成": "已完成",
};

/** 数据字典分类分组（与后端 web.config 中 dict:* 种子数据一致；仅影响左侧展示，不影响存储/调用） */
export const DICT_CATEGORIES = {
  "样本信息": ["样本来源", "来源医院", "样本类型"],
  "检测业务": ["检测项目"],
  "流程状态": ["状态枚举", "异常类型"],
  "设备管理": ["设备型号", "芯片类型"],
};
