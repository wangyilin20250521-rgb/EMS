// ─── 欢迎页示范问题（2026-09-21 重构） ─────────────────────────────────────
// 数据单源：完整分组模板库见 ai-features.ts。欢迎页只放「最经典」的 4 条入口
// （2026-09-21 用户设计：从 9 条收成 4 条，其余模板走侧栏「技能」面板），
// 精选口径 = 单点查询 / 汇总统计 / 风险预警 / 全链路演示 各一条。

import { AI_TEMPLATES } from "./ai-features"

export interface PromptTemplateItem {
  id: string
  label: string
  text: string
  icon: string
}

/** 精选顺序即展示顺序（仅存 id，文案仍取自 ai-features.ts，避免双份维护） */
const STARTER_IDS = ["query-sample", "batch-report", "tat-overdue", "ai-native-full-demo"]

export const WELCOME_STARTERS: PromptTemplateItem[] = STARTER_IDS
  .map((id) => AI_TEMPLATES.find((t) => t.id === id))
  .filter((t): t is NonNullable<typeof t> => !!t)
  .map(({ id, label, icon, prompt }) => ({ id, label, icon, text: prompt }))
