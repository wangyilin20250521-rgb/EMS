/**
 * AI 工具名 → 中文展示名（2026-09-28）：思考轨迹 / 工作记录共用一份口径。
 * 面向用户的展示一律用中文名；英文原名不丢——过程项自带 toolName，
 * 由 AIThinkingTrace / ConversationWorklog 挂在 title 上供 hover 查看。
 */

/** agent-server 静态工具 + 前端合成项 */
const STATIC_TOOL_LABELS: Record<string, string> = {
  query_database: "查询数据库",
  search_knowledge_base: "知识库检索",
  scan_operational_insights: "运营风险巡检",
  rule_guidance: "规则指引",
  read_file: "读取规则文件",
  show_rule_file: "规则文件预览",
  render_chart: "生成图表",
  create_workflow_task: "创建工作任务",
  update_workflow_task: "更新工作任务",
  // 正则快路的合成工具名（chat-handler 直接下发展示名，非注册表工具）
  结构化查询: "结构化查询",
  // 交互手段（通常被工作记录排除，但会出现在思考轨迹里）
  ask_user: "提问确认",
  request_form: "参数表单",
  request_file: "文件上传",
  propose_action: "操作提议",
  delegate: "委派子助手",
};

/** 业务只读工具（backend/packages/ai-tools 注册表 readOnly=true 条目） */
const CATALOG_TOOL_LABELS: Record<string, string> = {
  "alert.list": "查询预警",
  "anomaly.list": "查询异常",
  "reception.batch_samples": "查询批次样本",
  "reception.list_batches": "查询收样批次",
  "schedule.list_pre_orders": "查询排单",
  "schedule.siro_processes": "查询实验流程",
  "siro.device_status": "查询设备状态",
  "siro.specimen_results": "查询样例结果",
  "siro.task_status": "查询任务状态",
  "strategy_rule.list_files": "列出规则文件",
  "strategy_rule.read_file": "读取规则文件",
  "system.profile_detail": "查询方案详情",
  "system.profile_list": "查询方案列表",
  "system.profile_rule_file": "读取方案规则文件",
};

/** 工具中文名；未收录的工具原样回退（新增工具不会掉展示） */
export function aiToolLabel(toolName: string): string {
  return STATIC_TOOL_LABELS[toolName] ?? CATALOG_TOOL_LABELS[toolName] ?? toolName;
}
