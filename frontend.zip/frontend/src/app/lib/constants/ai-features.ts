// ─── 功能化引导模板库（2026-09：AIFeatureMenu「功能引导」数据源） ─────────────
// 八组场景（查询统计/收样登记/样本与制备/排单排程/实验与设备/质控处置/策略规则/演示测试），共 28 条。
// 目标：用户仅靠 AI 助手即可通过自然语言完成各模块操作。
// 写操作场景的措辞与 agent 指令严格对齐：
//   - schedule.create_pre_order（唯一 form:true 工具）→ 明确引导 request_form 参数表单一次收集
//   - 其余写操作（reception.* / sample.* / prep.* / product.* / alert.* / strategy_rule.update_file 等）→ propose_action 确认闭环
//   - 规则修改先读文件原文再提问 → update_file propose（确认卡展示字段级 diff）
// 禁止承诺工具办不到的行为（如"保存即自动触发排单"——task-schedule-rules 当前为规格定义）。

export type AITemplateGroupId = "query" | "reception" | "sample" | "schedule" | "lab" | "quality" | "rules" | "demo"

export interface AITemplateGroup {
  id: AITemplateGroupId
  label: string
  /** lucide 图标名（由 ai-template-icons 的 AI_TEMPLATE_ICON_MAP 解析） */
  icon: string
}

export interface AITemplateItem {
  id: string
  group: AITemplateGroupId
  label: string
  /** 面板行副文案（一句话，演示用） */
  description: string
  icon: string
  /** 点击后填入输入框的实际 prompt（发送给 AI 的场景文本） */
  prompt: string
}

export const AI_TEMPLATE_GROUPS: AITemplateGroup[] = [
  { id: "query", label: "查询统计", icon: "Search" },
  { id: "reception", label: "收样登记", icon: "Inbox" },
  { id: "sample", label: "样本与制备", icon: "TestTubes" },
  { id: "schedule", label: "排单排程", icon: "CalendarRange" },
  { id: "lab", label: "实验与设备", icon: "Microscope" },
  { id: "quality", label: "质控处置", icon: "ShieldCheck" },
  { id: "rules", label: "策略规则", icon: "Settings2" },
  { id: "demo", label: "演示测试", icon: "Zap" },
]

export const AI_TEMPLATES: AITemplateItem[] = [
  // ─── 查询统计 ───
  {
    id: "query-sample",
    group: "query",
    label: "今日样本概览",
    description: "今日样本按状态汇总并标注临期",
    icon: "Search",
    prompt: "列出今天收到的所有样本，按状态汇总，并标注即将超期的样本。",
  },
  {
    id: "analyze-anomaly",
    group: "query",
    label: "异常样本一览",
    description: "异常原因/处置状态/登记时间",
    icon: "AlertTriangle",
    prompt: "请列出所有异常样本，说明异常原因、当前处置状态和登记时间。",
  },
  {
    id: "schedule-suggestion",
    group: "query",
    label: "可排单样本",
    description: "满足排单条件的样本按项目分组",
    icon: "CalendarDays",
    prompt: "当前有哪些样本已满足排单条件可以送去实验？请按项目分组列出，标注收到的日期。",
  },
  {
    id: "tat-overdue",
    group: "query",
    label: "TAT 超期预警",
    description: "逐条列出超期与 24h 内临期样本",
    icon: "Clock",
    prompt: "请逐条列出 TAT 已超期或 24 小时内将超期的样本，包括样本编号、项目、TAT 截止日和超期天数。",
  },
  {
    id: "device-status",
    group: "query",
    label: "设备运行状态",
    description: "SIRO 在线状态/负载/心跳",
    icon: "Activity",
    prompt: "请列出所有 SIRO 设备的在线状态、当前负载和最近一次心跳时间。",
  },
  {
    id: "batch-report",
    group: "query",
    label: "今日生产摘要",
    description: "新收/入库/任务/异常/设备汇总",
    icon: "BarChart2",
    prompt: "请生成今日实验生产摘要，包括：新收样本数、已入库数、进行中任务数、异常数、设备利用率。",
  },
  {
    id: "sample-status-distribution",
    group: "query",
    label: "样本状态分布",
    description: "各状态样本量分布，可出图表",
    icon: "PieChart",
    prompt:
      "统计当前样本的总体分布：按状态（待接收/已接收/已收样/待实验/实验中/已完成/异常）汇总样本数，并给出各检测项目（NIFTY/WES/CNVseq/CMA/WGS 等）下的状态分布，可用柱状图或饼图展示，点出其中异常样本数量。没有数据时如实说明，不要编造。",
  },
  {
    id: "risk-scan",
    group: "query",
    label: "运营风险巡检",
    description: "一键扫描 TAT 临期与未处理异常",
    icon: "Radar",
    prompt:
      "请做一次运营风险巡检：调用 scan_operational_insights 扫描当前 TAT 临期样本与未处理异常，基于返回的确定性证据逐条列出风险项，标注影响并给出处理优先级建议（严重项优先）；扫描结果为空时如实说明当前无风险，不要编造。",
  },
  // ─── 收样登记 ───
  {
    id: "reception-register",
    group: "reception",
    label: "登记收样批次",
    description: "AI 提问采集细节后登记一批收样",
    icon: "Inbox",
    prompt:
      "我要登记一批收样样本，请引导我完成：先查询收样批次列表了解最近批次；再用提问逐项与我确认——先确认登记方式（①扫码登记：一管一条码 ②按检测产品与数量登记），再确认管数、纸单数、收样人、送检医院、来源等信息；收集齐全后经确认卡提议执行 reception.register_batch 等我确认。不要编造任何条码或数量。",
  },
  {
    id: "reception-confirm",
    group: "reception",
    label: "确认收样样本",
    description: "找待确认批次/样本并确认流转",
    icon: "PackageCheck",
    prompt:
      "请帮我完成收样确认：先查询收样批次列表找出待确认状态的批次与其中样本（向我展示一律用样本编号），让我选择要确认的批次与样本，再经确认卡提议执行 reception.confirm_samples 并说明结果。不要臆造批次或样本。",
  },
  {
    id: "reception-anomaly",
    group: "reception",
    label: "收样异常上报",
    description: "数量不符/破损等异常登记",
    icon: "ShieldAlert",
    prompt:
      "请帮我上报一条收样异常：先读取 data/rules/anomaly-rules.py 了解异常类别口径，再逐项问我：涉及哪个批次或样本、异常原因、补充说明（可选关联产品）；信息齐全后经确认卡提议执行 reception.report_anomaly。不要虚构异常。",
  },
  {
    id: "reception-batch-update",
    group: "reception",
    label: "收样批次补录",
    description: "修改批次内样本字段或补录新增样本",
    icon: "Pencil",
    prompt:
      "我要补录/修改某个收样批次的信息：先查询收样批次列表，让我选择目标批次并查看其样本明细；再逐项问我修改内容——是修改批次内已有样本的字段（如检测项目/样本类型/样本编号），还是补录新增样本；每项改动先与我确认，不要臆造样本编号；收集完整后经确认卡提议执行 reception.batch_update 等我确认。",
  },
  // ─── 样本与制备 ───
  {
    id: "sample-maintain",
    group: "sample",
    label: "样本信息与状态维护",
    description: "修改样本字段或流转状态",
    icon: "ClipboardList",
    prompt:
      "我要维护某个样本的信息：先按样本编号/项目/状态帮我定位并列出候选样本（展示一律用样本编号），让我选择目标样本；再用提问逐项确认操作——①修改信息字段（患者/性别/年龄/样本类型/检测项目等）②变更状态（如 待接收/已接收/已收样/待实验/已完成，按页面状态口径选择）；确认后经确认卡提议执行 sample.update 或 sample.update_status。不要臆造样本信息。",
  },
  {
    id: "prep-create",
    group: "sample",
    label: "创建制备任务",
    description: "选批次与分血上位机，建任务后提交实验",
    icon: "FlaskConical",
    prompt:
      "帮我创建一个分血/样本制备任务并提交实验：第一步查询收样批次列表与 SIRO 设备列表，让我选择批次与分血上位机（设备名与设备号必须来自查询结果，禁止编造）；第二步从所选批次中与我确认待制备样本；任务编号按页面同规则自动分配（PREP-加时间戳），无需我填写；信息齐全后经确认卡提议执行 prep.create，确认完成后继续提议 prep.submit_to_experiment 将制备任务提交至实验环节，并简要汇报结果。",
  },
  // ─── 排单排程 ───
  {
    id: "schedule-create",
    group: "schedule",
    label: "创建排单",
    description: "参数表单收集设备/项目/流程/样例",
    icon: "CalendarPlus",
    prompt:
      "帮我创建一张排单：先查询当前可排（已收样/待实验）样本按项目的数量作为说明依据，然后调用 request_form 打开参数表单（schedule.create_pre_order），由我在表单中选择设备型号、实验流程与本次排单样例——表单一次收集即可，不要改用逐条提问；收到表单确认值后按原值提议创建排单。不要编造流程号或样例。",
  },
  {
    id: "schedule-view",
    group: "schedule",
    label: "查看排单",
    description: "排单与任务状态总览（只读）",
    icon: "ListChecks",
    prompt:
      "请查询当前所有排单并按项目汇总：排单编号、设备型号、样本数、实验流程、状态（待确认/已确认）及对应实验任务进度，重点标出待确认超过 1 天或任务异常的排单。没有记录时如实告知。",
  },
  {
    id: "schedule-confirm",
    group: "schedule",
    label: "确认排单并投递",
    description: "选待确认排单，确认后自动建任务",
    icon: "CheckCircle2",
    prompt:
      "帮我确认排单：先查询状态为「待确认」的排单，把每个排单的项目/设备/样本数列成单选让我选择要确认哪一个，随后经确认卡提议执行 schedule.confirm_pre_order；确认完成后简要汇报生成的实验任务。",
  },
  // ─── 实验与设备 ───
  {
    id: "task-manage",
    group: "lab",
    label: "任务管理",
    description: "查看任务并启动或终止",
    icon: "PlayCircle",
    prompt:
      "帮我查看并管理实验任务：先查询任务列表（web.tasks，可按状态/项目筛选），列出任务编号、项目、状态、设备让我选择；随后按我的指令操作——启动任务（task.start）或终止任务（task.terminate，终止不可恢复，执行前必须明确警示并二次确认）；每步经确认卡提议等我确认。不要编造任务编号。",
  },
  {
    id: "sequencing-create",
    group: "lab",
    label: "创建测序任务",
    description: "选测序仪与芯片创建测序任务",
    icon: "Dna",
    prompt:
      "帮我创建一个测序任务：先查询可用测序仪（web.devices 中类型为测序仪的设备）并列出来让我选择——测序仪必须来自查询结果，禁止编造；再与我确认芯片信息（可选）；信息齐全后经确认卡提议执行 sequencing.create，等我确认后汇报创建的任务编号。",
  },
  {
    id: "product-ops",
    group: "lab",
    label: "产物登记与销毁",
    description: "登记/更新产物，销毁需红色警示",
    icon: "Boxes",
    prompt:
      "我要管理实验产物（文库/核酸/混样）：先查询现有产物列表（可按类型或关联任务筛选）并展示关键字段，让我选择操作——①登记新产物（产品类型/关联任务/浓度/体积/位置等先逐项与我确认）②更新产物信息（存储条件/有效期/备注）③销毁产物（不可恢复，执行前必须向我明确警示；先让我从产物列表中选择目标）；每步经确认卡提议执行 product.create / product.update / product.destroy。不要编造产物或任务编号。",
  },
  {
    id: "device-manage",
    group: "lab",
    label: "设备登记与维护",
    description: "登记设备、更新信息或维护计划",
    icon: "Wrench",
    prompt:
      "帮我登记并维护实验室设备：先查询现有设备列表供参考（避免重复登记），再逐项问我——设备类型（测序仪/功能岛/AGV）、名称、型号（可选 SN/IP/位置）；确认后经确认卡提议执行 device.create；若要调整已有设备信息（名称/状态等）或登记维护计划（维护时间与原因），改为提议 device.update / device.maintenance。设备信息必须来自我的输入或查询结果，不要臆造。",
  },
  // ─── 质控处置 ───
  {
    id: "anomaly-resolve",
    group: "quality",
    label: "异常处置",
    description: "选异常与处置方式后提议处置",
    icon: "ShieldCheck",
    prompt:
      "帮我处置一条实验异常：先查询异常列表（可按状态/级别筛选，默认待处理），把异常编号、类别、级别、描述列出来让我选择目标；再让我从五种处置方式中点选——使用原样本重新实验 / 使用备份样例 / 人工判定可接受（转已忽略）/ 让步接收 / 自定义处理；选「人工判定可接受/让步接收/自定义」时还要向我收集处置说明；齐备后经确认卡提议执行 anomaly.resolve 并汇报处置结果。不要臆造异常编号或处置方式。",
  },
  {
    id: "alert-handle",
    group: "quality",
    label: "预警处置",
    description: "确认或解决系统预警",
    icon: "Bell",
    prompt:
      "帮我处理系统预警：先查询预警列表（默认未处理项），把每条预警的编号、级别、类型、内容和时间列出来让我选择；再确认处置方式——「确认」表示已知晓（alert.acknowledge）或「解决」表示已处理完毕（alert.resolve）；选定后经确认卡提议执行等我确认，完成后汇报结果。不要编造预警编号；列表为空时如实告知当前无预警。",
  },
  // ─── 策略规则 ───
  {
    id: "rules-tat-view",
    group: "rules",
    label: "解读 TAT 规则",
    description: "读规则文件解释各项目 TAT 配置",
    icon: "BookOpen",
    prompt:
      "请帮我解读当前 TAT 规则：读取 data/rules/tat-rules.json 文件原文，用表格列出各检测项目配置的 TAT 截止天数与文件头注释中的消费说明；数值必须与文件一致，未配置的项目如实说明，不要猜测。",
  },
  {
    id: "rules-tat-edit",
    group: "rules",
    label: "调整 TAT 天数",
    description: "改规则文件中的天数，确认卡比对差异",
    icon: "SlidersHorizontal",
    prompt:
      "我要调整 TAT 规则：先读取 data/rules/tat-rules.json 核对现有各项目 TAT 天数，再逐项问我「改哪个项目、目标天数」（给出现值并让选择），确认后用完整文件内容经确认卡提议 strategy_rule.update_file 保存——保留文件头注释与其他项目配置不变，确认卡会展示字段级差异。",
  },
  {
    id: "rules-auto-schedule",
    group: "rules",
    label: "新增自动排单规则",
    description: "为项目添加四要素自动排单规则",
    icon: "FileCog",
    prompt:
      "请帮我在 data/rules/task-schedule-rules.py 中为项目新增一条自动排单规则：先读取该文件，参照头部注释与既有项目条目结构组织 trigger/ordering/autoScheduleCount/qc 四要素，禁止臆造字段形状；四要素取值用提问逐项让我选择；内容完整后经确认卡提议 strategy_rule.update_file 保存，并说明该规则当前按规格供自动排单接入。",
  },
  {
    id: "rules-overview",
    group: "rules",
    label: "规则文件总览与修改",
    description: "浏览全部规则文件，选一个解读或修改",
    icon: "FolderOpen",
    prompt:
      "请带我浏览策略规则文件：先用 strategy_rule.list_files 列出全部规则文件（名称/格式/大小/更新时间）并逐条用一句话说明用途，让我选择要解读或修改的文件；选定后先读取文件原文再操作——解读按原文逐项说明（数值必须与文件一致，不要猜测）；修改则先问清改动内容，保留文件头注释与其余配置不变，经确认卡提议 strategy_rule.update_file 保存（确认卡会展示字段级差异）。",
  },
  // ─── 演示测试 ───
  {
    id: "ai-native-full-demo",
    group: "demo",
    label: "全链路演示",
    description: "一键演示 AI Native 全链路（参数卡片/自动执行两种模式）",
    icon: "Zap",
    prompt:
      "全链路演示：收样登记→样本入库→策略管理自动排单。\n\n【第1步】样本来源固定使用演示样本：由你随机生成 16 个样本编号（规则与手工录入「随机填充」一致：年份后两位 + S + 8 位随机数字，如 26S12345678、26S86420975；16 个编号互不重复）。不要询问样本来源，也不要打开任何文件上传卡。\n\n【第2步】ask_user 提问执行模式，两个选项：① 参数卡片（你逐项确认检测项目（候选 NIFTY/WES/CNVseq）、样本数量、设备型号——由我自行选择） ② 自动执行（你先读取 data/rules/task-schedule-rules.py，把其中 enabled=true 的项目作为「自动排单策略」清单，再用 ask_user 把清单作为【选项按钮】列出（如「NIFTY 自动排单策略」「WES 自动排单策略」「CNVseq 自动排单策略」）供我点击选择——点击即选，不要要求我手动输入策略名；选定后按该策略的配置全自动执行，不再逐项问我参数）。\n\n【第3步】所有选择完成后立即执行，不允许再问任何确认问题。具体执行：\n\n如果是「自动执行」：先生成 16 个随机编号（26S+8位随机数字，互不重复）→无论库中是否已有历史演示样本或批次，都必须完整走流程——禁止因发现已有样本而跳过收样登记、复用旧批次或旧样本，每次运行都要创建新批次与 16 个新样本→直接提议 reception.register_batch（barcodes 填这 16 个新编号，project 传所选策略对应的项目、sampleTypes 传 16 个「血液」（与 barcodes 索引对齐——让登记占位行可见检测项目与类型；患者信息按设计留待入库步骤补全），products 传 [{name: 策略项目, count: 16}]，summary 写「策略项目 演示登记 16 例」，details 逐条列出全部 16 个新样本编号——完整列出、用「、」分隔，禁止范围简写，另附产品明细）→等待我确认→从系统通知提取本次新生成的 batchId（不得使用历史批次号）→直接提议 sample.create_batch：batchId 用上一步结果，samples 数组每项必须包含以下全部字段：sampleNo（本次生成的 16 个随机编号）、patient（受检者保密别名，与种子数据同规则：受检者 + 4 位字母数字，字符集 ABCDEFGHJKMNPQRSTUVWXYZ23456789「不含易混淆字符 I/L/O/0/1」，如 受检者S4PB、受检者K7XM；16 个别名互不相同）、gender（全部写「女」——业务 90% 女性样本，与随机填充规则一致）、age（20~69 之间随机整数）、type（全部写「血液」）、project（全部写策略项目）。每条样本的 6 个字段必须齐全，缺一不可；details 同样逐条列出全部 16 个新编号（禁止范围简写）。→等待我确认→汇报自动创建的排单编号（含项目名）和「前往排单看板确认」。注意：「自动执行」模式下参数已由所选策略确定，直接 propose 即可——禁止用 ask_user 询问条码列表或产品明细（批量参数已豁免询问门禁），也不要再问任何确认问题；这些信息在 propose_action 的 details 展示，用户通过确认卡一次性确认。\n\n如果是「参数卡片」：先生成 16 个随机编号（26S+8位随机数字，互不重复）→逐项 ask_user 问检测项目（候选 NIFTY/WES/CNVseq）、样本数量（默认 16）、设备型号（默认 SIRO-16）→收集完按所选项目执行上述两步 propose_action（所有 project 字段用所选项目填充）。",
  },
]
