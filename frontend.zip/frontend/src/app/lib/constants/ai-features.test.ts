import { describe, expect, it } from "vitest";
import { AI_TEMPLATES, AI_TEMPLATE_GROUPS } from "./ai-features";
import { WELCOME_STARTERS } from "./ai-prompts";

describe("AI 功能模板库一致性", () => {
  it("id 全局唯一且 group 均合法", () => {
    const ids = AI_TEMPLATES.map((t) => t.id);
    expect(new Set(ids).size).toBe(ids.length);
    const groupIds = new Set(AI_TEMPLATE_GROUPS.map((g) => g.id));
    for (const t of AI_TEMPLATES) expect(groupIds.has(t.group)).toBe(true);
  });

  it("覆盖全部分组且每组 ≥1 条", () => {
    for (const g of AI_TEMPLATE_GROUPS) {
      expect(AI_TEMPLATES.filter((t) => t.group === g.id).length).toBeGreaterThan(0);
    }
  });

  it("欢迎页示范问题 WELCOME_STARTERS = 精选 4 条（单点查询/汇总统计/风险预警/全链路演示）", () => {
    expect(WELCOME_STARTERS.map((t) => t.id)).toEqual([
      "query-sample",
      "batch-report",
      "tat-overdue",
      "ai-native-full-demo",
    ]);
    // 文案单源：label/text 必须与 AI_TEMPLATES 中同 id 条目逐字一致
    const byId = Object.fromEntries(AI_TEMPLATES.map((t) => [t.id, t]));
    for (const s of WELCOME_STARTERS) {
      expect(byId[s.id], `id ${s.id} 不存在于 AI_TEMPLATES`).toBeTruthy();
      expect(s.label).toBe(byId[s.id].label);
      expect(s.text).toBe(byId[s.id].prompt);
      expect(s.icon).toBe(byId[s.id].icon);
    }
    expect(WELCOME_STARTERS[0].text).toBe("列出今天收到的所有样本，按状态汇总，并标注即将超期的样本。");
  });
});
