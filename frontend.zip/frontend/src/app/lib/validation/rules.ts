import type { Sample, Task } from '../api/types'

export interface CrossFieldIssue {
  path: string[]
  message: string
  code: string
}

function parseDateTime(value: string): number | null {
  const normalized = /^\d{2}-\d{2}\s+\d{2}:\d{2}$/.test(value) ? `2026-${value}` : value
  const parsed = Date.parse(normalized.replace(' ', 'T'))
  return Number.isNaN(parsed) ? null : parsed
}

export function validateSampleCrossFields(sample: Pick<Sample, 'isCultured' | 'cultureStatus' | 'cultureDueDate' | 'source' | 'extId' | 'gestWeek'>): CrossFieldIssue[] {
  const issues: CrossFieldIssue[] = []

  if (sample.isCultured && !sample.cultureStatus?.trim()) {
    issues.push({ path: ['cultureStatus'], message: '培养样本必须填写培养状态', code: 'CV-001' })
  }

  if (sample.isCultured && !sample.cultureDueDate?.trim()) {
    issues.push({ path: ['cultureDueDate'], message: '培养样本必须填写预计培养完成日期', code: 'CV-001' })
  }

  if (sample.source === '外院' && !sample.extId?.trim()) {
    issues.push({ path: ['extId'], message: '外院样本必须填写外部编号', code: 'CV-002' })
  }

  if (sample.gestWeek !== null && sample.gestWeek !== undefined && (sample.gestWeek < 1 || sample.gestWeek > 45)) {
    issues.push({ path: ['gestWeek'], message: '孕周必须在 1 到 45 之间', code: 'CV-003' })
  }

  return issues
}

export function validateTaskCrossFields(task: Pick<Task, 'createdAt' | 'estDone'>): CrossFieldIssue[] {
  const createdAt = parseDateTime(task.createdAt)
  const estDone = parseDateTime(task.estDone)

  if (createdAt === null || estDone === null || estDone <= createdAt) {
    return [{ path: ['estDone'], message: '预计完成时间必须晚于创建时间', code: 'CV-004' }]
  }

  return []
}

