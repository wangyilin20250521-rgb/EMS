import type { z } from 'zod'
import { anomalySchema } from './schemas/anomaly'
import { sampleSchema } from './schemas/sample'
import { taskSchema } from './schemas/task'

export interface FieldError {
  field: string
  message: string
  code: string
}

export type ValidationResult<T> = { success: true; data: T } | { success: false; errors: FieldError[] }

export interface Validator<T> {
  validate(input: unknown): ValidationResult<T>
  validateField(field: keyof T, value: unknown): FieldError | null
}

export function zodIssuesToFieldErrors(issues: z.core.$ZodIssue[]): FieldError[] {
  return issues.map((issue) => ({
    field: issue.path.join('.') || 'form',
    message: issue.message,
    code: issue.code,
  }))
}

export function validateWithSchema<T>(schema: z.ZodType<T>, input: unknown): ValidationResult<T> {
  const result = schema.safeParse(input)
  return result.success
    ? { success: true, data: result.data }
    : { success: false, errors: zodIssuesToFieldErrors(result.error.issues) }
}

export function validateSample(input: unknown) {
  return validateWithSchema(sampleSchema, input)
}

export function validateTask(input: unknown) {
  return validateWithSchema(taskSchema, input)
}

export function validateAnomaly(input: unknown) {
  return validateWithSchema(anomalySchema, input)
}

export { anomalySchema } from './schemas/anomaly'
export type { AnomalyInput, AnomalyOutput } from './schemas/anomaly'
export { sampleSchema } from './schemas/sample'
export type { SampleInput, SampleOutput } from './schemas/sample'
export { taskCreationSchema, taskSchema } from './schemas/task'
export type { TaskCreationInput, TaskInput, TaskOutput } from './schemas/task'
export { loginSchema, changePasswordSchema } from './schemas/auth'
export type { LoginInput, LoginOutput, ChangePasswordInput } from './schemas/auth'
export { plateInfoSchema } from './schemas/plate-info'
export type { PlateInfoInput, PlateInfoOutput } from './schemas/plate-info'
export { createTaskSchema } from './schemas/create-task'
export type { CreateTaskInput, CreateTaskOutput } from './schemas/create-task'
export { createSequencingTaskSchema } from './schemas/sequencing-task'
export type { CreateSequencingTaskInput, CreateSequencingTaskOutput } from './schemas/sequencing-task'
export { validateSampleCrossFields, validateTaskCrossFields } from './rules'
