import { describe, expect, it } from 'vitest'
import { validateSample, validateTask } from './index'

describe('validation schemas', () => {
  it('accepts a complete sample and masks invalid missing external identifiers', () => {
    const validSample = {
      id: 'S20260715-001',
      patient: '张三',
      gender: '女',
      age: 32,
      gestWeek: 18,
      type: '血液',
      project: 'NIFTY',
      productType: 'NIFTY',
      status: '已收样',
      specimens: '未实验',
      receivedAt: '2026-07-15',
      tat: '72h',
      batchId: '2026-07-15-001',
      source: '本院',
      extId: '',
    }

    expect(validateSample(validSample).success).toBe(true)
    expect(validateSample({ ...validSample, source: '外院' })).toMatchObject({
      success: false,
      errors: expect.arrayContaining([expect.objectContaining({ field: 'extId' })]),
    })
  })

  it('rejects tasks whose estimated completion is not after creation', () => {
    expect(validateTask({
      id: 'T20260715-001',
      project: 'NIFTY',
      sampleCount: 1,
      specimenCount: 1,
      device: 'MGISEQ-2000 #1',
      status: '就绪',
      createdAt: '2026-07-15 10:00',
      estDone: '2026-07-15 09:00',
    })).toMatchObject({
      success: false,
      errors: expect.arrayContaining([expect.objectContaining({ field: 'estDone' })]),
    })
  })
})