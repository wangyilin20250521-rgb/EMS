import { z } from 'zod'

export const anomalySchema = z.object({
  id: z.string().regex(/^E\d{3}$/, '异常编号格式必须为 E001'),
  type: z.enum(['收样异常', '样本异常', 'AI识别异常', '实验异常', '收样核对', '设备异常', '系统异常']),
  related: z.string().trim().min(1, '关联对象必填'),
  desc: z.string().trim().min(1, '异常描述必填'),
  level: z.enum(['高', '中', '低']),
  status: z.string().trim().min(1, '异常状态必填'),
  time: z.string().trim().min(1, '异常时间必填'),
})

export type AnomalyInput = z.input<typeof anomalySchema>
export type AnomalyOutput = z.output<typeof anomalySchema>
