import { z } from 'zod'

/** Login form validation schema */
export const loginSchema = z.object({
  username: z.string().trim().min(1, '用户名不能为空').max(50, '用户名不超过50个字符'),
  password: z.string().min(6, '密码至少6位'),
})

/** Password change form validation schema */
export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, '请输入当前密码'),
  newPassword: z.string().min(6, '新密码至少6位'),
  confirmPassword: z.string().min(1, '请确认新密码'),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: '两次输入的新密码不一致',
  path: ['confirmPassword'],
}).refine((data) => data.newPassword !== data.currentPassword, {
  message: '新密码不能与当前密码相同',
  path: ['newPassword'],
})

export type LoginInput = z.input<typeof loginSchema>
export type LoginOutput = z.output<typeof loginSchema>
export type ChangePasswordInput = z.input<typeof changePasswordSchema>
