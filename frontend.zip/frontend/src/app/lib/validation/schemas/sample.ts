import { z } from 'zod'
import { SAMPLE_STATUSES } from '../../api/types'
import { PROJECT_OPTIONS, SOURCE_OPTIONS, SAMPLE_TYPE_OPTIONS } from '../../api'
import { validateSampleCrossFields } from '../rules'

export const sampleSchema = z.object({
  id: z.string().regex(/^S\d{8}-\d{3}$/, '样本编号格式必须为 SYYYYMMDD-001'),
  patient: z.string().trim().min(1, '患者姓名必填').max(50, '患者姓名不能超过 50 字符'),
  gender: z.enum(['男', '女']),
  age: z.coerce.number().int('年龄必须为整数').min(1, '年龄必须大于 0').max(150, '年龄不能超过 150'),
  gestWeek: z.coerce.number().min(1, '孕周必须在 1 到 45 之间').max(45, '孕周必须在 1 到 45 之间').nullable(),
  type: z.enum(SAMPLE_TYPE_OPTIONS),
  project: z.enum(PROJECT_OPTIONS),
  productType: z.string().trim().min(1, '产品类型必填'),
  status: z.enum(SAMPLE_STATUSES),
  specimens: z.string().regex(/^(\d+\/\d+|\d+\+\d+|未实验)$/, '样本份数格式必须为 1/1、1+1 或 未实验'),
  receivedAt: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, '到样日期格式必须为 YYYY-MM-DD'),
  tat: z.string().trim().min(1, 'TAT 必填'),
  batchId: z.string().trim().min(1, '批次号必填'),
  source: z.enum(SOURCE_OPTIONS),
  extId: z.string().default(''),
  isCultured: z.boolean().optional().default(false),
  cultureStatus: z.string().optional(),
  cultureDueDate: z.string().optional(),
  hasExperiment: z.boolean().optional().default(false),
}).superRefine((sample, context) => {
  validateSampleCrossFields(sample).forEach((issue) => {
    context.addIssue({ code: 'custom', path: issue.path, message: issue.message })
  })
})

export type SampleInput = z.input<typeof sampleSchema>
export type SampleOutput = z.output<typeof sampleSchema>
