import { z } from 'zod'
import { TASK_STATUSES } from '../../api/types'
import { PROJECT_OPTIONS } from '../../api'
import { validateTaskCrossFields } from '../rules'

const dateTimeSchema = z.string().regex(/^(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}|\d{2}-\d{2}\s\d{2}:\d{2})$/, '日期时间格式不正确')

export const taskSchema = z.object({
  id: z.string().regex(/^T\d{8}-\d{3}$/, '任务编号格式必须为 TYYYYMMDD-001'),
  project: z.enum(PROJECT_OPTIONS),
  sampleCount: z.coerce.number().int('样本数量必须为整数').positive('样本数量必须大于 0'),
  specimenCount: z.coerce.number().int('样例数量必须为整数').positive('样例数量必须大于 0'),
  device: z.string().trim().min(1, '设备必填'),
  status: z.enum(TASK_STATUSES),
  createdAt: dateTimeSchema,
  estDone: dateTimeSchema,
}).superRefine((task, context) => {
  validateTaskCrossFields(task).forEach((issue) => {
    context.addIssue({ code: 'custom', path: issue.path, message: issue.message })
  })
})

export const taskCreationSchema = taskSchema.extend({
  workflow: z.string().trim().min(1, '实验流程必填'),
  selectedSamples: z.array(z.string()).min(1, '请至少选择一个样本'),
})

export type TaskInput = z.input<typeof taskSchema>
export type TaskOutput = z.output<typeof taskSchema>
export type TaskCreationInput = z.input<typeof taskCreationSchema>
