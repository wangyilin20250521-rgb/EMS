import { z } from 'zod'
import { PLATE_TYPES } from '../../api/types'

/** Plate ID format: P-YYYYMMDD-NNN */
const plateIdRegex = /^P-\d{8}-\d{3}$/

/** Plate info validation schema */
export const plateInfoSchema = z.object({
  plateId: z.string().regex(plateIdRegex, '板号格式应为 P-YYYYMMDD-NNN（如 P-20260629-001）'),
  plateType: z.enum(PLATE_TYPES, { message: '请选择板类型' }),
  storageLocation: z.string().trim().min(1, '存放位置不能为空'),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, '日期格式应为 YYYY-MM-DD'),
})

export type PlateInfoInput = z.input<typeof plateInfoSchema>
export type PlateInfoOutput = z.output<typeof plateInfoSchema>
