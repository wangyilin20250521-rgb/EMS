import { z } from 'zod'

const laneSchema = z.object({
  index: z.number().int().min(0, 'Lane 索引不能为负数'),
  sampleIds: z.array(z.string()).min(1, '每个 Lane 至少分配一个样本'),
})

const chipSchema = z.object({
  id: z.string().min(1, '芯片 ID 不能为空'),
  sequencerId: z.string().min(1, '测序仪 ID 不能为空'),
  lanes: z.array(laneSchema).min(1, '芯片至少需要一个 Lane'),
})

/** Sequencing task creation validation schema */
export const createSequencingTaskSchema = z.object({
  sequencerId: z.string().min(1, '请选择测序仪'),
  chips: z.array(chipSchema).min(1, '至少需要创建一个芯片'),
})

export type CreateSequencingTaskInput = z.input<typeof createSequencingTaskSchema>
export type CreateSequencingTaskOutput = z.output<typeof createSequencingTaskSchema>
