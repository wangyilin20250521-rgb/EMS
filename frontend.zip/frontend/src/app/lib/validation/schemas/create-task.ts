import { z } from 'zod'
import { plateInfoSchema } from './plate-info'

/** Task creation form validation schema */
export const createTaskSchema = z.object({
  preOrderId: z.string().min(1, '请选择排单'),
  deviceId: z.string().min(1, '请选择设备'),
  plateInfo: plateInfoSchema,
})

export type CreateTaskInput = z.input<typeof createTaskSchema>
export type CreateTaskOutput = z.output<typeof createTaskSchema>
