/**
 * SSE 单轮对话回调引擎（2026-09-04 组F：useAIChat 与策略管理页双实现收敛为共享层）。
 *
 * 职责：消费 sse.ts 的流式回调 → 累积单轮 pending 态（正文/过程项/图表/提议/提问）→
 * rAF 合帧后经 apply() 提交给页面（页面只负责"把增量合入最后一条 streaming AI 消息"）。
 *
 * 差异点全部留在页面：apply（消息列表形态）、onDone（页级收尾）、onError（错误呈现
 * ——assistant 页替换整条、策略页追加文本）。引擎层不感知消息列表。
 *
 * 协议镜像消费（组E 配套）：tool_update 在 toolCallId 匹配未闭合工具时覆盖其 🔄 尾行
 * （不叠行不刷屏）；tool_end 的 sources（KB 溯源）追加为 📎 行；done/error 后引擎进入
 * dead 态，迟到事件一律丢弃（防 error 后残留 rAF 回写）。
 */

import type {
  ActionProposal,
  ChartSpec,
  FileRequestSpec,
  FormRequestSpec,
  QuestionSpec,
  RuleFileSpec,
  SSECallbacks,
  TaskUpdateEvent,
} from "../utils/sse";
import { aiToolLabel } from "../constants/ai-tool-labels";

/** 单轮过程项（thinking / 工具调用），与页面消息模型结构兼容 */
export interface TurnProcessItem {
  id: string;
  type: "thinking" | "tool";
  text: string;
  /** 结构化工具名（tool 项专有；工作记录按模块归组用，避免从展示文本正则反解） */
  toolName?: string;
  /** 工具是否失败（tool 项专有；工作记录区分"已完成/未成功"） */
  toolError?: boolean;
  /** 工具项阶段：start=调用开始行 / end=结果行（工作记录按 end 计数，避免一次调用被计两次） */
  toolPhase?: "start" | "end";
}

/** 一次 apply 的增量（数组每次换新引用，页面直接合入新对象） */
export interface TurnPatch {
  text: string;
  process: TurnProcessItem[];
  /** trackCharts=false 时恒为 undefined（策略页消息模型无 charts 字段） */
  charts?: ChartSpec[];
  proposals: ActionProposal[];
  questions: QuestionSpec[];
  /** 规则文件卡（show_rule_file → rule_file_request；随消息渲染，2026-09-16 用户主动索取） */
  ruleFiles: RuleFileSpec[];
}

export interface BuildStreamCallbacksOptions {
  /** 过程项 id 前缀（页面消息 pendingId） */
  idPrefix: string;
  /** 页级提交：rAF 合帧后把累积增量合入"最后一条 streaming AI 消息" */
  apply: (patch: TurnPatch) => void;
  /** 流正常结束（后端 done 事件）；页级清理 streaming/abortRef */
  onDone: () => void;
  /** 页级错误呈现；引擎随后进入 dead 态丢弃迟到事件（含 error 后的 done） */
  onError: (msg: string) => void;
  /** 是否累积 chart_data（策略页消息模型无 charts 字段 → false，默认 true） */
  trackCharts?: boolean;
  /** 工具成功结果展示截断长度（字符，失败结果全量）；默认 500 */
  resultMaxChars?: number;
  /**
   * 带 field 的提问分流（2026-09-09 向导卡）：写操作参数确认类问题（ask_user.field 存在）
   * 交给页面级向导状态机（WizardCard 分步卡），不再进 questions[] 渲染普通卡。
   * 不提供时（策略页）行为不变：全部进 questions[]。
   */
  onFieldQuestion?: (q: QuestionSpec) => void;
  /** 参数表单请求透传（页面级状态机处理，不进 TurnPatch；2026-09-11） */
  onFormRequest?: (req: FormRequestSpec) => void;
  /** 文件上传请求透传（页面级状态机处理，不进 TurnPatch；2026-09-15） */
  onFileRequest?: (req: FileRequestSpec) => void;
  onTaskUpdate?: (event: TaskUpdateEvent) => void;
}

// ─── 纯函数（导出供单测） ────────────────────────────────────────────────────

/**委派子 agent 的展示名（与后端 delegate.ts 的 SUB_AGENTS 一致） */
const DELEGATE_AGENT_LABELS: Record<string, string> = {
  strategy: "策略配置助手",
  document: "文档咨询助手",
  solution: "解决方案咨询助手",
}

/** 工具开始行（🔧 中文名\n参数；delegate 委派走 🤝 可读形态，不甩原始 JSON）。
 * 展示名统一走 aiToolLabel（英文原名保留在过程项的 toolName 上供 hover 查看）。 */
export function formatToolStart(toolName: string, args: Record<string, unknown>): string {
  if (toolName === "delegate") {
    const label = DELEGATE_AGENT_LABELS[String(args.agent ?? "")] ?? String(args.agent ?? "子 agent")
    const task = truncateText(String(args.task ?? ""), 200)
    return `🤝 委派 ${label}：${task}`;
  }
  return `🔧 ${aiToolLabel(toolName)}\n${JSON.stringify(args, null, 2)}`;
}

/** 文本截断（不截断时原样返回） */
export function truncateText(text: string, maxChars: number): string {
  return text.length > maxChars ? `${text.slice(0, maxChars)}…` : text;
}

/** 工具结束行（✅/❌ 中文名\n结果；失败全量，成功截断；sources 追加 📎 溯源行）。
 * delegate 委派：解析结果 JSON 展示「子 agent 名 + 答复」，不甩原始载荷。
 */
export function formatToolEnd(
  ok: boolean,
  toolName: string,
  result: unknown,
  resultMaxChars: number,
  sources?: Array<{ kb: string; score: string }>,
): string {
  const rs = typeof result === "string" ? result : JSON.stringify(result, null, 2);
  const sourceLines = (sources ?? []).map(s => `📎 来源: ${s.kb}（${s.score}）`);
  if (toolName === "delegate") {
    try {
      const d = JSON.parse(rs) as { delegatedTo?: string; target?: string; answer?: string }
      if (d && typeof d.answer === "string") {
        const head = `🤝 ${d.delegatedTo ?? "子 agent"}${d.target ? `（${d.target}）` : ""}`;
        const display = ok ? truncateText(d.answer, resultMaxChars) : d.answer;
        return [`${ok ? "✅" : "❌"} ${head}\n${display}`, ...sourceLines].join("\n");
      }
    } catch { /* 非 JSON 载荷退回通用格式 */ }
  }
  const display = ok ? truncateText(rs, resultMaxChars) : rs;
  return [`${ok ? "✅" : "❌"} ${aiToolLabel(toolName)}\n${display}`, ...sourceLines].join("\n");
}

/** 结构化 partial → 单行展示文本（截断 300）。
 * delegate 委派进度（{ delegateAgent, text }）渲染为「🤝 [子 agent 名] 进度」。
 */
export function formatPartial(partial: unknown): string {
  if (partial && typeof partial === "object" && "delegateAgent" in (partial as Record<string, unknown>)) {
    const p = partial as { delegateAgent?: unknown; text?: unknown };
    return truncateText(`🤝 [${String(p.delegateAgent ?? "子 agent")}] ${String(p.text ?? "")}`, 300);
  }
  const s = typeof partial === "string" ? partial : JSON.stringify(partial);
  return truncateText(s ?? String(partial ?? ""), 300);
}

// ─── 引擎 ────────────────────────────────────────────────────────────────────

type FrameHandle = ReturnType<typeof setTimeout>;

/** rAF 合帧；无 requestAnimationFrame 环境（vitest/node）回退 setTimeout */
function scheduleFrame(fn: () => void): FrameHandle {
  const raf = typeof requestAnimationFrame === "function" ? requestAnimationFrame : (cb: () => void) => setTimeout(cb, 0);
  return raf(() => fn()) as unknown as FrameHandle;
}

function cancelFrame(handle: FrameHandle): void {
  if (typeof cancelAnimationFrame === "function") cancelAnimationFrame(handle as unknown as number);
  else clearTimeout(handle);
}

export function buildStreamCallbacks(opts: BuildStreamCallbacksOptions): SSECallbacks {
  const { idPrefix, apply, onDone, onError, trackCharts = true, resultMaxChars = 500, onFieldQuestion, onFormRequest, onFileRequest, onTaskUpdate } = opts;

  // ── pending 态 ──
  const process: TurnProcessItem[] = [];
  const charts: ChartSpec[] = [];
  const proposals: ActionProposal[] = [];
  const questions: QuestionSpec[] = [];
  const ruleFiles: RuleFileSpec[] = [];
  let text = "";
  let alive = true;
  /** 未闭合工具（tool_update 匹配用；executionMode=sequential，同一时刻至多一个） */
  let openTool: { toolCallId: string; item: TurnProcessItem } | null = null;
  let frame: FrameHandle | 0 = 0;

  const pushProcess = (type: TurnProcessItem["type"], itemText: string, meta?: { toolName?: string; toolError?: boolean; toolPhase?: "start" | "end" }): TurnProcessItem => {
    const item: TurnProcessItem = { id: `${idPrefix}-t-${process.length}`, type, text: itemText, ...meta };
    process.push(item);
    return item;
  };

  const emit = (): void => {
    if (!alive) return;
    const patch: TurnPatch = { text, process: [...process], proposals: [...proposals], questions: [...questions], ruleFiles: [...ruleFiles] };
    if (trackCharts) patch.charts = [...charts];
    apply(patch);
  };

  const flush = (): void => {
    if (frame) { cancelFrame(frame); frame = 0; }
    emit();
  };

  const schedule = (): void => {
    if (!frame) frame = scheduleFrame(() => { frame = 0; emit(); });
  };

  return {
    onThinkingDelta: (delta) => {
      if (!alive) return;
      const last = process[process.length - 1];
      if (last?.type === "thinking") last.text += delta;
      else pushProcess("thinking", delta);
      schedule();
    },

    onTextDelta: (delta) => {
      if (!alive) return;
      text += delta;
      schedule();
    },

    onToolStart: (e) => {
      if (!alive) return;
      openTool = { toolCallId: e.toolCallId, item: pushProcess("tool", formatToolStart(e.toolName, e.args ?? {}), { toolName: e.toolName, toolPhase: "start" }) };
      schedule();
    },

    // 协议镜像（组E）：tool_update 仅覆盖未闭合工具的 🔄 尾行，不叠行不刷屏
    onToolUpdate: (e) => {
      if (!alive) return;
      if (!openTool || e.toolCallId !== openTool.toolCallId) return;
      const item = openTool.item;
      item.text = item.text.replace(/\n🔄[^\n]*$/, "");
      item.text += `\n🔄 ${formatPartial(e.partial)}`;
      schedule();
    },

    onToolEnd: (e) => {
      if (!alive) return;
      openTool = null;
      pushProcess("tool", formatToolEnd(!e.isError, e.toolName, e.result, resultMaxChars, e.sources), { toolName: e.toolName, toolError: !!e.isError, toolPhase: "end" });
      schedule();
    },

    onChartData: (chart) => {
      if (!alive || !trackCharts) return;
      charts.push(chart);
      schedule();
    },

    onActionProposal: (proposal) => {
      if (!alive) return;
      // 按 proposalId 去重：防止同一写操作重复提议（如工具重试）产生多张相同 id 的卡
      if (proposals.some(p => p.proposalId === proposal.proposalId)) return;
      proposals.push(proposal);
      schedule();
    },

    onQuestion: (q) => {
      if (!alive) return;
      if (q.field && onFieldQuestion) {
        onFieldQuestion(q); // 向导分流：不进普通 questions
        return;
      }
      questions.push(q);
      schedule();
    },

    onFormRequest: (req) => {
      if (!alive) return;
      onFormRequest?.(req); // 页面级状态机处理（参数表单卡），不进 TurnPatch
    },

    onFileRequest: (req) => {
      if (!alive) return;
      onFileRequest?.(req); // 页面级状态机处理（文件上传卡），不进 TurnPatch
    },

    onRuleFile: (spec) => {
      if (!alive) return;
      // 按文件去重：防止重复调用产生多张相同卡
      if (ruleFiles.some(f => f.file === spec.file)) return;
      ruleFiles.push(spec);
      schedule();
    },

    onTaskUpdate: (event) => {
      if (!alive) return;
      onTaskUpdate?.(event);
    },

    onDone: () => {
      if (!alive) return;
      flush();
      alive = false;
      onDone();
    },

    onError: (msg) => {
      if (!alive) return;
      flush();
      alive = false;
      onError(msg);
    },
  };
}
