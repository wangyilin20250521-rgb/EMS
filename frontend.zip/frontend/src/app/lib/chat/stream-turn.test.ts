import { afterEach, describe, expect, it, vi } from "vitest"
import { buildStreamCallbacks, formatPartial, formatToolEnd, formatToolStart, type TurnPatch } from "./stream-turn"
import type { ActionProposal, QuestionSpec } from "../utils/sse"

/** 驱动工具：累积 apply 快照 */
function harness(trackCharts = true) {
  const applies: TurnPatch[] = []
  let done = 0
  let error: string | null = null
  const cbs = buildStreamCallbacks({
    idPrefix: "msg-1",
    apply: p => applies.push(p),
    onDone: () => { done++ },
    onError: (msg) => { error = msg },
    trackCharts,
  })
  return { cbs, applies, done: () => done, error: () => error }
}

/** 推进假定时器让 rAF 帧触发（jsdom rAF 按 ~16ms 帧调度，推进 100ms 保证落帧） */
const flushTimers = async () => { await vi.advanceTimersByTimeAsync(100) }

const proposal: ActionProposal = {
  proposalId: "p-1", toolName: "anomaly.resolve", summary: "处置异常", args: {}, status: "pending",
}

const question: QuestionSpec = { questionId: "q-1", question: "确认处置类型？" }

afterEach(() => { vi.useRealTimers() })

describe("buildStreamCallbacks（组F 引擎）", () => {
  it("thinking 增量续尾、跨类型 push", async () => {
    vi.useFakeTimers()
    const { cbs, applies } = harness()
    cbs.onThinkingDelta?.("先");
    cbs.onThinkingDelta?.("分析");
    cbs.onToolStart?.({ toolCallId: "tc1", toolName: "query_database", args: { sql: "SELECT 1" } });
    await flushTimers();
    expect(applies.length).toBe(1)
    const p = applies[0]
    expect(p.process[0]).toMatchObject({ type: "thinking", text: "先分析" })
    expect(p.process[1].text).toContain("🔧 查询数据库") // 展示中文化（ai-tool-labels）
    expect(p.process[1].toolName).toBe("query_database") // 英文原名保留在过程项上（hover 用）
    expect(p.process[1].text).toContain("SELECT 1")
  })

  it("text_delta 累积为一条（rAF 合帧）", async () => {
    vi.useFakeTimers()
    const { cbs, applies } = harness()
    for (let i = 0; i < 5; i++) cbs.onTextDelta?.("字")
    await flushTimers()
    expect(applies.length).toBe(1) // 5 个事件只合一次帧
    expect(applies[0].text).toBe("字字字字字")
  })

  it("tool_update 覆盖 🔄 尾行且不叠行；tool_end 追加 ✅ 行", async () => {
    vi.useFakeTimers()
    const { cbs, applies } = harness()
    cbs.onToolStart?.({ toolCallId: "tc1", toolName: "read_file", args: { path: "x" } })
    cbs.onToolUpdate?.({ toolCallId: "tc1", toolName: "read_file", partial: { progress: 1 } })
    cbs.onToolUpdate?.({ toolCallId: "tc1", toolName: "read_file", partial: { progress: 2 } })
    cbs.onToolEnd?.({ toolCallId: "tc1", toolName: "read_file", result: "文件内容", isError: false })
    await flushTimers()

    const toolStart = applies[applies.length - 1].process[0] // 🔧 行应只保留最后一次 🔄
    expect((toolStart.text.match(/🔄/g) ?? []).length).toBe(1)
    expect(toolStart.text).toContain("progress")
    const toolEnd = applies[applies.length - 1].process[1]
    expect(toolEnd.text.startsWith("✅ 读取规则文件")).toBe(true)
    expect(toolEnd.text).toContain("文件内容")
  })

  it("tool_update 的 toolCallId 不匹配未闭合工具时忽略", async () => {
    vi.useFakeTimers()
    const { cbs, applies } = harness()
    cbs.onToolUpdate?.({ toolCallId: "stale", toolName: "x", partial: { a: 1 } }) // 无开放工具
    cbs.onToolStart?.({ toolCallId: "tc1", toolName: "a", args: {} })
    cbs.onToolUpdate?.({ toolCallId: "tc2", toolName: "b", partial: { x: 1 } }) // 不匹配
    await flushTimers()
    const last = applies[applies.length - 1]
    expect(last.process[0].text).not.toContain("🔄")
  })

  it("tool_end 失败展示全量错误 + sources 追加 📎 行", async () => {
    vi.useFakeTimers()
    const { cbs, applies } = harness()
    cbs.onToolStart?.({ toolCallId: "tc1", toolName: "search_knowledge_base", args: {} })
    cbs.onToolEnd?.({
      toolCallId: "tc1",
      toolName: "search_knowledge_base",
      result: "长".repeat(800) + "错误",
      isError: true,
      sources: [{ kb: "SOP知识库", score: "82.1" }],
    })
    await flushTimers()
    const endLine = applies[applies.length - 1].process[1].text
    expect(endLine.startsWith("❌ 知识库检索")).toBe(true)
    expect(endLine.length).toBeGreaterThan(800) // 失败不截断
    expect(endLine).toContain("📎 来源: SOP知识库（82.1）")
  })

  it("成功结果按 resultMaxChars 截断", async () => {
    vi.useFakeTimers()
    const { cbs, applies } = harness()
    cbs.onToolStart?.({ toolCallId: "tc1", toolName: "query_database", args: {} })
    cbs.onToolEnd?.({ toolCallId: "tc1", toolName: "query_database", result: "x".repeat(600), isError: false })
    await flushTimers()
    expect(applies[applies.length - 1].process[1].text.length).toBeLessThan(520) // 500 + 前缀后缀
  })

  it("done：先 flush 再回调，只触发一次", async () => {
    vi.useFakeTimers()
    const { cbs, applies, done } = harness()
    cbs.onTextDelta?.("正文")
    cbs.onChartData?.({ title: "t", chartType: "bar", data: [{ label: "a", value: 1 }] })
    cbs.onActionProposal?.(proposal)
    cbs.onQuestion?.(question)
    cbs.onDone?.(0)
    expect(done()).toBe(1)
    expect(applies.length).toBe(1) // done 时 flush 合并了 pending
    const patch = applies[0]
    expect(patch.text).toBe("正文")
    expect(patch.charts).toHaveLength(1)
    expect(patch.proposals).toHaveLength(1)
    expect(patch.questions).toHaveLength(1)
    await flushTimers()
    expect(applies.length).toBe(1) // done 后不再有迟到帧
  })

  it("error：flush 一次后进入 dead，迟到事件被丢弃", async () => {
    vi.useFakeTimers()
    const { cbs, applies, error } = harness()
    cbs.onTextDelta?.("半截")
    cbs.onError?.("AI 服务超时")
    expect(error()).toBe("AI 服务超时")
    expect(applies[0].text).toBe("半截")
    cbs.onTextDelta?.("迟到");
    cbs.onChartData?.({ title: "x", chartType: "pie", data: [] });
    cbs.onDone?.(0)
    await flushTimers()
    expect(applies.length).toBe(1) // error 后无任何回写
  })

  it("trackCharts=false：chart_data 丢弃且 patch 无 charts 键（策略页消息模型）", async () => {
    vi.useFakeTimers()
    const { cbs, applies } = harness(false)
    cbs.onTextDelta?.("正文")
    cbs.onChartData?.({ title: "t", chartType: "bar", data: [] })
    cbs.onDone?.(0)
    const patch = applies[0]
    expect(patch.charts).toBeUndefined()
    expect(patch.text).toBe("正文")
  })

  it("过程项 id 唯一且带前缀", async () => {
    vi.useFakeTimers()
    const { cbs, applies } = harness()
    cbs.onToolStart?.({ toolCallId: "t1", toolName: "a", args: {} })
    cbs.onToolStart?.({ toolCallId: "t2", toolName: "b", args: {} })
    cbs.onDone?.(0)
    const ids = applies[0].process.map(i => i.id)
    expect(new Set(ids).size).toBe(ids.length)
    expect(ids.every(id => id.startsWith("msg-1-t-"))).toBe(true)
  })
})

describe("formatToolEnd（纯函数）", () => {
  it("sources 组装 📎 行", () => {
    const line = formatToolEnd(true, "search_knowledge_base", "内容", 500, [{ kb: "kb1", score: "90.0" }])
    expect(line).toBe("✅ 知识库检索\n内容\n📎 来源: kb1（90.0）")
  })
})

describe("delegate 委派展示（总管家模式，纯函数）", () => {
  it("formatToolStart：委派走 🤝 可读形态，不甩原始 JSON", () => {
    const line = formatToolStart("delegate", { agent: "strategy", task: "解释 tat-rules 的 TAT 配置" })
    expect(line).toBe("🤝 委派 策略配置助手：解释 tat-rules 的 TAT 配置")
    expect(line).not.toContain("{")
  })

  it("formatToolStart：未知子 agent 回退枚举值", () => {
    expect(formatToolStart("delegate", { agent: "other", task: "x" })).toContain("other")
  })

  it("formatToolEnd：解析委派结果 JSON 展示子 agent 名与答复 + 溯源行", () => {
    const result = JSON.stringify({ delegatedTo: "文档咨询助手", target: "kb-doc-1", answer: "结论是……(来源: SOP知识库, 相关度 88%)" })
    const line = formatToolEnd(true, "delegate", result, 500, [{ kb: "SOP知识库", score: "88" }])
    expect(line).toContain("🤝 文档咨询助手（kb-doc-1）")
    expect(line).toContain("结论是……")
    expect(line).toContain("📎 来源: SOP知识库")
    expect(line).not.toContain("delegatedTo")
  })

  it("formatToolEnd：非 JSON 载荷退回通用格式", () => {
    const line = formatToolEnd(false, "delegate", "连接失败", 500)
    expect(line).toBe("❌ 委派子助手\n连接失败")
  })

  it("formatPartial：委派进度渲染为 🤝 [子 agent] 进度", () => {
    expect(formatPartial({ delegateAgent: "策略配置助手", text: "正在调用 strategy_rule.read_file…" }))
      .toBe("🤝 [策略配置助手] 正在调用 strategy_rule.read_file…")
    expect(formatPartial("普通部分结果")).toBe("普通部分结果")
  })
})
