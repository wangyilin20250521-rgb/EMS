import { getApiConfig } from "../api/config";
import { getAuthToken, setAuthToken } from "../api/http";

/**
 * SSE 协议清单（2026-09-04 与 agent-server 后端逐字段核对，修改两端时同步更新此处）：
 *
 * | wire 事件 | 载荷字段 | 后端生产点 |
 * |---|---|---|
 * | text_delta | { text } | chat-turn.ts（正文增量） |
 * | thinking_delta | { text } | chat-turn.ts（thinking 增量） |
 * | tool_start | { toolCallId, toolName, args } | chat-turn.ts |
 * | tool_update | { toolCallId, toolName, partial } | chat-turn.ts（结构化中间产物） |
 * | tool_end | { toolCallId, toolName, result, isError, sources? } | lib/sse-mapper.ts（sources=KB 溯源 [来源: kb, 相关度 n%]） |
 * | chart_data | { title, chartType, data } | sse-mapper.ts（render_chart 工具结果特判） |
 * | action_proposal | { proposalId, toolName, summary, rationale?, args, status, details?, diff? } | sse-mapper.ts（propose_action 特判） |
 * | question | { questionId, toolName?, question, field?, options?, required } | sse-mapper.ts（ask_user 特判） |
 * | form_request | { requestId, toolName, explanation?, fieldHints? } | sse-mapper.ts（request_form 特判） |
 * | file_request | { requestId, purpose, accept } | sse-mapper.ts（request_file 特判；2026-09-15 对话内上传卡） |
 * | rule_file_request | { file, name } | sse-mapper.ts（show_rule_file 特判；2026-09-16 用户主动索取时的规则文件卡） |
 * | done | { sessionId, messageCount } | chat-turn.ts（流结束；error 后也会发） |
 * | error | { message } | chat-handler.ts / chat-turn.ts / answers.ts |
 *
 * 镜像要点：toolCallId 全链路透传（用于匹配 openTool 的 tool_update 尾行更新）；
 * tool_end.sources 是 search_knowledge_base 的溯源信息，消费方应展示在推理面板。
 */


/** AI 图表规范（chart_data 事件载荷，前端用 recharts 渲染） */
export interface ChartSpec {
  title: string;
  chartType: "bar" | "line" | "pie";
  data: Array<{ label: string; value: number }>;
}

/** 结构化参数摘要（propose_action 的 details 字段，决策卡中部展示） */
export interface ProposalDetail {
  label: string;
  value: string;
}

/** 规则文件字段级变更对比（服务端计算，决策卡中部展示） */
export interface RuleDiff {
  /** schema=task-schedule-rules 中文标签；generic=其余规则文件原始路径 */
  kind: "schema" | "generic";
  file: string;
  /** 新增/移除项目（schema 模式） */
  added: string[];
  removed: string[];
  changed: Array<{
    /** 点分路径，如 "NIFTY.trigger.value" */
    path: string;
    /** schema 模式中文名 / generic 模式路径尾段 */
    label: string;
    old?: string | number;
    new?: string | number;
  }>;
}

/** AI 写操作提议（action_proposal 事件载荷，前端渲染确认卡/决策卡） */
export interface ActionProposal {
  proposalId: string;
  toolName: string;
  summary: string;
  rationale?: string;
  args: Record<string, unknown>;
  status: "pending" | "confirmed" | "cancelled" | "failed" | "expired";
  /** 确认执行后的结果摘要（confirm 端点返回，前端回填展示） */
  result?: string;
  /** 结构化参数摘要（AI 在 propose_action 中填写，2026-09-03 决策卡） */
  details?: ProposalDetail[];
  /** 规则文件字段级 diff（服务端计算，决策卡中部展示） */
  diff?: RuleDiff;
  /** 破坏性操作（2026-09-11）：删除/终止/销毁/设备控制——确认卡显示红色警示 */
  destructive?: boolean;
  /** 委派来源（总管家模式）：子 agent 展示名（如"策略配置助手"）——提议经 delegate 委派发起 */
  delegatedFrom?: string;
  /** 创建时间（毫秒；仅历史恢复接口返回，流式 action_proposal 事件不带——挂载回原消息用，2026-09-15） */
  ts?: number;
}

/** 参数表单候选选项（form_request 的 fieldHints / 动态加载器共用） */
export interface FormOption {
  value: string;
  label?: string;
  /** 分组键（如收样日期 YYYY-MM-DD；specimens 按此把候选组织为"批"） */
  group?: string;
  /** 组内批次号（specimens 范围整选二级维度：同一收样日多批次时按批次整选） */
  batch?: string;
  /** 灰显禁选（如设备型号在中台无可用流程） */
  disabled?: boolean;
  /** 灰显原因文案（展示在选项下） */
  reason?: string;
  /** 行内副说明（如"1 个可用流程"） */
  sub?: string;
}

/** 参数表单请求（request_form 虚拟工具 → form_request 事件；2026-09-11 schema 驱动表单卡） */
export interface FormRequestSpec {
  requestId: string;
  toolName: string;
  /** AI 写在表单顶部的说明（中文） */
  explanation?: string;
  /** 无前端动态数据源字段的候选补充（有动态源的字段由表单实时加载） */
  fieldHints?: Record<string, { label?: string; options?: FormOption[] }>;
}

/** 文件上传请求（request_file 虚拟工具 → file_request 事件；2026-09-15 对话内直传） */
export interface FileRequestSpec {
  requestId: string;
  /** AI 写的上传用途说明（显示在卡片顶部） */
  purpose: string;
  /** 接受的文件类型（如 ".xlsx,.xls,.csv"） */
  accept: string;
}

/**
 * 规则文件展示（show_rule_file 虚拟工具 → rule_file_request 事件；2026-09-16）。
 * 分层暴露策略：默认文件隐藏（自然语言微调自动写入），仅用户主动索取时在对话内展示文件卡。
 */
export interface RuleFileSpec {
  /** 规则文件名（不含扩展名，如 tat-rules） */
  file: string;
  /** 规则中文名称（显示在卡片上） */
  name: string;
}

/** AI 工作任务更新（任务实体由 agent-server 持久化，前端工作台显示）。 */
export interface TaskUpdateEvent { task: { id: string; [key: string]: unknown } }

/** 结构化提问（question 事件载荷，前端渲染问题卡片；2026-09 Phase A） */
export interface QuestionSpec {
  questionId: string;
  question: string;
  field?: string;
  options?: string[];
  /** true = 多选（列表类参数：候选样例/批量选择），勾选后点确认提交；默认单选点选即答 */
  multi?: boolean;
  required?: boolean;
  /** 前端本地标记：用户已回答（answerQuestion 提交后置位） */
  answered?: boolean;
  /** 用户回答原文（历史恢复时回填展示"已回答：xxx"；2026-09-15） */
  answerText?: string;
}

/** tool_start 事件载荷（toolCallId 全链路透传，供 tool_update 尾行匹配） */
export interface ToolStartEvent {
  toolCallId: string;
  toolName: string;
  args: Record<string, unknown>;
}

/** tool_update 事件载荷（结构化中间产物；仅当 toolCallId 与未闭合工具匹配时有意义） */
export interface ToolUpdateEvent {
  toolCallId: string;
  toolName: string;
  partial: unknown;
}

/** KB 溯源条目（tool_end.sources，由 sse-mapper 从工具结果文本抽取） */
export interface ToolSource {
  kb: string;
  score: string;
}

/** tool_end 事件载荷（result 为工具最终文本；sources 非空 = KB 检索溯源） */
export interface ToolEndEvent {
  toolCallId: string;
  toolName: string;
  result: unknown;
  isError: boolean;
  sources?: ToolSource[];
}

export interface SSECallbacks {
  onThinkingDelta?: (text: string) => void;
  onTextDelta?: (text: string) => void;
  onToolStart?: (e: ToolStartEvent) => void;
  onToolEnd?: (e: ToolEndEvent) => void;
  /** 工具部分结果（后端 tool_update 事件，2026-09-04 起透传 toolCallId 供匹配展示） */
  onToolUpdate?: (e: ToolUpdateEvent) => void;
  onChartData?: (chart: ChartSpec) => void;
  onActionProposal?: (proposal: ActionProposal) => void;
  /** 结构化提问（ask_user 工具） */
  onQuestion?: (q: QuestionSpec) => void;
  /** 参数表单请求（request_form → form_request 事件；2026-09-11） */
  onFormRequest?: (req: FormRequestSpec) => void;
  /** 文件上传请求（request_file → file_request 事件；2026-09-15 对话内直传） */
  onFileRequest?: (req: FileRequestSpec) => void;
    /** 规则文件展示（show_rule_file → rule_file_request 事件；2026-09-16 用户主动索取） */
    onRuleFile?: (spec: RuleFileSpec) => void;
  onTaskUpdate?: (event: TaskUpdateEvent) => void;
  onDone?: (messageCount: number) => void;
  onError?: (message: string) => void;
}

/**
 * 发起一条 SSE 对话流（/api/chat 与 /api/chat/answer 共用的读取/超时/事件解析循环）。
 * 返回 AbortController 供主动停止。
 */
function streamFrom(
  path: string,
  body: Record<string, unknown>,
  callbacks: SSECallbacks,
): AbortController {
  const controller = new AbortController();
  const { agentUrl } = getApiConfig();

  // 三级超时（2026-08-24）：网络不通/服务挂起时用户能直接得知，不再无限等待
  const CONNECT_TIMEOUT_MS = 15000; // 连接/首字节超时：15s 无任何数据
  const IDLE_TIMEOUT_MS = 60000;    // 流空闲超时：60s 无新数据（LLM 思考/工具执行不误杀，任意数据到达重置）

  const headers: Record<string, string> = { "Content-Type": "application/json" };
  const token = getAuthToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;

  let timeoutKind: "connect" | "idle" | null = null;
  let idleTimer: ReturnType<typeof setTimeout> | null = null;
  const clearIdle = () => { if (idleTimer) { clearTimeout(idleTimer); idleTimer = null; } };

  // 连接 + 首字节超时：fetch 发出即计时，收到首个数据后切换为空闲计时
  const connectTimer = setTimeout(() => {
    timeoutKind = "connect";
    controller.abort();
  }, CONNECT_TIMEOUT_MS);

  const resetIdle = () => {
    clearIdle();
    idleTimer = setTimeout(() => {
      timeoutKind = "idle";
      controller.abort();
    }, IDLE_TIMEOUT_MS);
  };

  fetch(`${agentUrl}${path}`, {
    method: "POST",
    headers,
    body: JSON.stringify(body),
    signal: controller.signal,
  })
    .then(async (res) => {
      if (!res.ok) {
        clearTimeout(connectTimer);
        clearIdle();
        // 401（token 缺失/过期）→ 与 http.ts 同路：清 token + 广播 auth:unauthorized，
        // 由 useAuth 统一提示并跳登录页；不再把 401 落成对话里的错误气泡误导为 AI 回复
        if (res.status === 401) {
          setAuthToken(null);
          window.dispatchEvent(new Event("auth:unauthorized"));
          return;
        }
        callbacks.onError?.(`HTTP ${res.status}: ${res.statusText}`);
        return;
      }
      const reader = res.body?.getReader();
      if (!reader) {
        clearTimeout(connectTimer);
        clearIdle();
        callbacks.onError?.("Response body is not readable");
        return;
      }
      const decoder = new TextDecoder();
      let buffer = "";
      // 连接成功：进入空闲计时（15s 无数据 → 首字节超时）
      clearTimeout(connectTimer);
      resetIdle();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        resetIdle(); // 任意数据到达 → 重置空闲计时
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        let currentEvent = "";
        for (const line of lines) {
          if (line.startsWith("event: ")) {
            currentEvent = line.slice(7).trim();
          } else if (line.startsWith("data: ")) {
            const dataStr = line.slice(6);
            try {
              const data = JSON.parse(dataStr);
              handleEvent(currentEvent, data, callbacks);
            } catch { /* skip */ }
            currentEvent = "";
          }
        }
      }
      clearIdle();
    })
    .catch((err) => {
      clearTimeout(connectTimer);
      clearIdle();
      if (err.name === "AbortError") {
        // 超时中止 → 明确告知；用户主动中止（停止按钮）→ 静默
        if (timeoutKind === "connect") {
          callbacks.onError?.("连接 AI 服务超时（15 秒无响应），请检查网络或确认 AI 服务已启动");
        } else if (timeoutKind === "idle") {
          callbacks.onError?.("响应中断（60 秒无数据），请检查网络后重试");
        }
      } else {
        // fetch 网络错误（Failed to fetch 等）→ 中文提示
        const msg = /fetch|network|load failed/i.test(err.message || "")
          ? "网络连接失败，请检查网络或确认 AI 服务已启动"
          : err.message || "网络错误";
        callbacks.onError?.(msg);
      }
    });

  return controller;
}

export function streamChat(
  message: string,
  callbacks: SSECallbacks,
  opts?: {
    strategy?: boolean; document?: boolean; solution?: boolean; sessionId?: string;
    /**随消息上传的聊天附件引用（uploadAttachment 返回，AI 经 read_attachment 读取） */
    attachments?: Array<{ id: string; name: string; kind: string }>;
  },
): AbortController {
  return streamFrom("/api/chat", {
    message,
    ...(opts?.sessionId ? { sessionId: opts.sessionId } : {}),
    ...(opts?.strategy ? { mode: "strategy" } : {}),
    ...(opts?.document ? { mode: "document" } : {}),
    ...(opts?.solution ? { mode: "solution" } : {}),
    ...(opts?.attachments?.length ? { attachments: opts.attachments } : {}),
  }, callbacks);
}

/** 回答结构化提问并继续对话流（POST /api/chat/answer，2026-09 Phase A） */
/** 提交参数表单并续流（POST /api/chat/form-submit；2026-09-11 schema 驱动表单卡） */
export function submitFormChat(
  sessionId: string,
  toolName: string,
  values: Record<string, unknown>,
  optionsByField: Record<string, string[]>,
  callbacks: SSECallbacks,
): AbortController {
  return streamFrom('/api/chat/form-submit', { sessionId, toolName, values, optionsByField }, callbacks);
}

export function answerChatQuestion(
  sessionId: string,
  questionId: string,
  answer: string,
  callbacks: SSECallbacks,
  field?: string,
): AbortController {
  return streamFrom("/api/chat/answer", {
    sessionId,
    questionId,
    answer,
    ...(field ? { field } : {}),
  }, callbacks);
}

/** *确认执行后自动续流（POST /api/chat/continue；2026-09-15）：
 * 确认卡执行成功后由前端触发——叫醒 AI 继续后续流程步骤（链式写操作的下一步提议）
 * 或收尾汇报。注入的续流指令为系统通知语义（用户侧不可见）。 */
export function continueChat(
  sessionId: string,
  callbacks: SSECallbacks,
): AbortController {
  return streamFrom("/api/chat/continue", { sessionId }, callbacks);
}

function handleEvent(
  event: string,
  data: Record<string, unknown>,
  callbacks: SSECallbacks,
): void {
  switch (event) {
    case "thinking_delta":
      callbacks.onThinkingDelta?.(data.text as string);
      break;
    case "text_delta":
      callbacks.onTextDelta?.(data.text as string);
      break;
    case "tool_start":
      callbacks.onToolStart?.({
        toolCallId: data.toolCallId as string,
        toolName: data.toolName as string,
        args: (data.args || {}) as Record<string, unknown>,
      });
      break;
    case "tool_end":
      callbacks.onToolEnd?.({
        toolCallId: data.toolCallId as string,
        toolName: data.toolName as string,
        result: data.result,
        isError: data.isError as boolean,
        sources: data.sources as ToolSource[] | undefined,
      });
      break;
    case "tool_update":
      callbacks.onToolUpdate?.({
        toolCallId: data.toolCallId as string,
        toolName: data.toolName as string,
        partial: data.partial,
      });
      break;
    case "chart_data":
      callbacks.onChartData?.(data as unknown as ChartSpec);
      break;
    case "action_proposal":
      callbacks.onActionProposal?.(data as unknown as ActionProposal);
      break;
    case "form_request":
      callbacks.onFormRequest?.(data as unknown as FormRequestSpec);
      break;
    case "file_request":
      callbacks.onFileRequest?.(data as unknown as FileRequestSpec);
      break;
    case "rule_file_request":
      callbacks.onRuleFile?.(data as unknown as RuleFileSpec);
      break;
    case "task_update":
      callbacks.onTaskUpdate?.(data as unknown as TaskUpdateEvent);
      break;
    case "question":
      callbacks.onQuestion?.(data as unknown as QuestionSpec);
      break;
    case "done":
      callbacks.onDone?.(data.messageCount as number);
      break;
    case "error":
      callbacks.onError?.(data.message as string);
      break;
  }
}
