/** Convert ISO/UTC time string to Beijing time display string */
export function fmtBeijing(isoStr: string | undefined | null): string {
  if (!isoStr) return "—"
  const d = new Date(isoStr)
  if (isNaN(d.getTime())) return isoStr
  const bj = new Date(d.getTime() + 8 * 60 * 60 * 1000)
  return bj.toISOString().replace("T", " ").replace(/\.\d{3}Z$/, "")
}
