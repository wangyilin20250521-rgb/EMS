/**
 * 通用下载工具 —— 触发浏览器文件下载
 *
 * 支持两种模式：
 * 1. downloadBlob(blob, filename) —— 后端返回二进制文件（Blob），前端直接触发下载
 * 2. triggerFileDownload(url, filename) —— 通过 URL 触发下载（保留兼容）
 */

/**
 * 通过 Blob 对象触发浏览器下载
 * @param blob     后端返回的文件 Blob
 * @param filename 保存时的文件名
 */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.style.display = 'none'
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  // 延迟释放 URL，确保浏览器已开始下载
  setTimeout(() => URL.revokeObjectURL(url), 5000)
}

/**
 * 通过 URL 触发浏览器下载（保留兼容）
 * @param downloadUrl  文件下载地址
 * @param filename     保存时的文件名
 */
export function triggerFileDownload(downloadUrl: string, filename: string): void {
  const a = document.createElement('a')
  a.href = downloadUrl
  a.download = filename
  a.style.display = 'none'
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
}
