import * as XLSX from "xlsx"

// ─── 样本制备 Excel 导入解析器 ─────────────────────────────────────────────
// 兼容两种模板布局：
//   ① 制备结果登记模板（2026-09-22 美化版）：第 1 行标题、第 2 行填写说明、第 3 行表头、数据从第 4 行起；
//   ② 共享 template.xlsx（样本中心同款）：第 1 行标题、第 2 行表头、数据从第 3 行起。
//   表头行按「来源医院 + 样本编号」自动定位，故标题/说明行增减不影响导入。
//   A=来源医院 B=收样日期 C=样本编号 D=检测项目 E=样本类型 F=患者姓名 G=患者性别 H=患者年龄 I=样例编号

export interface PrepImportRow {
  sampleId: string
  sampleNo: string
  project: string
  type: string
  patient: string
  gender: string
  age: number | string
  /**样例（EP 条码）编号：模板第 9 列可选，多个用 、 , , ; ; 空格 分隔；无则制备结果待上报/补填 */
  specimens: string[]
}

const MAX_ROWS = 500

/** 行级校验：编号必填/查重、年龄数字 */
function validatePrepRows(rows: PrepImportRow[], rowLabel: (i: number) => string | number): void {
  if (rows.length > MAX_ROWS) throw new Error(`单次导入最多 ${MAX_ROWS} 行`)
  const seen = new Set<string>()
  rows.forEach((r, i) => {
    const rowNo = rowLabel(i)
    if (!r.sampleNo) throw new Error(`第 ${rowNo} 行缺少样本编号`)
    if (seen.has(r.sampleNo)) throw new Error(`第 ${rowNo} 行样本编号重复：${r.sampleNo}`)
    seen.add(r.sampleNo)
    // 必填与模板列头 * 标记一致：检测项目/样本类型必填；患者信息非必填
    if (!r.project) throw new Error(`第 ${rowNo} 行缺少检测项目`)
    if (!r.type) throw new Error(`第 ${rowNo} 行缺少样本类型`)
    const ageRaw = String(r.age ?? "").trim()
    if (ageRaw && !/^\d{1,3}$/.test(ageRaw)) throw new Error(`第 ${rowNo} 行年龄不是有效数字：${ageRaw}`)
  })
}

/** Parse the first sheet of an uploaded workbook into import rows */
export async function parsePrepImportFile(file: File): Promise<PrepImportRow[]> {
  const wb = XLSX.read(await file.arrayBuffer(), { type: "array" })
  const ws = wb.Sheets[wb.SheetNames[0]]
  if (!ws) throw new Error("Excel 文件中没有工作表")
  const rows = XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, defval: "" })
  return parsePrepImportRows(rows)
}

/**表头行定位：在前 10 行内找「来源医院 + 样本编号」开头的行（去 * 与空白后比对）。
 * 美化模板表头在第 3 行、共享模板在第 2 行，均能命中；找不到返回 -1。 */
function findHeaderRowIndex(rows: unknown[][]): number {
  const probe = rows.slice(0, 10)
  for (let i = 0; i < probe.length; i++) {
    const cells = (probe[i] ?? []).map(c => String(c ?? "").trim().replace(/\*/g, ""))
    if (cells[0] === "来源医院" && (cells[2] ?? "").startsWith("样本编号")) return i
  }
  return -1
}

/** Parse raw AOA rows：表头行自动定位，数据取其下所有非空行 */
export function parsePrepImportRows(rows: unknown[][]): PrepImportRow[] {
  const headerIdx = findHeaderRowIndex(rows)
  if (headerIdx < 0) {
    throw new Error(
      rows.length < 2
        ? "文件内容为空（未找到表头行）"
        : "模板表头不匹配：未找到「来源医院 / 样本编号」表头行，请使用下载的模板填写"
    )
  }
  const headers = rows[headerIdx].map(c => String(c ?? "").trim())
  // 新模板 A-H 8 列；带 * 的必填列头兼容（如 样本编号*）
  const expected = ["来源医院", "收样日期", "样本编号", "检测项目", "样本类型", "患者姓名", "患者性别", "患者年龄"]
  const bad = expected.filter((h, i) => headers[i] && headers[i].replace(/\*/g, "") !== h)
  if (bad.length > 0) throw new Error(`模板表头不匹配：${bad.join("、")}`)
  const dataRows = rows.slice(headerIdx + 1).filter(r => r.some(c => String(c ?? "").trim()))
  if (dataRows.length === 0) throw new Error("模板中没有可导入的数据")

  const parsed = dataRows.map((row) => {
    const ageRaw = String(row[7] ?? "").trim()
    // 第 9 列样例编号（可选列，旧模板无此列）：多种分隔符兼容
    const specimensRaw = String(row[8] ?? "").trim()
    const specimens = specimensRaw.split(/[、,，;；\/\s]+/).map(x => x.trim()).filter(Boolean)
    return {
      // 模板无批次序号列，sampleId 留空（后端按 IMP 批次自动分配）
      sampleId: "",
      sampleNo: String(row[2] ?? "").trim(),
      project: String(row[3] ?? "").trim(),
      type: String(row[4] ?? "").trim(),
      patient: String(row[5] ?? "").trim(),
      gender: String(row[6] ?? "").trim(),
      age: ageRaw || 0,
      specimens,
    }
  })
  validatePrepRows(parsed, i => i + headerIdx + 2) // Excel 实际行号（表头行 +1 起为数据）
  return parsed
}
