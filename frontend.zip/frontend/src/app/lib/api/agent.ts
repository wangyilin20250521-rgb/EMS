import { apiPost } from './http'
import type {
  SubmitResolutionPayload,
  SubmitResolutionResponse,
} from './types'

// ─── Agent Backend API ───────────────────────────────────────────────────────
// Anomaly resolution is routed to the Web Server (port 3457), not Agent Server.

/**
 * 提交异常处置方案。
 * 调用 POST /anomalies/{id}/resolve（保存 type/content/operator 并更新状态，
 * 新状态由后端按处置类型映射：人工判定可接受 → 已忽略，其余 → 已解决）。
 * 注意：不能走 PUT /status —— 该接口只改状态不保存处置内容。
 */
export async function submitAnomalyResolution(
  payload: SubmitResolutionPayload,
): Promise<SubmitResolutionResponse> {
  const res = await apiPost<{ resolutionId: string; newAnomalyStatus: string }>(
    `/anomalies/${payload.anomalyId}/resolve`,
    {
      type: payload.type,
      content: payload.content ?? "",
      operator: payload.operator,
    },
  )
  return { success: true, ...res }
}
