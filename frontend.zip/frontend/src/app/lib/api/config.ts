const DEFAULT_TIMEOUT = 30000

// M-LIMS backend — 直接读取 .env（本地开发 .env 含 localhost 地址，vite build 时 .env.production 覆盖为同源）
const BASE_URL = import.meta.env.VITE_API_BASE_URL || window.location.origin
const AGENT_URL = import.meta.env.VITE_AGENT_URL || window.location.origin
const SIRO_URL = import.meta.env.VITE_SIRO_URL || window.location.origin

export interface ApiConfig {
  baseUrl: string
  agentUrl: string
  siroUrl: string
  timeout: number
  apiKey?: string
}

export function getApiConfig(): ApiConfig {
  return {
    baseUrl: BASE_URL,
    agentUrl: AGENT_URL,
    siroUrl: SIRO_URL,
    timeout: Number(import.meta.env.VITE_API_TIMEOUT ?? DEFAULT_TIMEOUT),
    apiKey: import.meta.env.VITE_API_KEY,
  }
}
