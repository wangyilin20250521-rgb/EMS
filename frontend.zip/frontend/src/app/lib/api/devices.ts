import type { LabDevice } from './types'
import { apiGet, apiPut, apiPost } from './http'

export async function getLabDevices(): Promise<LabDevice[]> {
  return apiGet('/lab-devices')
}

// ─── Extended Device API ───────────────────────────────────────────────────────

export interface DeviceUpdatePayload {
  name?: string
  model?: string
  sn?: string
  ip?: string
  port?: string
  endpoint?: string
  location?: string
  notes?: string
  status?: string
}

/** 手动登记 EMS 管理设备（测序仪/功能岛/AGV），持久化到 web.devices 作为设备仓库 */
export interface DeviceCreatePayload {
  device_type: 'sequencer' | 'island' | 'agv' | 'fridge'
  name: string
  model: string
  sn?: string
  ip?: string
  port?: string
  endpoint?: string
  location?: string
  notes?: string
}

export async function createLabDevice(payload: DeviceCreatePayload): Promise<LabDevice> {
  return apiPost('/lab-devices', payload)
}

export interface DeviceLogEntry {
  time: string
  level: 'INFO' | 'WARN' | 'ERROR'
  message: string
}

/** 获取设备详情 */
export async function getLabDeviceById(id: string): Promise<LabDevice | null> {
  return apiGet(`/lab-devices/${id}`)
}

/** 更新设备信息 */
export async function updateLabDevice(
  id: string,
  payload: DeviceUpdatePayload,
): Promise<{ success: boolean; device: LabDevice }> {
  return apiPut(`/lab-devices/${id}`, payload)
}

/** 安排设备维护 */
export async function scheduleDeviceMaintenance(
  id: string,
  scheduledAt: string,
  reason: string,
): Promise<{ success: boolean; maintenanceId: string }> {
  return apiPost(`/lab-devices/${id}/maintenance`, { scheduledAt, reason })
}

/** 获取设备运行日志 */
export async function getDeviceLogs(id: string): Promise<DeviceLogEntry[]> {
  return apiGet(`/lab-devices/${id}/logs`)
}

/** 样本制备设备状态 */
export interface SamplePrepDevice {
  deviceName: string
  online: boolean
  lastSync: string
}

/** 获取样本制备页所有在线设备状态 */
export async function getSamplePrepDeviceStatus(): Promise<SamplePrepDevice[]> {
  return apiGet<SamplePrepDevice[]>('/sample-prep/device-status')
}

/** 同步 SIRO 设备 */
export async function syncSamplePrepDevice(): Promise<{
  success: boolean
  syncedCount: number
  message: string
}> {
  return apiPost('/sample-prep/sync')
}
