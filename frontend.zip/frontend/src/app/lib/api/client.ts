export interface ApiError {
  status: number
  code: string
  message: string
  details?: unknown
}

export type ApiResult<T> = { ok: true; data: T } | { ok: false; error: ApiError }

export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'

export interface RequestOptions {
  method?: HttpMethod
  body?: unknown
  headers?: Record<string, string>
  params?: Record<string, string | number | boolean>
}

export interface ApiClient {
  get<T>(path: string, options?: RequestOptions): Promise<ApiResult<T>>
  post<T>(path: string, body?: unknown, options?: RequestOptions): Promise<ApiResult<T>>
  put<T>(path: string, body?: unknown, options?: RequestOptions): Promise<ApiResult<T>>
  delete<T>(path: string, options?: RequestOptions): Promise<ApiResult<T>>
}

export function apiSuccess<T>(data: T): ApiResult<T> {
  return { ok: true, data }
}

export function apiFailure(error: ApiError): ApiResult<never> {
  return { ok: false, error }
}
