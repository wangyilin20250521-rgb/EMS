export type ViewId =
  | 'dashboard'
  | 'ai-assistant'
  | 'alerts'
  | 'unpack-register'
  | 'strategy-management'
  | 'sample-center'
  | 'product-management'
  | 'sample-prep'
  | 'sample-collect'
  | 'experiment-schedule'
  | 'task-list'
  | 'sequencing-task'
  | 'anomaly-center'
  | 'devices'
  | 'reagents'
  | 'documents'
  | 'settings'
  | 'solutions'
  | 'login'
  | 'user-info'

export const SAMPLE_STATUSES = ['已收样', '已分血', '待实验', '培养中', '培养完成', '实验中', '实验完成', '实验失败', '待测序', '实验异常', '已完成', '完成', '异常'] as const
export type SampleStatus = (typeof SAMPLE_STATUSES)[number]

export const TASK_STATUSES = ['待启动', '就绪', '运行中', '已暂停', '已终止', '完成', '失败'] as const
export type TaskStatus = (typeof TASK_STATUSES)[number]

export type Gender = '男' | '女'
export type SampleSource = '本院' | '外院'
export type AnomalyLevel = '高' | '中' | '低'

export interface Sample {
  id: string
  sampleNo?: string
  patient: string
  gender: Gender
  age: number
  gestWeek: number | null
  type: string
  project: string
  productType: string
  status: SampleStatus
  specimens: string
  /** 样例编号预览（前 2 个，列表直接可见） */
  specimensPreview?: string[]
  receivedAt: string
  tat: string
  batchId: string
  source: SampleSource
  extId: string
  isCultured?: boolean
  cultureStatus?: string
  cultureDueDate?: string
  hasExperiment?: boolean
}

export interface Task {
  id: string
  project: string
  sampleCount: number
  specimenCount: number
  device: string
  status: TaskStatus
  createdAt: string
  /** 最后更新时间（上位机上报状态时刷新，任务完成弹窗据此算完成时间/耗时） */
  updatedAt?: string
  estDone: string
  currentStage?: string
  owner?: string
  sampleIds?: string[]
  chipLanes?: any
  /** 排单孔板布局（手动排单的样本分布图） */
  wellLayout?: Array<{
    row: number
    col: number
    specimenId?: string
    isControl?: boolean
    controlType?: string
    /** 每孔 Barcode（1-1000 正整数，默认 1；质控孔无） */
    barcode?: number
  }>
}

export interface SpecimenDetail {
  id: string
  status: string
  usage: string
  location: string
  task: string
  type?: 'sample' | 'specimen'
}

export interface Anomaly {
  id: string
  category: 'sample' | 'task'
  type: string
  related: string
  desc: string
  level: AnomalyLevel
  status: string
  time: string
  source: 'manual' | 'rule' | 'ai'
  patient?: string
  project: string
  device?: string
  step?: string
  scenePhotos?: string[]
}

export interface ChartDatum {
  name: string
  value: number
  color: string
}

export interface BarDatum {
  time: string
  count: number
}

// ─── Auth Types ─────────────────────────────────────────────────────────────

export interface AuthUser {
  id: string
  username: string
  displayName: string
  role: string
  avatar?: string
  email?: string
  phone?: string
}

export interface LoginRequest {
  username: string
  password: string
  /** 顶下线强制登录：账号已有在线用户时，true 跳过在线确认直接顶掉旧会话 */
  force?: boolean
}

export interface LoginResponse {
  user: AuthUser
  token: string
}

export interface ChangePasswordRequest {
  currentPassword: string
  newPassword: string
  confirmPassword: string
}

export interface ChangePasswordResponse {
  success: boolean
  message: string
}

export interface AuthState {
  isAuthenticated: boolean
  user: AuthUser | null
  loading: boolean
}

// ─── Task Creation Types ───────────────────────────────────────────────────────

export const PLATE_TYPES = ['96孔PCR板', '384孔PCR板', '96孔深孔板'] as const
export type PlateType = (typeof PLATE_TYPES)[number]

export const DEVICE_STATUSES = ['空闲', '运行中', '维护中'] as const
export type DeviceStatus = (typeof DEVICE_STATUSES)[number]

export interface PlateInfo {
  plateId: string
  plateType: PlateType
  storageLocation: string
  date: string
}

export interface Device {
  id: string
  name: string
  model: string
  status: DeviceStatus
}

export interface Sequencer {
  id: string
  name: string
  model: string
  laneCount: 2 | 4
  status: DeviceStatus
}

export interface Lane {
  index: number
  sampleIds: string[]
}

export interface Chip {
  id: string
  name: string
  sequencerId: string
  lanes: Lane[]
}

export interface CreateTaskRequest {
  taskOrderId: string
  deviceId: string
  plateInfo: PlateInfo
}

export interface CreateSequencingTaskRequest {
  sequencerId: string
  chips: Chip[]
}

// ─── Alert Types ─────────────────────────────────────────────────────────────

export type AlertLevel = '警告' | '信息'
export type AlertStatus = '未确认' | '已确认' | '已解决'

export interface Alert {
  id: string
  level: AlertLevel
  type: string
  status: AlertStatus
  title: string
  time: string
  isRead: boolean
}

// ─── Anomaly Resolution Types ────────────────────────────────────────────────────

export type ResolutionType = 'reuse_original' | 'reuse_backup' | 'custom' | 'manual_accept' | 'concession'

export interface AnomalyResolution {
  anomalyId: string
  type: ResolutionType
  content?: string
  operator?: string
  submittedAt?: string
}

export interface SubmitResolutionPayload {
  anomalyId: string
  type: ResolutionType
  content?: string
  operator: string
}

export interface SubmitResolutionResponse {
  success: boolean
  resolutionId: string
  newAnomalyStatus: string
  message?: string
}

// ─── Sample Entry Types ───────────────────────────────────────────────────────

export type SampleEntryMode = 'ocr' | 'manual' | 'excel'

export interface OCRField {
  key: string
  label: string
  value: string
  confidence: number
  modified?: boolean
}

export interface OCRQueueItem {
  id: string
  rawImageUrl?: string
  fields: OCRField[]
  confidence: number
  status: 'pending' | 'confirmed' | 'modified'
}

export interface ManualSampleRow {
  rowId: string
  sampleNo: string
  [fieldKey: string]: string
}

export interface SampleCreateItem {
  sampleNo: string
  patient: string
  gender?: string
  age?: number
  type?: string
  project?: string
  [key: string]: string | number | undefined
}

export interface BatchCreateSamplesRequest {
  mode: SampleEntryMode
  productType: string
  samples: SampleCreateItem[]
}

export interface BatchCreateSamplesResponse {
  success: boolean
  createdIds: string[]
  errors?: Array<{ index: number; message: string }>
}

export interface SampleAdvancedFilter {
  statuses?: string[]
  types?: string[]
  productType?: string
  source?: string
  dateRange?: { start: string; end: string }
}

// ─── Sample Reception Types ─────────────────────────────────────────────────────

export interface SampleReceptionRecord {
  id: string
  sampleId: string
  barcode?: string
  voucherFiles?: string[]
  receivedAt: string
  operator: string
}

// ─── Schedule Types ───────────────────────────────────────────────────────────

export type ScheduleOrderStatus = '待确认' | '待执行' | '执行中' | '已完成' | '已取消'
export type PreScheduleTag = 'urgent' | 'full_batch' | 'scheduled' | 'normal'
export type SIRODeviceType = 'SIRO-16' | 'SIRO-48' | 'SIRO-96'

/**
 * SIRO 孔板配置：设备有效孔区（rows×cols=total）+ 标准板型（plateRows×plateCols）。
 * 标准 96 孔板 = 8 行（A-H）× 12 列（1-12）；SIRO-16/48 使用其前 2/6 列（每列 A-H 8 孔），
 * 其余列未启用（灰显）。
 */
export const WELL_PLATE_CONFIG: Record<SIRODeviceType, { rows: number; cols: number; total: number; plateRows: number; plateCols: number }> = {
  'SIRO-16': { rows: 8, cols: 2,  total: 16, plateRows: 8, plateCols: 12 },
  'SIRO-48': { rows: 8, cols: 6,  total: 48, plateRows: 8, plateCols: 12 },
  'SIRO-96': { rows: 8, cols: 12, total: 96, plateRows: 8, plateCols: 12 },
}

export interface ScheduleSpecimen {
  specimenId: string
  sampleId: string
  sampleType: string
  productCode: string
  patient: string
  tat: string
}

export interface PreScheduleOrder {
  id: string
  project: string
  sampleCount: number
  device: string
  estHours: number
  tatDue: string
  createdAt: string
  specimens: ScheduleSpecimen[]
  tags: PreScheduleTag[]
  confirmed: boolean
  cancelled: boolean
}

export interface ExecutionOrder {
  id: string
  project: string
  sampleCount: number
  device: string
  scheduledAt: string
  status: ScheduleOrderStatus
  sourcePreId: string
}

export interface WellPlateSlot {
  row: number
  col: number
  specimenId?: string
  isControl?: boolean
  controlType?: string
  /** 每孔 Barcode（1-1000 正整数，默认 1；质控孔无） */
  barcode?: number
}

export interface ManualScheduleRequest {
  project: string
  flowScope: string
  deviceType: SIRODeviceType
  slots: WellPlateSlot[]
}

export interface ManualScheduleResponse {
  success: boolean
  orderId: string
  message?: string
}

// ─── Sample Prep Types (items/records) ─────────────────────────────────────────

export interface SamplePrepItem {
  sampleId: string
  sampleNo?: string
  specimens: string[]
  /** true = 样本中心正本样本（任务内为快照，确认制备时回填） */
  linked: boolean
  sampleStatus: string
  /** true = Excel 导入的内嵌样本（不在样本中心） */
  embedded?: boolean
  patient?: string
  project?: string
  type?: string
  /** pending | matched | mismatch | skipped | manualPassed */
  reviewStatus?: string
  scannedBarcode?: string
  scannedEpBarcodes?: string[]
}

export interface SamplePrepRecord {
  id: string
  time: string
  scheme: string
  device: string
  sampleCount: number
  operator?: string
  syncStatus: string
  batchId?: string
  hostId?: string
  embeddedCount?: number
  samples: SamplePrepItem[]
}

// ─── Strategy Rule Types ───────────────────────────────────────────────────────

export interface CreateStrategyRuleRequest {
  category: string
  name: string
  priority: '高' | '中' | '低'
  enabled: boolean
  fields: Array<{ label: string; value: string }>
}

// ─── Pagination Types ──────────────────────────────────────────────────────────

/** 服务端分页响应 */
export interface PaginatedResponse<T> {
  items: T[]
  total: number
  page: number
  pageSize: number
}

/** 分页查询参数 */
export interface PaginationParams {
  page?: number
  pageSize?: number
}

// ─── Sample Reception（sample registration） ───

export interface ReceptionAnomalyItem {
  sampleId: string
  reason: string
  photo?: string | null
}

export interface ReceptionError {
  field: string
  message: string
}

export interface SampleReceptionPayload {
  /** @deprecated Batch-level project — prefer `projects` array. */
  project?: string
  /** Per-sample projects, index-aligned with tubeCount (or sampleIds if provided). */
  projects?: string[]
  /** Per-sample types, index-aligned with tubeCount (or sampleIds if provided). */
  sampleTypes?: string[]
  /** 分产品收样明细（结构化落库）：[{ name 产品类型, sampleType 样本类型, count 数量, package 产品套餐 }] */
  products?: Array<{ name: string; sampleType?: string; count?: number; package?: string }>
  /** 扫码收样：批量样本条码（sample_no），后端分配内部 id 生成占位行 */
  barcodes?: string[]
  /** HIS 复核未匹配条码（扫码模式 Step3 提交；未复核/跳过/未开启时省略） */
  hisUnmatched?: string[]
  receivedAt: string
  notes: string
  tubeCount?: number
  sampleIds?: string[]
  scannedNos?: string[]
  /** @deprecated Batch-level type — prefer `sampleTypes` array. */
  sampleType?: string
  source?: string
  hospital?: string
  actualTubes?: number
  actualPapers?: number
  /** 收样人（第 1 类固定信息，收样登记模块录入） */
  receiver?: string
}

export interface SampleReceptionResult {
  batchId?: string
  batchNo?: string
  sampleIds?: string[]
  createdCount?: number
  message: string
  errors?: ReceptionError[]
}

// ─── Sample Reception（unpack register）Types ───────────────────────────────────

/** 收样批次记录（后端 /sample-reception/batches 返回项） */
export interface UnpackRecord {
  id: string
  batchNo: string
  hospital: string
  source: string
  time: string
  receiver?: string
  actual: number
  /** 实收单据数 */
  papers?: number
  /** 实际统计管数（分产品合计/条码数，与申报数 actual 可不同） */
  calculated?: number
  recorded: number
  anomalies: number
  status: string
  detail: string
  projects?: string
  types?: string
  notes?: string
  /** 分产品收样明细（结构化，后端 JSONB 返回） */
  products?: Array<{ name: string; sampleType?: string; count?: number; package?: string }>
  /** 最后操作人（创建/编辑批次时的登录用户） */
  updatedBy?: string
  /** 最后操作时间（ISO 字符串） */
  updatedAt?: string
}

/** HIS 复核单条结果 */
export interface HisVerifyResult { barcode: string; found: boolean; patient?: string }

/** HIS 复核响应（enabled=false 表示未开启，后端直接判全部通过） */
export interface HisVerifyResponse { enabled: boolean; results: HisVerifyResult[] }

/** 收样登记页统计卡片纯数值 */
export interface UnpackStatValue {
  key: string
  value: number
}

/** 新建收样登记表单状态 */
export interface UnpackFormState {
  hospital: string
  source: string
  receiveTime: string
  receiver: string
  actualTubes: number
  actualPapers: number
  remark: string
  products: Array<{ name: string; count: number; sampleType: string }>
}

/** 收样项目摘要（声明/实收对比） */
export interface ReceptionProject {
  name: string
  declared: number
  actual: number
  diff: number
  status: string
}

// ─── Device Types ────────────────────────────────────────────────────────────

/** 实验室设备（后端 /lab-devices 返回项，rowToDevice 映射） */
export interface LabDevice {
  id: string
  deviceType: string
  /** 兼容字段：后端与 deviceType 同值 */
  type: string
  name: string
  model: string
  sn: string
  ip: string
  port: string
  status: string
  currentTask?: string
  progress?: number
  laneCount?: number
  location: string
  notes: string
  createdAt?: string
  updatedAt?: string
  /** SIRO 设备扩展字段（由 mapSiroToLabDevice 填充） */
  endpoint?: string
  lastHeartbeat?: string
  connectedAt?: string
  _source?: "siro" | "ems"
}

// ─── Dashboard Types ──────────────────────────────────────────────────────────

/** 统计卡片纯数值（颜色/图标等由前端 dashboard-config.json 配置） */
export interface StatCardValue {
  key: string
  value: number
  subMetrics?: Array<{ key: string; value: number }>
}

/** 仪表盘最近活动条目 */
export interface DashboardActivity {
  icon: string
  color: string
  text: string
  time: string
}

/** TAT 预警条目 */
export interface TatWarning {
  sampleId: string
  patient: string
  project: string
  tatRemaining: string
  isOverdue: boolean
}

// ─── Sample Detail Types ───────────────────────────────────────────────────────

/** 样本扩展信息（优先/医院/科室/TAT 截止） */
export interface SampleExtraInfo {
  priority: string
  hospital: string
  department: string
  tatDeadline: string
}

/** 样本状态时间线节点 */
export interface SampleTimelineStep {
  label: string
  time: string
  operator: string
  done: boolean
  active?: boolean
}

// ─── Sample Prep Stats Types ───────────────────────────────────────────────────

/** 样本制备页统计卡片纯数值 */
export interface SamplePrepStatValue {
  key: string
  value: number
}

// ─── Sequencing Task Types ──────────────────────────────────────────────────────

export type ChipStatus = '待测序' | '测序中' | '已完成' | '异常'
export type LaneStatus = '通过' | '让步接收' | '不合格'

// ─── System Management Types ─────────────────────────────────────────────────────

export interface DictionaryItem {
  code: string
  name: string
  sort: number
  status: string
}

export interface SystemUser {
  id: string
  username: string
  name: string
  roles: string[]
  phone: string
  status: string
  lastLogin: string
  createdAt: string
}

export interface SystemRole {
  id: string
  name: string
  userCount: number
  type: string
  createdAt: string
  desc: string
}

export interface SystemLogEntry {
  time: string
  user: string
  username: string
  ip: string
  module: string
  action: string
  desc: string
}

export interface PermissionModule {
  module: string
  pages: Array<{ name: string; perms: string[] }>
}

// ─── AI / Agent Types ───────────────────────────────────────────────────────

/** AI 页面统计卡片纯数值 */
export interface AIStatValue {
  key: string
  value: number | string
}

/** AI 对话摘要（Agent 服务端 ConversationMeta） */
export interface ConversationSummary {
  sessionId: string
  title: string
  preview: string
  messageCount?: number
  createdAt: string
  updatedAt: string
}

/** 落盘的提问卡结构化记录（Agent 服务端 ConversationQuestion 镜像；2026-09-09） */
export interface StoredQuestion {
  questionId: string
  question: string
  field?: string
  options?: string[]
  /** 多选（历史恢复保持多选形态；2026-09-15） */
  multi?: boolean
  answered?: boolean
  answerText?: string
  ts: number
}

/** 参数表单提交收据（2026-09-12 结构化恢复：重开历史对话恢复"已提交"表单卡） */
export interface StoredFormReceipt {
  toolName: string
  /** 人类可读提交摘要（buildFormSummary 产物，无 JSON） */
  summary: string
  ts: number
}

/** AI 对话详情（Agent 服务端 GET /api/conversations/:id） */
export interface ConversationDetail {
  id: string
  title: string
  messages: Array<{ role: 'user' | 'ai' | 'toolResult'; text: unknown }>
  /** 结构化载荷（旧对话无此键 → 回退纯文本）：提问卡 + 参数表单收据 */
  structured?: { questions?: StoredQuestion[]; forms?: StoredFormReceipt[] }
}
