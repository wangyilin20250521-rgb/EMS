import type { PaginationParams, Task } from './types'
import { apiGet, apiPost, getAuthToken } from './http'
import { getApiConfig } from './config'
import { downloadBlob } from '../utils/download'

// ─── Types ──────────────────────────────────────────────────────────────────

/** 实验进度步骤 */
export interface ExperimentStep {
  name: string
  done: boolean
  count: string
  active: boolean
}

/** QC 结果 */
export interface QcResult {
  id: string
  conc: number
  total: number
  pass: boolean
}

/** 板信息 */
export interface TaskPlateInfo {
  plateId: string
  plateType: string
  storageLocation: string
  date: string
}

/** 实验明细行 */
export interface ExperimentDetailRow {
  well: string
  sampleId: string
  concentration: string
  scanned: boolean
  status: string
}

/** 任务详情（查看接口返回的完整信息） */
export interface TaskDetail extends Task {
  /** 任务类型(experiment / sample_prep / schedule / sequencing) */
  taskType?: string
  /** 实验进度 */
  steps: ExperimentStep[]
  /** QC 结果详情 */
  qcResults: QcResult[]
  /** 板信息 */
  plateInfo: TaskPlateInfo
  /** 实验明细 */
  experimentDetails: ExperimentDetailRow[]
}

/** 创建任务 payload */
export interface CreateTaskPayload {
  preOrderId: string
  deviceId: string
  executionMode: string
  plateInfo: {
    plateId: string
    plateType: string
    storageLocation: string
    date: string
  }
  sampleIds?: string[]
}

/** 创建任务响应 — 后端返回完整任务对象（rowToTask） */
export type CreateTaskResult = Task

// ─── Backward-compat Re-exports ────────────────────────────────────────────────

export type { Task, TaskStatus } from './types'

// ─── API Functions ────────────────────────────────────────────────────────────

export interface GetTasksParams extends PaginationParams {
  status?: string
}

/** 获取实验任务列表 */
export async function getTasks(params: GetTasksParams = {}): Promise<Task[]> {
  return apiGet<Task[]>('/tasks', { task_type: 'experiment', ...params } as Record<string, string | number | boolean | undefined>)
}

/** 获取任务详情（含实验进度、QC、板信息、孔板图、实验明细） */
export async function getTaskDetail(id: string): Promise<TaskDetail | null> {
  return apiGet<TaskDetail>(`/tasks/${id}`)
}

/** 启动任务 */
export async function startTask(id: string): Promise<{ success: boolean; message: string }> {
  return apiPost(`/tasks/${id}/start`)
}

/** 暂停任务 */
export async function pauseTask(id: string): Promise<{ success: boolean; message: string }> {
  return apiPost(`/tasks/${id}/pause`)
}

/** 恢复任务 */
export async function resumeTask(id: string): Promise<{ success: boolean; message: string }> {
  return apiPost(`/tasks/${id}/resume`)
}

/** 终止任务 */
export async function terminateTask(id: string, reason?: string): Promise<{ success: boolean; message: string }> {
  return apiPost(`/tasks/${id}/terminate`, { reason })
}

/** 创建实验任务 */
export async function createTask(payload: CreateTaskPayload): Promise<CreateTaskResult> {
  return apiPost('/tasks', payload)
}

/** 导出实验任务列表（按当前筛选条件导出全量） */
export async function exportTasks(status?: string): Promise<{ success: boolean; downloadUrl: string; filename: string }> {
  return apiGet('/tasks/export', status && status !== '全部' ? { status } : undefined)
}

/** 投递实验结果到第三方测序系统的结果（POST /tasks/:id/deliver-sequencing） */
export interface DeliverSequencingResult {
  ok: boolean
  status?: number
  error?: string
  /** 测序系统响应 body（成功时原样透传） */
  response?: unknown
  sampleCount?: number
  /** 累计投递次数（含自动重试），失败时可用于提示"重试用尽" */
  attempts?: number
  exhausted?: boolean
}

/** 投递任务实验结果到第三方测序系统（终态实验任务：完成/失败） */
export async function deliverSequencing(id: string): Promise<DeliverSequencingResult> {
  return apiPost(`/tasks/${id}/deliver-sequencing`)
}

/** 样例实验结果条目(experiment_data 为全量 JSONB:41 契约键 + 扩展真实检测键) */
export interface TaskExperimentSpecimen {
  specimenId: string
  sampleId: string
  sampleNo: string
  patient: string
  experimentData: Record<string, string>
}

/** GET /tasks/:id/experiment-data 响应数据 */
export interface TaskExperimentData {
  taskNo: string
  /**任务样本名册（手工录入面板的行来源；SIRO 模式忽略） */
  samples: Array<{ sampleId: string; sampleNo: string; patient: string }>
  specimens: TaskExperimentSpecimen[]
}

/** 获取任务样例级实验结果数据(任务详情「实验结果数据」面板) */
export async function getTaskExperimentData(id: string): Promise<TaskExperimentData> {
  return apiGet<TaskExperimentData>(`/tasks/${id}/experiment-data`)
}

// ─── 手工实验结果录入（manual 模式；重复覆盖） ─────────────────────────────

/**手工录入字段（与后端 MANUAL_RESULT_FIELDS 同字典） */
export const MANUAL_RESULT_FIELDS: Array<{ key: string; label: string; type: "number" | "text"; required: boolean }> = [
  { key: "libConc", label: "建库产物浓度", type: "number", required: true },
  { key: "libFluo", label: "建库产物荧光值", type: "number", required: false },
  { key: "libConcNg", label: "文库浓度(ng/μl)", type: "number", required: true },
  { key: "subLibVolume", label: "子文库体积", type: "number", required: false },
  { key: "mixLibWaterVol", label: "混合文库补水体积", type: "number", required: false },
  { key: "dnbConc", label: "DNB浓度", type: "number", required: false },
  { key: "qcWord", label: "样本质控", type: "text", required: false },
  { key: "qcFailReason", label: "质控失败原因", type: "text", required: false },
  { key: "dupFlag", label: "标示是否为重复样", type: "text", required: false },
  { key: "runDate", label: "实验日期", type: "text", required: false },
]

export interface ManualSaveResult {
  saved: number
  skipped: Array<{ sampleNo: string; reason: string }>
  warnings: string[]
}

/** 保存手工录入结果（表单行；写同一张 specimen_results，重复覆盖） */
export async function saveManualExperimentData(id: string, rows: Array<{ sampleNo: string; values: Record<string, string> }>, enteredBy: string): Promise<ManualSaveResult> {
  return apiPost(`/tasks/${id}/experiment-data`, { rows, enteredBy })
}

/** 导入手工结果 Excel（中文表头：样本编号 + 字段标签列） */
export async function importManualExperimentData(id: string, file: File, enteredBy: string): Promise<ManualSaveResult & { total: number }> {
  const { baseUrl } = getApiConfig()
  const headers: Record<string, string> = {}
  const token = getAuthToken()
  if (token) headers["Authorization"] = `Bearer ${token}`
  const form = new FormData()
  form.append("file", file)
  form.append("enteredBy", enteredBy)
  const res = await fetch(`${baseUrl}/tasks/${id}/experiment-data/import`, { method: "POST", headers, body: form })
  const json = await res.json().catch(() => null)
  if (!res.ok || json?.code !== "0") {
    throw new Error(json?.message || `导入失败 (HTTP ${res.status})`)
  }
  return json.data
}

/** 下载手工录入模板（预填任务样本编号） */
export async function downloadManualResultTemplate(taskId: string): Promise<void> {
  const { baseUrl } = getApiConfig()
  const headers: Record<string, string> = {}
  const token = getAuthToken()
  if (token) headers["Authorization"] = `Bearer ${token}`
  const res = await fetch(`${baseUrl}/tasks/${taskId}/experiment-data/template`, { headers })
  if (!res.ok) {
    const text = await res.text().catch(() => "")
    let message = `模板下载失败 (HTTP ${res.status})`
    try { const j = JSON.parse(text); if (j?.message) message = j.message } catch { /* 非 JSON */ }
    throw new Error(message)
  }
  downloadBlob(await res.blob(), `实验结果录入模板_${taskId}.xlsx`)
}

/** 完成实验（手工模式）：任务置「完成」+ 样本状态继承刷新 */
export async function completeManualExperiment(id: string): Promise<{ success: boolean; enteredResults: number }> {
  return apiPost(`/tasks/${id}/complete-experiment`)
}

/** 导出任务样本结果 Excel（含未关联的内嵌样本） */
export async function exportTaskSamples(taskId: string): Promise<void> {
  const { baseUrl } = getApiConfig()
  const headers: Record<string, string> = {}
  const token = getAuthToken()
  if (token) headers["Authorization"] = `Bearer ${token}`
  const res = await fetch(`${baseUrl}/tasks/${taskId}/samples/export`, { headers })
  if (!res.ok) {
    const text = await res.text().catch(() => "")
    let message = `导出失败 (HTTP ${res.status})`
    try { const j = JSON.parse(text); if (j?.message) message = j.message } catch { /* 非 JSON */ }
    throw new Error(message)
  }
  downloadBlob(await res.blob(), `实验任务_${taskId}_样本结果_${new Date().toISOString().slice(0, 10)}.xlsx`)
}
