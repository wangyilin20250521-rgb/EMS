/**
 * Dashboard API.
 *
 * Frontend config (colors/icons/categories/time ranges) lives in dashboard-config.json.
 * Backend returns raw values; this module merges them with the static config.
 */
import type { StatCardValue, DashboardActivity, TatWarning } from './types'
import type { ChartDatum, BarDatum } from './types'
import { apiGet } from './http'
import config from '../constants/dashboard-config.json'

// ─── Config Types ────────────────────────────────────────────────────────────

export interface StatCardConfig {
  key: string
  label: string
  icon: string
  color: string
  bg: string
  subMetrics: { label: string; key: string }[]
  subFormat: string
}

export interface DistributionCategoryConfig {
  name: string
  color: string
}

export interface TrendSlotConfig {
  time: string
}

// ─── Merged View Models ───────────────────────────────────────────────────────

export interface DashboardStatCard {
  key: string
  label: string
  value: number
  subMetrics: { label: string; value: number }[]
  subFormat: string
  color: string
  bg: string
  icon: string
}

// ─── Config Accessors ─────────────────────────────────────────────────────────

export const STAT_CARD_CONFIG = config.statCards as StatCardConfig[]
export const DISTRIBUTION_CONFIG = config.sampleDistribution as DistributionCategoryConfig[]
export const TREND_CONFIG = config.receptionTrend as TrendSlotConfig[]

// ─── Merge Helpers ──────────────────────────────────────────────────────────

function mergeStats(values: StatCardValue[]): DashboardStatCard[] {
  const map = new Map(values.map(v => [v.key, v]))
  return STAT_CARD_CONFIG.map(cfg => {
    const val = map.get(cfg.key)
    // 将 subMetric 的 key 映射到 config 中定义的 label
    const cfgSubMap = new Map(cfg.subMetrics.map(s => [s.key, s.label]))
    const subMetrics = (val?.subMetrics ?? []).map(s => ({
      label: cfgSubMap.get(s.key) ?? s.key,
      value: s.value,
    }))
    return {
      key: cfg.key,
      label: cfg.label,
      value: val?.value ?? 0,
      subMetrics,
      subFormat: cfg.subFormat,
      color: cfg.color,
      bg: cfg.bg,
      icon: cfg.icon,
    }
  })
}

function mergeDistribution(values: { name: string; value: number }[]): ChartDatum[] {
  const map = new Map(values.map(v => [v.name, v.value]))
  return DISTRIBUTION_CONFIG.map(cfg => ({
    name: cfg.name,
    value: map.get(cfg.name) ?? 0,
    color: cfg.color,
  }))
}

function mergeTrend(values: { time: string; count: number }[]): BarDatum[] {
  const map = new Map(values.map(v => [v.time, v.count]))
  return TREND_CONFIG.map(cfg => ({
    time: cfg.time,
    count: map.get(cfg.time) ?? 0,
  }))
}

/** 多日范围趋势：直接映射后端按天数据（MM-DD），不套 config slots */
function mergeDayTrend(values: { time: string; count: number }[]): BarDatum[] {
  return values.map(v => ({ time: v.time, count: v.count }))
}

// ─── API Functions ────────────────────────────────────────────────────────────

/** 日期范围查询参数（缺省 = 今日）；Record 字面量以满足 apiGet 的 params 签名 */
export type DashboardDateRange = Record<"dateFrom" | "dateTo", string>

/** 统计卡片（config + API values）；dateRange 缺省为今日 */
export async function getDashboardStats(dateRange?: DashboardDateRange): Promise<DashboardStatCard[]> {
  const values = await apiGet<StatCardValue[]>('/dashboard/stats', dateRange)
  return mergeStats(values)
}

/** 样本状态分布（config colors + API values）；dateRange 缺省为全量 */
export async function getSampleDistribution(dateRange?: DashboardDateRange): Promise<ChartDatum[]> {
  const values = await apiGet<{ name: string; value: number }[]>('/dashboard/sample-distribution', dateRange)
  return mergeDistribution(values)
}

/** 收样趋势：单日按时段（config slots），多日按天（MM-DD） */
export async function getReceptionTrend(dateRange?: DashboardDateRange): Promise<BarDatum[]> {
  const values = await apiGet<{ time: string; count: number }[]>('/dashboard/reception-trend', dateRange)
  return dateRange && dateRange.dateFrom !== dateRange.dateTo ? mergeDayTrend(values) : mergeTrend(values)
}

/** TAT 预警列表 */
export async function getTatWarnings(): Promise<TatWarning[]> {
  return apiGet<TatWarning[]>('/dashboard/tat-warnings')
}

/** 最近活动 */
export async function getDashboardActivities(): Promise<DashboardActivity[]> {
  return apiGet<DashboardActivity[]>('/dashboard/activities')
}
