import type { ApiResult } from './client'
import type { PaginationParams, Sample, SampleAdvancedFilter, SampleStatus, SpecimenDetail, OCRField } from './types'
import type { SampleExtraInfo, SampleTimelineStep } from './types'
import { apiGet, apiPost, apiPut, apiDelete, apiUpload, getApiClient, getAuthToken } from './http'
import { getApiConfig } from './config'

export interface GetSamplesParams extends PaginationParams {
  status?: string
  project?: string
  type?: string
  search?: string
  source?: string
  receivedAfter?: string
  receivedBefore?: string
  /** 列头排序（样本中心）：sampleNo | receivedAt | tat */
  sortBy?: string
  sortOrder?: "asc" | "desc"
}

export function getSamples(
  params: GetSamplesParams = {},
): Promise<ApiResult<Sample[]>> {
  return getApiClient().get<Sample[]>('/samples', { params: params as Record<string, string | number | boolean> })
}

export function getSampleById(id: string): Promise<ApiResult<Sample>> {
  return getApiClient().get<Sample>(`/samples/${id}`)
}

export async function getSamplesByIds(ids: string[]): Promise<Sample[]> {
  if (!ids.length) return []
  return apiPost<Sample[]>('/samples/by-ids', { ids })
}

export function getSampleSpecimens(id: string): Promise<ApiResult<SpecimenDetail[]>> {
  return getApiClient().get<SpecimenDetail[]>(`/samples/${id}/specimens`)
}

export function updateSampleStatus(id: string, status: SampleStatus): Promise<ApiResult<Sample>> {
  return getApiClient().put<Sample>(`/samples/${id}/status`, { status })
}

export async function getSampleExtraInfo(id: string): Promise<SampleExtraInfo> {
  return apiGet(`/samples/${id}/extra-info`)
}

export async function getSampleTimeline(id: string): Promise<SampleTimelineStep[]> {
  return apiGet(`/samples/${id}/timeline`)
}

export interface SampleUpdatePayload {
  sampleNo?: string
  patient?: string
  gender?: string
  age?: number
  gestWeek?: number | null
  type?: string
  project?: string
  source?: string
  extId?: string
  priority?: string
  hospital?: string
  department?: string
}

/**
 * 创建单条样本（OCR 批量录入等场景，含 hospital 全字段）。
 * id 可不传 —— 样本编号统一由后端按 26B 规则分配，返回创建的样本 id。
 */
export async function createSample(payload: {
  id?: string
  patient: string
  gender: string
  age: number
  type: string
  project: string
  productType?: string
  hospital?: string
  priority?: string
  batchId?: string
}): Promise<{ success: boolean; id?: string }> {
  const created = await apiPost<{ id: string }>('/samples', payload)
  return { success: true, id: created.id }
}

export async function updateSample(id: string, payload: SampleUpdatePayload & { specimens?: Array<{ id: string; location?: string }> }): Promise<{ success: true; id: string }> {
  return apiPut(`/samples/${id}`, payload)
}

// ─── Extended Sample API ───────────────────────────────────────────────────────

/** 上传 OCR 图片 */
export async function uploadOCRImage(
  file: File,
): Promise<{ success: boolean; imageUrl: string; queueId: string }> {
  return apiUpload('/samples/ocr/upload', file)
}

/** OCR 识别处理 */
export async function processOCR(
  queueId: string,
): Promise<{ success: boolean; fields: OCRField[]; confidence: number }> {
  return apiPost('/samples/ocr/process', { queueId })
}

/** Excel 批量导入 */
export async function importSamplesFromExcel(
  file: File,
  productType: string,
  batchId?: string,
): Promise<{
  success: boolean
  imported: number
  errors: Array<{ row: number; message: string }>
  /** 导入触发自动排单时返回（web-server 达阈值后创建待审预排单） */
  autoScheduledOrder?: { orderId: string; project: string; sampleCount: number; deviceType: string; message?: string }
}> {
  return apiUpload('/samples/excel-import', file, { productType, ...(batchId !== undefined ? { batchId } : {}) })
}

/** 导出样本列表 */
export async function exportSamples(
  filter?: SampleAdvancedFilter,
): Promise<{ success: boolean; downloadUrl: string; filename: string }> {
  return apiPost('/samples/export', filter)
}

/**
 * 下载 Excel 导入模板：预填批次号/样本编号/检测项目/样本类型（未入库样本），
 * 用户只填患者信息（姓名/性别/年龄）后导入。
 * 返回 true 表示已触发下载。
 */
export async function downloadExcelTemplate(batchId: string): Promise<boolean> {
  // 必须使用与 api 层一致的绝对 baseUrl（相对路径会打到 vite dev server 的 SPA fallback 返回 HTML）
  const { baseUrl, apiKey } = getApiConfig()
  const url = new URL(`/samples/excel-import/template?batchId=${encodeURIComponent(batchId)}`, baseUrl)
  const headers: Record<string, string> = {}
  const token = getAuthToken()
  if (token) headers["Authorization"] = `Bearer ${token}`
  if (apiKey) headers["X-API-Key"] = apiKey
  const res = await fetch(url.toString(), { headers })
  if (!res.ok) {
    const text = await res.text().catch(() => "")
    let message = `下载模板失败 (HTTP ${res.status})`
    try { const j = JSON.parse(text); if (j?.message) message = j.message } catch { /* 非 JSON */ }
    throw new Error(message)
  }
  const blob = await res.blob()
  const a = document.createElement("a")
  a.href = URL.createObjectURL(blob)
  a.download = `导入模板_${batchId}.xlsx`
  a.click()
  URL.revokeObjectURL(a.href)
  return true
}

/** 高级筛选查询 */
export async function advancedFilterSamples(
  filter: SampleAdvancedFilter,
): Promise<Sample[]> {
  return apiPost('/samples/advanced-filter', filter)
}

/** 删除样本 */
export async function deleteSample(id: string): Promise<{ success: boolean }> {
  return apiDelete(`/samples/${id}`)
}

/** 获取可排单的样本+样例列表（用于排单看板选择） */
export interface AvailableSpecimen {
  id: string
  sampleId: string
  sampleNo?: string
  patient: string
  sampleType: string
  project?: string
  status: string
  receivedAt: string
  /** 收样批次号（范围整选维度：按批次整选；手建/内嵌样本可为空） */
  batchNo?: string
  /** true = Excel 导入的内嵌样本（不在样本中心） */
  embedded?: boolean
}

/** 已收样登记但样本中心尚未录入的批次（批次级概要，仅查看） */
export interface PendingReceptionBatch {
  batchId: string
  batchNo: string
  hospital: string
  source: string
  tubeCount: number
  receivedAt: string
  notes?: string
}

/** 可排单候选：已入库样本 + 待录入批次概要 + 扫码占位行（有条码无患者，可排单） */
export interface AvailableSpecimensResult {
  samples: AvailableSpecimen[]
  pendingBatches: PendingReceptionBatch[]
  pendingSpecimens: AvailableSpecimen[]
}

/** 获取可排单的样本+样例列表（NIFTY → 制备链路样本；非 NIFTY → 样本中心样本 + 待录入批次） */
export async function getAvailableSpecimens(project?: string): Promise<AvailableSpecimensResult> {
  const data = await apiGet<AvailableSpecimen[] | AvailableSpecimensResult>('/samples/available-specimens', project ? { project } : undefined)
  // NIFTY 老模式返回数组，归一化为统一结构
  if (Array.isArray(data)) return { samples: data, pendingBatches: [], pendingSpecimens: [] }
  return {
    samples: data.samples ?? [],
    pendingBatches: data.pendingBatches ?? [],
    pendingSpecimens: data.pendingSpecimens ?? [],
  }
}

/** 获取产物样本列表（用于测序 Lane 分配） */
export interface PoolSample {
  id: string
  name: string
  sampleNo?: string
  patientName?: string
  productType: string
  concentration: number
  volume: number
}
export async function getPoolSamples(): Promise<PoolSample[]> {
  return apiGet<PoolSample[]>('/products/pool-samples')
}

/** 批量创建样本（batchId 为收样登记创建的批次号，可选，由后端写入 batch_id；内部编号后端自动分配） */
export async function addSampleBatch(
  samples: Array<{
    sampleNo?: string;
    patient?: string;
    gender?: string;
    age?: number;
    type?: string;
    project?: string;
    source?: string;
    hospital?: string;
    receivedAt?: string;
    extId?: string;
    /** 产品套餐（分产品收样同步，随样本落库） */
    package?: string;
  }>,
  batchId?: string,
): Promise<{ success: boolean; createdIds: string[]; updatedIds?: string[]; errors?: Array<{ index: number; message: string }> }> {
  return apiPost('/samples/batch', { samples, batchId })
}

/** OmicsOne 接口查询到的样本（字段已由后端适配层规范化为内部字段） */
export interface OmicsSample {
  sampleNo: string
  patient: string
  gender?: string
  age?: number
  type?: string
  project?: string
  hospital?: string
  receivedAt?: string
  source?: string
  extId?: string
}

export interface OmicsQueryResponse {
  enabled: boolean
  samples: OmicsSample[]
}

/** 按日期范围查询 OmicsOne 样本（后端读配置调医院接口；未开启/异常时后端报错透出） */
export async function queryOmicsSamples(dateFrom: string, dateTo: string): Promise<OmicsQueryResponse> {
  return apiPost('/samples/omics-query', { dateFrom, dateTo })
}

/**
 * 按样本编号批量查询 OmicsOne（手动填写「智能预填」用）。
 * 后端契约（预备）：POST /samples/omics-query-by-codes，body { codes }，
 * 返回结构同 omics-query（enabled/samples）；未匹配编号由前端按 codes 与 samples 差集计算。
 * 后端未实现时调用报错，由前端降级提示，不影响手动兜底。
 */
export async function queryOmicsSamplesByCodes(codes: string[]): Promise<OmicsQueryResponse> {
  return apiPost('/samples/omics-query-by-codes', { codes })
}
