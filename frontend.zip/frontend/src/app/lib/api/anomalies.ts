import type { ApiResult } from './client'
import type { Anomaly, PaginationParams } from './types'
import { apiGet, getApiClient } from './http'

export interface GetAnomaliesParams extends PaginationParams {
  status?: string
  level?: string
  category?: string
}

export function getAnomalies(
  params: GetAnomaliesParams = {},
): Promise<ApiResult<Anomaly[]>> {
  return getApiClient().get<Anomaly[]>('/anomalies', { params: params as Record<string, string | number | boolean> })
}

export function getAnomalyById(id: string): Promise<ApiResult<Anomaly>> {
  return getApiClient().get<Anomaly>(`/anomalies/${id}`)
}

export function updateAnomalyStatus(id: string, status: string): Promise<ApiResult<Anomaly>> {
  return getApiClient().put<Anomaly>(`/anomalies/${id}/status`, { status })
}

/** 导出异常列表（按当前筛选条件导出全量） */
export async function exportAnomalies(params?: GetAnomaliesParams): Promise<{ success: boolean; downloadUrl: string; filename: string }> {
  return apiGet('/anomalies/export', params as Record<string, string | number | boolean | undefined>)
}
