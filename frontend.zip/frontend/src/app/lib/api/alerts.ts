import type { ApiResult } from './client'
import type { Alert, PaginationParams } from './types'
import { apiPut, apiPost, getApiClient } from './http'

// ─── Alerts API ─────────────────────────────────────────────────────────────

export interface GetAlertsParams extends PaginationParams {
  status?: string
  type?: string
}

export function getAlertsList(
  params: GetAlertsParams = {},
): Promise<ApiResult<Alert[]>> {
  return getApiClient().get<Alert[]>('/alerts', { params: params as Record<string, string | number | boolean> })
}

/** 确认单条警报 */
export async function acknowledgeAlert(id: string): Promise<{ success: boolean; alert: Alert }> {
  return apiPut(`/alerts/${id}/acknowledge`)
}

/** 解决单条警报 */
export async function resolveAlert(id: string): Promise<{ success: boolean; alert: Alert }> {
  return apiPut(`/alerts/${id}/resolve`)
}

/** 批量确认警报 */
export async function batchAcknowledgeAlerts(ids: string[]): Promise<{ success: boolean; acknowledgedIds: string[] }> {
  return apiPost('/alerts/batch-acknowledge', { ids })
}

/** 批量解决警报 */
export async function batchResolveAlerts(ids: string[]): Promise<{ success: boolean; resolvedIds: string[] }> {
  return apiPost('/alerts/batch-resolve', { ids })
}

/** 标记警报已读 */
export async function markAlertRead(id: string): Promise<{ success: boolean }> {
  return apiPut(`/alerts/${id}/read`)
}
