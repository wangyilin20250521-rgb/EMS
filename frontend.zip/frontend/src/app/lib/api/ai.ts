import { getApiConfig } from './config'
import { apiGet, apiPost, getAuthToken } from './http'
import type { ConversationSummary, ConversationDetail } from './types'
import type { ActionProposal } from '../utils/sse'

export type AiWorkflowTaskStatus = 'active' | 'waiting_confirmation' | 'blocked' | 'completed' | 'cancelled'
export interface AiWorkflowTask {
  id: string; title: string; type: string; status: AiWorkflowTaskStatus; priority: string
  /**所属会话 id（工作记录按当前会话过滤任务用；2026-09-17） */
  sessionId: string
  progress: number; nextAction?: string; createdAt: string; updatedAt: string
  steps: Array<{ seq: number; title: string; status: string; requiresConfirmation: boolean; reference: Record<string, unknown> }>
}
// ─── Conversation History ────────────────────────────────────────────────────────

// Conversation endpoints are on the Agent Server (port 3456), not Web Server
const agentBase = () => getApiConfig().agentUrl

// agent-server 自 2026-08-27 起要求 JWT 鉴权（与 web-server 共享 secret），会话接口必须带 Bearer
const agentHeaders = (): Record<string, string> => {
  const token = getAuthToken()
  return token ? { Authorization: `Bearer ${token}` } : {}
}

/** 当前用户进行中的 AI 工作任务（工作台侧栏使用）。 */
export async function getAiWorkflowTasks(): Promise<AiWorkflowTask[]> {
  const res = await fetch(`${agentBase()}/api/tasks`, { headers: agentHeaders() })
  if (!res.ok) throw new Error(`Agent error: ${res.status}`)
  const json = await res.json()
  return (json.code === '0' || json.code === 0) && Array.isArray(json.data) ? json.data : []
}

/** GET /api/conversations (Agent Server) */
export async function getConversations(): Promise<ConversationSummary[]> {
  const res = await fetch(`${agentBase()}/api/conversations`, { headers: agentHeaders() })
  if (!res.ok) throw new Error(`Agent error: ${res.status}`)
  const json = await res.json()
  return (json.code === "0" || json.code === 0) ? json.data : json
}

/** GET /api/conversations/:id (Agent Server) */
export async function getConversationById(id: string): Promise<ConversationDetail | null> {
  const res = await fetch(`${agentBase()}/api/conversations/${id}`, { headers: agentHeaders() })
  if (!res.ok) return null
  const json = await res.json()
  return (json.code === "0" || json.code === 0) ? json.data : json
}

/** DELETE /api/conversations/:id (Agent Server) — deletes the conversation JSON file */
export async function deleteConversation(id: string): Promise<void> {
  const res = await fetch(`${agentBase()}/api/conversations/${id}`, { method: 'DELETE', headers: agentHeaders() })
  // 404 means the file doesn't exist — already cleared, treat as success
  if (!res.ok && res.status !== 404) throw new Error(`Agent error: ${res.status}`)
}

// ─── AI Action 确认/取消（Agent Server /api/actions，P2 提议闭环） ────────────
// 2026-09-04 组F：useAIChat 与策略管理页的 fetch 收编到此处；失败统一带后端 message
//（含 403"仅提议人本人或管理员"文案，页面原样 toast 展示）。

export type AiActionResult = { ok: true; result?: unknown } | { ok: false; status: number; message: string }

/** POST /api/actions/:id/confirm — 确认并执行写操作（以确认人 JWT 执行） */
export async function confirmAiAction(proposalId: string): Promise<AiActionResult> {
  const res = await fetch(`${agentBase()}/api/actions/${encodeURIComponent(proposalId)}/confirm`, {
    method: 'POST',
    headers: agentHeaders(),
  })
  const json = await res.json().catch(() => null)
  if (res.ok && (json?.code === "0" || json?.code === 0)) return { ok: true, result: json.data?.result }
  return { ok: false, status: res.status, message: json?.message ?? `执行失败（HTTP ${res.status}）` }
}

/** POST /api/actions/:id/cancel — 取消提议（pending → cancelled） */
export async function cancelAiAction(proposalId: string): Promise<AiActionResult> {
  const res = await fetch(`${agentBase()}/api/actions/${encodeURIComponent(proposalId)}/cancel`, {
    method: 'POST',
    headers: agentHeaders(),
  })
  const json = await res.json().catch(() => null)
  if (res.ok && (json?.code === "0" || json?.code === 0)) return { ok: true }
  return { ok: false, status: res.status, message: json?.message ?? `取消失败（HTTP ${res.status}）` }
}

/** GET /api/actions/pending — 当前用户未决确认卡（刷新页面后恢复） */
export async function getPendingAiActions(sessionId?: string): Promise<ActionProposal[]> {
  const qs = sessionId ? `?sessionId=${encodeURIComponent(sessionId)}` : ''
  const res = await fetch(`${agentBase()}/api/actions/pending${qs}`, { headers: agentHeaders() })
  if (!res.ok) throw new Error(`Agent error: ${res.status}`)
  const json = await res.json()
  return (json.code === "0" || json.code === 0) && Array.isArray(json.data) ? json.data as ActionProposal[] : []
}

/** GET /api/actions/session — 会话全部提议（历史卡片恢复，2026-09-15）：
 * 含终态（已执行/已取消/失败）与过期归一；前端重开对话时按 ts 挂回原消息保持卡片视觉。 */
export async function getSessionAiActions(sessionId: string): Promise<ActionProposal[]> {
  const res = await fetch(`${agentBase()}/api/actions/session?sessionId=${encodeURIComponent(sessionId)}`, { headers: agentHeaders() })
  if (!res.ok) throw new Error(`Agent error: ${res.status}`)
  const json = await res.json()
  return (json.code === "0" || json.code === 0) && Array.isArray(json.data) ? json.data as ActionProposal[] : []
}

// ─── AI Action Audit（Agent Server /api/actions） ────────────────────────────

export interface AiActionRow {
  id: number
  proposal_id: string
  session_id: string
  tool_name: string
  args: Record<string, unknown>
  summary: string
  status: string
  username: string
  confirm_username: string | null
  confirmed_at: string | null
  cancelled_at: string | null
  error: string | null
  created_at: string
}

export interface AiActionListResult {
  items: AiActionRow[]
  total: number
  page: number
  pageSize: number
}

/** GET /api/actions — 管理员查询 AI 操作审计（工具/状态/用户过滤 + 分页） */
export async function getAiActions(filters: {
  toolName?: string
  status?: string
  username?: string
  page?: number
  pageSize?: number
} = {}): Promise<AiActionListResult> {
  const qs = new URLSearchParams()
  if (filters.toolName) qs.set("tool_name", filters.toolName)
  if (filters.status) qs.set("status", filters.status)
  if (filters.username) qs.set("username", filters.username)
  if (filters.page) qs.set("page", String(filters.page))
  if (filters.pageSize) qs.set("pageSize", String(filters.pageSize))
  const q = qs.toString()
  const res = await fetch(`${agentBase()}/api/actions${q ? `?${q}` : ""}`, { headers: agentHeaders() })
  if (!res.ok) throw new Error(`Agent error: ${res.status}`)
  const json = await res.json()
  return (json.code === "0" || json.code === 0) ? json.data : json
}

// ─── AI Read Audit（Agent Server /api/actions/reads，2026-09-11 ai_reads） ───

export interface AiReadRow {
  id: number
  ts: string
  session_id: string
  username: string
  mode: "query_database" | "bridge" | "kb"
  target: string
  tool_name: string | null
  row_count: number | null
  duration_ms: number | null
  ok: boolean
  error: string | null
}

export interface AiReadListResult {
  items: AiReadRow[]
  total: number
  page: number
  pageSize: number
}

/** GET /api/actions/reads — 管理员查询 AI 读操作审计（模式/用户过滤 + 分页） */
export async function getAiReads(filters: {
  mode?: string
  username?: string
  page?: number
  pageSize?: number
} = {}): Promise<AiReadListResult> {
  const qs = new URLSearchParams()
  if (filters.mode) qs.set("mode", filters.mode)
  if (filters.username) qs.set("username", filters.username)
  if (filters.page) qs.set("page", String(filters.page))
  if (filters.pageSize) qs.set("pageSize", String(filters.pageSize))
  const q = qs.toString()
  const res = await fetch(`${agentBase()}/api/actions/reads${q ? `?${q}` : ""}`, { headers: agentHeaders() })
  if (!res.ok) throw new Error(`Agent error: ${res.status}`)
  const json = await res.json()
  return (json.code === "0" || json.code === 0) ? json.data : json
}

// ─── 演示数据（系统设置 → 数据维护；web-server /demo-seed/*，管理员） ──────────────

export interface DemoSeedStatus {
  seeded: boolean
  /**播种时间（播种器标记内的 seededAt，如 "2026-09-18 09:56"） */
  seededAt?: string | null
}

/**演示数据状态（依据播种器标记） */
export async function getDemoSeedStatus(): Promise<DemoSeedStatus> {
  return apiGet<DemoSeedStatus>('/demo-seed/status')
}

/**灌入演示数据（reset + up 两步子进程，约 5~10 秒；生产档案 DB_RESET_WEB=false 下服务端拒绝） */
export async function seedDemoData(): Promise<{ seeded: boolean; log: string }> {
  return apiPost<{ seeded: boolean; log: string }>('/demo-seed/up', {})
}

/**清空演示数据（按标记删除播种的行，无标记为 no-op） */
export async function clearDemoData(): Promise<{ cleared: boolean; log: string }> {
  return apiPost<{ cleared: boolean; log: string }>('/demo-seed/reset', {})
}

// ─── 委派回执（总管家模式：EMS 助手在子 agent 模块的代办记录） ──────────────
// delegate 工具每次成功委派在 agent.delegation_logs 落一条回执；模块页面（解决方案卡片/
// 文档/策略）按 module+ref 查询展示"EMS 助手在本模块的工作记录"，用户切换页面能看到
// 与主对话一致的解答。同模块共享可见（标注咨询人）。

export type DelegationModule = 'strategy' | 'document' | 'solution'

export interface DelegationReceipt {
  id: number
  module: DelegationModule
  targetRef: string | null
  question: string
  answer: string
  sources: Array<{ kb: string; score: string }> | null
  username: string | null
  createdAt: string
}

/** GET /api/delegations?module=&ref=&limit= (Agent Server) — 某模块（可选按目标引用）的最近回执 */
export async function getDelegationReceipts(
  module: DelegationModule,
  ref?: string | null,
  limit = 20
): Promise<DelegationReceipt[]> {
  const qs = new URLSearchParams({ module, limit: String(limit) })
  if (ref) qs.set('ref', ref)
  const res = await fetch(`${agentBase()}/api/delegations?${qs}`, { headers: agentHeaders() })
  if (!res.ok) throw new Error(`Agent error: ${res.status}`)
  const json = await res.json()
  return (json.code === '0' || json.code === 0) && Array.isArray(json.data) ? json.data : []
}

// ─── 聊天附件上传（总管家模式：用户主动给 AI 材料） ─────────────────────────
// 上传即返回引用（id/name/kind），正文不进对话——AI 经 read_attachment 工具按需读取
// （表格→CSV 文本 / 图片→视觉模型提取，服务端缓存提取结果）。

export type AttachmentKind = 'spreadsheet' | 'image' | 'text'

export interface UploadedAttachment {
  id: string
  name: string
  kind: AttachmentKind
  size: number
}

/** POST /api/attachments (Agent Server, multipart field "file") */
export async function uploadAttachment(file: File): Promise<UploadedAttachment> {
  const form = new FormData()
  form.append('file', file)
  const res = await fetch(`${agentBase()}/api/attachments`, {
    method: 'POST',
    headers: agentHeaders(),
    body: form,
  })
  const json = await res.json().catch(() => null)
  if (!res.ok || !json || !(json.code === '0' || json.code === 0)) {
    throw new Error(json?.message || `附件上传失败: ${res.status}`)
  }
  return json.data as UploadedAttachment
}
