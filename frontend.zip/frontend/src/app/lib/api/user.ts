import { apiGet, apiPut } from './http'

// ─── Profile API ───────────────────────────────────────────────────────────

export interface UserProfile {
  id: string
  username: string
  displayName: string
  role: string
  email: string
  phone: string
  avatar?: string
  department: string
  lastLogin: string
}

export interface UserProfileUpdate {
  displayName?: string
  email?: string
  phone?: string
  department?: string
}

/** 获取个人信息 */
export async function getUserProfile(): Promise<UserProfile> {
  return apiGet('/user/profile')
}

/** 更新个人信息 */
export async function updateUserProfile(
  payload: UserProfileUpdate,
): Promise<{ success: boolean; profile: UserProfile }> {
  return apiPut('/user/profile', payload)
}
