/**
 * SIRO 中台直连客户端
 *
 * 前端直接访问 siro-server（VITE_SIRO_URL，默认 :8080），不经过 web-server 中转。
 * SIRO 端点无需 JWT（与 OpenAPI 约定一致）。
 */
import { getApiConfig } from './config'
import { getAuthToken } from './http'

interface SiroResponse<T = any> {
  code: string
  message: string
  data?: T
}

async function siroRequest<T>(method: 'GET' | 'POST' | 'PUT' | 'DELETE', path: string, body?: unknown): Promise<SiroResponse<T>> {
  const { siroUrl, timeout } = getApiConfig()
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeout)
  try {
    const res = await fetch(`${siroUrl}/api/v1/hospital${path}`, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    })
    const json = await res.json().catch(() => ({}))
    if (!res.ok) {
      throw { status: res.status, code: '-1', message: json?.message || `SIRO HTTP ${res.status}` }
    }
    return json as SiroResponse<T>
  } finally {
    clearTimeout(timer)
  }
}

export interface SiroDispatchPayload {
  /** M-LIMS 任务编号（task_source_no） */
  taskId: string
  taskName?: string
  processNo?: string
  processVersion?: string
  projectCode?: string
  sampleCount?: number
  /** 上位机 SampleNoInfoDto 数组（ExperimentSampleId 为任务内唯一关联键） */
  sampleNos?: Record<string, unknown>[]
}

/** 投递任务到 SIRO 中台 — POST /api/v1/hospital/tasks */
export async function dispatchTaskToSiro(payload: SiroDispatchPayload): Promise<SiroResponse<any>> {
  const { taskId, taskName, processNo, processVersion, projectCode, sampleCount, sampleNos } = payload
  return siroRequest('POST', '/tasks', {
    task_source_no: taskId,
    task_name: taskName || `实验任务 ${taskId}`,
    process_no: processNo || '',
    process_version: processVersion || 'V1.0.0',
    project_code: projectCode || 'NIFTY',
    sample_count: sampleCount || 0,
    sample_nos: sampleNos || [],
  })
}

/** 拉取可用流程列表 — POST /api/v1/hospital/process/list (可选按 device_type 筛选) */
export async function fetchSiroProcessList(deviceType?: string): Promise<any[]> {
  const body: any = {}
  if (deviceType) body.device_type = deviceType.replace("-", "_")
  const json = await siroRequest<{ process?: any[] }>('POST', '/process/list', body)
  const list = json?.data?.process
  return Array.isArray(list) ? list : []
}

/** 导入流程 — POST /api/v1/hospital/process/import */
export async function importSiroProcess(processInfo: any, steps: any[]): Promise<any> {
  const json = await siroRequest('POST', '/process/import', { process_info: processInfo, steps })
  return json?.data ?? json
}

/** 查询流程详情 — GET /api/v1/hospital/process/list/:id */
export async function getSiroProcessDetail(id: string): Promise<any> {
  const json = await siroRequest('GET', `/process/list/${encodeURIComponent(id)}`)
  return json?.data
}

/** 删除流程 — DELETE /api/v1/hospital/process/list/:id */
export async function deleteSiroProcess(id: string): Promise<any> {
  const json = await siroRequest('DELETE', `/process/list/${encodeURIComponent(id)}`)
  return json?.data ?? json
}

export interface SiroDevice {
  biz_host_id: string
  host_name: string
  host_type: string
  device_id: string
  device_ip: string
  device_port: number
  status: string
  current_task_count: number
  load_percent: number
  max_task_count: number
  last_heartbeat: string
  error_message: string | null
  location: string
  notes: string
  create_time: string
  update_time: string
}

/** 拉取 SIRO 注册设备列表 — GET /api/v1/hospital/device/register/list */
export async function fetchSiroDeviceList(): Promise<SiroDevice[]> {
  const json = await siroRequest<any[]>('GET', '/device/register/list')
  return Array.isArray(json?.data) ? json.data : []
}

export interface SiroTaskStatusLog {
  log_id: string
  log_type: string
  log_level: string
  step_name: string | null
  log_content: string
  log_time: string
}

/** 结构化样本结果（从上报的 sample_nos 解析） */
export interface SiroSampleResult {
  experimentSampleId: string
  sampleNo: string
  testName: string
  sampleType: string
  qcType: string
  preptreatmentPlate: string
  preptreatmentWell: string
  libprepPlate: string
  libprepWell: string
  hybridPlate: string
  hybridWell: string
  seqprepPlate: string
  seqprepWell: string
  barcodeID: string
  index: string
  umi: string
  dnaSamplingVolume: string
  libraryVolume: string
  poolingID: string
  hybridizationID: string
  extractionQC: string
  extractionSignal: string
  libprepQC: string
  libprepSignal: string
  hybridQC: string
  hybridSignal: string
  seqprepQC: string
  seqprepSignal: string
}

/** 步骤时间线条目（每个步骤的最新状态） */
export interface SiroStepTimeline {
  stepNo: string
  status: string
  updatedAt: string
}

/** 上位机上报的任务运行状态（存于 siro-server 数据库） */
export interface SiroTaskStatus {
  task_no: string
  status: string
  current_step: string | null
  current_step_status: string | null
  step_no: string | null
  progress: number
  biz_host_id: string | null
  claim_time: string | null
  status_reason: string | null
  report_payload: unknown
  sample_nos: Record<string, unknown>[]
  samples: SiroSampleResult[]
  steps: SiroStepTimeline[]
  logs: SiroTaskStatusLog[]
}

/** 获取 SIRO 任务运行时状态 — GET /siro/task-status/:taskSourceNo (via web-server proxy) */
export async function fetchSiroTaskStatus(taskSourceNo: string): Promise<SiroTaskStatus | null> {
  const { baseUrl } = getApiConfig()
  const headers: Record<string, string> = {}
  const token = getAuthToken()
  if (token) headers["Authorization"] = `Bearer ${token}`
  const res = await fetch(`${baseUrl}/siro/task-status/${encodeURIComponent(taskSourceNo)}`, { headers })
  if (!res.ok) return null
  const json = await res.json().catch(() => ({}))
  return json?.data ?? null
}

/** 释放中台任务（按 EMS 任务号）：任务回 READY，上位机可重新认领（重复测试） */
export async function releaseSiroTask(taskId: string): Promise<{ taskNo: string; released: boolean; message: string }> {
  const { baseUrl } = getApiConfig()
  const headers: Record<string, string> = { "Content-Type": "application/json" }
  const token = getAuthToken()
  if (token) headers["Authorization"] = `Bearer ${token}`
  const res = await fetch(`${baseUrl}/siro/release-task`, {
    method: "POST",
    headers,
    body: JSON.stringify({ taskId }),
  })
  const json = await res.json().catch(() => ({}))
  if (json?.code !== "0" && json?.code !== 0) throw new Error(json?.message || "释放失败")
  return json?.data
}

/**
 * 远程控制上位机任务 — POST /siro/host-command (web-server 代理)
 * 后端按认领该任务的上位机注册地址（biz_host.device_ip/device_port）转发
 * stop/pause/resume 到上位机 HTTP 服务。
 */
export async function sendHostCommand(
  taskId: string,
  action: "stop" | "pause" | "resume",
  reason?: string,
): Promise<unknown> {
  const { baseUrl } = getApiConfig()
  const headers: Record<string, string> = { "Content-Type": "application/json" }
  const token = getAuthToken()
  if (token) headers["Authorization"] = `Bearer ${token}`
  const res = await fetch(`${baseUrl}/siro/host-command`, {
    method: "POST",
    headers,
    body: JSON.stringify({ taskId, action, reason }),
  })
  const json = await res.json().catch(() => ({}))
  if (json?.code !== "0" && json?.code !== 0) throw new Error(json?.message || "控制指令下发失败")
  return json?.data
}

/** 拉取分血流程列表 — POST /api/v1/hospital/process/list/blood */
export async function fetchBloodProcessList(): Promise<any[]> {
  const json = await siroRequest<any[]>('POST', '/process/list/blood')
  return Array.isArray(json?.data) ? json.data : []
}

/** 导入分血流程 — POST /api/v1/hospital/process/import/blood */
export async function importBloodProcess(methods: any[]): Promise<any> {
  const json = await siroRequest('POST', '/process/import/blood', methods)
  return json?.data ?? json
}

/** 删除分血流程 — DELETE /api/v1/hospital/process/list/blood/:id */
export async function deleteBloodProcess(id: string): Promise<any> {
  const json = await siroRequest('DELETE', `/process/list/blood/${encodeURIComponent(id)}`)
  return json?.data ?? json
}

/** 注册虚拟设备（测试用） — POST /api/v1/hospital/device/register */
export async function registerSiroDevice(payload: {
  host_name: string
  host_type: string
  device_id: string
  device_ip?: string
  device_port?: number
  location?: string
}): Promise<any> {
  const json = await siroRequest('POST', '/device/register', payload)
  return json?.data ?? json
}

/** 更新 SIRO 设备信息（位置/备注） — PUT /api/v1/hospital/device/:id */
export async function updateSiroDevice(id: string, payload: { location?: string; notes?: string }): Promise<any> {
  const json = await siroRequest('PUT', `/device/${encodeURIComponent(id)}`, payload)
  return json?.data ?? json
}
