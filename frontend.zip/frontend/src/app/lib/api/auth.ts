import { useApiClient } from './provider'
import type { ChangePasswordRequest, ChangePasswordResponse, LoginRequest, LoginResponse } from './types'
import type { ApiResult } from './client'

/** Auth API functions using the API client abstraction layer */
export function useAuthApi() {
  const client = useApiClient()

  return {
    async login(credentials: LoginRequest): Promise<ApiResult<LoginResponse>> {
      return client.post<LoginResponse>('/auth/login', credentials)
    },

    async logout(): Promise<ApiResult<{ success: boolean }>> {
      return client.post<{ success: boolean }>('/auth/logout')
    },

    async changePassword(input: ChangePasswordRequest): Promise<ApiResult<ChangePasswordResponse>> {
      return client.post<ChangePasswordResponse>('/auth/change-password', input)
    },
  }
}

import { getApiClient } from './http'

/**
 * Standalone auth API functions (for use outside React components).
 */
export async function login(credentials: LoginRequest): Promise<ApiResult<LoginResponse>> {
  return getApiClient().post<LoginResponse>('/auth/login', credentials)
}

export async function logout(): Promise<ApiResult<{ success: boolean }>> {
  return getApiClient().post<{ success: boolean }>('/auth/logout')
}

export async function changePassword(input: ChangePasswordRequest): Promise<ApiResult<ChangePasswordResponse>> {
  return getApiClient().post<ChangePasswordResponse>('/auth/change-password', input)
}
