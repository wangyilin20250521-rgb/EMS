import { apiGet, apiPut, apiPost } from './http'
import type { PaginationParams } from './types'

export type ProductType = 'nucleic' | 'library' | 'pooling'
/** 对齐后端中文枚举：'正常' / '已销毁' */
export type ProductStatus = '正常' | '已销毁'

/** 登记产物（建库实验完成 → 文库入库）；taskId 自动绑定任务 */
export interface ProductCreatePayload {
  type: ProductType
  taskId?: string
  concentration?: string
  unit?: string
  volume?: string
  plateNo?: string
  wellPos?: string
  location?: string
  storageCondition?: string
  expiryDate?: string
  notes?: string
}

export interface Product {
  id: string
  type: ProductType
  typeName: string
  icon: string
  relatedId: string
  relatedName: string
  taskId: string
  plateNo: string
  wellPos: string
  concentration: string
  unit: string
  volume: string
  total: string
  date: string
  location: string
  storageCondition: string
  expiryDate: string
  notes: string
  status: ProductStatus
  remindDays: number
}

export type ProductUpdate = Pick<Product, 'storageCondition' | 'expiryDate' | 'notes'>

export interface ProductMutationResult {
  success: boolean
}

export async function createProduct(payload: ProductCreatePayload): Promise<Product> {
  return apiPost(`/products`, payload)
}

export async function updateProduct(id: string, patch: ProductUpdate): Promise<ProductMutationResult> {
  return apiPut(`/products/${id}`, patch)
}

export async function destroyProduct(id: string, reason = ''): Promise<ProductMutationResult> {
  return apiPost(`/products/${id}/destroy`, { reason })
}

// ─── Extended Product API ──────────────────────────────────────────────────────

export interface GetProductsParams extends PaginationParams {
  /** 搜索:产物编号/样本编号/任务编号 */
  q?: string
  type?: string
  status?: string
}

/** 获取产物列表 */
/** 产物分页结果(2026-09:GET /products 服务端分页返回 { items, total }) */
export interface ProductsPageResult {
  items: Product[]
  total: number
}

export async function getProducts(params: GetProductsParams = {}): Promise<ProductsPageResult> {
  return apiGet<ProductsPageResult>('/products', params as Record<string, string | number | boolean | undefined>)
}

/** 获取产物详情 */
export async function getProductById(id: string): Promise<Product | null> {
  return apiGet(`/products/${id}`)
}

/** 导出产物列表 */
export async function exportProducts(filterType?: string): Promise<{ success: boolean; downloadUrl: string; filename: string }> {
  return apiGet('/products/export', filterType ? { type: filterType } : undefined)
}
