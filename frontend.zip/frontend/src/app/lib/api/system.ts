import type { PermissionModule, SystemUser, SystemRole, SystemLogEntry, DictionaryItem, PaginationParams } from './types'
import { apiGet, apiPost, apiPut, apiDelete } from './http'

// ─── Types ──────────────────────────────────────────────────────────────────

export interface BackupRecord {
  id: string
  createdAt: string
  size: number       // bytes
  tables: number     // count of backed-up tables
}

export interface BackupCreateResult {
  backupId: string
}

export interface BackupRestoreResult {
  restored: number
}

// ─── 解决方案（/system/profiles，管理员端点） ─────────────────────────────────────

export interface SolutionProfileSummary {
  id: string
  label: string
  description: string
}

export interface SolutionProfilesPayload {
  /**config.json 中选中的方案（重启后端后生效） */
  selected: string
  /**当前运行态方案 */
  applied: { id: string; label?: string } | null
  profiles: SolutionProfileSummary[]
}

/** 方案清单（AI 助手「解决方案」入口卡用；非管理员会 403，由调用方降级为空列表） */
export async function getSolutionProfiles(): Promise<SolutionProfilesPayload> {
  return apiGet('/system/profiles')
}

// ─── Permissions & Backup ───────────────────────────────────────────────────────

export async function getPermissionTree(): Promise<PermissionModule[]> {
  return apiGet('/system/permissions')
}

export async function getBackupRecords(): Promise<BackupRecord[]> {
  return apiGet('/system/backups')
}

export async function createBackup(): Promise<BackupCreateResult> {
  return apiPost('/system/backup')
}

export async function restoreBackup(id: string): Promise<BackupRestoreResult> {
  return apiPost(`/system/backups/${id}/restore`)
}

// ─── System User Management ─────────────────────────────────────────────────────

/** 获取用户列表 */
export async function getSystemUsers(): Promise<SystemUser[]> {
  return apiGet('/system/users')
}

/** 新增用户 */
export async function createSystemUser(
  payload: { username: string; name: string; phone: string; email: string; password: string; role: string },
): Promise<{ success: boolean; user: SystemUser }> {
  return apiPost('/system/users', payload)
}

/** 编辑用户 */
export async function updateSystemUser(
  id: string,
  payload: { username?: string; name?: string; phone?: string; email?: string; role?: string; password?: string },
): Promise<{ success: boolean }> {
  return apiPut(`/system/users/${id}`, payload)
}

/** 启用/禁用用户 */
export async function toggleSystemUserStatus(
  id: string,
  status: '正常' | '已禁用',
): Promise<{ success: boolean }> {
  return apiPut(`/system/users/${id}/status`, { status })
}

// ─── System Role Management ─────────────────────────────────────────────────────

/** 获取角色列表 */
export async function getSystemRoles(): Promise<SystemRole[]> {
  return apiGet('/system/roles')
}

/** 获取角色权限 */
export async function getRolePermissions(roleId: string): Promise<Array<{ module: string; page: string; perms: string[] }>> {
  return apiGet(`/system/roles/${roleId}/permissions`)
}

/** 更新角色权限 */
export async function updateRolePermissions(
  roleId: string,
  permissions: Array<{ module: string; page: string; perms: string[] }>,
): Promise<{ success: boolean }> {
  return apiPut(`/system/roles/${roleId}/permissions`, { permissions })
}

// ─── System Config ────────────────────────────────────────────────────────────

export interface SystemBasicConfig {
  hospitalName: string
  departmentName: string
  systemTitle: string
}

export interface SystemSecurityConfig {
  timeout: number
  lockCount: number
  lockTime: number
  pwdCycle: number
  desensitize: boolean
}

/** 获取系统配置（含实验执行模式：siro|manual|hybrid，随当前方案投影；见 lib/execution-mode 单源） */
export type ExecutionModeApi = "siro" | "manual" | "hybrid"

export async function getSystemConfig(): Promise<{
  executionMode?: ExecutionModeApi
  /**当前模式允许注册的实验执行设备类型 */
  allowedExperimentDeviceTypes?: string[]
  basic: SystemBasicConfig
  security: SystemSecurityConfig
}> {
  return apiGet('/system/config')
}

/** 更新基础配置 */
export async function updateSystemBasicConfig(config: SystemBasicConfig): Promise<{ success: boolean }> {
  return apiPut('/system/config/basic', config)
}

/** 更新安全配置 */
export async function updateSystemSecurityConfig(config: SystemSecurityConfig): Promise<{ success: boolean }> {
  return apiPut('/system/config/security', config)
}

/** 医院 HIS 接口配置（单例固定三项） */
export interface SystemHisConfig {
  enabled: boolean
  ip: string
  port: string
}

/** 获取医院 HIS 接口配置 */
export async function getHisConfig(): Promise<SystemHisConfig> {
  return apiGet('/system/config/his')
}

/** 更新医院 HIS 接口配置 */
export async function updateHisConfig(config: SystemHisConfig): Promise<{ success: boolean }> {
  return apiPut('/system/config/his', config)
}

/** OmicsOne 接口配置（单例固定三项） */
export interface OmicsConfig {
  enabled: boolean
  ip: string
  port: string
}

/** 获取 OmicsOne 接口配置 */
export async function getOmicsConfig(): Promise<OmicsConfig> {
  return apiGet('/system/config/omics')
}

/** 更新 OmicsOne 接口配置 */
export async function updateOmicsConfig(config: OmicsConfig): Promise<{ success: boolean }> {
  return apiPut('/system/config/omics', config)
}

/** 测序系统对接配置（单例固定三项；任务完成后手动投递实验结果） */
export interface SequencingConfig {
  enabled: boolean
  ip: string
  port: string
}

/** 获取测序系统对接配置 */
export async function getSequencingConfig(): Promise<SequencingConfig> {
  return apiGet('/system/config/sequencing')
}

/** 更新测序系统对接配置 */
export async function updateSequencingConfig(config: SequencingConfig): Promise<{ success: boolean }> {
  return apiPut('/system/config/sequencing', config)
}


// ─── System Logs ─────────────────────────────────────────────────────────────

/** 获取操作日志（分页） */
export interface GetSystemLogsParams extends PaginationParams {
  module?: string
  action?: string
  search?: string
  /** YYYY-MM-DD（含当天） */
  dateFrom?: string
  dateTo?: string
}

export async function getSystemLogs(params: GetSystemLogsParams = {}): Promise<SystemLogEntry[]> {
  return apiGet<SystemLogEntry[]>('/system/logs', params as Record<string, string | number | boolean | undefined>)
}

/** 导出操作日志 */
export async function exportSystemLogs(filter?: { module?: string; action?: string; dateFrom?: string; dateTo?: string }): Promise<{ success: boolean; downloadUrl: string; filename: string }> {
  return apiGet('/system/logs/export', filter as Record<string, string | number | boolean | undefined>)
}

// ─── Data Dictionary ───────────────────────────────────────────────────────────

/** 获取数据字典分类 */
export async function getDictCategories(): Promise<Record<string, string[]>> {
  return apiGet('/system/dictionary')
}

/** 获取字典项列表 */
export async function getDictItems(category: string): Promise<DictionaryItem[]> {
  return apiGet(`/system/dictionary/${category}`)
}

/** 新增字典项 */
export async function createDictItem(
  category: string,
  item: { code?: string; name: string; sort?: number },
): Promise<{ success: boolean; code?: string }> {
  return apiPost(`/system/dictionary/${category}`, item)
}

/** 编辑字典项 */
export async function updateDictItem(
  category: string,
  code: string,
  payload: { name?: string; sort?: number; status?: '启用' | '禁用' },
): Promise<{ success: boolean }> {
  return apiPut(`/system/dictionary/${category}/${code}`, payload)
}

/** 删除字典项 */
export async function deleteDictItem(category: string, code: string): Promise<{ success: boolean }> {
  return apiDelete(`/system/dictionary/${category}/${code}`)
}

/** 分类元信息（自定义分类描述）：GET /system/dictionary/meta */
export async function getDictMeta(): Promise<Record<string, { description?: string }>> {
  return apiGet('/system/dictionary/meta')
}

/** 新增自定义字典分类（名称即编码）：POST /system/dictionary/category */
export async function createDictCategory(category: string, description?: string): Promise<{ success: boolean; category: string }> {
  return apiPost('/system/dictionary/category', { category, description })
}

/** 删除自定义字典分类（预置分类后端拒绝）：DELETE /system/dictionary/category/:category */
export async function deleteDictCategory(category: string): Promise<{ success: boolean }> {
  return apiDelete(`/system/dictionary/category/${encodeURIComponent(category)}`)
}
