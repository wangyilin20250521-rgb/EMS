import type { SamplePrepStatValue, SamplePrepRecord } from './types'
import { apiGet, apiPost, getAuthToken } from './http'
import { getApiConfig } from './config'
import { downloadBlob } from '../utils/download'

// ─── Sample Prep API ─────────────────────────────────────────────────────────

/** 获取样本制备页统计卡片纯数值 */
export async function getSamplePrepStats(): Promise<SamplePrepStatValue[]> {
  return apiGet<SamplePrepStatValue[]>('/sample-prep/stats')
}

/** 获取样本制备记录列表 */
export async function getSamplePrepRecords(params?: { dateFilter?: string; page?: number; pageSize?: number }): Promise<SamplePrepRecord[]> {
  return apiGet<SamplePrepRecord[]>('/sample-prep/records', params as Record<string, string | number | boolean | undefined>)
}

/** 获取可排单的任务列表（status='待实验'） */
export async function getSchedulableTasks(): Promise<SchedulableTask[]> {
  return apiGet<SchedulableTask[]>('/sample-prep/schedulable-tasks')
}

export interface SchedulableTask {
  taskId: string
  project: string
  sampleCount: number
  specimenCount: number
  batchId: string
  scheme: string
  specimens: Array<{ specimenId: string; sampleId: string; patient: string }>
}

/** 提交实验：将任务下已录入的样本推进到待实验 */
export async function submitToExperiment(taskId: string): Promise<{ taskId: string; updatedCount: number; message: string }> {
  return apiPost('/sample-prep/submit-to-experiment', { taskId })
}

/** 导出样本制备记录（按当前筛选条件导出全量） */
export async function exportSamplePrepRecords(dateFilter?: string): Promise<{ success: boolean; downloadUrl: string; filename: string }> {
  return apiGet('/sample-prep/export', dateFilter && dateFilter !== '全部' ? { dateFilter } : undefined)
}

/** Excel 导入的一行样本（不落库，随制备任务内嵌） */
export interface PrepImportedSamplePayload {
  batchSeq?: string
  sampleNo: string
  project?: string
  type?: string
  patient?: string
  gender?: string
  age?: number | string
  /**样例（EP 条码）编号：非空时视为制备结果已登记（reviewStatus=matched） */
  specimens?: string[]
}

/** 登记制备结果（场景3：单一 Excel 路径，样本中心按编号自动匹配，命中即关联） */
export async function createPrepTask(payload: {
  taskId: string
  /**手动登记时可不填（设备信息仅自动链路随上报附带） */
  deviceNo?: string
  project?: string
  /** 分血上位机 biz_host_id（分血完成回执按设备归属关联） */
  hostId?: string
  scheme?: string
  /** 场景3 手工登记：固定 "import"（Excel 导入，样本内嵌随任务；样本中心自动匹配） */
  source?: "import"
  importedSamples?: PrepImportedSamplePayload[]
}): Promise<{
  taskId: string
  scheme: string
  sampleCount: number
  linkedCount: number
  embeddedCount: number
}> {
  return apiPost('/sample-prep/create', payload)
}

/** 上位机上报自动创建制备任务（自动化模式）：入参仅 reportId，幂等 + 按样本编号去重 */
export interface AutoCreatePrepResult {
  taskId: string
  created: number
  skipped: number
  already?: boolean
  noNew?: boolean
}
export async function autoCreatePrepTask(reportId: string): Promise<AutoCreatePrepResult> {
  return apiPost('/sample-prep/auto-create', { reportId })
}

export interface HostSeparationReport {
  report_id: string
  biz_host_id: string
  report_time: string
  /** 接收状态:accepted=已确认应用,不再弹窗预览(历史回执只作底部信息展示) */
  accept_status?: string
  /** 上位机注册名称 / 设备标识 */
  host_name?: string
  device_id?: string
  /** 上位机上报的分血明细（方法/样本数/复核信息） */
  report_payload?: {
    device_id?: string
    method_id?: string
    method_name?: string
    sample_count?: number
    review_skipped?: boolean
    review_records?: Array<{
      sample_barcode: string
      ep_barcode: string
      position: string
      verify_result: string
      scan_time: string
    }>
  }
}

/** 上位机分血完成回执列表（存在 SIRO 中台库，EMS 按设备归属匹配制备任务） */
export async function getHostReports(): Promise<HostSeparationReport[]> {
  return apiGet<HostSeparationReport[]>('/sample-prep/host-reports')
}

/** 应用上位机分血回执：逐行比对样本编号 vs 扫描条码，匹配的填充样例 */
export async function applyPrepReport(taskId: string): Promise<{ matched: number; mismatch: number; skipped: number; skippedReview: boolean; unmatchedScans: number }> {
  return apiPost(`/sample-prep/${taskId}/apply-report`)
}

/** 单行人工确认通过（复核不一致时人工检查后标记通过） */
export async function manualPassPrepSample(taskId: string, sampleId: string): Promise<{ sampleId: string; reviewStatus: string }> {
  return apiPost(`/sample-prep/${taskId}/samples/${sampleId}/manual-pass`)
}

/** 检查样本编号是否已被未完成（未释放）的制备任务占用 */
export async function checkPrepDuplicates(sampleNos: string[]): Promise<{ duplicates: Array<{ sampleNo: string; taskId: string }> }> {
  return apiPost('/sample-prep/check-duplicates', { sampleNos })
}

/** 释放任务：样本编号解绑后可重新创建（重复测试流程） */
export async function releasePrepTask(taskId: string): Promise<{ taskId: string; message: string }> {
  return apiPost(`/sample-prep/${taskId}/release`)
}

/** EMS 接收决策回传上位机（accepted：已接受并准备排单 / rejected：未接受，请重新提交） */
export async function ackPrepReport(reportId: string, status: "accepted" | "rejected"): Promise<{ reportId: string; status: string; hostNotified: boolean }> {
  return apiPost('/sample-prep/report-ack', { reportId, status })
}

/** 下载制备结果登记模板（场景3：在样本中心 8 列基础上增加第 9 列「样例编号」，可选）。
 * 2026-09-22 起由后端生成（xlsx-populate，字体统一微软雅黑 + 表头配色/边框/冻结），
 * 前端只负责携带鉴权拉取——样式能力是 SheetJS 社区版没有的；仍不复用样本中心的共享 template.xlsx。 */
export async function downloadPrepImportTemplate(): Promise<void> {
  const { baseUrl, apiKey } = getApiConfig()
  const headers: Record<string, string> = {}
  const token = getAuthToken()
  if (token) headers["Authorization"] = `Bearer ${token}`
  if (apiKey) headers["X-API-Key"] = apiKey
  const res = await fetch(new URL("/sample-prep/import-template", baseUrl).toString(), { headers })
  if (!res.ok) {
    const text = await res.text().catch(() => "")
    let message = `模板下载失败 (HTTP ${res.status})`
    try { const j = JSON.parse(text); if (j?.message) message = j.message } catch { /* 非 JSON 响应 */ }
    throw new Error(message)
  }
  downloadBlob(await res.blob(), "制备结果登记模板.xlsx")
}
