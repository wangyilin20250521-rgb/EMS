import { apiGet, apiPut } from './http'

// ─── Strategy Rule Types ───────────────────────────────────────────────────────

export type StrategyRuleCategory =
  | '自动排单'
  | '分血规则'
  | '异常处置规则'
  | '排板规则'
  | '质控品规则'
  | 'QC判定规则'
  | 'TAT规则'
  | '命名规则'
  | '医院基础配置'
  | '自定义'

export interface StrategyRule {
  id: string
  name: string
  category: StrategyRuleCategory
  enabled: boolean
  priority: '高' | '中' | '低'
  fields: Array<{ label: string; value: string }>
  updatedBy?: string
  updatedAt?: string
}

// ─── Strategy Rule File API（.py Python 规则文件） ────────────────────────────

export interface RuleFileInfo {
  name: string
  size: number
  updatedAt: string
}

/** List all rule files */
export async function getRulesFiles(): Promise<RuleFileInfo[]> {
  return apiGet('/strategy-rules/files')
}

/** Get rule file content */
export async function getRulesConfig(name: string): Promise<{ exists: boolean; name: string; content: string }> {
  return apiGet(`/strategy-rules/files/${name}`)
}

/** Save rule file content */
export async function uploadRuleConfig(name: string, content: string): Promise<{ saved: boolean }> {
  return apiPut(`/strategy-rules/files/${name}`, { content })
}

// ─── Rule Metadata API（持久化于后端 data/rules/.meta.json） ─────────────────

export interface RuleMetaEntry {
  name?: string
  category?: string
  enabled?: boolean
  priority?: '高' | '中' | '低'
  fields?: Array<{ label: string; value: string }>
  updatedBy?: string
  updatedAt?: string
}

/** Get all rule metadata */
/** 实验流程规则（workflow-rules.py 解析后 JSON）：按项目过滤排单可用流程（processes 配置） */
export async function getWorkflowRules(): Promise<Record<string, any>> {
  return apiGet('/strategy-rules/workflow')
}

export async function getRulesMeta(): Promise<Record<string, RuleMetaEntry>> {
  return apiGet('/strategy-rules/meta')
}

/** Merge metadata for one rule */
export async function saveRuleMeta(name: string, patch: RuleMetaEntry): Promise<{ name: string; meta: RuleMetaEntry }> {
  return apiPut(`/strategy-rules/meta/${name}`, patch)
}
