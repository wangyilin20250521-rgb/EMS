import { createContext, createElement, useContext, type PropsWithChildren } from 'react'
import type { ApiClient } from './client'
import { RealApiClient } from './real-client'

/** Real mode only — all requests go to the backend REST API. */
const defaultApiClient: ApiClient = new RealApiClient()

const ApiContext = createContext<ApiClient>(defaultApiClient)

export function ApiProvider({ children }: PropsWithChildren) {
  return createElement(ApiContext.Provider, { value: defaultApiClient }, children)
}

export function useApiClient(): ApiClient {
  return useContext(ApiContext)
}
