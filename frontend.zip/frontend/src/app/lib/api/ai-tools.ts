import { apiGet } from "./http";

/** AI 写工具目录条目镜像（agent-server/web-server ai-tools.ts；2026-09-11 参数表单卡数据源） */
export interface AiToolCatalogEntry {
  name: string;
  module: string;
  description: string;
  method: string;
  path: string;
  readOnly: boolean;
  hasBody: boolean;
  /** 合并后的工具参数 JSON Schema（path/query/body） */
  parameters: Record<string, unknown>;
  mustAsk?: Array<{ field: string; label: string; options?: string[] }>;
  /** true = 参数表单化（request_form 打开前端表单一次收集） */
  form?: boolean;
}

let catalogPromise: Promise<AiToolCatalogEntry[]> | null = null;

/** 拉取 AI 工具目录（模块级缓存；供参数表单卡渲染 schema） */
export function getAiToolCatalog(): Promise<AiToolCatalogEntry[]> {
  if (!catalogPromise) {
    catalogPromise = apiGet<AiToolCatalogEntry[]>("/ai-tools").catch((e) => {
      catalogPromise = null; // 失败允许下次重试
      throw e;
    });
  }
  return catalogPromise;
}

/** 按名称取目录条目（含缓存失效时重新拉取一次） */
export async function findAiTool(name: string): Promise<AiToolCatalogEntry | undefined> {
  try {
    return (await getAiToolCatalog()).find((t) => t.name === name);
  } catch {
    return undefined;
  }
}
