// ─── Core: client, HTTP, types, auth, provider ───
export type { ApiClient, ApiError, ApiResult, HttpMethod, RequestOptions } from './client'
export { apiFailure, apiSuccess } from './client'
export type { ApiConfig } from './config'
export { getApiConfig } from './config'
export { getApiClient, setAuthToken, getAuthToken, apiGet, apiPost, apiPut, apiDelete, apiUpload } from './http'
export { RealApiClient } from './real-client'
export { ApiProvider, useApiClient } from './provider'

// ─── Types ───
export type {
  Anomaly, AnomalyLevel, Alert, AlertLevel, AlertStatus,
  AnomalyResolution, ResolutionType, SubmitResolutionPayload, SubmitResolutionResponse,
  AuthState, AuthUser, BarDatum,
  BatchCreateSamplesRequest, BatchCreateSamplesResponse,
  ChangePasswordRequest, ChangePasswordResponse, ChartDatum,
  Chip, CreateSequencingTaskRequest, CreateStrategyRuleRequest, CreateTaskRequest,
  Device, DeviceStatus, ExecutionOrder,
  Gender, Lane, LoginRequest, LoginResponse,
  ManualSampleRow, ManualScheduleRequest, ManualScheduleResponse,
  OCRField, OCRQueueItem,
  PaginatedResponse, PaginationParams,
  PlateInfo, PlateType, PreScheduleOrder, PreScheduleTag,
  Sample, SampleAdvancedFilter, SampleCreateItem, SampleEntryMode,
  SamplePrepItem, SamplePrepRecord, SampleReceptionRecord, SampleSource, SampleStatus,
  ScheduleOrderStatus, Sequencer,
  SIRODeviceType, SpecimenDetail,
  Task, TaskStatus,
  ViewId, WellPlateSlot,
  // Reception / unpack
  ReceptionProject, UnpackRecord, UnpackStatValue, UnpackFormState,
  // Devices
  LabDevice,
  // Dashboard
  StatCardValue, DashboardActivity, TatWarning,
  // Sample detail
  SampleExtraInfo, SampleTimelineStep,
  // Sample prep
  SamplePrepStatValue,
  // Sequencing
  ChipStatus, LaneStatus,
  // System management
  DictionaryItem, SystemUser, SystemRole, SystemLogEntry, PermissionModule,
  // AI / Agent
  AIStatValue, ConversationSummary, ConversationDetail,
} from './types'
export { DEVICE_STATUSES, PLATE_TYPES, SAMPLE_STATUSES, TASK_STATUSES, WELL_PLATE_CONFIG } from './types'

// ─── Business Option Constants ───
export {
  PROJECT_OPTIONS, SOURCE_OPTIONS, HOSPITAL_OPTIONS, SAMPLE_TYPE_OPTIONS, SIRO_DEVICE_OPTIONS,
  SEQUENCER_MODELS, ISLAND_TYPES, PACKAGE_SUFFIXES,
  STATUS_TO_TIMELINE_LABEL, DICT_CATEGORIES, UNPACK_DATE_FILTERS, UNPACK_AVAILABLE_PRODUCTS, UNPACK_DEFAULT_FORM,
} from '../constants/options'

// ─── Business APIs: samples, tasks, sequencing, anomalies, products, devices, alerts, schedule, sample-prep, reception ───
export { getSampleById, getSampleSpecimens, getSamples, updateSampleStatus, updateSample, getSampleExtraInfo, getSampleTimeline, getAvailableSpecimens, getPoolSamples } from './samples'
export { uploadOCRImage, processOCR, createSample, importSamplesFromExcel, downloadExcelTemplate, exportSamples, advancedFilterSamples, deleteSample, addSampleBatch, queryOmicsSamples, queryOmicsSamplesByCodes } from './samples'
export type { SampleUpdatePayload, GetSamplesParams, AvailableSpecimen, AvailableSpecimensResult, PendingReceptionBatch, PoolSample, OmicsSample, OmicsQueryResponse } from './samples'

export { getTasks, getTaskDetail, startTask, pauseTask, resumeTask, terminateTask, createTask, exportTasks, exportTaskSamples, deliverSequencing, getTaskExperimentData, saveManualExperimentData, importManualExperimentData, downloadManualResultTemplate, completeManualExperiment, MANUAL_RESULT_FIELDS } from './tasks'
export type { TaskDetail, ExperimentStep, QcResult, TaskPlateInfo, ExperimentDetailRow, CreateTaskPayload, CreateTaskResult, GetTasksParams, DeliverSequencingResult, TaskExperimentData, TaskExperimentSpecimen, ManualSaveResult } from './tasks'

export { getSequencingTasks, getSequencingTaskDetail, createSequencingTask, importSequencingTasks, confirmImportSequencingTasks, getSequencingReport, exportSequencingTask, exportSequencingTasks } from './sequencing-tasks'
export type { SequencingTask, SequencingTaskDetail, SequencingLane, LaneSample, CreateSequencingTaskPayload, CreateSequencingTaskResult, ImportSequencingTasksPayload, ImportPreviewRow, ImportSequencingTasksResult, SequencingReport, ExportSequencingTaskResult, GetSequencingTasksParams } from './sequencing-tasks'

export { getAnomalies, getAnomalyById, updateAnomalyStatus, exportAnomalies } from './anomalies'
export type { GetAnomaliesParams } from './anomalies'

export { destroyProduct, updateProduct } from './products'
export { getProducts, getProductById, exportProducts } from './products'
export type { Product, ProductMutationResult, ProductStatus, ProductType, ProductUpdate, GetProductsParams } from './products'

export { getLabDevices } from './devices'
export { getLabDeviceById, updateLabDevice, createLabDevice, scheduleDeviceMaintenance, getDeviceLogs, getSamplePrepDeviceStatus, syncSamplePrepDevice } from './devices'
export type { DeviceUpdatePayload, DeviceCreatePayload, DeviceLogEntry, SamplePrepDevice } from './devices'

export { getAlertsList, acknowledgeAlert, resolveAlert, batchAcknowledgeAlerts, batchResolveAlerts, markAlertRead } from './alerts'
export type { GetAlertsParams } from './alerts'

// Documents（SOP 知识库文档归档，直连 Agent Server /api/kb）
export { getKbDocuments, getKbDocument } from './documents'
export type { KbDocSummary, KbDocDetail } from './documents'

export { getPreOrders, getPreOrderById, updatePreOrder, deletePreOrder, confirmPreOrder, createManualSchedule, exportPreOrders } from './schedule'
export type { PreOrder, ScheduleSpecimen, PreOrderUpdatePayload, CreateSchedulePayload, CreateScheduleResult, GetPreOrdersParams } from './schedule'

export { getSamplePrepRecords, getSamplePrepStats, exportSamplePrepRecords, submitToExperiment, getSchedulableTasks, createPrepTask, autoCreatePrepTask, downloadPrepImportTemplate, getHostReports, applyPrepReport, manualPassPrepSample, checkPrepDuplicates, releasePrepTask, ackPrepReport, type SchedulableTask, type PrepImportedSamplePayload, type HostSeparationReport, type AutoCreatePrepResult } from './sample-prep'

export { getReceptionProjects, getReceptionStats, getReceptionBatches, getReceptionSources, getReceptionHospitals, getReceptionProducts, getReceptionSampleTypes, getReceptionDateFilters, registerSampleReception, scanReceptionBarcode, uploadSampleReceptionVoucher, getUnpackRecords, getBatchSamples, reportReceptionAnomaly, updateBatchSamples, updateBatchMeta, deleteReceptionBatch, hisVerifyReception } from './sample-reception'
export type { GetUnpackRecordsParams } from './sample-reception'
export type { BatchSample } from './sample-reception'
export type { BatchSampleEditPayload, BatchSampleEditResult } from './sample-reception'
export type { HisVerifyResult, HisVerifyResponse } from './types'

// ─── Auth, AI, Agent ───
export { login, logout, changePassword, useAuthApi } from './auth'
export { getConversations, getConversationById, deleteConversation, getAiActions, getAiReads } from './ai'
export { getDemoSeedStatus, seedDemoData, clearDemoData, type DemoSeedStatus } from './ai'
export type { AiActionRow, AiActionListResult, AiReadRow, AiReadListResult } from './ai'
export { submitAnomalyResolution } from './agent'

// ─── Dashboard, System, Strategy, User, SIRO ───
export { getDashboardStats, getSampleDistribution, getReceptionTrend, getTatWarnings, getDashboardActivities, STAT_CARD_CONFIG, DISTRIBUTION_CONFIG, TREND_CONFIG } from './dashboard'
export type { DashboardStatCard, StatCardConfig, DistributionCategoryConfig, TrendSlotConfig, DashboardDateRange } from './dashboard'

export { getPermissionTree, getBackupRecords } from './system'
export { getSystemUsers, createSystemUser, updateSystemUser, toggleSystemUserStatus } from './system'
export { getSystemRoles, getRolePermissions, updateRolePermissions } from './system'
export { getSystemConfig, updateSystemBasicConfig, updateSystemSecurityConfig, getHisConfig, updateHisConfig, getOmicsConfig, updateOmicsConfig, getSequencingConfig, updateSequencingConfig } from './system'
export { createBackup, restoreBackup } from './system'
export { getSystemLogs, exportSystemLogs } from './system'
export { getDictCategories, getDictItems, createDictItem, updateDictItem, deleteDictItem, getDictMeta, createDictCategory, deleteDictCategory } from './system'
export type { SystemBasicConfig, SystemSecurityConfig, SystemHisConfig, OmicsConfig, SequencingConfig, BackupRecord, BackupCreateResult, BackupRestoreResult } from './system'
export { getSolutionProfiles } from './system'
export type { SolutionProfileSummary, SolutionProfilesPayload } from './system'

export { getRulesFiles, getRulesConfig, uploadRuleConfig, getRulesMeta, saveRuleMeta, getWorkflowRules, type RuleFileInfo, type RuleMetaEntry, type StrategyRule, type StrategyRuleCategory } from './strategy'
export { getUserProfile, updateUserProfile } from './user'
export type { UserProfile, UserProfileUpdate } from './user'
export { dispatchTaskToSiro, fetchSiroProcessList, importSiroProcess, getSiroProcessDetail, deleteSiroProcess, fetchSiroDeviceList, updateSiroDevice } from './siro'
export type { SiroDispatchPayload, SiroDevice } from './siro'
