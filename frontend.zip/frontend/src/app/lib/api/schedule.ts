import type { PaginationParams, SIRODeviceType, WellPlateSlot } from './types'
import { apiGet, apiPost, apiPut, apiDelete } from './http'

// ─── Types ──────────────────────────────────────────────────────────────────

/** 预排单中的样本 */
export interface ScheduleSpecimen {
  specimenId: string
  sampleId: string
  sampleNo?: string
  sampleType: string
  productCode: string
  /** 检测项目（rowToPreOrder 从 web.samples.project 富化，2026-08-28 补充） */
  project?: string
  patient: string
  tat: string
  /** 样本来源（本院/外院，rowToPreOrder 从 web.samples.source 富化） */
  source?: string
  controlType?: 'Positive' | 'Negative' | 'Blank'
  /** 每孔 Barcode（1-1000 正整数；随 well_layout 持久化，此处为展示投影，缺失为未设置） */
  barcode?: number
}

/** 预排单（待确认 / 已确认 / 已取消） */
export interface PreOrder {
  id: string
  /** 排单编号，确认或手动创建后由后端分配 */
  orderNo?: string
  project: string
  sampleCount: number
  estHours: number
  tatDue: string
  createdAt: string
  specimens: ScheduleSpecimen[]
  status: 'pending' | 'confirmed' | 'cancelled'
  tags?: string[]
  siroDevice?: SIRODeviceType
  /** @deprecated 已替换为 processNo */
  flowRange?: string
  /** SIRO 流程编号 */
  processNo?: string
  /** 关联实验任务的实时状态（排单确认后生成） */
  experimentStatus?: string
  experimentId?: string
  /** 孔板布局真相源（row/col 及每孔 barcode），审核/编辑弹窗按它还原孔位；老排单可能为空数组 */
  wellLayout?: WellPlateSlot[]
}

/** 更新预排单 payload */
export interface PreOrderUpdatePayload {
  specimens?: Array<{ specimenId: string }>
  wellLayout?: unknown
  siroDevice?: SIRODeviceType
  processNo?: string
  project?: string
}

/** 手动创建排单 payload */
export interface CreateSchedulePayload {
  project: string
  processNo: string
  deviceType: SIRODeviceType
  specimens: Array<{ specimenId: string }>
  totalWells?: number
  wellLayout?: unknown
}

/** 手动创建排单响应 */
export interface CreateScheduleResult {
  success: boolean
  orderId: string
  orderNo: string
  message: string
}

// ─── API Functions ────────────────────────────────────────────────────────────

export interface GetPreOrdersParams extends PaginationParams {
  tabStatus?: string
}

/**
 * 获取预排单列表
 * @param status - 可选筛选：'pending'（待确认）| 'confirmed'（已确认）
 */
export async function getPreOrders(
  status?: 'pending' | 'confirmed',
  params: GetPreOrdersParams = {},
): Promise<PreOrder[]> {
  return apiGet<PreOrder[]>('/schedule/pre-orders', { status, ...params } as Record<string, string | number | boolean | undefined>)
}

/** 获取预排单详情 */
export async function getPreOrderById(id: string): Promise<PreOrder | null> {
  return apiGet<PreOrder>(`/schedule/pre-orders/${id}`)
}

/** 修改预排单 */
export async function updatePreOrder(id: string, payload: PreOrderUpdatePayload): Promise<{ success: boolean; orderId: string }> {
  return apiPut(`/schedule/pre-orders/${id}`, payload)
}

/** 删除预排单 */
export async function deletePreOrder(id: string): Promise<{ success: boolean }> {
  return apiDelete(`/schedule/pre-orders/${id}`)
}

/** 确认预排单（审核通过，自动投递任务到 SIRO 中台） */
export interface ConfirmPreOrderResult {
  success: boolean
  orderId: string
  orderNo: string
  message: string
  /** 投递到 SIRO 中台的结果（审核通过时自动触发） */
  dispatch?: { ok: boolean; status: number | null; error: string | null }
}
export async function confirmPreOrder(id: string): Promise<ConfirmPreOrderResult> {
  return apiPost(`/schedule/pre-orders/${id}/confirm`)
}

/** 手动创建排单 */
export async function createManualSchedule(payload: CreateSchedulePayload): Promise<CreateScheduleResult> {
  return apiPost('/schedule/pre-orders', payload)
}

/** 导出排单列表（按当前筛选条件导出全量） */
export async function exportPreOrders(tabStatus?: string): Promise<{ success: boolean; downloadUrl: string; filename: string }> {
  return apiGet('/schedule/pre-orders/export', tabStatus && tabStatus !== '全部' ? { tabStatus } : undefined)
}

/** SIRO 流程行（GET /schedule/siro-processes 返回；2026-09-11 参数表单动态选项） */
export interface SiroProcessRow {
  process_no: string
  process_name?: string
  product_line_code?: string
  product_line_name?: string
  process_type?: string
  device_type?: string
  current_version?: string
  estimated_duration_minutes?: number
}

/** 按设备查询 SIRO 合法流程（表单中 deviceType → processNo 动态选项）。SIRO 故障（code -1）时抛错由调用方显示"加载失败可重试" */
export async function getSiroProcesses(deviceType?: string): Promise<SiroProcessRow[]> {
  return apiGet<SiroProcessRow[]>('/schedule/siro-processes', deviceType ? { deviceType } : undefined)
}

// ─── 排单表单可用性组合接口（2026-09-12 GET /schedule/form-options）───────────
// 表单打开一次拉全：设备型号目录 × 各型号中台流程（有流程才可排）；SIRO 中台不可达时
// 携带 siroError（不整体失败），前端灰显全部设备并允许重试。

/** 某型号的可用流程（表单中 deviceType → processNo 本地联动） */
export interface PreOrderFormDevice {
  deviceType: string
  flowCount: number
  processes: Array<Pick<SiroProcessRow,
    'process_no' | 'process_name' | 'product_line_code' | 'product_line_name' | 'estimated_duration_minutes' | 'current_version'
  >>
}

export interface PreOrderFormOptions {
  devices: PreOrderFormDevice[]
  projects: string[]
  /** SIRO 中台不可达时存在（flowCount 全 0 不代表"没流程"） */
  siroError?: string
}

export async function getPreOrderFormOptions(): Promise<PreOrderFormOptions> {
  return apiGet<PreOrderFormOptions>('/schedule/form-options')
}

// ─── 质控品插入参考计划（control-rules） ────────────────────────────────────

/** 质控品插入计划项 */
export interface ControlPlanItem {
  control: string
  position: string
  count: number
  note: string
}

/** 获取质控品插入参考计划（后端读 control-rules，按 totalWells/sampleCount 计算） */
export async function getControlPlan(totalWells: number, sampleCount: number): Promise<{ totalWells: number; sampleCount: number; plan: ControlPlanItem[] }> {
  return apiGet('/schedule/control-plan', { totalWells, sampleCount })
}
