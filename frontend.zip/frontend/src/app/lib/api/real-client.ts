/**
 * RealApiClient — fetch-based HTTP client.
 *
 * Implements ApiClient, targets the real backend.
 * Uses the token management and fetch logic from http.ts internally.
 */
import { apiFailure, apiSuccess, type ApiClient, type ApiResult, type RequestOptions } from './client'
import { getAuthToken } from './http'
import { getApiConfig } from './config'

export class RealApiClient implements ApiClient {
  private get baseUrl(): string {
    return getApiConfig().baseUrl
  }

  async get<T>(path: string, options?: RequestOptions): Promise<ApiResult<T>> {
    return this.request<T>('GET', path, undefined, options)
  }

  async post<T>(path: string, body?: unknown, options?: RequestOptions): Promise<ApiResult<T>> {
    return this.request<T>('POST', path, body, options)
  }

  async put<T>(path: string, body?: unknown, options?: RequestOptions): Promise<ApiResult<T>> {
    return this.request<T>('PUT', path, body, options)
  }

  async delete<T>(path: string, options?: RequestOptions): Promise<ApiResult<T>> {
    return this.request<T>('DELETE', path, undefined, options)
  }

  private async request<T>(
    method: string,
    path: string,
    body?: unknown,
    options?: RequestOptions,
  ): Promise<ApiResult<T>> {
    const { apiKey, timeout } = getApiConfig()
    const url = new URL(path, this.baseUrl)

    if (options?.params) {
      for (const [k, v] of Object.entries(options.params)) {
        if (v === undefined || v === null || v === '') continue
        url.searchParams.set(k, String(v))
      }
    }

    const headers: Record<string, string> = { ...options?.headers }
    if (body !== undefined) headers['Content-Type'] = 'application/json'
    const token = getAuthToken()
    if (token) headers['Authorization'] = `Bearer ${token}`
    if (apiKey) headers['X-API-Key'] = apiKey

    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), timeout)

    try {
      const res = await fetch(url.toString(), {
        method,
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined,
        signal: controller.signal,
      })

      if (!res.ok) {
        let message = res.statusText
        try {
          const errBody = await res.json()
          message = errBody.message ?? errBody.error ?? message
        } catch { /* not JSON */ }
        return apiFailure({ status: res.status, code: 'HTTP_ERROR', message })
      }

      if (res.status === 204) return apiSuccess(undefined as unknown as T)
      const json = await res.json()

      // All backend responses MUST follow { code, message, data } format
      if (!json || typeof json !== 'object' || !('code' in json)) {
        return apiFailure({
          status: res.status,
          code: 'FORMAT_ERROR',
          message: `后端响应格式异常，缺少 code 字段。URL: ${method} ${path}，收到: ${JSON.stringify(json).substring(0, 200)}`,
        })
      }
      if (json.code === '0' || json.code === 0) {
        return apiSuccess<T>(json.data as T)
      }
      return apiFailure({
        status: res.status,
        code: String(json.code),
        message: (json as any).message || 'Backend error'
      })
    } catch (err: unknown) {
      if (err instanceof Error && err.name === 'AbortError') {
        return apiFailure({ status: 0, code: 'TIMEOUT', message: '请求超时' })
      }
      return apiFailure({ status: 0, code: 'NETWORK_ERROR', message: String(err) })
    } finally {
      clearTimeout(timer)
    }
  }
}
