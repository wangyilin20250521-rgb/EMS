import type { ChipStatus, LaneStatus, PaginationParams } from './types'
import { apiGet, apiPost } from './http'

// ─── Types ──────────────────────────────────────────────────────────────────

/** 芯片 Lane 信息 */
export interface SequencingLane {
  lane: string
  status: LaneStatus
  sampleCount: number
}

/** 测序任务（列表项） */
export interface SequencingTask {
  id: string
  taskNo: string
  chipNo: string
  status: ChipStatus
  sampleCount: number
  sequenceStartTime?: string
  sequenceEndTime?: string
  lanes: SequencingLane[]
  createdAt: string
  createdBy: string
  sequencedAt?: string
}

/** Lane 样本明细 */
export interface LaneSample {
  sampleNo: string
  patientName: string
  concentration: number
  volume: number
}

/** 测序任务详情 */
export interface SequencingTaskDetail extends SequencingTask {
  /** 关联设备 */
  device: string
  /** 进度百分比 */
  progress: number
  /** 各 lane 样本明细 */
  laneSamples: Record<string, LaneSample[]>
  /** 芯片 Lane 分布（芯片名 → lanes） */
  chipLanes?: Array<{ name: string; lanes: Array<{ sampleIds: string[] }> }>
}

/** 手动创建测序任务 payload */
export interface CreateSequencingTaskPayload {
  sequencerId: string
  chips: Array<{
    name: string
    lanes: Array<{ sampleIds: string[] }>
  }>
}

/** 创建测序任务响应 */
export interface CreateSequencingTaskResult {
  success: boolean
  taskIds: string[]
  message: string
}

/** 导入测序任务 payload */
export interface ImportSequencingTasksPayload {
  mode: 'file' | 'paste'
  /** 文件上传时为 base64，粘贴时为原始文本 */
  data: string
  filename?: string
}

/** 导入预览行 */
export interface ImportPreviewRow {
  taskNo: string
  chipNo: string
  sampleCount: number
  status: string
}

/** 导入测序任务响应 */
export interface ImportSequencingTasksResult {
  success: boolean
  importedCount: number
  message: string
}

/** 测序报告 */
export interface SequencingReport {
  taskNo: string
  chipNo: string
  device: string
  status: ChipStatus
  startTime?: string
  endTime?: string
  totalSamples: number
  passRate: string
  laneResults: Array<{
    lane: string
    status: LaneStatus
    sampleCount: number
    yield: string
    q30: string
  }>
}

/** 导出响应 */
export interface ExportSequencingTaskResult {
  success: boolean
  downloadUrl: string
  filename: string
}

// ─── Type Re-exports ──────────────────────────────────────────────────────────

export type { ChipStatus, LaneStatus } from './types'

// ─── API Functions ────────────────────────────────────────────────────────────

export interface GetSequencingTasksParams extends PaginationParams {
  status?: string
}

/** 获取测序任务列表 */
export async function getSequencingTasks(params: GetSequencingTasksParams = {}): Promise<SequencingTask[]> {
  return apiGet<SequencingTask[]>('/sequencing-tasks', params as Record<string, string | number | boolean | undefined>)
}

/** 获取测序任务详情（含芯片 lane 分布 + 样本明细） */
export async function getSequencingTaskDetail(id: string): Promise<SequencingTaskDetail | null> {
  return apiGet<SequencingTaskDetail>(`/sequencing-tasks/${id}`)
}

/** 手动创建测序任务 */
export async function createSequencingTask(payload: CreateSequencingTaskPayload): Promise<CreateSequencingTaskResult> {
  return apiPost('/sequencing-tasks/create', payload)
}

/** 导入测序任务单（文件上传 / 粘贴数据） */
export async function importSequencingTasks(payload: ImportSequencingTasksPayload): Promise<{ preview: ImportPreviewRow[] }> {
  return apiPost('/sequencing-tasks/import', payload)
}

/** 确认导入测序任务 */
export async function confirmImportSequencingTasks(rows: ImportPreviewRow[]): Promise<ImportSequencingTasksResult> {
  return apiPost('/sequencing-tasks/import/confirm', { rows })
}

/** 查看测序报告 */
export async function getSequencingReport(id: string): Promise<SequencingReport | null> {
  return apiGet<SequencingReport>(`/sequencing-tasks/${id}/report`)
}

/** 导出测序任务信息 */
export async function exportSequencingTask(id: string): Promise<ExportSequencingTaskResult> {
  return apiPost(`/sequencing-tasks/${id}/export`)
}

/** 导出测序任务列表（按当前筛选条件导出全量） */
export async function exportSequencingTasks(status?: string): Promise<{ success: boolean; downloadUrl: string; filename: string }> {
  return apiGet('/sequencing-tasks/export', status && status !== '全部' ? { status } : undefined)
}

