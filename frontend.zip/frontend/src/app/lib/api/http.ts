/**
 * HTTP transport layer — unified fetch wrapper, always targets real backend.
 */
import { toast } from 'sonner'
import { getApiConfig } from './config'
import { RealApiClient } from './real-client'
import type { ApiClient } from './client'

// ─── Auth Token ─────────────────────────────────────────────────────────────

const TOKEN_KEY = 'mlims_auth_token'

interface TokenStorage {
  get(key: string): string | null
  set(key: string, value: string): void
  remove(key: string): void
}

let _tokenStorage: TokenStorage = {
  get: (k) => { try { return localStorage.getItem(k) } catch { return null } },
  set: (k, v) => { try { localStorage.setItem(k, v) } catch { /* noop */ } },
  remove: (k) => { try { localStorage.removeItem(k) } catch { /* noop */ } },
}

/** Inject a custom token storage implementation (e.g. PlatformAdapter). */
export function setTokenStorage(s: TokenStorage) { _tokenStorage = s }

let _onUnauthorized: (() => void) | null = null

/** Inject callback for 401 responses (e.g. redirect to login). */
export function setOnUnauthorized(fn: () => void) { _onUnauthorized = fn }

function loadToken(): string | null {
  return _tokenStorage.get(TOKEN_KEY)
}

function saveToken(token: string | null) {
  if (token) _tokenStorage.set(TOKEN_KEY, token)
  else _tokenStorage.remove(TOKEN_KEY)
}

let _token: string | null = loadToken()

/** Set Bearer token (called after successful login). */
export function setAuthToken(token: string | null) {
  _token = token
  saveToken(token)
}

export function getAuthToken(): string | null {
  return _token
}

// ─── Internal Fetch ──────────────────────────────────────────────────────────

async function request<T>(
  method: string,
  path: string,
  body?: unknown,
  params?: Record<string, string | number | boolean | undefined>,
): Promise<T> {
  const { baseUrl, apiKey, timeout } = getApiConfig()
  const url = new URL(path, baseUrl)

  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== '') url.searchParams.set(k, String(v))
    }
  }

  const headers: Record<string, string> = {}
  if (body !== undefined && !(body instanceof FormData)) {
    headers['Content-Type'] = 'application/json'
  }
  if (_token) headers['Authorization'] = `Bearer ${_token}`
  if (apiKey) headers['X-API-Key'] = apiKey

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeout)

  try {
    const res = await fetch(url.toString(), {
      method,
      headers,
      body: body instanceof FormData ? body : body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    })

    if (!res.ok) {
      const text = await res.text().catch(() => '')
      let errorData: any
      try { errorData = JSON.parse(text) } catch { /* not JSON */ }
      if (res.status === 401 && !path.startsWith('/auth/login')) {
        setAuthToken(null)
        _onUnauthorized?.()
        // 广播 auth:unauthorized（useAuth 监听：提示"登录已过期"并跳登录页）。
        // 2026-09-17 修复：此前该事件从未被派发，useAuth 的监听实际收不到，401 后不跳转
        window.dispatchEvent(new Event('auth:unauthorized'))
        // 单账号单会话：被顶掉时明确提示（区别于普通登录过期）
        if (errorData?.message?.includes('其他设备')) {
          toast.error('账号已在其他设备登录，你已被顶下线')
        }
      }
      const backendMsg = errorData?.message || errorData?.error
      throw {
        status: res.status,
        code: errorData?.code || 'HTTP_ERROR',
        message: backendMsg || res.statusText || `HTTP ${res.status}`,
        details: errorData,
      }
    }

    if (res.status === 204) return undefined as unknown as T

    const json = await res.json()
    if (!json || typeof json !== 'object' || !('code' in json)) {
      throw {
        status: res.status,
        code: 'FORMAT_ERROR',
        message: `后端响应格式异常，缺少 code 字段。URL: ${method} ${path}，收到: ${JSON.stringify(json).substring(0, 200)}`,
      }
    }
    if (json.code !== '0' && json.code !== 0) {
      throw { status: res.status, code: String(json.code), message: (json as any).message || 'Backend error' }
    }
    return (json as any).data as T
  } finally {
    clearTimeout(timer)
  }
}

// ─── Public HTTP Methods ──────────────────────────────────────────────────────

export function apiGet<T>(path: string, params?: Record<string, string | number | boolean | undefined>): Promise<T> {
  return request<T>('GET', path, undefined, params)
}

export function apiPost<T>(path: string, body?: unknown): Promise<T> {
  return request<T>('POST', path, body)
}

export function apiPut<T>(path: string, body?: unknown): Promise<T> {
  return request<T>('PUT', path, body)
}

export function apiDelete<T>(path: string): Promise<T> {
  return request<T>('DELETE', path)
}

/** multipart/form-data 文件上传 */
export async function apiUpload<T>(
  path: string,
  file: File,
  extraFields?: Record<string, string>,
): Promise<T> {
  const { baseUrl, apiKey } = getApiConfig()
  const formData = new FormData()
  formData.append('file', file)
  if (extraFields) {
    for (const [k, v] of Object.entries(extraFields)) formData.append(k, v)
  }

  const headers: Record<string, string> = {}
  if (_token) headers['Authorization'] = `Bearer ${_token}`
  if (apiKey) headers['X-API-Key'] = apiKey

  const res = await fetch(new URL(path, baseUrl).toString(), {
    method: 'POST',
    headers,
    body: formData,
  })

  if (!res.ok) {
    // 后端校验失败（如 Excel 模板校验 400）带 JSON 错误体：优先展示其 message/details
    // （历史回归：直接抛 statusText 导致用户只见 "Bad Request"、逐行错误无处展示）
    let message: string = res.statusText
    let details: unknown
    try {
      const errJson = await res.json() as { message?: string; data?: unknown }
      if (errJson?.message) message = errJson.message
      if (errJson?.data !== undefined) details = { data: errJson.data }
    } catch { /* 非 JSON 错误体保持 statusText */ }
    throw { status: res.status, code: 'UPLOAD_ERROR', message, ...(details ? { details } : {}) }
  }
  const json = await res.json() as { code?: string | number; message?: string; data?: unknown }
  if (json && json.code !== undefined && json.code !== '0' && json.code !== 0) {
    throw { status: res.status, code: String(json.code), message: json.message || 'Upload error' }
  }
  return (json as any)?.data as T
}

// ─── Unified API Client ──────────────────────────────────────────────────────

/** Get the current ApiClient */
export function getApiClient(): ApiClient {
  return new RealApiClient()
}
