import type {
  PaginationParams,
  UnpackRecord,
  UnpackStatValue,
  ReceptionProject,
  SampleReceptionPayload,
  SampleReceptionResult,
  HisVerifyResponse,
} from './types'
import { apiGet, apiPost, apiPut, apiDelete, apiUpload } from './http'

// ─── Sample Reception API ──────────────────────────────────────────────────────
// 合并 reception + unpack 为统一接口，路径前缀 /sample-reception/*

/** 获取收样项目摘要（按项目维度的声明/实收对比） */
export async function getReceptionProjects(): Promise<ReceptionProject[]> {
  return apiGet<ReceptionProject[]>('/sample-reception/projects')
}

/** 获取收样登记页统计卡片纯数值 */
export async function getReceptionStats(dateFilter?: string): Promise<UnpackStatValue[]> {
  return apiGet<UnpackStatValue[]>('/sample-reception/stats', dateFilter ? { dateFilter } : undefined)
}

/** 批次样本明细（扩展卡片）：样本编号 + 入库/收样登记全字段 */
export interface BatchSample {
  sampleNo: string
  realSampleNo?: string
  patient: string
  gender: string
  age: number
  type: string
  project: string
  status: string
  receivedAt: string
  source: string
  hospital: string
  /** 已入库 = 样本中心已录入患者信息并确认入库（patient 非空） */
  registered: boolean
}

/** 获取某批次的样本编号明细（已入库/未入库） */
export async function getBatchSamples(batchId: string): Promise<BatchSample[]> {
  return apiGet(`/sample-reception/batches/${batchId}/samples`)
}

// ─── Batch Edit（补录/删除/改项目，详情抽屉编辑态一次性提交） ───────────────

export interface BatchSampleEditPayload {
  /** 修改已有样本（project/type 空值不更新；sampleNo 为条码，可显式清空） */
  updates?: Array<{ id: string; project?: string | null; type?: string | null; sampleNo?: string | null }>
  /** 补录新样本行（缺省值取批次众数） */
  additions?: Array<{ project?: string; type?: string; sampleNo?: string }>
  /** 删除错录样本行 */
  deletions?: string[]
}

export interface BatchSampleEditResult {
  addedIds: string[]
  updatedCount: number
  deletedCount: number
}

/** 修改批次登记概要（实收管数/单据数，样本录入数与实收数不一致时人工复核调整） */
export async function updateBatchMeta(
  batchId: string,
  payload: {
    actualTubes?: number;
    actualPapers?: number;
    anomalyCount?: number;
    /** 编辑弹窗扩展字段（2026-08-24）：来源/医院/收样人/备注/收样时间 */
    source?: string;
    hospital?: string;
    receiver?: string;
    notes?: string;
    receivedAt?: string;
  },
): Promise<{ batchId: string }> {
  return apiPut<{ batchId: string }>(`/sample-reception/batches/${batchId}/meta`, payload)
}

/** 删除批次（仅无关联的干净批次可删，后端引用检查兜底） */
export async function deleteReceptionBatch(batchId: string): Promise<{ success: boolean }> {
  return apiDelete(`/sample-reception/batches/${encodeURIComponent(batchId)}`)
}

/** 批次详情编辑态一次性提交：补录(加管)/删除(减管)/修改项目与类型 */
export async function updateBatchSamples(
  batchId: string,
  payload: BatchSampleEditPayload,
): Promise<BatchSampleEditResult> {
  return apiPut<BatchSampleEditResult>(`/sample-reception/batches/${batchId}/samples`, payload)
}

/** 获取收样批次列表 */
export async function getReceptionBatches(dateFilter?: string, opts?: { registeredOnly?: boolean; excludePrep?: boolean }): Promise<UnpackRecord[]> {
  const params: Record<string, string | number | boolean> = { page: 1, pageSize: 999 }
  if (dateFilter) params.dateFilter = dateFilter
  if (opts?.registeredOnly) params.registered = 'true'
  if (opts?.excludePrep) params.exclude_prep = 'true'
  const res = await apiGet<{ items: UnpackRecord[] }>('/sample-reception/batches', params)
  return res.items
}

export interface GetUnpackRecordsParams extends PaginationParams {
  dateFilter?: string
  search?: string
  /** 列头排序（收样登记）：receivedAt | updatedAt */
  sortBy?: string
  sortOrder?: "asc" | "desc"
}

/** 获取开包登记记录 */
export async function getUnpackRecords(params: GetUnpackRecordsParams = {}): Promise<{ items: UnpackRecord[]; total: number }> {
  return apiGet<{ items: UnpackRecord[]; total: number }>('/sample-reception/batches', params as Record<string, string | number | boolean | undefined>)
}

/** 获取样本来源选项 */
export async function getReceptionSources(): Promise<string[]> {
  return apiGet<string[]>('/sample-reception/sources')
}

/** 获取来源医院列表 */
export async function getReceptionHospitals(): Promise<string[]> {
  return apiGet<string[]>('/sample-reception/hospitals')
}

/** 获取可选产品列表 */
export async function getReceptionProducts(): Promise<string[]> {
  return apiGet<string[]>('/sample-reception/available-products')
}

/** 获取样本类型历史值（预设 + 历史自定义值动态累积） */
export async function getReceptionSampleTypes(): Promise<string[]> {
  return apiGet<string[]>('/sample-reception/sample-types')
}

/** 获取日期筛选选项 */
export async function getReceptionDateFilters(): Promise<string[]> {
  return apiGet<string[]>('/sample-reception/date-filters')
}

/**
 * 新建收样登记
 * 后端核对数量后：
 *   - 成功：返回 { success: true, batchNo, message }
 *   - 失败：返回 { success: false, errors: [{ field, message }] }
 */
export async function registerSampleReception(
  payload: SampleReceptionPayload,
): Promise<SampleReceptionResult> {
  return apiPost<SampleReceptionResult>('/sample-reception/register', payload)
}

/** 扫码枪录入 */
export async function scanReceptionBarcode(
  barcode: string,
): Promise<{ success: boolean; sampleId: string; patient: string; project: string }> {
  return apiPost('/sample-reception/scan-barcode', { barcode })
}

/** HIS 复核（后端读字典配置并调用医院 HIS；未开启时后端直接返回全部通过） */
export async function hisVerifyReception(barcodes: string[]): Promise<HisVerifyResponse> {
  return apiPost<HisVerifyResponse>('/sample-reception/his-verify', { barcodes })
}

/** 上报收样异常 */
export interface ReceptionAnomalyReportPayload {
  /** 样本 ID（收样登记解耦后可能没有，交给 batchId 兜底） */
  sampleId?: string
  /** 批次号：样本未录入时异常挂批次级 */
  batchId?: string
  /** 条码：可匹配已录入样本的 sample_no 精确绑定 */
  barcode?: string
  reason: string
  description?: string
  /** 关联检测产品（异常样本所属产品，便于后续追溯） */
  product?: string
}

export interface ReceptionAnomalyReportResult {
  anomalyId: string
  /** 实际绑定对象（样本 ID 或批次号） */
  related?: string
  /** 是否批次级异常 */
  batchLevel?: boolean
}

export async function reportReceptionAnomaly(
  payload: ReceptionAnomalyReportPayload,
): Promise<ReceptionAnomalyReportResult> {
  return apiPost('/sample-reception/anomaly-report', payload)
}

/** 凭证文件上传 */
export async function uploadSampleReceptionVoucher(
  file: File,
): Promise<{ success: boolean; fileUrl: string }> {
  return apiUpload('/sample-reception/voucher-upload', file)
}
