import { getApiConfig } from './config'
import { getAuthToken } from './http'

/** 文档归档（SOP 知识库）API — 数据在 Agent Server（KB 所有者），直连 3456。
 * 契约：详情不返回章节原文（正文经 document 模式 AI 检索问答），只给元数据 + 章节名 + 核心介绍。 */

export interface KbDocSummary {
  docId: string
  title: string
  product: string
  platform: string
  docType: string
  sourceFile: string
  conclusion: string
  sectionCount: number
  intro: string
}

export interface KbDocDetail extends KbDocSummary {
  equipment: string
  script: string
  authors: string[]
  reviewers: string[]
  approvers: string[]
  /**章节名列表（不含原文） */
  sections: string[]
}

const agentBase = () => getApiConfig().agentUrl

const agentHeaders = (): Record<string, string> => {
  const token = getAuthToken()
  return token ? { Authorization: `Bearer ${token}` } : {}
}

/** GET /api/kb/documents (Agent Server) — 文档卡片列表 */
export async function getKbDocuments(): Promise<KbDocSummary[]> {
  const res = await fetch(`${agentBase()}/api/kb/documents`, { headers: agentHeaders() })
  if (!res.ok) throw new Error(`Agent error: ${res.status}`)
  const json = await res.json()
  return (json.code === "0" || json.code === 0) && Array.isArray(json.data) ? json.data : []
}

/** GET /api/kb/documents/:docId (Agent Server) — 单文档详情（章节仅名称） */
export async function getKbDocument(docId: string): Promise<KbDocDetail | null> {
  const res = await fetch(`${agentBase()}/api/kb/documents/${encodeURIComponent(docId)}`, { headers: agentHeaders() })
  if (!res.ok) return null
  const json = await res.json()
  return (json.code === "0" || json.code === 0) ? json.data : null
}
