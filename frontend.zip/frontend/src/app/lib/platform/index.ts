import { createContext, createElement, useContext, type PropsWithChildren } from 'react'
import { browserPlatform } from './browser-adapter'
import type { PlatformProvider as PlatformProviderValue } from './interfaces'

export type { ClipboardAdapter, NotificationAdapter, PlatformProvider as PlatformProviderValue, StorageAdapter } from './interfaces'
export { browserPlatform }

const PlatformContext = createContext<PlatformProviderValue>(browserPlatform)

export function PlatformProvider({ value = browserPlatform, children }: PropsWithChildren<{ value?: PlatformProviderValue }>) {
  return createElement(PlatformContext.Provider, { value }, children)
}

export function usePlatform(): PlatformProviderValue {
  return useContext(PlatformContext)
}
