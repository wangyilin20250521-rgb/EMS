export interface StorageAdapter {
  get(key: string): string | null
  set(key: string, value: string): void
  remove(key: string): void
  clear(): void
}

export interface NotificationOptions {
  body?: string
  icon?: string
  tag?: string
}

export interface NotificationAdapter {
  show(title: string, options?: NotificationOptions): void
  requestPermission(): Promise<'granted' | 'denied' | 'default'>
}

export interface ClipboardAdapter {
  writeText(text: string): Promise<void>
  readText(): Promise<string>
}

export interface PlatformProvider {
  storage: StorageAdapter
  notification: NotificationAdapter
  clipboard: ClipboardAdapter
}
