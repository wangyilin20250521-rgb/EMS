import type { ClipboardAdapter, NotificationAdapter, PlatformProvider, StorageAdapter } from './interfaces'

class BrowserStorageAdapter implements StorageAdapter {
  get(key: string): string | null {
    return globalThis.localStorage?.getItem(key) ?? null
  }

  set(key: string, value: string): void {
    globalThis.localStorage?.setItem(key, value)
  }

  remove(key: string): void {
    globalThis.localStorage?.removeItem(key)
  }

  clear(): void {
    globalThis.localStorage?.clear()
  }
}

class BrowserNotificationAdapter implements NotificationAdapter {
  show(title: string, options?: NotificationOptions): void {
    if ('Notification' in globalThis && globalThis.Notification.permission === 'granted') {
      new globalThis.Notification(title, options)
    }
  }

  async requestPermission(): Promise<'granted' | 'denied' | 'default'> {
    if (!('Notification' in globalThis)) {
      return 'denied'
    }

    return globalThis.Notification.requestPermission()
  }
}

class BrowserClipboardAdapter implements ClipboardAdapter {
  async writeText(text: string): Promise<void> {
    await globalThis.navigator?.clipboard?.writeText(text)
  }

  async readText(): Promise<string> {
    return globalThis.navigator?.clipboard?.readText() ?? ''
  }
}

export const browserPlatform: PlatformProvider = {
  storage: new BrowserStorageAdapter(),
  notification: new BrowserNotificationAdapter(),
  clipboard: new BrowserClipboardAdapter(),
}
