import { defineConfig, type Plugin } from 'vite'
import path from 'path'
import { readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { gzipSync } from 'node:zlib'
import { join } from 'node:path'
import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'

// 构建后 gzip 预压缩 dist/assets（配合 nginx gzip_static 直接发送 .gz，传输量降 ~70%）
function gzipAssets(): Plugin {
  return {
    name: 'gzip-assets',
    apply: 'build',
    closeBundle() {
      const dir = join(__dirname, 'dist', 'assets')
      let total = 0, saved = 0, count = 0

      for (const f of readdirSync(dir)) {
        if (!/\.(js|css|svg|html)$/.test(f) || f.endsWith(".gz")) continue;
        const p = join(dir, f);
        const buf = readFileSync(p);
        const gz = gzipSync(buf, { level: 9 });
        writeFileSync(p + ".gz", gz);
        total += buf.length;
        saved += buf.length - gz.length;
        count++;
        console.log(`  ${f}  ${(buf.length / 1024).toFixed(0)}KB → ${(gz.length / 1024).toFixed(0)}KB`);
      }

      console.log(`gzip 完成：${count} 个文件，节省 ${(saved / 1024 / 1024).toFixed(2)} MB（-${total > 0 ? Math.round((saved / total) * 100) : 0}%）`);
    },
  }
}

export default defineConfig({
  base: './',
  plugins: [
    // The React and Tailwind plugins are both required for Make, even if
    // Tailwind is not being actively used – do not remove them
    react(),
    tailwindcss(),
    gzipAssets(),
  ],
  resolve: {
    alias: {
      // Alias @ to the src directory
      '@': path.resolve(__dirname, './src'),
    },
  },

  // File types to support raw imports. Never add .css, .tsx, or .ts files to this.
  assetsInclude: ['**/*.svg', '**/*.csv'],

  // 2026-08-31 首屏优化：vendor/charts 独立 chunk，浏览器并行下载 + 长期缓存复用
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom', 'react-router', 'zustand', 'sonner'],
          charts: ['recharts'],
        },
      },
    },
  },
})
